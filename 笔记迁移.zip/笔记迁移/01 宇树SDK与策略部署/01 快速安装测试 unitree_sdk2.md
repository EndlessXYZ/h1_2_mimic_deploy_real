
> **主要参考官方文档**：[H1 开发快速开始](https://support.unitree.com/home/zh/H1_developer/start)

**在部署系列中的全局定位**：整条 H1-2 开发学习路径的起点。完成 unitree_sdk2 的安装并验证 CycloneDDS 通信链路，为后续所有依赖 DDS 通信的实验（状态监测、底层控制、高层控制、RL 部署）奠定通信基础。

本文介绍如何安装 `unitree_sdk2` 并运行 HelloWorld 例程来验证 CycloneDDS 通信。

## 1. 系统依赖
- **推荐系统**：Ubuntu 20.04 + ROS2 开发环境。

## 2. 安装与编译 unitree_sdk2
假设当前的工作路径为 `~/Documents/unitree_h1/`。在此路径下执行以下步骤完成 SDK 的编译和安装：

```bash
# === 隔离安装（推荐，安装到 local_deps/usr，无需 sudo）===
cd ~/Documents/unitree_h1/
git clone https://github.com/unitreerobotics/unitree_sdk2.git
cd ~/Documents/unitree_h1/unitree_sdk2/
mkdir -p build && cd build
cmake -DCMAKE_INSTALL_PREFIX=~/Documents/unitree_h1/local_deps/usr -DBUILD_EXAMPLES=ON ..
make -j4
make install  # SDK 库与示例均安装到 local_deps/usr

# === 系统级安装（备用，会污染 /usr/local）===
# cd ~/Documents/unitree_h1/unitree_sdk2/
# mkdir -p build && cd build
# cmake ..
# sudo make install
# make  # 编译测试例程
```

## 3. 运行 HelloWorld 测试
在正式测试前，请根据官方的 [《快速开始》指南](https://support.unitree.com/home/zh/H1_developer/quick_start) 确保机器人已成功进入调试模式。接着，通过配置 `CYCLONEDDS_URI` 环境变量来强行绑定指定的网卡（如回环网卡 `lo`），从而开始测试 DDS 实时通信功能。具体操作步骤如下：

1. **配置网卡绑定环境变量**：
   在终端中执行以下命令，将 DDS 绑定到 `lo` 网卡：
   ```bash
   export CYCLONEDDS_URI='<CycloneDDS><Domain><General><Interfaces><NetworkInterface name="lo" priority="default" multicast="default" /></Interfaces></General></Domain></CycloneDDS>'
   ```
2. **启动数据发布端**（终端 A）：
   打开一个新终端，进入编译产物目录，然后运行测试发布端。
   ```bash
   cd ~/Documents/unitree_h1/unitree_sdk2/build/bin
   # 注意：必须在当前终端中设置上述 CYCLONEDDS_URI 环境变量
   # 提示：由于最新官方代码（截至26.06.12）与文档不一致，此处的 test_publisher 无法通过命令行传递参数，请直接运行
   ./test_publisher
   ```
3. **启动数据接收端**（终端 B）：
   打开另一个新终端，同样配置好 `CYCLONEDDS_URI` 环境变量，然后运行接收端监听相同的话题：
   ```bash
   cd ~/Documents/unitree_h1/unitree_sdk2/build/bin
   # 注意：同样必须在当前终端中设置上述 CYCLONEDDS_URI 环境变量
   ./test_subscriber
   ```

### 预期效果
- **发布端**：在后台以 1Hz 的频率（每秒一次）发送包含当前毫秒时间戳的测试消息。
- **接收端**：实时捕获发布端投递的数据并打印消息内容。由于 `test_subscriber` 源码中默认包含了周期性关闭与重连通道的逻辑，因此控制台在正常打印接收数据的同时，会交替周期性输出 `reseted. sleep 3`：
  ```text
  userID:1781256468996, message:HelloWorld.
  userID:1781256469996, message:HelloWorld.
  userID:1781256470996, message:HelloWorld.
  reseted. sleep 3
  userID:1781256474997, message:HelloWorld.
  userID:1781256475997, message:HelloWorld.
  ```

若收发数据一切正常，则说明 CycloneDDS 的物理通信通道已成功打通，网络多播及网卡绑定配置正确，这为后续的实机控制实验奠定了基础。

