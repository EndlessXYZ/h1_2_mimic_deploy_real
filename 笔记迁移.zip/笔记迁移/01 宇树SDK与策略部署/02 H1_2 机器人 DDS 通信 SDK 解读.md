
**在部署系列中的全局定位**：在完成 SDK 安装（01）后，本文深入剖析 DDS 通信原理、SDK 核心 API 和三线程并发安全架构，是理解后续所有控制例程通信机制的理论基础。

在宇树 H1_2 机器人内部，分布式硬件计算节点和高频实时控制算法之间的通信是整个控制系统的命脉。宇树在 `unitree_sdk2` 中集成了以性能优越、低延迟著称的开源 DDS（数据分发服务）实现 —— **Eclipse CycloneDDS**。

本篇将详细剖析其通信技术基础、机载网络架构、网卡绑定、底层 API 声明以及三线程并发安全设计。

---

## 1. DDS 通信基础与机身网络架构


### 1.1 为什么采用 DDS？

传统的 ROS 1 (Master-Slave) 架构或 TCP/UDP 通信在人形机器人高频（500Hz - 1000Hz）全身控制中存在痛点：

- **拓扑复杂**：节点增多导致网络连接呈指数级变复杂，易产生单点故障。
- **时延抖动**：中心中转与握手校验会带来时延积压，导致控制器失稳。

DDS（数据分发服务）是“以数据为中心”的分布式通信标准：

- **全局数据空间**：节点间通过自动发现机制（Discovery）建立 Peer-to-Peer 端到端直接通信，无 Broker 中转。
- **强类型 IDL 约束**：编译期生成高效序列化代码，方便快速通讯。
- **细粒度 QoS 策略**：控制指令采用 `Best Effort` 及 `History Keep Last (Depth=1)`，丢包不重传，避免队首阻塞；配置参数采用 `Reliable`，确保必达。

由于上述优点，宇树在 `unitree_sdk2` 中集成了开源 DDS 实现中以性能重、低延迟著称的 **Eclipse CycloneDDS**。

### 1.2 机身以太网 IP 物理分配

机器人机载局域网基于千兆工业交换机组织，主要运行在 `192.168.123.X` 网段：

| 硬件计算单元 | 默认静态 IP | 核心职责与访问控制说明 |
| :--- | :--- | :--- |
| **运控 PC 1** (步态主控) | 内部隔离，不开放 SSH | “小脑”。搭载硬实时 Linux 系统（`PREEMPT_RT`），运行官方闭源的高频平衡与运动控制服务（MCF）。直接通过高速物理总线控制关节驱动板，负责将状态打包发布到 DDS 话题 `rt/lowstate`，并订阅 `rt/lowcmd` 驱动电机。 |
| **开发 PC 4** (用户核心开发机) | `192.168.123.164` | “大脑”。向二次开发人员开放。用户在此部署高级控制算法（如强化学习闭环控制、全身规划器等）。高频订阅状态并下发控制指令。 |
| **机载 AI 模块** (NVIDIA Orin) | `192.168.123.X` | 部署高算力感知算法，如三维激光雷达（雷达 IP 常固定为 `192.168.123.120`）与深度相机的多源感知数据融合及具身智能推理。 |
| **外部开发 PC** (本地调试机) | `192.168.123.99`等 | 开发者的物理调试电脑。通过网线直连机器人右侧航空口加入交换机局域网，用于雷达点云监控或进行本地控制测试。 |

---

## 2. 网卡强绑定与 CycloneDDS 配置详解

多网卡环境（有线网口、无线 WiFi、本地虚拟回环 `lo`、Docker 虚拟网卡 `docker0`）下，DDS 默认会向所有网口广播数据或错绑网口，导致通信受阻或引发广播风暴。最好强制显式绑定，避免这些问题。

### 2.1 临时网卡绑定环境变量

在终端中强制将 CycloneDDS 绑定到直连有线网卡（如 `enp7s0`）或回环网卡 `lo`：
```bash
export CYCLONEDDS_URI='<CycloneDDS><Domain><General><Interfaces><NetworkInterface name="enp7s0" priority="default" multicast="default" /></Interfaces></General></Domain></CycloneDDS>'
```

### 2.2 完整配置文件 (`cyclonedds.xml`)

若需更详细的设置，配置环境变量 `export CYCLONEDDS_URI=/path/to/cyclonedds.xml` 以加载配置文件：

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<CycloneDDS xmlns="https://cdds.io/config" 
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
            xsi:schemaLocation="https://cdds.io/config https://raw.githubusercontent.com/eclipse-cyclonedds/cyclonedds/master/etc/cyclonedds.xsd">
    <Domain id="any">
        <General>
            <!-- 绑定特定网卡，避免多网卡下的广播风暴 -->
            <NetworkInterfaceAddress>enp7s0</NetworkInterfaceAddress>
            <AllowMulticast>true</AllowMulticast>
            <MaxMessageSize>65500</MaxMessageSize>
        </General>
        <Discovery>
            <ParticipantIndex>auto</ParticipantIndex>
            <MaxAutoParticipantIndex>120</MaxAutoParticipantIndex>
            <!-- 多播受限或被干扰时，可显式指定单播对等发现 -->
            <Peers>
                <Peer address="192.168.123.161"/> <!-- 运控 PC 1 的 IP -->
            </Peers>
        </Discovery>
        <Internal>
            <Watermarks>
                <WhcHigh>500kB</WhcHigh>
            </Watermarks>
            <!-- 申请大容量内核套接字缓冲区，防止高频/大包数据引发 Sample dropped 丢包 -->
            <SocketReceiveBufferSize min="10MB"/>
        </Internal>
        <Tracing>
            <Verbosity>severe</Verbosity>
            <OutputFile>stdout</OutputFile>
        </Tracing>
    </Domain>
</CycloneDDS>
```

其中，

1. **`NetworkInterfaceAddress`（网卡绑定）**：
   在多网卡环境（如有线以太网和无线 Wi-Fi 同时开启）下，必须显式指定与机器人通信的网卡名称（通过在终端输入 `ifconfig` 或 `ip a` 查看，如 `eth0` 或 `enp7s0`）。如果省略该项，DDS 会向所有网段全量广播数据，造成极其严重的控制失步。
2. **`Peers`（可选：单播对等发现）**：
   由于默认的多播（Multicast）发现在复杂的网络环境（如同时开启 Wi-Fi）下容易引发全网段的广播风暴。在这里显式填入机器人局域网 IP（例如宇树默认主控板的 `192.168.123.161`），DDS 将从多播发现退化为点对点精准单播探测，从而顺利建立连接并彻底切断无线网络上的无效广播。
3. **`AllowMulticast`**：
   默认开启。但是，如果你是在容器环境（如 Docker 或 Podman）内部运行控制节点，或者在某些禁用了多播广播的企业 Wi-Fi 路由器下，网络多播会发生堵塞导致命令挂起，遇到这种情况可以在配置文件中将此项设置为 `false` 来彻底禁用多播。
4. **`SocketReceiveBufferSize`（系统套接字缓存限制）**：
   当机器人传输大分辨率原始图像或高频 3D 点云时，海量的 UDP 数据包分片会瞬间塞满 Linux 内核默认的接收缓冲区（通常仅为 256KB 左右）。一旦缓冲区溢出丢失一个数据包切片，整张图像或点云都会被丢弃，引起终端狂刷 “Sample dropped” 警告。将接收缓冲区申请值扩大（如 `10MB` 甚至更高）能够有效解决高带宽下的局部花屏与卡顿问题。

### 2.3 ROS 2 兼容与 RMW (ROS2 Middleware) 绑定
由于 ROS 2 的底层也是 DDS 接口规范，且默认支持 CycloneDDS。我们可以通过切换 RMW 实现 ROS 2 节点与 SDK 2 话题无缝直连：
```bash
# 安装 CycloneDDS ROS2 适配包
sudo apt-get install ros-${ROS_DISTRO}-rmw-cyclonedds-cpp

# 设置环境变量，强制 ROS 2 底层切换为 CycloneDDS
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
```
配置完成后，将 ROS 2 与 SDK 指向同一个 `CYCLONEDDS_URI` 配置文件，ROS 2 即可直接订阅 `rt/lowstate` 话题提取遥测状态。

---
## 3. 宇树 SDK 2 DDS 底层 C++ API 声明

### 3.1 核心对象 C++ API 

宇树 SDK 2 对 CycloneDDS 进行了面向对象的模板封装，核心类声明及用途如下：

- **`ChannelFactory`**：管理通信参与者（`DomainParticipant`）生命周期的单例：
  ```cpp
  // 0 代表 Domain ID，后跟网卡名称（为空则读取 CYCLONEDDS_URI 环境变量）
  ChannelFactory::Instance()->Init(0, networkInterface);
  ```
- **`ChannelPublisher<T>`**：消息发布模板类。内部封装 `Publisher` 和 `DataWriter`：
  ```cpp
  ChannelPublisher<HelloWorldData::Msg> publisher("TopicHelloWorld");
  publisher.InitChannel();
  publisher.Write(msg); // 传入由 IDL 编译生成的 C++ 结构体实例
  ```
- **`ChannelSubscriber<T>`**：消息订阅模板类。使用异步事件驱动回调：
  ```cpp
  ChannelSubscriber<HelloWorldData::Msg> subscriber("TopicHelloWorld");
  // 传入回调 Lambda 表达式，第二个参数为队列深度 QoS
  subscriber.InitChannel([](const void* msg) {
      auto pm = static_cast<const HelloWorldData::Msg*>(msg);
      std::cout << "UserID: " << pm->userID() << " Msg: " << pm->message() << std::endl;
  }, 10);
  ```

## 3.3. 推荐采用的三线程通讯架构

在人形机器人的底层控制程序中（500Hz，2ms 周期），如果控制主线程同步执行网络 I/O、算法计算与数据写入，一旦网络出现波动或系统发生调度延时，就会导致严重的控制时延抖动。为了提高通讯稳定性，宇树底层控制例程一般会采用三并发线程异步解耦架构，其时序和数据流动逻辑如下：

1. **DDS 接收回调线程（DDS 库内部线程）**：网卡收到 `rt/lowstate` 包时，DDS 内部网络线程被自动唤醒并触发接收回调，解析并加锁拷贝到共享状态缓冲区。
2. **控制算法主线程（500Hz 定时唤醒）**：使用高精度周期定时器（2ms 周期），从共享状态缓冲区读取最新关节快照，计算阻抗控制目标，并将指令写入共享指令缓冲区。
3. **DDS 写入发送线程（500Hz 定时唤醒）**：以 2ms 周期唤醒，从共享指令缓冲区读取命令，计算 CRC 校验码，调用 `Write` 通过 `rt/lowcmd` 下发动作。

具体代码编写方法参考本文第4章。

## 3.4. 共享并发安全

在 C++ 中，**`std::shared_ptr` 智能指针对象本身并不是线程安全的**。它的引用计数增减是原子的，但指针内部的对象指针和控制块指针的修改写操作非原子。如果一个线程在写入（智能指针原子级替换），而另一个线程在读取产生拷贝，会发生未定义的数据竞争（Data Race），导致野指针或程序崩溃。

为此，宇树低层控制例程中采用了基于 **C++17 读写锁（`std::shared_mutex`）** 的轻量级线程安全共享容器（data_buffer.hpp）：

```cpp
#pragma once
#include <memory>
#include <shared_mutex>
#include <mutex>

template <typename T> 
class DataBuffer {
public:
  // 写入端使用独占写锁 (std::unique_lock) 进行排他写
  void SetData(const T &newData) {
    std::unique_lock<std::shared_mutex> lock(mutex);
    data = std::make_shared<T>(newData);
  }

  // 采样端使用共享读锁 (std::shared_lock) 提高并发读性能
  std::shared_ptr<const T> GetData() {
    std::shared_lock<std::shared_mutex> lock(mutex);
    return data; // 返回智能指针的拷贝，由 shared_lock 保证拷贝过程的线程安全
  }

  void Clear() {
    std::unique_lock<std::shared_mutex> lock(mutex);
    data = nullptr;
  }

private:
  std::shared_ptr<T> data;
  std::shared_mutex mutex; // 读写锁
};
```

---

## 4. 简易 HelloWorld 通信测试与运行流程

这里对 `unitree_sdk2/example/helloworld/` 进行简化然后分析。

运行的效果在上一篇文章中介绍了。

### 4.1 IDL 接口描述文件 (`HelloWorldData.idl`)
DDS 规范要求通信必须是强类型的。通过接口定义语言（IDL）预先定义数据结构：
```idl
module HelloWorldData {
    struct Msg {
        long long userID;
        string message;
    };
};
```
编译时，DDS 编译器会自动生成序列化与反序列化 C++ 类文件 `HelloWorldData.hpp`。

### 4.2 简版发布端代码 (`publisher.cpp`)
```cpp
#include <unitree/robot/channel/channel_publisher.hpp>
#include <unitree/common/time/time_tool.hpp>
#include "HelloWorldData.hpp"

int main() {
    // 1. 初始化通道工厂，使用默认 Domain ID 0
    unitree::robot::ChannelFactory::Instance()->Init(0);
    
    // 2. 创建话题 TopicHelloWorld 的消息发布器实例
    auto publisher = std::make_shared<unitree::robot::ChannelPublisher<HelloWorldData::Msg>>("TopicHelloWorld");
    
    // 3. 初始化底层 DDS 通道（构建 DataWriter）
    publisher->InitChannel();

    while (true) {
        // 4. 填充当前毫秒时间戳与消息内容
        HelloWorldData::Msg msg(unitree::common::GetCurrentTimeMillisecond(), "HelloWorld.");
        
        // 5. 写入数据通道发送
        publisher->Write(msg);
        std::cout << "Publish Message: " << msg.message() << std::endl;
        sleep(1); // 1Hz 发送频率
    }
    return 0;
}
```

### 4.3 简版接收端代码 (`subscriber.cpp`)
```cpp
#include <unitree/robot/channel/channel_subscriber.hpp>
#include "HelloWorldData.hpp"

// 1. 定义消息接收回调函数，将无类型指针转换为强类型 Msg 指针
void Handler(const void* msg) {
    auto pm = (const HelloWorldData::Msg*)msg;
    std::cout << "userID:" << pm->userID() << ", message:" << pm->message() << std::endl;
}

int main() {
    // 2. 初始化通道工厂
    unitree::robot::ChannelFactory::Instance()->Init(0);
    
    // 3. 创建相同话题的数据订阅器
    unitree::robot::ChannelSubscriber<HelloWorldData::Msg> subscriber("TopicHelloWorld");
  
    // 4. 注册回调并模拟周期性关闭与重连测试
    subscriber.InitChannel(Handler);
    sleep(10);
    subscriber.CloseChannel();
    std::cout << "reseted. sleep 3" << std::endl;
    sleep(3);
    subscriber.InitChannel(Handler);

    // 5. 保持主线程活动以等待异步回调触发
    while (true) { sleep(10); }
    return 0;
}
```

---

## 5. 实战常见问题与解决方案

### 5.1 问题 1：DDS 消息“看不见”（无法建立连接或接收不到数据）
**排查与解决步骤**：
1. **检查网线连接**：确保网线物理连接至机器人躯干交换机（通常位于腰部后侧），且开发机网口显示“已连接”。
2. **检查本地 IP 静态配置**：在终端运行 `ping 192.168.123.164`（PC 4）或 `ping 192.168.123.161`。若不通，检查有线网卡 IP 是否被静态设置为 `192.168.123.X`（如 `192.168.123.99`），且**子网掩码必须为 `255.255.255.0`，网关留空**。
3. **检查 DDS 域（Domain ID）**：宇树默认通信域为 `0`。如果当前环境变量配置了其他的 `ROS_DOMAIN_ID`，会导致 DDS 通信强隔离。确保 `ChannelFactory` 初始化传入的 ID 为 `0`。
4. **关闭防火墙拦截**：Linux 防火墙（如 `ufw`）可能会拦截 UDP 多播包。可先临时关闭防火墙测试：
   ```bash
   sudo ufw disable
   ```
5. **网卡名称绑定校验**：核对 `CYCLONEDDS_URI` 环境变量中的网卡名称（如 `enp7s0`）是否与 `ifconfig` 或 `ip a` 中的有线网卡名称精确匹配。

### 5.2 问题 2：高频（500Hz）实时通信下的丢包与延迟抖动
**排查与解决步骤**：
若在运动中关节出现异常震荡或微小异响，且观察到 `LowState` 回调时间发生毫秒级延迟抖动，通常是由于网络阻塞或 QoS 策略不匹配。
1. **强制配置高频话题为 `Best Effort`（尽力而为）**：高频控制话题（`rt/lowcmd` 和 `rt/lowstate`）必须使用 Best Effort。如果错误使用了 Reliable 模式，底层网络重传机制会导致队首阻塞，引起控制周期的突发性延迟。
2. **限制队列深度为 1**：将订阅器的队列深度（Queue Size）设为 `1`。确保控制算法总是读取到最新的关节数据，而将堆积在缓冲区中的“历史过期数据”自动抛弃。

### 5.3 问题 3：ROS 2 节点与 Unitree SDK 2 冲突或无法共存
**排查与解决步骤**：
ROS 2 默认使用 Domain ID `30`，而 SDK 2 默认使用 `0`。默认状态下两者端口隔离，可无冲突运行。如需将两者打通，请参考以下最佳实践：
1. **强制 ROS 2 切换底层 RMW 为 CycloneDDS**：
   ```bash
   sudo apt-get install ros-${ROS_DISTRO}-rmw-cyclonedds-cpp
   export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
   ```
2. **共享相同的 `CYCLONEDDS_URI` 配置文件**：使 ROS 2 终端和控制程序终端读取相同的 `cyclonedds.xml`，保证两者绑定同一张物理网卡，打通数据交互通道。
