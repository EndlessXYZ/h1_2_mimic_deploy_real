
**在部署系列中的全局定位**：搭建 MuJoCo 物理仿真环境并完成仿真器编译运行，为后续所有无真机环境的仿真实验（状态反馈、手臂控制、底层控制、RL 部署）提供物理仿真平台。

本文详述如何在 Ubuntu 上，配置运行宇树 H1_2 机器人的 MuJoCo 仿真。

---

## 1. 核心工程原则

在进行仿真环境搭建与自定义工具开发时，本文遵守以下核心准则：
- 严禁修改 `unitree_sdk2` 和 `unitree_mujoco` 两个官方仓库中的任何源代码、示例及内置 CMake 构建文件。

---

## 2. 工作区目录结构

本配置方案以 `~/Documents/unitree_h1` 作为全局绝对根目录（简称 `{WORKSPACE}`）。工作区内部采用分层、模块化布局，各依赖组件、仿真器、外置工具和生成产物均严格按照指定位置存放：

```text
~/Documents/unitree_h1/
├── unitree_sdk2/                    # 宇树官方 SDK2 源码库 [保持不动]
│   ├── example/                     # 官方原生示例目录
│   └── thirdparty/                  # SDK 依赖的第三方库
│       └── lib/
│           └── x86_64/              # 存放 DDS 动态链接库
│
├── unitree_mujoco/                  # 宇树官方 MuJoCo 物理仿真库 [保持不动]
│   └── simulate/
│       ├── build/                   # 仿真器编译工作目录
│       ├── config.yaml              # 仿真运行配置文件，可按实验记录修改
│       ├── mujoco/                  # 软链接，指向 ../../local_deps/mujoco-3.3.6
│       └── src/
│           └── main.cc              # 仿真器入口文件
│
├── local_deps/                      # 本地隔离依赖缓存目录（防止污染系统全局路径）
│   ├── mujoco-3.3.6/                # 预解包的 MuJoCo SDK 运行时与静态头文件
│   └── usr/                         # 本地解包的系统开发依赖库（如静态编译的 GLFW 等）
│       ├── include/                 # glfw 等第三方头文件
│       └── lib/
│           └── x86_64-linux-gnu/    # 对应动态链接库（提供 libglfw.so.3）
│
├── artifacts/                       # 实验产物归档目录（存放控制日志、状态导出、截图等）
└── ToDelete/                        # 垃圾回收区（用于存放不再使用的陈旧/过期文件）
```

---

## 3. 系统依赖与隔离依赖部署

为了防止污染系统全局开发路径并规避动态库版本冲突，本方案采用“基础依赖系统安装 + 核心依赖局部提取”的物理隔离策略。

### 3.1 系统级基础工具链安装（若缺失）
若当前环境尚未安装基础编译工具与 OpenGL 开发库，请安装：
```bash
sudo apt-get update && sudo apt-get install -y \
    build-essential cmake git libgl1-mesa-dev libglu1-mesa-dev \
    libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev libxi-dev \
    libyaml-cpp-dev libboost-program-options-dev libfmt-dev python3-pip
```

### 3.2 局部开发库隔离解包
在工作空间全局根目录 `~/Documents/unitree_h1/` 下初始化 `local_deps/`：
```bash
cd ~/Documents/unitree_h1 && mkdir -p local_deps

# 1. 提取免安装版 MuJoCo SDK
tar -xf mujoco-3.3.6-linux-x86_64.tar.gz -C local_deps

# 2. （可选）GLFW3 隔离提取
# 若系统未安装 libglfw3-dev，从 deb 包提取：
# cd ~/Documents/unitree_h1/local_deps && mkdir -p deb_glfw usr
# dpkg-deb -x libglfw3_3.3.6-1_amd64.deb deb_glfw/libglfw3
# dpkg-deb -x libglfw3-dev_3.3.6-1_amd64.deb deb_glfw/libglfw3-dev
# cp -r deb_glfw/libglfw3/usr/* usr/
# cp -r deb_glfw/libglfw3-dev/usr/* usr/
# 
# 本环境中 GLFW3 为系统级安装，此步骤跳过
```


### 3.3 软链接与 CMake 构建检索配置
进入仿真器源码目录，建立软链接指向解压出的 MuJoCo 运行库，使其 CMake 构建脚本能基于相对路径自动匹配头文件与动态库，而无需改动官方编译脚本：
```bash
cd ~/Documents/unitree_h1/unitree_mujoco/simulate
ln -sfn ../../local_deps/mujoco-3.3.6 mujoco
```
编译官方仿真器可执行文件时，需通过前缀路径参数定位已安装的 SDK 2 库：
```bash
mkdir -p build && cd build

# 隔离路径（SDK 安装在 local_deps 时使用，推荐）
cmake -DCMAKE_PREFIX_PATH=~/Documents/unitree_h1/local_deps/usr/lib/cmake/unitree_sdk2 ..

# SDK 系统安装时使用（备用）：
# CPATH=~/Documents/unitree_h1/local_deps/usr/include \
# LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu \
# cmake -DCMAKE_PREFIX_PATH=/usr/local/lib/cmake/unitree_sdk2 ..

make -j4
```

> **提示**：若在 conda 环境中编译遇到 `GLIBCXX_3.4.30 not found` 错误（conda 的 `libstdc++.so.6` 仅支持至 3.4.29），使用 `LD_PRELOAD` 绕回系统库：
> ```bash
> export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
> ```

---

## 4. 运行配置

### 4.1 DDS 域对齐与回环限制

仿真器与外部控制程序通过 CycloneDDS 进行通信。为防止同网段下其他机器人的多播数据在局域网内串扰，同时减少向无线网络广播带来的丢包：
1. 通信域 Domain ID 统一对齐为 **`0`**（官方原生 `config.yaml` 默认为 `1`，而 SDK 例程默认为 `0`，故必须修改对齐，否则双端无法连通）。
2. 通信网口强制绑定在 **`lo` 本地回环接口**（所有 DDS 报文限制在 `127.0.0.1` 环路中）。

可以通过，启动时传入参数进行动态覆盖（优先级高于 `config.yaml` 配置文件）：
```bash
./unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml
```

但最好修改 `unitree_mujoco/simulate/config.yaml` 作为实验的默认运行预设，同时还要启用虚拟挂带：
```yaml
robot: "h1_2"
robot_scene: "scene.xml"
domain_id: 0             # 强制设为 0 以对齐控制端
interface: "lo"          # 强制绑定本地回环，防止物理广播
enable_elastic_band: 1   # 启用虚拟挂带，防止上电初速度为 0 时发生瘫软
```

---

### 4.2 运行场景

在 `unitree_mujoco/unitree_robots/h1_2/scene.xml` 中，官方配置了机器人的基础仿真物理世界，包括 `h1_2_handless.xml` 动力学模型（描述了 27 个关节执行器、各连杆的转动惯量与物理特征）、站立所需的静/滑动摩擦平面以及默认相机视角。

由于人形机器人在加载启动的瞬间各关节力矩输出均为零，如果在重力作用下直接自由落地，可能会发生瘫软或在地面碰撞中触发积分器发散。为此，仿真器内置了 **Elastic Band（弹性吊带）** 安全悬吊保护机制：
- **原理**：在机器人骨盆（`pelvis`）正上方虚设一个空间锚点。当吊带开启时，仿真器会在骨盆与该锚点之间施加一层基于胡克定律的拉伸弹力，从而产生向向上的恢复力以协助人形机器人保持直立或悬空。
- **启用方法**：修改 `unitree_mujoco/simulate/config.yaml` 的 `enable_elastic_band: 1`
- **键盘物理交互热键**：
  - **按 `9`**：开关虚拟挂带。松开后，机器人将失去拉伸弹力瞬间自由落地，可用于测试行走和站立平衡算法。
  - **按 `7` 或 `UP` 键**：缩短挂带长度（每次 0.1m），即向垂直上方吊起机器人。
  - **按 `8` 或 `DOWN` 键**：延长挂带长度（每次 0.1m），即垂直降低机器人高度。
  - **按 `Backspace`**：一键清空所有仿真物理状态数据，并瞬间还原重置仿真器。


---

## 5. 仿真运行步骤

确定编译完成之后，运行

```bash
# 1. 设置图形会话变量
export DISPLAY=:10 # 根据您系统实际桌面编号进行设置，这里采用 NoMachine

# 2. 设置隔离的本地 GLFW 链接库搜索路径及仿真器所需动态库
export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:${LD_LIBRARY_PATH}

# 3. 如需在 conda 环境中绕开 libstdc++ 版本冲突：
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6

# 4. 运行仿真（命令行重写 Domain 0 与环回网卡 lo）
~/Documents/unitree_h1/unitree_mujoco/simulate/build/unitree_mujoco \
    -i 0 -n lo -r h1_2 -s scene.xml
```


进入仿真GUI后，默认机器人会被吊起（可能会缓慢坐下）

![20260615153503.png](assets/20260615153503.png)

按下按键 9,  松开虚拟挂带，机器人立即摊倒在地。

![20260615153834.png](assets/20260615153834.png)

重新按下按键 9,  挂上虚拟挂带，机器人又坐起。按 7 逐渐吊起。

![20260615153944.png](assets/20260615153944.png)


---

## 6. 常见错误与排查手册

- **问题 1：外部控制例程启动时提示找不到共享库 `libunitree_sdk2.so`**
  - **原因**：系统安装 SDK 2 后未刷新加载缓存，或 `/usr/local/lib` 未加入到动态库搜索路径中。
  - **排查与解决**：
    ```bash
    sudo ldconfig
    export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
    ```
- **问题 2：仿真器拉起后外部控制端一直提示连接超时，无法传输控制量**
  - **原因**：两端通信的 DDS Domain ID 不一致。如一方用了 config.yaml 默认的 `1`，而另一方用了默认的 `0`。
  - **排查与解决**：利用 `ps -ef | grep unitree_mujoco` 检查正在运行的进程参数，确保命令行中附带 `-i 0`。同时检查控制端在启动时也传入了 `lo` 网卡参数以确保走本地环回。
- **问题 3：仿真器启动即发生段错误 (Segmentation Fault)**
  - **原因**：在无显示器的 Headless 服务器上直接运行了物理 GUI 渲染启动；或是由于 `LD_LIBRARY_PATH` 错绑了系统的低版本 GLFW 库。
  - **排查与解决**：确认有可用的 DISPLAY（如 NoMachine 会话 `:10`）：
    ```bash
    export DISPLAY=:10   # 使用已有 NoMachine 会话，无需 sudo 安装 Xvfb
    ```
