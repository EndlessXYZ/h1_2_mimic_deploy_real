
先前的文章都是采用基于规则的算法，而本篇开始将采用强化学习RL策略。前置基础为《[03 mujoco仿真实验.md]》与《[07 高层步态例程解读.md]》。

**本篇目的**：在不修改官方仓库源码与配置、使用隔离 Conda 运行环境以及直接加载官方自带预训练策略的零侵入式规范下，在 MuJoCo 物理引擎中跑通 H1_2 步态策略的 Sim2Sim 仿真验证，打通 RL 部署链路的 Python 仿真第一环。

**在部署系列中的全局定位**：本篇在 Python 仿真侧完成了 RL 策略的简易物理闭环（单进程、无中间件），是整个 RL 部署链路的起点。后续的《11 部署用 CppSDK 解读》和《12 部署用 CppSDK 支持 H1-2 和 Onnx》将在此基础上迁移到 C++ 部署 SDK，引入 DDS 通信中间件，实现硬实时、高频的闭环控制，最终对齐真机部署接口。

---

## 1. 系统架构与仓库联动

Sim2Sim 部署验证依赖以下三个仓库在 `~/Documents/unitree_h1` 下并列存放，其网络地址与核心职责如下：
* **unitree_rl_gym**（`https://github.com/unitreerobotics/unitree_rl_gym`）：宇树人形机器人强化学习步态策略的训练与部署框架。基于 `legged_gym` 构建，封装了 H1/H1_2/G1 等机型的步态策略网络、运动学参数和仿真配置文件，提供 MuJoCo 推理启动器 `deploy_mujoco.py`。主要用来推理。
* **unitree_sdk2**（`https://github.com/unitreerobotics/unitree_sdk2`）：宇树第二代机器人低层通信与控制 SDK（支持 C++/Python），底层集成 CycloneDDS 协议，负责与机器人主控或仿真桥接层进行高频实时数据交互（话题 `rt/lowstate` 和 `rt/lowcmd`）。
* **unitree_mujoco**（`https://github.com/unitreerobotics/unitree_mujoco`）：基于 MuJoCo 物理引擎的官方仿真平台。内置 DDS 桥接层，可订阅控制端下发的关节指令并计算电机动力学，同时回传 IMU 与关节遥测数据，实现仿真与真机在控制层面的接口对齐。

在 DDS 闭环部署下的联动关系：

```mermaid
graph TD
    subgraph unitree_rl_gym ["决策控制端 (unitree_rl_gym / C++ 部署 SDK)"]
        A[DDS 接收线程] -->|解析 LowState| B(状态预处理 & Obs 组装)
        B -->|IMU折算 / 关节 / 相位特征| C[RL 策略网络推理]
        C -->|输出动作 Action| D(PD 关节指令生成)
        D -->|打包 LowCmd 报文| E[DDS 发送线程]
    end

    subgraph unitree_sdk2 ["通信中间件"]
        F((DDS 话题: rt/lowstate))
        G((DDS 话题: rt/lowcmd))
    end

    subgraph unitree_mujoco ["物理仿真器 (unitree_mujoco)"]
        H[MuJoCo 物理引擎] -->|物理遥测状态| I[DDS 桥接模块]
        I -->|PD解算并施加电机力矩| H
    end

    I -->|发布| F
    F -->|订阅| A
    E -->|发布| G
    G -->|订阅| I
```

> **注意**：上述 DDS 闭环架构是后续 C++ 部署阶段（第12、13篇）的目标形态，此处仅作为全局架构预览。本篇的实际工作聚焦于「本地 Python 简易仿真模式」——不经过 `unitree_sdk2` 和 DDS 通信，直接在单个 Python 进程内完成 MuJoCo 物理仿真与策略推理的闭环。


---

## 2. 隔离环境与策略安装

### 2.1 Conda 环境配置
```bash
cd ~/Documents/unitree_h1

# 1. 创建 Python 3.10 隔离环境并激活
conda create -n unitree-rl-sim2sim-py310 python=3.10 -y
conda activate unitree-rl-sim2sim-py310

# 2. 安装科学计算与仿真依赖
env -u PYTHONPATH pip install \
  torch==2.3.1 torchvision==0.18.1 torchaudio==2.3.1 \
  numpy==1.26.4 mujoco==3.2.3 pyyaml matplotlib==3.7.5 tensorboard \
  -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 2.2 可编辑安装 `legged_gym`
通过 `--no-deps` 忽略 Isaac Gym 等训练级依赖，仅注册策略包：
```bash
cd ~/Documents/unitree_h1

conda activate unitree-rl-sim2sim-py310
env -u PYTHONPATH pip install -e ~/Documents/unitree_h1/unitree_rl_gym --no-deps
```

---

## 3. 本地运行与结果校验

### 3.1 策略配置核对

仿真脚本启动时自动读取 YAML 配置以定位网络权重与机器人模型。默认配置文件 `h1_2.yaml` 中已使用 `{LEGGED_GYM_ROOT_DIR}` 动态宏索引本地路径：

```yaml
policy_path: "{LEGGED_GYM_ROOT_DIR}/deploy/pre_train/h1_2/motion.pt"
xml_path: "{LEGGED_GYM_ROOT_DIR}/resources/robots/h1_2/scene.xml"
```

配置与策略均指向官方内置的 H1_2 行走模型，无需修改。


### 3.2 物理 GUI 仿真运行
```bash
cd ~/Documents/unitree_h1/unitree_rl_gym

source ~/miniconda3/etc/profile.d/conda.sh
conda activate ~/.conda/envs/unitree-rl-sim2sim-py310
env -u PYTHONPATH python deploy/deploy_mujoco/deploy_mujoco.py h1_2.yaml
```

* **预期行为**：仿真窗口弹出后，H1_2 机器人平稳直立于地面；策略网络周期性推理输出步态动作，机器人展现连贯、对称的双足向前行走步态，无滑倒或关节畸变。


