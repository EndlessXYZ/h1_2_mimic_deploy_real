
参考：https://github.com/unitreerobotics/unitree_rl_gym/blob/main/deploy/deploy_real/README.zh.md

前置基础为《[11 RL策略 Sim2Sim 部署仿真实验.md]》。

**本篇目的**：Python 部署受限于 GIL 和 GC 延迟，难以满足实机部署的高频硬实时控制闭环需求。本篇对宇树官方 C++ 部署 SDK（CppSDK）的系统级架构进行全面解析，涵盖双速率异步自旋锁多线程设计（50Hz 策略推理 + 500Hz DDS 报文）和保障安全上电/退出的有限状态机（FSM）。

**在部署系列中的全局定位**：在第10篇完成 Python 端 RL 仿真验证后，本篇作为第二篇，从理论与代码架构上剖析 C++ 部署的核心知识库。理解本篇中基于 G1 的原始 C++ SDK 数据流与限制，是下一篇《12 部署用 CppSDK 支持 H1-2 和 Onnx》针对 H1-2 机型完成迁移重构与双后端推理支持的理论基础。

---

## 1. 系统级架构设计

实机部署面临两大核心挑战：
1. **通信保活硬实时**：底层控制器要求 `rt/lowcmd` 以 ≥500Hz 持续下发，若中断则看门狗判定断联，强制电机掉电。
2. **神经网络推理耗时波动**：策略推理（LibTorch/TorchScript）耗时数毫秒且波动，无法稳定在 500Hz，训练时决策周期约定为 50Hz。

为解耦这两种速率，SDK 将程序拆分为三个并发线程，通过自旋锁保护的共享缓冲区（`DataBuffer`）完成数据交换：

1. **DDS 接收回调线程（500Hz）**：由 CycloneDDS 在收到 `rt/lowstate` 报文时自动唤醒。反序列化为 `LowState_` 结构后，提取电机位置 `q_m`、速度 `dq_m` 和 IMU 四元数/角速度，写入线程安全的状态缓存 `mLowStateBuf` 后快速退出，避免阻塞网络 I/O。
2. **控制决策主线程（50Hz，20ms 周期）**：从 `mLowStateBuf` 读取最新状态快照，经 Eigen 坐标变换后组装 47 维观测向量，送入 LibTorch 加载的 `motion.pt` 进行前向推理，输出 12 维目标动作 `act`。动作经 `action_scale` 缩放并叠加 `default_angles` 后得到期望关节角度 `q_des`，写入指令缓存 `mLowCmdBuf`。
3. **DDS 发送线程（500Hz，2ms 周期）**：定时从 `mLowCmdBuf` 读取最新指令，同步 `mode_machine` 握手字段、注入各关节 PD 增益（`Kp`/`Kd`），计算 CRC32 校验和后发布至 `rt/lowcmd` 话题。该线程以 2ms 高频重复发送，确保底层看门狗不超时断联。

### 1.1 程序状态机切换逻辑

控制器的生命周期由有限状态机（FSM）驱动：

```mermaid
stateDiagram-v2
    [*] --> Init: 程序启动
    Init --> ZeroTorque: 获取首帧 rt/lowstate 反包
    state ZeroTorque {
        SendZeroCmd: 周期下发全零阻抗 (Kp=0, Kd=0, tau=0)
    }
    ZeroTorque --> MoveToDefault: 按下遥控器 START 键
    state MoveToDefault {
        Interpolation: 100步(2s)一阶线性插值过度到默认姿态 q_default
    }
    MoveToDefault --> RunController: 按下遥控器 A 键
    state RunController {
        RL_Policy: 50Hz 神经网络前向推理与增量控制
    }
    RunController --> Damping: 按下 SELECT 键 或 跌倒保护触发 (obs(5) > 0)
    state Damping {
        SendDamping: 下发阻尼指令 (Kp=0, Kd=8, tau=0) 以缓速下蹲
    }
    Damping --> [*]: 程序终止
```

---

## 2. 观测（Observation）与动作（Action）物理转换

根据 configs/g1.yaml，输入观测向量（obs）为 **47 维**：
* **0~/2**：机身角速度（缩放因子 `ang_vel_scale = 0.25`）。
* **3~/5**：投影重力向量 $\boldsymbol{g}_{proj}^B = - [R(2, 0), R(2, 1), R(2, 2)]^T$。
* **6~/8**：用户速度指令（手柄速度映射）。
* **9~/20**：下肢电机位置偏差 $\boldsymbol{q}_{err}$（`dof_pos_scale = 1.0`）。
* **21~/32**：下肢关节速度 $\dot{\boldsymbol{q}}$（`dof_vel_scale = 0.05`）。
* **33~/44**：前一时刻动作历史值 $\boldsymbol{a}_{prev}$。
* **45~/46**：步态余弦正弦相位信号。

### 2.1 核心公式与代码实现
1. **重力投影向量计算**：
   $$\boldsymbol{g}^B = (\boldsymbol{R}_B^W)^T \boldsymbol{g}^W = - \begin{bmatrix} R(2, 0) \\ R(2, 1) \\ R(2, 2) \end{bmatrix}$$
   ```cpp
   // 提取自 Controller.cpp
   Eigen::Matrix3f R = Eigen::Quaternionf(
       low_state->imu_state().quaternion()[0], low_state->imu_state().quaternion()[1],
       low_state->imu_state().quaternion()[2], low_state->imu_state().quaternion()[3]
   ).toRotationMatrix();
   for (int i = 0; i < 3; i++) {
       obs(i + 3) = -R(2, i);
   }
   ```
2. **跌倒保护判定**：
   若机身水平翻转角超过 90 度，则 $R(2,2) \le 0 \implies \text{obs}(5) \ge 0$。
   ```cpp
   if (obs(5) > 0) break; // 跳出策略循环，进入阻尼悬挂保护
   ```
3. **动作输出转换**：
   增量控制公式为：$q_{des, i} = a_i \cdot \text{action\_scale} + q_{default, i}$。
   ```cpp
   low_cmd->motor_cmd()[i].q() = act(i) * action_scale + default_angles[i];
   ```

---

## 3. 高实时自旋锁与数据共享缓冲区

为消解 500Hz 通信线程与 50Hz 控制主循环的共享冲突，使用低延迟自旋锁 AtomicLock.h 和线程安全覆盖式缓冲区 DataBuffer.h：

```cpp
// AFLock 实现：基于 std::atomic_flag 忙等，避免阻塞上下文切换
class AFLock {
public:
    void Lock() { while (mAFL.test_and_set(std::memory_order_acquire)); }
    void Unlock() { mAFL.clear(std::memory_order_release); }
private:
    std::atomic_flag mAFL = ATOMIC_FLAG_INIT;
};

// DataBuffer 模板类实现：隔离多线程数据并发读写
template<typename T>
class DataBuffer {
public:
    void SetDataPtr(const std::shared_ptr<T>& dataPtr) {
        ScopedLock<AFLock> lock(mLock);
        mDataPtr = dataPtr;
    }
    std::shared_ptr<T> GetDataPtr() {
        ScopedLock<AFLock> lock(mLock);
        return mDataPtr;
    }
private:
    std::shared_ptr<T> mDataPtr;
    AFLock mLock;
};

// ScopedLock：RAII 作用域锁，构造时加锁，析构时自动解锁
template<typename L>
class ScopedLock {
public:
    explicit ScopedLock(L& lock) : mLock(lock) { mLock.Lock(); }
    ~/ScopedLock() { mLock.Unlock(); }
private:
    L& mLock;
};
```

---

## 4. 有限状态机与线程保活实现

主循环通过 main.cpp 阻塞式线性转移控制逻辑：

1. **零扭矩卸荷** zero_torque_state：下发全零指令，直至检测到手柄按下 `start` 键。
2. **线性平滑上电** move_to_default_pos：100 步（2s 内）一阶线性位置插值，把关节缓慢拉到 `default_angles`。
3. **策略网络推理** run：运行前向网络推理并下发腿部目标，直到按 `select` 键或跌倒。
4. **安全阻尼下蹲** damp：下发微分阻尼指令（Kp=0, Kd=8），依靠电机反电动势消除下落冲量。

```cpp
// main.cpp 主循环结构
while (running) {
    if (joy.btn.components.start && state == zero_torque) {
        state = move_to_default_pos;
    } else if (joy.btn.components.A && state == move_to_default_pos) {
        state = run;
    } else if ((joy.btn.components.select || fall_detected) && state == run) {
        state = damp;
    }
    switch (state) {
        case zero_torque:       ctrl->zero_torque_state();   break;
        case move_to_default_pos: ctrl->move_to_default_pos(); break;
        case run:               ctrl->run();                  break;
        case damp:              ctrl->damp();                 break;
    }
    usleep(20000); // 20ms → 50Hz
}
```

### 4.1 通信握手与校验
在高频发送线程中，下发的 `LowCmd_` 必须同步当前 `LowState_` 的 `mode_machine`，且尾部注入硬件级 CRC32 校验字：
```cpp
// 提取自 Controller.cpp 里的 low_cmd_write_handler
lowCmdPtr->mode_machine() = mLowStateBuf.GetDataPtr()->mode_machine();
lowCmdPtr->mode_pr() = 0; // 踝关节采用 PR 模式
for (auto &cmd : lowCmdPtr->motor_cmd()) cmd.mode() = 1; // 电机使能
lowCmdPtr->crc() = crc32_core((uint32_t*)(lowCmdPtr.get()), (sizeof(unitree_hg::msg::dds_::LowCmd_) >> 2) - 1);
lowcmd_publisher->Write(*lowCmdPtr);
```

