
前置基础为《[11 部署用 CppSDK 解读.md]》。

**本篇目的**：原版 C++ SDK 专为 G1 设计，存在硬编码限制（固定读取 `g1.yaml`、硬编码 29 维关节上限、未做 IMU 躯干到骨盆坐标变换等），且仅支持 TorchScript 后端。本篇记录将该 SDK 迁移到 H1-2 人形机器人并加入 ONNX Runtime 推理支持的关键步骤，包括躯干到骨盆 IMU 坐标变换的数学推导与 C++ 实现，以及独立 Policy 类对 TorchScript / ONNX 双后端的解耦封装。

**在部署系列中的全局定位**：在第11篇理清 CppSDK 架构后，本篇完成针对 H1-2 机型与 ONNX 模型的代码迁移重构与双后端推理支持，为后续第13、14篇的仿真部署实验提供可直接编译使用的 C++ 控制器源码（`cpp_h1_2` 目录）。

---

## 1. 迁移动机

原版 C++ SDK 专为 G1 机器人（29 DoF，IMU 在骨盆）开发，存在大量硬编码：
* 写死读取 `g1.yaml` 配置文件，不支持命令行参数切换机型；
* 控制指令下发循环上限硬编码为下肢 12 维、全身 29 维，无法适配 H1-2 的 27 DoF；
* 默认 IMU 安装在骨盆（Pelvis），未实现躯干到骨盆的坐标变换。

相比之下，Python 版 `deploy_real.py` 天然支持多机型——通过命令行动态加载任意 YAML，关节循环以配置数组大小驱动，并根据 `imu_type == "torso"` 动态判断是否调用 IMU 变换。

若直接将原版 C++ SDK 用于 H1-2，会导致控制维度（29 vs 27）不匹配引发 DDS 数组越界，且 IMU 姿态未变换将导致策略无法维持平衡。

迁移的核心思路：**将 C++ 侧的硬编码改造为类似 Python SDK 的动态可配置模式**——利用 YAML 长度控制循环上限、用 Eigen 补充 IMU 变换分支。为保证原 G1 部署环境不受影响，新建 `cpp_h1_2` 目录隔离。

---

## 二、 G1 与 H1-2 控制层面的核心差异

将 SDK 从 G1 迁移到 H1-2，需要明确两个机器人在硬件架构、自由度分布以及传感器安装位置上的根本性差异。

### 2.1 自由度（DoF）与空间拓扑对比

在 `unitree_hg` 底层协议中，电机控制与测量数组的大小静态硬编码为 **35 维**。G1 和 H1-2 对应占据的前向物理索引不同：

* **G1 平台**：包含 29 个物理关节。
  * **下肢腿部**：左右腿各 6 DoF，合计 12 DoF（索引 0 ~ 11）。
  * **躯干与手臂**：腰部及双臂合计 17 DoF（索引 12 ~ 28）。
* **H1-2 平台**：包含 27 个物理关节（不含灵巧手）。
  * **下肢腿部**：左右腿各 6 DoF，合计 12 DoF（索引 0 ~ 11），升级了并联足踝侧向摆动（Roll）自由度。
  * **躯干与手臂**：腰部 1 DoF（索引 12）及左右手臂各 7 DoF，合计 15 DoF（索引 12 ~ 26）。其对应的低层硬件通信映射如下表：

|     索引范围     | 对应物理关节 (H1-2)         | 对应物理关节 (G1)         | 迁移处理                                                |
| :---------------: | :-------------------------- | :------------------------ | :------------------------------------------------------ |
| **0 ~ 11** | 左右腿共 12 自由度          | 左右腿共 12 自由度        | 维度完全对齐，加载各自 YAML 映射                        |
|   **12**   | 腰部偏航关节 (WaistYaw)     | 腰部俯仰关节 (WaistPitch) | 物理索引相同，但由于腰部运动轴不同，刚度/前馈需调整     |
| **13 ~ 19** | 左臂 7 自由度 (肩3+肘1+腕3) | 腰及左臂关节              | 维度收缩，H1-2 左臂包含 7 DoF，G1 该段混有腰部横滚等    |
| **20 ~ 26** | 右臂 7 自由度 (肩3+肘1+腕3) | 右臂关节                  | 维度收缩，H1-2 右臂包含 7 DoF，原 G1 通道 27、28 无效化 |
| **27 ~ 34** | 预留通道 (未物理连接)       | 冗余/灵巧手/未连接通道    | 控制指令中需全部填零，避免引发协议层报错                |

### 2.2 IMU 安装位置与 Pelvis 坐标系变换

这是 Sim-to-Real 迁移中最容易被忽略、且会导致控制策略瞬间瘫痪的物理差异：

* **G1 机器人**：其机载 9轴 IMU 直接安装在**骨盆（Pelvis）**上。因此，算法中所需的机身姿态（四元数）和角速度直接从 `low_state.imu_state` 读取即可使用。
* **H1-2 机器人**：其 IMU 安装在**躯干（Torso/胸腔）**上。强化学习策略网络通常在骨盆坐标系（Pelvis Frame）下进行观测和动作输出，因此必须通过腰部偏航角（Waist Yaw）对 IMU 的遥测数据进行逆向变换，折算到骨盆系中。

#### IMU 变换数学公式

设腰部偏航旋转角为 $q_{waist}$，其旋转速度为 $\dot{q}_{waist}$；IMU 测得的躯干姿态四元数对应的旋转矩阵为 $\boldsymbol{R}_{torso}$，三轴角速度为 $\boldsymbol{\omega}_{torso}$。

1. 绕 $Z$ 轴旋转的腰部旋转矩阵：
   $$
   \boldsymbol{R}_{z,waist} = \boldsymbol{R}_z(q_{waist})
   $$
2. 变换后的骨盆系旋转矩阵：
   $$
   \boldsymbol{R}_{pelvis} = \boldsymbol{R}_{torso} \cdot \boldsymbol{R}_{z,waist}^T
   $$
3. 变换后的骨盆系三轴角速度：
   $$
   \boldsymbol{\omega}_{pelvis} = \boldsymbol{R}_{z,waist} \cdot \boldsymbol{\omega}_{torso} - [0, 0, \dot{q}_{waist}]^T
   $$

在迁移过程中，若配置文件指定 `imu_type: "torso"`，C++ SDK 必须使用以上公式对 IMU 数据进行实时变换。

---

## 三、 C++ SDK 迁移至 H1-2 具体实施步骤与说明

在迁移至 H1-2 平台时，我们对代码及构建配置进行了如下关键改动。

这里只展示部分，完整版请下载源码。

#### 3.1 头文件 (Controller.h) 的定义扩充

* 引入了 `<utility>` 标准头文件，用于后续在 IMU 变换函数中返回键值对形式的 `std::pair`。
* 声明了新辅助函数 `transform_imu_data`。
* 在 YAML 配置项的私有成员变量区，增加了成员变量 `std::string imu_type`，用于保存读取到的 IMU 安装位置类型。

#### 3.2 IMU 躯干到骨盆坐标系变换实现

* 在 `Controller.cpp` 中实现了 `transform_imu_data` 函数。函数中使用 Eigen 库，首先根据传入的 `waist_yaw`（腰部偏航角）构造绕 Z 轴的旋转矩阵，然后利用该矩阵的转置与躯干 IMU 四元数转换得到的旋转矩阵相乘，计算得到骨盆姿态矩阵并转换为骨盆四元数；同时将测得的躯干角速度经腰部旋转转换后，减去腰部偏航角速度，从而折算出骨盆框架下的角速度。
* 在主控制推理循环 `run()` 中，加入了对 `imu_type` 的实时分支处理。若为 `"torso"`，则自动提取腰部电机的角度和角速度作为转换输入，调用上述变换函数，将转换后得到的骨盆系四元数和角速度乘以相应的缩放比例，以此组装成策略网络的输入观测值向量 `obs`。


```cpp
// 1. IMU 遥测数据躯干到骨盆的坐标系转换
std::pair<Eigen::Quaternionf, Eigen::Vector3f> Controller::transform_imu_data(
    float waist_yaw, float waist_yaw_omega, 
    const Eigen::Quaternionf &imu_quat, const Eigen::Vector3f &imu_omega)
{
    // 构造绕 Z 轴的腰部偏航旋转矩阵
    Eigen::Matrix3f RzWaist = Eigen::AngleAxisf(waist_yaw, Eigen::Vector3f::UnitZ()).toRotationMatrix();
    Eigen::Matrix3f R_torso = imu_quat.toRotationMatrix();
    // 逆旋转：R_pelvis = R_torso * R_waist^T
    Eigen::Matrix3f R_pelvis = R_torso * RzWaist.transpose();
    Eigen::Quaternionf q_pelvis(R_pelvis);
    // 角速度转换（需扣除腰部旋转偏航角速度）
    Eigen::Vector3f w = RzWaist * imu_omega - Eigen::Vector3f(0.0f, 0.0f, waist_yaw_omega);
    return {q_pelvis, w};
}

// 2. 主循环 run() 中的动态调用
if (imu_type == "torso")
{
    int waist_motor_idx = arm_waist_joint2motor_idx[0];
    float waist_yaw = low_state->motor_state()[waist_motor_idx].q();
    float waist_yaw_omega = low_state->motor_state()[waist_motor_idx].dq();

    Eigen::Quaternionf imu_quat(
        low_state->imu_state().quaternion()[0], low_state->imu_state().quaternion()[1],
        low_state->imu_state().quaternion()[2], low_state->imu_state().quaternion()[3]);
    Eigen::Vector3f imu_omega(
        low_state->imu_state().gyroscope()[0], low_state->imu_state().gyroscope()[1],
        low_state->imu_state().gyroscope()[2]);

    auto [q_pelvis, w_pelvis] = transform_imu_data(waist_yaw, waist_yaw_omega, imu_quat, imu_omega);
    Eigen::Matrix3f R = q_pelvis.toRotationMatrix();
    // 拼装前向观测向量 obs
    for (int i = 0; i < 3; i++)
    {
        obs(i) = ang_vel_scale * w_pelvis[i];
        obs(i + 3) = -R(2, i);
    }
}
```

### 3.3 双推理引擎支持与推理逻辑重构 (Policy 类封装)

为了同时支持 TorchScript (`.pt`) 与 ONNX (`.onnx`) 模型推理，并保持控制器代码的整洁与解耦，我们引入了独立的 `Policy` 类进行封装：

* **动态引擎识别与加载**：在 `Policy` 类的构造函数中，通过识别 `policy_path` 文件的后缀名判断模型类型：
  * **ONNX 引擎**：若为 `.onnx` 后缀，则启动 **ONNX Runtime** C++ 引擎。通过创建 `Ort::Session` 并动态提取模型的输入输出节点名称，免除了对节点名的硬编码。
  * **TorchScript 引擎**：若为 `.pt` 后缀，则通过 **LibTorch** 的 `torch::jit::load` 加载 TorchScript 模型。
* **前向推理封装 (`forward`)**：调用者只需执行 `policy->forward(obs)` 即可获取原始的推理动作向量 `act`。复杂的内部数据封装与张量转换逻辑（如 ONNX Value 创建、LibTorch Tensor 的共享与拷贝）均在 `Policy` 内部闭环完成。
* **后处理封装 (`post_process`)**：后处理逻辑（即动作乘上 `action_scale` 并加算 `default_angles`）被移至 `policy->post_process(act)` 统一计算，外部控制器直接获取目标关节位置数据并直接赋值到低层命令。

```cpp
Eigen::VectorXf Policy::forward(const Eigen::VectorXf& obs)
{
    Eigen::VectorXf act(num_actions);
    act.setZero();

    if (use_onnx)
    {
        std::vector<int64_t> input_shape = {1, static_cast<int64_t>(obs.size())};
        auto memory_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
        Ort::Value input_tensor = Ort::Value::CreateTensor<float>(
            memory_info, const_cast<float*>(obs.data()), obs.size(), input_shape.data(), input_shape.size()
        );
        auto output_tensors = ort_session->Run(
            Ort::RunOptions{nullptr}, input_names_char.data(), &input_tensor, 1, output_names_char.data(), 1
        );
        float* output_data = output_tensors[0].GetTensorMutableData<float>();
        std::memcpy(act.data(), output_data, act.size() * sizeof(float));
    }
    else
    {
        torch::NoGradGuard no_grad;
        torch::Tensor torch_tensor = torch::from_blob(const_cast<float*>(obs.data()), {1, obs.size()}, torch::kFloat).clone();
        std::vector<torch::jit::IValue> inputs;
        inputs.push_back(torch_tensor);
        torch::Tensor output_tensor = module.forward(inputs).toTensor();
        std::memcpy(act.data(), output_tensor.data_ptr<float>(), output_tensor.size(1) * sizeof(float));
    }
    return act;
}
```

* **Controller 接口**：重构后，`Controller` 内部不再包含任何 LibTorch 或 ONNX Runtime 的底层逻辑与成员变量，模型推理核心逻辑简化为两行：
  ```cpp
  act = policy->forward(obs);
  Eigen::VectorXf target_angles = policy->post_process(act);
  ```
* **CMake 模块配置**：在 `CMakeLists.txt` 中添加了详尽的 ONNX Runtime 包含目录和链接库配置的注释模板，开发者下载好 ONNX Runtime SDK 库后一键解除注释即可编译。


