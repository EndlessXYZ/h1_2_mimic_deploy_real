
**本篇目的**：
为了能在真实机载算力上运行重构后的双后端控制器，必须先搭建对应的底层依赖库环境。本篇的目的是在严格遵守“隔离安装依赖”与“零侵入开发”规范的前提下，记录如何下载并隔离配置 LibTorch (CPU) 与 ONNX Runtime C++ SDK 物理库，同时安装 Python 侧 of ONNX 相关转换工具，并最终修改 CMakeLists.txt 实现 `h1_2_walk_deploy_real/cpp_h1_2` 控制器的成功编译。

**在部署系列中的顺序与承接关系**：
在第三篇针对 H1-2 机型和 ONNX 模型完成代码架构的迁移重构与双后端推理支持后，本篇作为第四篇，完成了 C++ 运行环境的配置与编译验证，为后续仿真联调提供了物理可执行文件。完成本篇的编译后，我们将在第五篇《14 Onnx-CppSDK 仿真部署实验 P2 键盘输入.md》中对控制器的 DDS 通信与 MuJoCo 仿真器进行键盘模拟联调。

---

## 1. 实验基本设计

为了支持 `cpp_h1_2` 的 TorchScript / ONNX 双后端推理框架，实验设计了依赖与源码解耦的隔离部署方案：

1. **双后端推理支持**：
   - **TorchScript 后端**：通过 `LibTorch` 运行时加载 `motion.pt`。
   - **ONNX 后端**：通过 `ONNX Runtime C++ SDK` 加载 `.onnx` 策略模型。
2. **目录隔离设计**：主工作目录 `~/Documents/unitree_h1` 结构映射如下：
   - **源码仓库**：`h1_2_walk_deploy_real/cpp_h1_2`
   - **原始下载包暂存**：
     - `downloads/cppsdk/`：存放 LibTorch 压缩包。
     - `downloads/onnx/`：存放 ONNX Runtime 压缩包与 Python 离线 wheel。
   - **隔离依赖库落点**：
     - `local_deps/h1_2_deploy_real/libtorch/`
     - `local_deps/h1_2_deploy_real/onnxruntime/`
   - **Conda 虚拟环境**：复用既有的 `~/.conda/envs/unitree-rl-sim2sim-py310` 环境，承载 Python 侧 ONNX 工具链。

---

## 2. 推理环境与依赖隔离部署

### 2.1 原始文件下载
在进行离线安装之前，需先将 `LibTorch`、`ONNX Runtime C++ SDK` 以及 Python 侧 ONNX wheel 下载到工作区下的统一下载目录中。

#### 2.1.1 创建下载目录
```bash
mkdir -p ~/Documents/unitree_h1/downloads/cppsdk
mkdir -p ~/Documents/unitree_h1/downloads/onnx
```

#### 2.1.2 下载 `LibTorch`

```bash
cd ~/Documents/unitree_h1/downloads/cppsdk

wget -c --content-disposition \
  'https://download.pytorch.org/libtorch/cpu/libtorch-cxx11-abi-shared-with-deps-2.3.1%2Bcpu.zip'
```

#### 2.1.3 下载 Python 侧 ONNX 工具链 wheel 与 ONNX Runtime C++ SDK
```bash
cd ~/Documents/unitree_h1/downloads/onnx

wget -c \
  'https://files.pythonhosted.org/packages/f5/3d/d28484e5d87d4500db0d3b44836d9cd31d88f1efbe168356dbb1dd4f2571/onnx-1.16.2-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl'

wget -c \
  'https://files.pythonhosted.org/packages/04/da/cd671caf4231942c4f68bf0dc1a959303df91dfd0e1d55c556b924d8e68e/onnxruntime-1.18.1-cp310-cp310-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl'

wget -c \
  'https://files.pythonhosted.org/packages/d9/6e/80c77b5c6ec079994295e6e685097fa42732a1e7c5a22fe9c5c4ca1aac74/onnxsim-0.4.36-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl'

wget -c --content-disposition \
  'https://github.com/microsoft/onnxruntime/releases/download/v1.18.1/onnxruntime-linux-x64-1.18.1.tgz'
```

### 2.2 Python 侧 ONNX 工具链安装
复用已有的 Python 3.10 仿真虚拟环境，并通过离线方式安装 ONNX 运行与图简化工具。

为防止 ROS Humble 相关的 `PYTHONPATH` 环境变量污染 Conda 环境，需显式声明清空：
```bash
cd ~/Documents/unitree_h1

# 激活环境并离线安装 Python ONNX 工具链 wheel
source ~/miniconda3/etc/profile.d/conda.sh
conda activate ~/.conda/envs/unitree-rl-sim2sim-py310

env -u PYTHONPATH pip install \
  ~/Documents/unitree_h1/downloads/onnx/onnx-1.16.2-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl \
  ~/Documents/unitree_h1/downloads/onnx/onnxruntime-1.18.1-cp310-cp310-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl \
  ~/Documents/unitree_h1/downloads/onnx/onnxsim-0.4.36-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
```

### 2.3 C++ 侧运行时解压
将运行时解包至工作区外的独立依赖目录下（`local_deps`），保障源码库的干净程度：
```bash
cd ~/Documents/unitree_h1

# 创建隔离落点目录
mkdir -p local_deps/h1_2_deploy_real/libtorch
mkdir -p local_deps/h1_2_deploy_real/onnxruntime

# 解压 LibTorch 与 ONNX Runtime C++ SDK
unzip -q -o \
  downloads/cppsdk/libtorch-cxx11-abi-shared-with-deps-2.3.1+cpu.zip \
  -d local_deps/h1_2_deploy_real

tar -xzf \
  downloads/onnx/onnxruntime-linux-x64-1.18.1.tgz \
  -C local_deps/h1_2_deploy_real/onnxruntime
```

---

## 3. C++ 编译接入与仓库内建配置

### 3.1 `CMakeLists.txt`

修改`h1_2_walk_deploy_real/cpp_h1_2/CMakeLists.txt`：

```cmake
cmake_minimum_required(VERSION 3.16)
project(h1_2_walk_deploy_real)

set(CMAKE_BUILD_TYPE Debug)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# 隔离路径（SDK 通过 CMAKE_INSTALL_PREFIX 安装至 local_deps 时使用，推荐）
include_directories(~/Documents/unitree_h1/local_deps/usr/include/ddscxx)
include_directories(~/Documents/unitree_h1/local_deps/usr/include/iceoryx/v2.0.2)
# 系统安装时使用（备用）：
# include_directories(/usr/local/include/ddscxx)
# include_directories(/usr/local/include/iceoryx/v2.0.2)

set(DEFAULT_LOCAL_DEPS_ROOT "~/Documents/unitree_h1/local_deps/h1_2_deploy_real")
set(LIBTORCH_ROOT "${DEFAULT_LOCAL_DEPS_ROOT}/libtorch" CACHE PATH "Path to the extracted LibTorch root")
set(ONNXRUNTIME_ROOT "${DEFAULT_LOCAL_DEPS_ROOT}/onnxruntime/onnxruntime-linux-x64-1.18.1" CACHE PATH "Path to the extracted ONNX Runtime root")

list(APPEND CMAKE_PREFIX_PATH "${LIBTORCH_ROOT}/share/cmake")
find_package(Torch REQUIRED)
include_directories(${TORCH_INCLUDE_DIRS})
include_directories("${ONNXRUNTIME_ROOT}/include")

aux_source_directory(. SRC_LIST)
add_executable(${PROJECT_NAME} ${SRC_LIST})

find_package(yaml-cpp REQUIRED)
if (TARGET yaml-cpp::yaml-cpp)
  set(YAML_CPP_TARGET yaml-cpp::yaml-cpp)
elseif(TARGET yaml-cpp)
  set(YAML_CPP_TARGET yaml-cpp)
else()
  message(FATAL_ERROR "yaml-cpp target not found")
endif()

target_link_libraries(${PROJECT_NAME}
  unitree_sdk2
  ddsc
  ddscxx
  ${TORCH_LIBRARIES}
  ${YAML_CPP_TARGET}
  "${ONNXRUNTIME_ROOT}/lib/libonnxruntime.so"
  pthread
)
```

使其原生支持以下能力：

1. **隔离路径下的 LibTorch**
   - 通过 `LIBTORCH_ROOT` 指向：
     - `~/Documents/unitree_h1/local_deps/h1_2_deploy_real/libtorch`
2. **隔离路径下的 ONNX Runtime**
   - 通过 `ONNXRUNTIME_ROOT` 指向：
     - `~/Documents/unitree_h1/local_deps/h1_2_deploy_real/onnxruntime/onnxruntime-linux-x64-1.18.1`
3. **Ubuntu 22.04 下的 `yaml-cpp` target 兼容**
   - 同时兼容：
     - `yaml-cpp::yaml-cpp`
     - `yaml-cpp`


### 3.2 编译与构建指令
```bash
cd ~/Documents/unitree_h1/h1_2_walk_deploy_real/cpp_h1_2
mkdir -p build

# CMake 配置，显式指定 LibTorch 路径
cmake -S . -B build -DTorch_DIR=~/Documents/unitree_h1/local_deps/h1_2_deploy_real/libtorch/share/cmake/Torch

# 执行本地多核编译
cmake --build build -j4
```
**编译结果**：控制台正确输出 `[100%] Built target h1_2_walk_deploy_real`，表明本地构建成功。
