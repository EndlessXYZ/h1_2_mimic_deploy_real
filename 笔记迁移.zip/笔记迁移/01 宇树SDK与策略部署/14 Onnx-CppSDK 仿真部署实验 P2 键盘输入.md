
参考：https://blog.csdn.net/qq_56908984/article/details/161085149

**在部署系列中的全局定位**：C++ 仿真部署实验的第二部分。解决仿真环境中无实体手柄的难题——通过修改 unitree_mujoco 仿真器源码添加键盘模拟手柄功能，打通"控制器 + MuJoCo + 键盘输入"的完整闭环联调链路。

**本篇目的**：
由于 C++ 控制器（`h1_2_walk_deploy_real`）在启动后依赖手柄遥控器信号来推进状态机（如 ZeroTorque -> MoveToDefault -> RunController），而在普通仿真环境中通常没有真实的手柄硬件与输入设备，本篇的目的是记录如何修改 `unitree_mujoco` 仿真器的源码（添加 `keyboard` 摇杆分支并消解与原生 UI 冲突的按键回调），从而通过键盘按键（Enter/Space/WASD/Tab）完美模拟手柄控制信号，实现无硬件条件下的 C++ 控制器与 MuJoCo 仿真器闭环联调行走验证。


---

## 1. 修改目标与总体策略

本次实验的目标是解决这样一个现实问题：

- `cpp_h1_2` 控制器在启动后会等待 `wireless_remote` 中的 `start`、`A`、`select`
- 但仿真时一般没有 `/dev/input/js0`，也没有 Xbox / Switch 手柄
- 若不提供遥控器输入，`motion.pt` 路线即使编译成功，也无法真正进入步态控制循环

因此，本实验采用**键盘模拟手柄**的方式，在官方 MuJoCo 仿真器内部补出 `wireless_remote` 输入源，并最终完成 C++ 控制器的 `motion.pt` 路线测试。


本次修改目标非常明确：

1. 直接在 `unitree_mujoco` 中增加一种新的 `joystick_type: "keyboard"`
2. 保持 Xbox / Switch 手柄逻辑不受影响

---

## 2. 实际修改文件

本次实际修改了 5 个文件：

1. `unitree_mujoco/simulate/src/physics_joystick.h`
2. `unitree_mujoco/simulate/src/unitree_sdk2_bridge.h`
3. `unitree_mujoco/simulate/src/main.cc`
4. `unitree_mujoco/simulate/mujoco/simulate/simulate.cc`
5. `unitree_mujoco/simulate/config.yaml`

这些修改都集中在：

- 键盘输入采样
- 键盘事件与 MuJoCo UI 冲突消解
- 配置切换到 `keyboard`

---

## 3. 修改内容详解

### 3.1 `physics_joystick.h`：新增 `KeyboardJoystick`

在原有：

- `XBoxJoystick`
- `SwitchJoystick`

之外，新增了：

- `KeyboardJoystick`

它直接继承 `unitree::common::UnitreeJoystick`，并通过：

```cpp
glfwGetKey(window_, ...)
```

轮询 MuJoCo 主窗口当前的键盘状态。(注意不是终端按键)


### 3.2 键盘到手柄的映射

本次实际采用的映射如下。

#### 摇杆 / 扳机

- `W / S` -> 左摇杆 `ly`
- `A / D` -> 左摇杆 `lx`
- `↑ / ↓` -> 右摇杆 `ry`
- `← / →` -> 右摇杆 `rx`
- `Q` -> `LT`
- `E` -> `RT`

#### 按钮

- `Space` -> `A`
- `Left Shift` -> `B`
- `F` -> `X`
- `G` -> `Y`
- `C` -> `LB`
- `V` -> `RB`
- `Enter` -> `start`
- `Tab` -> `back/select`
- `Z` -> `LS`
- `X` -> `RS`
- `1` -> `F1`
- `2` -> `F2`

### 3.3 `unitree_sdk2_bridge.h`：新增 `keyboard` 分支

在桥接层里，本来只支持：

- `xbox`
- `switch`

本次新增：

```cpp
else if(param::config.joystick_type == "keyboard") {
    joystick = std::make_shared<KeyboardJoystick>(g_sim_window);
}
```

这一步的意义在于：让原有的 `lowstate->joystick->update()` 发布链保持不变，只是把底层输入源从手柄换成键盘。

### 3.4 `main.cc`：增加 GLFW 窗口指针与链式回调

为了让 `KeyboardJoystick` 能访问当前 MuJoCo 窗口，本次增加了：

```cpp
GLFWwindow* g_sim_window = nullptr;
```

同时增加：

```cpp
GLFWkeyfun s_mujoco_key_callback = nullptr;
```

用于保存 MuJoCo 原本注册的键盘回调函数。

随后在 `main()` 中将：

```cpp
g_sim_window = static_cast<mj::GlfwAdapter*>(sim->platform_ui.get())->window_;
s_mujoco_key_callback = glfwSetKeyCallback(g_sim_window, user_key_cb);
```

这样 `user_key_cb` 就不再是简单覆盖，而是**链式回调**：

1. 先调用 MuJoCo 原生回调
2. 再处理弹性带、复位等自定义按键逻辑

### 3.5 `simulate.cc`：屏蔽冲突热键

如果不做额外处理，MuJoCo 本身会占用很多键盘按键：

- `Space`
- 方向键
- `Tab`
- 以及一部分 UI 导航键

这些键与本次“键盘手柄”映射完全冲突。

因此在 `UiEvent()` 最开始，对下列按键做了直接拦截并 `return`：

- `W A S D`
- `Q E`
- `F G`
- `C V`
- `Z X`
- `1 2`
- `Space`
- `Left Shift`
- `Left Right Up Down`
- `Tab`
- `Enter`

这样这些按键就不会再被 MuJoCo UI 自己吃掉，而只用于模拟遥控器输入。

### 3.6 `simulate/config.yaml`：切到键盘模式

最终把配置从：

```yaml
use_joystick: 0
joystick_type: "xbox"
```

改成：

```yaml
use_joystick: 1
joystick_type: "keyboard"
```

这表示：

1. 启用遥控器模拟
2. 输入源不是实体手柄，而是 MuJoCo 窗口键盘

---

## 4. 重新编译 `unitree_mujoco`

配置：

```bash
cd ~/Documents/unitree_h1/unitree_mujoco/simulate
cmake -S . -B build \
      -DCMAKE_CXX_FLAGS='-I~/Documents/unitree_h1/local_deps/usr/include' \
      -DCMAKE_EXE_LINKER_FLAGS='-L~/Documents/unitree_h1/local_deps/usr/lib'
```

然后编译：

```bash
cd ~/Documents/unitree_h1/unitree_mujoco/simulate
cmake --build build -j4
```


---

## 5. `motion.pt` 路线联调测试

### 5.1 测试目标

本次测试不是 ONNX，而是先走现成的：

```text
~/Documents/unitree_h1/unitree_rl_gym/deploy/pre_train/h1_2/motion.pt
```

即：

- `cpp_h1_2` 编译产物
- `motion.pt`
- `unitree_mujoco` 键盘手柄模拟

组合联调。

### 5.2 启动 MuJoCo

实际启动命令：

```bash
cd ~/Documents/unitree_h1/unitree_mujoco/simulate
export DISPLAY=:10
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6  # conda 环境需绕过 libstdc++ 冲突
env LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH \
stdbuf -oL -eL \
./build/unitree_mujoco \
  -i 0 -n lo -r h1_2 -s scene.xml
```

日志保存到：

```text
~/Documents/unitree_h1/artifacts/unitree_mujoco_keyboard_20260617.log
```

### 5.3 启动 C++ 控制器

实际启动命令(注意提前把之前的旧线程Kill掉）：

```bash
cd ~/Documents/unitree_h1/h1_2_walk_deploy_real/cpp_h1_2
env LEGGED_GYM_ROOT_DIR=~/Documents/unitree_h1/unitree_rl_gym \
    YAML_CONFIG_PATH=~/Documents/unitree_h1/h1_2_walk_deploy_real/configs/h1_2.yaml \
    LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 \
    LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/h1_2_deploy_real/libtorch/lib:~/Documents/unitree_h1/local_deps/h1_2_deploy_real/onnxruntime/onnxruntime-linux-x64-1.18.1/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH \
    stdbuf -oL -eL \
    ./build/h1_2_walk_deploy_real lo
```

日志保存到：

```text
~/Documents/unitree_h1/artifacts/h1_2_cpp_motion_pt_20260617.log
```

### 5.4 键盘触发流程

由于当前环境没有实体手柄，本次实际通过聚焦 MuJoCo 窗口后发送键盘事件完成状态推进：

1. `Enter`
   - 对应 `start`
   - 让控制器退出 `zero_torque_state`
2. `Space`
   - 对应 `A`
   - 让控制器退出默认位姿等待并进入 `run`
3. `W A S D`
   - 对应右摇杆
   - 让控制器前后左右移动
4. `Tab`
   - 对应 `select`
   - 让控制器退出 `run` 进入 `damping`

### 5.5 彻底清理环境

联调测试完成后，为避免后台残留进程占用 CPU 或 DDS 通信端口导致下一次运行失败，请在终端执行以下命令彻底清理：

```bash
pkill -9 -f 'unitree_mujoco' || true
pkill -9 -f 'h1_2_walk_deploy_real' || true
```

---

## 6. 实际测试结果

首先是 MuJoCo 仿真侧结果：

1. 仿真器正常拉起，没有崩溃或打印新的错误
2. 场景加载正常，机器人出现在初始位置
3. 键盘输入被正确捕获并转换为遥控器信号
4. `start` -> `run` -> `damping` 状态切换流程正常

此外 C++ 控制器日志：

```text
Loading policy from: ~/Documents/unitree_h1/unitree_rl_gym/deploy/pre_train/h1_2/motion.pt
TorchScript model loaded successfully!
... selected interface "lo" is not multicast-capable: disabling multicast
Controller init done!
zero_torque_state, press start
move_to_default_pos, press A
run controller, press select
damping
```

这段日志说明：

1. `motion.pt` 已成功加载
2. DDS `lo` 回环链路已连通
3. 键盘模拟确实把 `start` 注入进了 `wireless_remote`
4. 键盘模拟确实把 `A` 注入进了 `wireless_remote`
5. 控制器已经进入了 `run controller` 主循环
6. 最终顺利进入 `damping`

也就是说，**`motion.pt + cpp_h1_2 + 键盘手柄模拟 + MuJoCo` 这条链已经被真正跑通了一次。**