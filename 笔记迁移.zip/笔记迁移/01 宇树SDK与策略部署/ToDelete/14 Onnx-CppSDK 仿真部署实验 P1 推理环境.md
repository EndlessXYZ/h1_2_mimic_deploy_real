# 14 Onnx-CppSDK 仿真部署实验 P1 推理环境

本篇介绍如何隔离部署 LibTorch (CPU) 与 ONNX Runtime C++ SDK，并配置 CMakeLists.txt 编译控制器。

---

## 1. 物理依赖隔离部署

为支持双后端推理，需解耦第三方依赖与系统环境：
* **暂存路径**：`downloads/` (包含下载的 zip/tgz/whl)
* **安装路径**：`local_deps/h1_2_deploy_real/` (下设 `libtorch/` 与 `onnxruntime/`)
* **Python 隔离环境**：`~/.conda/envs/unitree-rl-sim2sim-py310`

### 1.1 一键下载与解压命令
```bash
cd ~/Documents/unitree_h1
mkdir -p downloads/cppsdk downloads/onnx local_deps/h1_2_deploy_real/onnxruntime

# 下载 C++ SDK & Whl 工具包
wget -P downloads/cppsdk https://download.pytorch.org/libtorch/cpu/libtorch-cxx11-abi-shared-with-deps-2.3.1%2Bcpu.zip
wget -P downloads/onnx https://github.com/microsoft/onnxruntime/releases/download/v1.18.1/onnxruntime-linux-x64-1.18.1.tgz
wget -P downloads/onnx https://files.pythonhosted.org/packages/f5/3d/d28484e5d87d4500db0d3b44836d9cd31d88f1efbe168356dbb1dd4f2571/onnx-1.16.2-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl

# 解压至隔离的本地依赖目录
unzip -q downloads/cppsdk/*.zip -d local_deps/h1_2_deploy_real/
tar -xzf downloads/onnx/*.tgz -C local_deps/h1_2_deploy_real/onnxruntime/
```

### 1.2 离线安装 Python 侧 ONNX 工具
在 Conda 虚拟环境下安装离线 Wheels，需显式清理 `PYTHONPATH` 环境变量：
```bash
cd ~/Documents/unitree_h1
conda activate unitree-rl-sim2sim-py310
env -u PYTHONPATH pip install downloads/onnx/*.whl
```

---

## 2. C++ 编译集成

在 CMakeLists.txt 中指向上述隔离路径：
```cmake
set(DEFAULT_LOCAL_DEPS_ROOT "~/Documents/unitree_h1/local_deps/h1_2_deploy_real")
set(LIBTORCH_ROOT "${DEFAULT_LOCAL_DEPS_ROOT}/libtorch" CACHE PATH "Path to LibTorch")
set(ONNXRUNTIME_ROOT "${DEFAULT_LOCAL_DEPS_ROOT}/onnxruntime/onnxruntime-linux-x64-1.18.1" CACHE PATH "Path to ORT")

list(APPEND CMAKE_PREFIX_PATH "${LIBTORCH_ROOT}/share/cmake")
find_package(Torch REQUIRED)
include_directories(${TORCH_INCLUDE_DIRS} "${ONNXRUNTIME_ROOT}/include")
target_link_libraries(${PROJECT_NAME} unitree_sdk2 ddsc ddscxx ${TORCH_LIBRARIES} yaml-cpp "${ONNXRUNTIME_ROOT}/lib/libonnxruntime.so" pthread)
```

运行编译：
```bash
cd ~/Documents/unitree_h1/h1_2_walk_deploy_real/cpp_h1_2
cmake -S . -B build -DTorch_DIR=~/Documents/unitree_h1/local_deps/h1_2_deploy_real/libtorch/share/cmake/Torch
cmake --build build -j4
```
