# 15 Onnx-CppSDK 仿真部署实验 P2 键盘输入

本篇记录修改 `unitree_mujoco` 源码以实现键盘模拟手柄控制信号，打通 C++ 控制器与 MuJoCo 仿真器闭环联调的实施方案。

---

## 1. 模拟方案与修改文件

为在无手柄硬件下推进控制器的 FSM（`ZeroTorque -> MoveToDefault -> RunController`），在仿真中添加 `joystick_type: "keyboard"` 输入源：

* **按键映射**：`W/S/A/D` $\to$ 左摇杆（控制速度），方向键 $\to$ 右摇杆；`Space` $\to$ `A` 键（网络托管）；`Enter` $\to$ `Start`（线性上电）；`Tab` $\to$ `Select`（急停/阻尼）。
* **修改的文件**：
  1. **physics_joystick.h**：实现 `KeyboardJoystick` 类，使用 `glfwGetKey` 获取键盘状态。
  2. **unitree_sdk2_bridge.h**：新增 `"keyboard"` 选项分支以构建 `KeyboardJoystick`。
  3. **main.cc**：引出并挂载全局 `GLFWwindow*` 窗口指针，实现键盘链式回调。
  4. **simulate.cc**：拦截 `Space`、方向键、`Tab`、`Enter` 等热键，消解与 MuJoCo UI 导航冲突。
  5. **config.yaml**：启用并切换模式：`use_joystick: 1` 和 `joystick_type: "keyboard"`。

---

## 2. 编译与闭环测试

### 2.1 编译仿真器
```bash
cd ~/Documents/unitree_h1/unitree_mujoco/simulate
cmake -S . -B build -DCMAKE_CXX_FLAGS='-I~/Documents/unitree_h1/local_deps/usr/include' -DCMAKE_EXE_LINKER_FLAGS='-L~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu'
cmake --build build -j4
```

### 2.2 启动联调测试 (以后台挂载为例)
```bash
# 1. 启动 MuJoCo 仿真器
cd ~/Documents/unitree_h1/unitree_mujoco/simulate
env LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH \
  ./build/unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml > /dev/null 2>&1 &

# 2. 启动 C++ 控制器 (主线程在 cpp_h1_2 中定义)
cd ~/Documents/unitree_h1/h1_2_walk_deploy_real/cpp_h1_2
env LEGGED_GYM_ROOT_DIR=~/Documents/unitree_h1/unitree_rl_gym \
    YAML_CONFIG_PATH=~/Documents/unitree_h1/h1_2_walk_deploy_real/configs/h1_2.yaml \
    LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/h1_2_deploy_real/libtorch/lib:~/Documents/unitree_h1/local_deps/h1_2_deploy_real/onnxruntime/onnxruntime-linux-x64-1.18.1/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH \
    ./build/h1_2_walk_deploy_real lo > /dev/null 2>&1 &
```

### 2.3 状态触发控制步骤
1. 鼠标点击并聚焦 MuJoCo 仿真窗口。
2. 按 **`Enter`** 键平滑上电，锁定默认姿态。
3. 按 **`Space`** 键激活步态策略，机器人开始原地踏步。
4. 按 **`W/A/S/D`** 键操纵机器人移动。
5. 按 **`Tab`** 键触发急停并阻尼下蹲。

测试完毕后，在控制台执行一键清理：
```bash
cd ~/Documents/unitree_h1
pkill -9 -f 'unitree_mujoco' || true
pkill -9 -f 'h1_2_walk_deploy_real' || true
```
