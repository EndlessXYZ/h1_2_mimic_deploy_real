# 16 Onnx-CppSDK 仿真部署实验 P3 检验输出

本篇介绍通过离线轨迹采样和数值回放比对，验证 C++ 控制器与 Python 仿真、TorchScript 与 ONNX 在物理观测和前向推理动作输出上的数值精度一致性。

---

## 1. 校验工具与逻辑

校验共涉及以下脚本：
* **capture_python_rollout.py**：捕获 Python 仿真中的机器人状态并保存为 `.npz` 基准包。
* **policy_replay_dump.cpp**：C++ 离线工具，读取采样输入并调用策略推理动作输出。
* **compare_raw_state_obs.py**：计算并提取两端的最大绝对误差 (Max Abs Error)。

### 1.1 校验逻辑
1. **推理一致性**：为两端推理引擎提供完全相同的观测（obs）输入，比对网络动作（act）输出差值，用以验证 ONNX Runtime 与 JIT 后端的等价性。
2. **物理计算一致性**：在 Python 离线端模拟 C++ 的 IMU 四元数/角速度转换算法（躯干到骨盆坐标系变换），对比重组后的 obs 与仿真记录的 obs，验证 C++ 空间投影逻辑。

---

## 2. 校验执行流程

### 2.1 编译 C++ 离线工具并采样
```bash
cd ~/Documents/unitree_h1/h1_2_walk_deploy_real/cpp_h1_2
cmake --build build --target policy_replay_dump -j4

# 运行 Python 采样
cd ~/Documents/unitree_h1/h1_2_walk_deploy_real
env -u PYTHONPATH ~/.conda/envs/unitree-rl-sim2sim-py310/bin/python tools/capture_python_rollout.py
```

### 2.2 导出 ONNX 模型并进行严格对比
```bash
cd ~/Documents/unitree_h1

# 1. 导出 ONNX 格式模型
~/.conda/envs/unitree-rl-sim2sim-py310/bin/python -c '
import torch
model = torch.jit.load("~/Documents/unitree_h1/unitree_rl_gym/deploy/pre_train/h1_2/motion.pt")
torch.onnx.export(model, torch.randn(1, 47), "~/Documents/unitree_h1/unitree_rl_gym/deploy/pre_train/h1_2/motion.onnx",
                  input_names=["input"], output_names=["output"], opset_version=12)
'

# 2. 复制配置文件指向 onnx 并运行比对
cd ~/Documents/unitree_h1/h1_2_walk_deploy_real
cp configs/h1_2.yaml configs/h1_2_onnx.yaml
sed -i 's/motion.pt/motion.onnx/g' configs/h1_2_onnx.yaml
env -u PYTHONPATH ~/.conda/envs/unitree-rl-sim2sim-py310/bin/python tools/compare_raw_state_obs.py configs/h1_2_onnx.yaml
```

---

## 3. 校验结果与结论

### 3.1 最大绝对误差汇总

| 对比项 | PT (.pt) 模式最大绝对误差 | ONNX (.onnx) 模式最大绝对误差 | 校验结论 |
| :--- | :---: | :---: | :--- |
| **C++ 观测重建 vs Python 仿真观测** | $2.98 \times 10^{-8}$ | $2.98 \times 10^{-8}$ | 验证了 C++ IMU（Torso 到 Pelvis）坐标转换计算正确 |
| **Python 推理 vs C++ 推理 (同一观测)** | $7.75 \times 10^{-7}$ | $4.77 \times 10^{-7}$ | 验证了 LibTorch/ONNX Runtime 推理器的数学一致性 |
| **C++ 最终关节目标位置误差** | $6.56 \times 10^{-7}$ | $2.38 \times 10^{-7}$ | 误差极小，对控制指令输出的影响微乎其微，具备实机部署安全 |

### 3.2 结论
两端动作输出的最大绝对误差控制在 $10^{-7}$ 量级，计算与推理链路双后端完全对齐，验证了 C++ 移植后 Policy 引擎与坐标变换物理计算的正确性。
