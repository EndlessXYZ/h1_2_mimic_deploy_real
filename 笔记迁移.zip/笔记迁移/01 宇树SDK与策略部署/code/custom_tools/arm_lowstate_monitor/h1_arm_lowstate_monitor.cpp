#include <array>
#include <chrono>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <thread>
#include <mutex>
#include <atomic>

#include <unitree/idl/hg/LowState_.hpp>
#include <unitree/robot/channel/channel_factory.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>

namespace {

constexpr char kTopicState[] = "rt/lowstate";

enum JointIndex {
  kLeftShoulderPitch = 13,
  kLeftShoulderRoll = 14,
  kRightShoulderPitch = 20,
  kRightShoulderRoll = 21,
};

constexpr std::array<int, 4> kTrackedJoints = {
    kLeftShoulderPitch,
    kLeftShoulderRoll,
    kRightShoulderPitch,
    kRightShoulderRoll,
};

constexpr std::array<const char*, 4> kTrackedJointNames = {
    "left_shoulder_pitch",
    "left_shoulder_roll",
    "right_shoulder_pitch",
    "right_shoulder_roll",
};

}  // namespace

// ==========================================
// 辅助代码 (Auxiliary Code)
// ==========================================

// 命令行参数解析与校验
struct CommandLineArgs {
  std::string network_interface;
  std::string output_csv;
  double duration_sec = 8.0;

  static bool Parse(int argc, char const* argv[], CommandLineArgs& args) {
    if (argc < 3) {
      std::cerr << "Usage: " << argv[0]
                << " network_interface output_csv [duration_sec]\n";
      return false;
    }

    args.network_interface = argv[1];
    args.output_csv = argv[2];
    if (argc >= 4) {
      try {
        args.duration_sec = std::stod(argv[3]);
      } catch (const std::exception& e) {
        std::cerr << "Invalid duration_sec argument. Using default 8.0s.\n";
        args.duration_sec = 8.0;
      }
    }
    return true;
  }
};

// CSV文件记录器
class CsvLogger {
public:
  explicit CsvLogger(const std::string& filepath) : filepath_(filepath) {}

  ~CsvLogger() {
    Close();
  }

  bool Open() {
    file_.open(filepath_);
    return file_.is_open();
  }

  void WriteHeader(const std::array<const char*, 4>& joint_names) {
    if (!file_.is_open()) return;
    file_ << "time_sec,imu_roll,imu_pitch,imu_yaw";
    for (const char* name : joint_names) {
      file_ << "," << name;
    }
    file_ << "\n";
  }

  void WriteRow(double time_sec, const unitree_hg::msg::dds_::LowState_& state_msg, const std::array<int, 4>& joint_indices) {
    if (!file_.is_open()) return;
    file_ << std::fixed << std::setprecision(6) << time_sec
          << "," << state_msg.imu_state().rpy().at(0)
          << "," << state_msg.imu_state().rpy().at(1)
          << "," << state_msg.imu_state().rpy().at(2);

    for (int joint : joint_indices) {
      file_ << "," << state_msg.motor_state().at(joint).q();
    }
    file_ << "\n";
  }

  void Close() {
    if (file_.is_open()) {
      file_.close();
    }
  }

private:
  std::string filepath_;
  std::ofstream file_;
};

// 关节角度定时打印器
class JointPrinter {
public:
  explicit JointPrinter(double interval_sec = 0.5)
      : interval_sec_(interval_sec), last_print_time_(-interval_sec_) {}

  void PrintIfTime(double current_time, const unitree_hg::msg::dds_::LowState_& state_msg,
                    const std::array<int, 4>& joint_indices, const std::array<const char*, 4>& joint_names) {
    if (current_time - last_print_time_ >= interval_sec_) {
      last_print_time_ = current_time;
      std::cout << std::fixed << std::setprecision(4);
      std::cout << "[Time: " << std::setw(6) << current_time << "s] Joints -> ";
      for (size_t i = 0; i < joint_indices.size(); ++i) {
        int joint_idx = joint_indices[i];
        std::cout << joint_names[i] << ": " << std::setw(7) << state_msg.motor_state().at(joint_idx).q();
        if (i < joint_indices.size() - 1) {
          std::cout << " | ";
        }
      }
      std::cout << std::endl;
    }
  }

private:
  double interval_sec_;
  double last_print_time_;
};

// ==========================================
// 核心代码 (Core Code)
// ==========================================

// DDS 状态订阅器 (线程安全)
class LowStateSubscriber {
public:
  explicit LowStateSubscriber(const std::string& topic_name)
      : topic_name_(topic_name), got_state_(false) {}

  void Init() {
    subscriber_ = std::make_shared<unitree::robot::ChannelSubscriber<unitree_hg::msg::dds_::LowState_>>(topic_name_);
    subscriber_->InitChannel([this](const void* msg) {
      auto* state = static_cast<const unitree_hg::msg::dds_::LowState_*>(msg);
      std::lock_guard<std::mutex> lock(mutex_);
      std::memcpy(&state_msg_, state, sizeof(unitree_hg::msg::dds_::LowState_));
      got_state_ = true;
    }, 1);
  }

  bool WaitForState(double timeout_sec) {
    const auto wait_start = std::chrono::steady_clock::now();
    while (!got_state_) {
      const auto elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - wait_start).count();
      if (elapsed > timeout_sec) {
        return false;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    return true;
  }

  unitree_hg::msg::dds_::LowState_ GetLatestState() {
    std::lock_guard<std::mutex> lock(mutex_);
    return state_msg_;
  }

private:
  std::string topic_name_;
  std::shared_ptr<unitree::robot::ChannelSubscriber<unitree_hg::msg::dds_::LowState_>> subscriber_;
  std::mutex mutex_;
  unitree_hg::msg::dds_::LowState_ state_msg_;
  std::atomic<bool> got_state_;
};

// ==========================================
// 主函数 (Main Function)
// ==========================================

int main(int argc, char const* argv[]) {
  CommandLineArgs args;
  if (!CommandLineArgs::Parse(argc, argv, args)) {
    return 1;
  }

  // 初始化 Channel 工厂
  unitree::robot::ChannelFactory::Instance()->Init(0, args.network_interface);

  // 初始化订阅器并开始监听
  LowStateSubscriber sub(kTopicState);
  sub.Init();

  std::cout << "Waiting for low state on topic '" << kTopicState << "'..." << std::endl;
  if (!sub.WaitForState(5.0)) {
    std::cerr << "Timed out waiting for rt/lowstate\n";
    return 2;
  }
  std::cout << "Successfully connected to topic." << std::endl;

  // 打开 CSV 记录器
  CsvLogger logger(args.output_csv);
  if (!logger.Open()) {
    std::cerr << "Failed to open CSV output file: " << args.output_csv << "\n";
    return 3;
  }
  logger.WriteHeader(kTrackedJointNames);

  // 初始化关节打印器 (默认每 0.5 秒打印一次)
  JointPrinter printer(0.5);

  const auto start = std::chrono::steady_clock::now();
  while (true) {
    const auto now = std::chrono::steady_clock::now();
    const double t = std::chrono::duration<double>(now - start).count();
    if (t > args.duration_sec) {
      break;
    }

    // 获取最新的机器人状态快照 (线程安全)
    unitree_hg::msg::dds_::LowState_ current_state = sub.GetLatestState();

    // 记录到 CSV 文件 (50Hz)
    logger.WriteRow(t, current_state, kTrackedJoints);

    // 终端周期打印关节角 (2Hz)
    printer.PrintIfTime(t, current_state, kTrackedJoints, kTrackedJointNames);

    std::this_thread::sleep_for(std::chrono::milliseconds(20));
  }

  logger.Close();
  std::cout << "Saved monitor data to " << args.output_csv << std::endl;
  return 0;
}
