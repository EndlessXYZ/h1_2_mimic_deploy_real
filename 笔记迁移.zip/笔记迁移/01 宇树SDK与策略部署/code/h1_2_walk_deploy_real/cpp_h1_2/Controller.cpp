#include "Controller.h"
#include <yaml-cpp/yaml.h>
#include <algorithm>
#include <thread>
#include <cstdlib>
#include <iostream>
#include "utilities.h"

#define TOPIC_LOWCMD "rt/lowcmd"
#define TOPIC_LOWSTATE "rt/lowstate"

Controller::Controller(const std::string &net_interface, bool auto_start)
	: mAutoStart(auto_start)
{
        const char* env_config = std::getenv("YAML_CONFIG_PATH");
        std::string config_path = env_config ? std::string(env_config) : "../../configs/h1_2.yaml";
        YAML::Node yaml_node = YAML::LoadFile(config_path);

	leg_joint2motor_idx = yaml_node["leg_joint2motor_idx"].as<std::vector<float>>();
        kps = yaml_node["kps"].as<std::vector<float>>();
        kds = yaml_node["kds"].as<std::vector<float>>();
	default_angles = yaml_node["default_angles"].as<std::vector<float>>();
	arm_waist_joint2motor_idx = yaml_node["arm_waist_joint2motor_idx"].as<std::vector<float>>();
	arm_waist_kps = yaml_node["arm_waist_kps"].as<std::vector<float>>();
	arm_waist_kds = yaml_node["arm_waist_kds"].as<std::vector<float>>();
	arm_waist_target = yaml_node["arm_waist_target"].as<std::vector<float>>();
	ang_vel_scale = yaml_node["ang_vel_scale"].as<float>();
	dof_pos_scale = yaml_node["dof_pos_scale"].as<float>();
	dof_vel_scale = yaml_node["dof_vel_scale"].as<float>();
	action_scale = yaml_node["action_scale"].as<float>();
	cmd_scale = yaml_node["cmd_scale"].as<std::vector<float>>();
	num_actions = yaml_node["num_actions"].as<float>();
	num_obs = yaml_node["num_obs"].as<float>();
	max_cmd = yaml_node["max_cmd"].as<std::vector<float>>();
	imu_type = yaml_node["imu_type"].as<std::string>();

	obs.setZero(num_obs);
	act.setZero(num_actions);

	std::string policy_path_str = yaml_node["policy_path"].as<std::string>();
	std::string root_dir_placeholder = "{LEGGED_GYM_ROOT_DIR}";
	size_t pos = policy_path_str.find(root_dir_placeholder);
	if (pos != std::string::npos)
	{
		const char* env_root = std::getenv("LEGGED_GYM_ROOT_DIR");
		std::string root_dir = env_root ? std::string(env_root) : "../../../unitree_rl_gym";
		policy_path_str.replace(pos, root_dir_placeholder.length(), root_dir);
	}

	policy = std::make_unique<Policy>(policy_path_str, num_obs, num_actions, action_scale, default_angles);

	unitree::robot::ChannelFactory::Instance()->Init(0, net_interface);

	lowcmd_publisher.reset(new unitree::robot::ChannelPublisher<unitree_hg::msg::dds_::LowCmd_>(TOPIC_LOWCMD));
	lowstate_subscriber.reset(new unitree::robot::ChannelSubscriber<unitree_hg::msg::dds_::LowState_>(TOPIC_LOWSTATE));

	lowcmd_publisher->InitChannel();
	lowstate_subscriber->InitChannel(std::bind(&Controller::low_state_message_handler, this, std::placeholders::_1));

	while (!mLowStateBuf.GetDataPtr())
	{
		usleep(100000);
	}
	
	low_cmd_write_thread_ptr = unitree::common::CreateRecurrentThreadEx("low_cmd_write", UT_CPU_ID_NONE, 2000, &Controller::low_cmd_write_handler, this);
	std::cout << "Controller init done!\n";
}

void Controller::zero_torque_state()
{
	const std::chrono::milliseconds cycle_time(20);
	auto next_cycle = std::chrono::steady_clock::now();

	if (mAutoStart)
	{
		std::cout << "zero_torque_state, auto mode: running zero torque for 50 steps...\n";
	}
	else
	{
		std::cout << "zero_torque_state, manual mode: press start...\n";
	}

	int zero_torque_steps = 0;
	while (true)
	{
		if (mAutoStart && zero_torque_steps >= 50)
		{
			break;
		}
		if (!mAutoStart && joy.btn.components.start)
		{
			break;
		}

		auto low_cmd = std::make_shared<unitree_hg::msg::dds_::LowCmd_>();

		for (auto &cmd : low_cmd->motor_cmd())
		{
			cmd.q() = 0;
			cmd.dq() = 0;
			cmd.kp() = 0;
			cmd.kd() = 0;
			cmd.tau() = 0;
		}

		mLowCmdBuf.SetDataPtr(low_cmd);

		zero_torque_steps++;
		next_cycle += cycle_time;
		std::this_thread::sleep_until(next_cycle);
	}
}

void Controller::move_to_default_pos()
{
	if (mAutoStart)
	{
		std::cout << "move_to_default_pos, auto mode: moving to default position...\n";
	}
	else
	{
		std::cout << "move_to_default_pos, manual mode: press A to start...\n";
	}

	const std::chrono::milliseconds cycle_time(20);
	auto next_cycle = std::chrono::steady_clock::now();

	auto low_state = mLowStateBuf.GetDataPtr();	
	std::array<float, 35> jpos;
	for (int i = 0; i < 35; i++)
	{
		jpos[i] = low_state->motor_state()[i].q();
	}

	int num_steps = 100;
	int count = 0;

	while (true)
	{
		bool interpolation_done = (count >= num_steps);
		if (mAutoStart && interpolation_done)
		{
			break;
		}
		if (!mAutoStart && interpolation_done && joy.btn.components.A)
		{
			break;
		}

		auto low_cmd = std::make_shared<unitree_hg::msg::dds_::LowCmd_>();
		float phase = std::clamp<float>(float(count++) / num_steps, 0, 1);
		
		// leg
		int num_leg_joints = leg_joint2motor_idx.size();
		for (int i = 0; i < num_leg_joints; i++)
		{
			int motor_idx = leg_joint2motor_idx[i];
			low_cmd->motor_cmd()[motor_idx].q() = (1 - phase) * jpos[motor_idx] + phase * default_angles[i];
			low_cmd->motor_cmd()[motor_idx].kp() = kps[i];
			low_cmd->motor_cmd()[motor_idx].kd() = kds[i];
			low_cmd->motor_cmd()[motor_idx].tau() = 0.0;
			low_cmd->motor_cmd()[motor_idx].dq() = 0.0;
		}

		// waist arm
		int num_arm_waist_joints = arm_waist_joint2motor_idx.size();
		for (int i = 0; i < num_arm_waist_joints; i++)
		{
			int motor_idx = arm_waist_joint2motor_idx[i];
			low_cmd->motor_cmd()[motor_idx].q() = (1 - phase) * jpos[motor_idx] + phase * arm_waist_target[i];
			low_cmd->motor_cmd()[motor_idx].kp() = arm_waist_kps[i];
			low_cmd->motor_cmd()[motor_idx].kd() = arm_waist_kds[i];
			low_cmd->motor_cmd()[motor_idx].tau() = 0.0;
			low_cmd->motor_cmd()[motor_idx].dq() = 0.0;
		}

		mLowCmdBuf.SetDataPtr(low_cmd);

		next_cycle += cycle_time;
		std::this_thread::sleep_until(next_cycle);
	}
}

void Controller::run()
{
	if (mAutoStart)
	{
		std::cout << "run controller, auto mode: running control loop...\n";
	}
	else
	{
		std::cout << "run controller, manual mode: press select to exit...\n";
	}

	const std::chrono::milliseconds cycle_time(20);
	auto next_cycle = std::chrono::steady_clock::now();

	float period = .8;
	float time = 0;

	while (!joy.btn.components.select)
	{
		auto low_state = mLowStateBuf.GetDataPtr();
		// obs
		Eigen::Matrix3f R;
		if (imu_type == "torso")
		{
			int waist_motor_idx = arm_waist_joint2motor_idx[0];
			float waist_yaw = low_state->motor_state()[waist_motor_idx].q();
			float waist_yaw_omega = low_state->motor_state()[waist_motor_idx].dq();
			
			Eigen::Quaternionf imu_quat(
				low_state->imu_state().quaternion()[0], 
				low_state->imu_state().quaternion()[1], 
				low_state->imu_state().quaternion()[2], 
				low_state->imu_state().quaternion()[3]);
				
			Eigen::Vector3f imu_omega(
				low_state->imu_state().gyroscope()[0], 
				low_state->imu_state().gyroscope()[1], 
				low_state->imu_state().gyroscope()[2]);
				
			auto [q_pelvis, w_pelvis] = transform_imu_data(waist_yaw, waist_yaw_omega, imu_quat, imu_omega);
			R = q_pelvis.toRotationMatrix();
			
			for (int i = 0; i < 3; i++)
			{
				obs(i) = ang_vel_scale * w_pelvis[i];
				obs(i + 3) = -R(2, i);
			}
		}
		else
		{
			R = Eigen::Quaternionf(
				low_state->imu_state().quaternion()[0], 
				low_state->imu_state().quaternion()[1], 
				low_state->imu_state().quaternion()[2], 
				low_state->imu_state().quaternion()[3]).toRotationMatrix();
				
			for (int i = 0; i < 3; i++)
			{
				obs(i) = ang_vel_scale * low_state->imu_state().gyroscope()[i];
				obs(i + 3) = -R(2, i);
			}
		}

		if (obs(5) > 0)
		{
			break;
		}

		obs(6) = joy.ly * max_cmd[0] * cmd_scale[0];
		obs(7) = joy.lx * -1 * max_cmd[1] * cmd_scale[1];
		obs(8) = joy.rx * -1 * max_cmd[2] * cmd_scale[2];

		int num_leg_joints = leg_joint2motor_idx.size();
		for (int i = 0; i < num_leg_joints; i++)
		{
			int motor_idx = leg_joint2motor_idx[i];
			obs(9 + i) = (low_state->motor_state()[motor_idx].q() - default_angles[i]) * dof_pos_scale;
			obs(9 + num_leg_joints + i) = low_state->motor_state()[motor_idx].dq() * dof_vel_scale;
		}
		obs.segment(9 + num_leg_joints * 2, num_leg_joints) = act;

		float phase = std::fmod(time / period, 1);
		time += .02;
		obs(9 + num_leg_joints * 3) = std::sin(2 * M_PI * phase);
		obs(9 + num_leg_joints * 3 + 1) = std::cos(2 * M_PI * phase);

		// policy forward
		act = policy->forward(obs);

		// post-process to get target joint positions
		Eigen::VectorXf target_angles = policy->post_process(act);

		auto low_cmd = std::make_shared<unitree_hg::msg::dds_::LowCmd_>();
		// leg
		for (int i = 0; i < num_leg_joints; i++)
		{
			int motor_idx = leg_joint2motor_idx[i];
			low_cmd->motor_cmd()[motor_idx].q() = target_angles(i);
			low_cmd->motor_cmd()[motor_idx].kp() = kps[i];
			low_cmd->motor_cmd()[motor_idx].kd() = kds[i];
			low_cmd->motor_cmd()[motor_idx].dq() = 0;
			low_cmd->motor_cmd()[motor_idx].tau() = 0;
		}

		// waist arm
		int num_arm_waist_joints = arm_waist_joint2motor_idx.size();
		for (int i = 0; i < num_arm_waist_joints; i++)
		{
			int motor_idx = arm_waist_joint2motor_idx[i];
			low_cmd->motor_cmd()[motor_idx].q() = arm_waist_target[i];
			low_cmd->motor_cmd()[motor_idx].kp() = arm_waist_kps[i];
			low_cmd->motor_cmd()[motor_idx].kd() = arm_waist_kds[i];
			low_cmd->motor_cmd()[motor_idx].dq() = 0;
			low_cmd->motor_cmd()[motor_idx].tau() = 0;
		}

		mLowCmdBuf.SetDataPtr(low_cmd);

		next_cycle += cycle_time;
		std::this_thread::sleep_until(next_cycle);
	}
}

void Controller::damp()
{
	std::cout << "damping\n";
	const std::chrono::milliseconds cycle_time(20);
	auto next_cycle = std::chrono::steady_clock::now();

	while (true)
	{
		auto low_cmd = std::make_shared<unitree_hg::msg::dds_::LowCmd_>();
		for (auto &cmd : low_cmd->motor_cmd())
		{
			cmd.kp() = 0;
			cmd.kd() = 8;
			cmd.dq() = 0;
			cmd.tau() = 0;
		}

		mLowCmdBuf.SetDataPtr(low_cmd);

		next_cycle += cycle_time;
		std::this_thread::sleep_until(next_cycle);
	}
}


void Controller::low_state_message_handler(const void *message)
{
	unitree_hg::msg::dds_::LowState_* ptr = (unitree_hg::msg::dds_::LowState_*)message;
	mLowStateBuf.SetData(*ptr);
	std::memcpy(&joy, ptr->wireless_remote().data(), ptr->wireless_remote().size() * sizeof(uint8_t));
}

void Controller::low_cmd_write_handler()
{
	if (auto lowCmdPtr = mLowCmdBuf.GetDataPtr())
	{
		lowCmdPtr->mode_machine() = mLowStateBuf.GetDataPtr()->mode_machine();
		lowCmdPtr->mode_pr() = 0;
		for (auto &cmd : lowCmdPtr->motor_cmd())
		{
			cmd.mode() = 1;
		}
		lowCmdPtr->crc() = crc32_core((uint32_t*)(lowCmdPtr.get()), (sizeof(unitree_hg::msg::dds_::LowCmd_) >> 2) - 1);
		lowcmd_publisher->Write(*lowCmdPtr);
	}
}

std::pair<Eigen::Quaternionf, Eigen::Vector3f> Controller::transform_imu_data(
	float waist_yaw, float waist_yaw_omega, 
	const Eigen::Quaternionf &imu_quat, const Eigen::Vector3f &imu_omega)
{
	Eigen::Matrix3f RzWaist = Eigen::AngleAxisf(waist_yaw, Eigen::Vector3f::UnitZ()).toRotationMatrix();
	Eigen::Matrix3f R_torso = imu_quat.toRotationMatrix();
	Eigen::Matrix3f R_pelvis = R_torso * RzWaist.transpose();
	Eigen::Quaternionf q_pelvis(R_pelvis);
	Eigen::Vector3f w = RzWaist * imu_omega - Eigen::Vector3f(0.0f, 0.0f, waist_yaw_omega);
	return {q_pelvis, w};
}
