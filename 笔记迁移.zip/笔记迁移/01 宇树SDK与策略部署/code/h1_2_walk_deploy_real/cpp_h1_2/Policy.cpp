#include "Policy.h"
#include <cstdlib>
#include <iostream>
#include <cstring>

Policy::Policy(const std::string& policy_path, int num_obs, int num_actions, float action_scale, const std::vector<float>& default_angles)
    : num_obs(num_obs), num_actions(num_actions), action_scale(action_scale), default_angles(default_angles)
{
    std::cout << "Loading policy from: " << policy_path << "\n";

    if (policy_path.size() >= 5 && policy_path.compare(policy_path.size() - 5, 5, ".onnx") == 0)
    {
        use_onnx = true;
        ort_env = std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_WARNING, "onnx_inference");
        Ort::SessionOptions session_options;
        session_options.SetIntraOpNumThreads(1);
        ort_session = std::make_unique<Ort::Session>(*ort_env, policy_path.c_str(), session_options);

        Ort::AllocatorWithDefaultOptions allocator;
        size_t num_input_nodes = ort_session->GetInputCount();
        for (size_t i = 0; i < num_input_nodes; i++)
        {
#if ORT_API_VERSION >= 12
            auto input_name = ort_session->GetInputNameAllocated(i, allocator);
            input_names_str.push_back(input_name.get());
#else
            char* input_name = ort_session->GetInputName(i, allocator);
            input_names_str.push_back(input_name);
            allocator.Free(input_name);
#endif
        }

        size_t num_output_nodes = ort_session->GetOutputCount();
        for (size_t i = 0; i < num_output_nodes; i++)
        {
#if ORT_API_VERSION >= 12
            auto output_name = ort_session->GetOutputNameAllocated(i, allocator);
            output_names_str.push_back(output_name.get());
#else
            char* output_name = ort_session->GetOutputName(i, allocator);
            output_names_str.push_back(output_name);
            allocator.Free(output_name);
#endif
        }

        for (const auto& name : input_names_str)
        {
            input_names_char.push_back(name.c_str());
        }
        for (const auto& name : output_names_str)
        {
            output_names_char.push_back(name.c_str());
        }
        std::cout << "ONNX model loaded successfully!\n";
    }
    else
    {
        use_onnx = false;
        module = torch::jit::load(policy_path);
        module.eval();
        std::cout << "TorchScript model loaded successfully!\n";
    }
}

Eigen::VectorXf Policy::forward(const Eigen::VectorXf& obs)
{
    Eigen::VectorXf act(num_actions);
    act.setZero();

    if (use_onnx)
    {
        std::vector<int64_t> input_shape = {1, static_cast<int64_t>(obs.size())};
        auto memory_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
        Ort::Value input_tensor = Ort::Value::CreateTensor<float>(
            memory_info, 
            const_cast<float*>(obs.data()), 
            obs.size(), 
            input_shape.data(), 
            input_shape.size()
        );

        auto output_tensors = ort_session->Run(
            Ort::RunOptions{nullptr},
            input_names_char.data(),
            &input_tensor,
            1,
            output_names_char.data(),
            1
        );

        float* output_data = output_tensors[0].GetTensorMutableData<float>();
        std::memcpy(act.data(), output_data, act.size() * sizeof(float));
    }
    else
    {
        torch::NoGradGuard no_grad;
        torch::Tensor torch_tensor = torch::from_blob(const_cast<float*>(obs.data()), {1, obs.size()}, torch::kFloat).clone();
        std::vector<torch::jit::IValue> inputs;
        inputs.push_back(torch_tensor);
        torch::Tensor output_tensor = module.forward(inputs).toTensor();
        std::memcpy(act.data(), output_tensor.data_ptr<float>(), output_tensor.size(1) * sizeof(float));
    }

    return act;
}

Eigen::VectorXf Policy::post_process(const Eigen::VectorXf& act) const
{
    Eigen::VectorXf target_angles(num_actions);
    for (int i = 0; i < num_actions; i++)
    {
        target_angles(i) = act(i) * action_scale + default_angles[i];
    }
    return target_angles;
}
