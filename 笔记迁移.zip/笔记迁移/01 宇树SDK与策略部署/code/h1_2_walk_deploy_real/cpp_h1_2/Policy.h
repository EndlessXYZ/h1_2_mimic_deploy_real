#ifndef POLICY_H
#define POLICY_H

#include <string>
#include <vector>
#include <memory>
#include <eigen3/Eigen/Eigen>

#include "torch/script.h"
#include <onnxruntime_cxx_api.h>

class Policy
{
public:
    Policy(const std::string& policy_path, int num_obs, int num_actions, float action_scale, const std::vector<float>& default_angles);
    
    // 执行前向推理，接受 obs (Eigen::VectorXf) 并返回原始的动作 act (Eigen::VectorXf)
    Eigen::VectorXf forward(const Eigen::VectorXf& obs);

    // 对原始动作进行后处理，计算目标关节角度：act * action_scale + default_angles
    Eigen::VectorXf post_process(const Eigen::VectorXf& act) const;

private:
    int num_obs;
    int num_actions;
    float action_scale;
    std::vector<float> default_angles;

    bool use_onnx = false;
    
    // TorchScript 引擎
    torch::jit::script::Module module;
    
    // ONNX Runtime 引擎
    std::unique_ptr<Ort::Env> ort_env;
    std::unique_ptr<Ort::Session> ort_session;
    std::vector<std::string> input_names_str;
    std::vector<std::string> output_names_str;
    std::vector<const char*> input_names_char;
    std::vector<const char*> output_names_char;
};

#endif // POLICY_H
