#include <iostream>
#include <string>
#include <cstring>
#include "Controller.h"

int main(int argc, char **argv)
{
	if (argc < 2 || argc > 3)
	{
		std::cout << "Usage: h1_2_walk_deploy_real [net_interface] [--auto]" << std::endl;
		exit(1);
	}

	bool auto_start = false;
	if (argc == 3)
	{
		if (std::strcmp(argv[2], "--auto") == 0)
		{
			auto_start = true;
		}
		else
		{
			std::cout << "Unknown argument: " << argv[2] << std::endl;
			std::cout << "Usage: h1_2_walk_deploy_real [net_interface] [--auto]" << std::endl;
			exit(1);
		}
	}

	Controller controller(argv[1], auto_start);
	controller.zero_torque_state();
	controller.move_to_default_pos();
	controller.run();
	controller.damp();
	return 0;
}
