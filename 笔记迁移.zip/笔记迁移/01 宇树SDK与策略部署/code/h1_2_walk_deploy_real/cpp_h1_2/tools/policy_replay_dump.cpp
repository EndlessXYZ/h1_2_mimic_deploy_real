#include "Policy.h"
#include <fstream>
#include <iomanip>
#include <iostream>

static std::vector<float> load_vector(const std::string& path)
{
    std::ifstream ifs(path);
    if (!ifs)
    {
        throw std::runtime_error("failed to open " + path);
    }
    std::vector<float> values;
    float v;
    while (ifs >> v)
    {
        values.push_back(v);
    }
    return values;
}

int main(int argc, char** argv)
{
    if (argc != 8)
    {
        std::cerr << "usage: policy_replay_dump <policy> <num_obs> <num_actions> <action_scale> <default_angles_txt> <obs_seq_txt> <out_txt>\n";
        return 1;
    }

    const std::string policy_path = argv[1];
    const int num_obs = std::stoi(argv[2]);
    const int num_actions = std::stoi(argv[3]);
    const float action_scale = std::stof(argv[4]);
    const auto default_angles = load_vector(argv[5]);
    const auto obs_values = load_vector(argv[6]);
    const std::string out_path = argv[7];

    if (static_cast<int>(default_angles.size()) != num_actions || obs_values.size() % num_obs != 0)
    {
        std::cerr << "size mismatch\n";
        return 2;
    }

    const int steps = static_cast<int>(obs_values.size() / num_obs);
    Policy policy(policy_path, num_obs, num_actions, action_scale, default_angles);
    std::ofstream ofs(out_path);
    if (!ofs)
    {
        std::cerr << "failed to open output " << out_path << "\n";
        return 3;
    }

    ofs << std::setprecision(9);
    for (int s = 0; s < steps; ++s)
    {
        Eigen::VectorXf obs(num_obs);
        for (int i = 0; i < num_obs; ++i)
        {
            obs(i) = obs_values[s * num_obs + i];
        }
        Eigen::VectorXf act = policy.forward(obs);
        Eigen::VectorXf target = policy.post_process(act);
        for (int i = 0; i < act.size(); ++i)
        {
            if (i) ofs << ' ';
            ofs << act(i);
        }
        ofs << '\n';
        for (int i = 0; i < target.size(); ++i)
        {
            if (i) ofs << ' ';
            ofs << target(i);
        }
        ofs << '\n';
    }
    return 0;
}
