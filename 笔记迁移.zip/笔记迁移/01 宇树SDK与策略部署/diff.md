diff --git "a/01 \345\277\253\351\200\237\345\256\211\350\243\205\346\265\213\350\257\225 unitree_sdk2.md" "b/01 \345\277\253\351\200\237\345\256\211\350\243\205\346\265\213\350\257\225 unitree_sdk2.md"
index 86bef6a..69e6ba7 100644
--- "a/01 \345\277\253\351\200\237\345\256\211\350\243\205\346\265\213\350\257\225 unitree_sdk2.md"	
+++ "b/01 \345\277\253\351\200\237\345\256\211\350\243\205\346\265\213\350\257\225 unitree_sdk2.md"	
@@ -10,16 +10,18 @@
 假设当前的工作路径为 `~/Documents/unitree_h1/`。在此路径下执行以下步骤完成 SDK 的编译和安装：
 
 ```bash
-# 编译并安装 SDK 动态库到系统
+# 编译 SDK 并安装到本地隔离目录（避免 sudo 污染系统）
+cd ~/Documents/unitree_h1/
+git clone https://github.com/unitreerobotics/unitree_sdk2.git
 cd ~/Documents/unitree_h1/unitree_sdk2/
 mkdir -p build && cd build
-cmake ..
-sudo make install
-
-# 编译测试例程（生成的可执行文件将输出到 build/bin 目录下）
-make
+cmake -DCMAKE_INSTALL_PREFIX=~/Documents/unitree_h1/local_deps/usr -DBUILD_EXAMPLES=ON ..
+make -j4
+make install  # 安装到 local_deps/usr，无需 sudo
 ```
 
+> **与官方文档的差异**：官方文档使用 `sudo make install` 将 SDK 安装到系统路径 `/usr/local`。为避免污染全局环境，此处使用 `-DCMAKE_INSTALL_PREFIX` 重定向到工作区的 `local_deps/usr` 下。
+
 ## 3. 运行 HelloWorld 测试
 在正式测试前，请根据官方的 [《快速开始》指南](https://support.unitree.com/home/zh/H1_developer/quick_start) 确保机器人已成功进入调试模式。接着，通过配置 `CYCLONEDDS_URI` 环境变量来强行绑定指定的网卡（如回环网卡 `lo`），从而开始测试 DDS 实时通信功能。具体操作步骤如下：
 
diff --git "a/03 mujoco\344\273\277\347\234\237\345\256\236\351\252\214.md" "b/03 mujoco\344\273\277\347\234\237\345\256\236\351\252\214.md"
index f8e8535..99c9d8f 100644
--- "a/03 mujoco\344\273\277\347\234\237\345\256\236\351\252\214.md"	
+++ "b/03 mujoco\344\273\277\347\234\237\345\256\236\351\252\214.md"	
@@ -47,15 +47,18 @@
 
 为了防止污染系统全局开发路径并规避动态库版本冲突，本方案采用“基础依赖系统安装 + 核心依赖局部提取”的物理隔离策略。
 
-### 3.1 系统级基础工具链安装
-在终端中执行以下包管理器指令以安装基础编译与 OpenGL 开发库：
+### 3.1 系统级基础工具链安装（若缺失）
+若当前环境尚未安装基础编译工具与 OpenGL 开发库，请安装：
 ```bash
 sudo apt-get update && sudo apt-get install -y \
     build-essential cmake git libgl1-mesa-dev libglu1-mesa-dev \
     libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev libxi-dev \
-    libyaml-cpp-dev libboost-program-options-dev libfmt-dev python3-pip
+    libyaml-cpp-dev libboost-program-options-dev libfmt-dev python3-pip \
+    libglfw3-dev
 ```
 
+> 本实验环境中 GLFW3 (`libglfw3-dev`) 已由系统预装，**不需要手动提取 deb 包**。
+
 ### 3.2 局部开发库隔离解包
 在工作空间全局根目录 `~/Documents/unitree_h1/` 下初始化 `local_deps/`：
 ```bash
@@ -64,12 +67,15 @@ cd ~/Documents/unitree_h1 && mkdir -p local_deps
 # 1. 提取免安装版 MuJoCo SDK
 tar -xf mujoco-3.3.6-linux-x86_64.tar.gz -C local_deps
 
-# 2. 隔离提取 GLFW3 库（避免污染全局图形调用）
-cd local_deps && mkdir -p deb_glfw usr
-dpkg-deb -x libglfw3_3.3.6-1_amd64.deb deb_glfw/libglfw3
-dpkg-deb -x libglfw3-dev_3.3.6-1_amd64.deb deb_glfw/libglfw3-dev
-cp -r deb_glfw/libglfw3/usr/* usr/
-cp -r deb_glfw/libglfw3-dev/usr/* usr/
+# 2. （可选）GLFW3 隔离提取
+# 若系统未安装 libglfw3-dev，从 deb 包提取：
+# cd local_deps && mkdir -p deb_glfw usr
+# dpkg-deb -x libglfw3_3.3.6-1_amd64.deb deb_glfw/libglfw3
+# dpkg-deb -x libglfw3-dev_3.3.6-1_amd64.deb deb_glfw/libglfw3-dev
+# cp -r deb_glfw/libglfw3/usr/* usr/
+# cp -r deb_glfw/libglfw3-dev/usr/* usr/
+# 
+# 本环境中 GLFW3 为系统级安装，此步骤跳过
 ```
 
 
@@ -83,13 +89,18 @@ ln -sfn ../../local_deps/mujoco-3.3.6 mujoco
 ```bash
 mkdir -p build && cd build
 
-CPATH=~/Documents/unitree_h1/local_deps/usr/include \
-LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu \
-cmake -DCMAKE_PREFIX_PATH=/usr/local/lib/cmake/unitree_sdk2 ..
+cmake -DCMAKE_PREFIX_PATH=~/Documents/unitree_h1/local_deps/usr/lib/cmake/unitree_sdk2 ..
 
 make -j4
 ```
 
+> **与笔记原始版本的差异**：由于 SDK 安装在本地隔离路径而非系统路径 `/usr/local`，cmake 需通过 `CMAKE_PREFIX_PATH` 指定 `unitree_sdk2` 的 cmake 配置位置。原始笔记中假设 SDK 安装在 `/usr/local/lib/cmake/unitree_sdk2`。
+
+> **conda 环境编译问题**：若在 conda 环境中编译遇到 `GLIBCXX_3.4.30 not found` 错误，原因是 conda 的 `libstdc++.so.6`（仅支持至 3.4.29）与系统版本（3.4.30）冲突。使用 `LD_PRELOAD` 绕过：
+> ```bash
+> export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
+> ```
+
 ---
 
 ## 4. 运行配置
@@ -138,13 +149,15 @@ enable_elastic_band: 1   # 启用虚拟挂带，防止上电初速度为 0 时
 
 ```bash
 # 1. 设置图形会话变量
-export DISPLAY=:0
-export XAUTHORITY=/run/user/1000/gdm/Xauthority
+export DISPLAY=:10
 
 # 2. 设置隔离的本地 GLFW 链接库搜索路径及仿真器所需动态库
-export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:/usr/local/lib:${LD_LIBRARY_PATH}
+export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:${LD_LIBRARY_PATH}
 
-# 3. 运行仿真（命令行重写 Domain 0 与环回网卡 lo）
+# 3. 如需在 conda 环境中绕开 libstdc++ 版本冲突：
+export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
+
+# 4. 运行仿真（命令行重写 Domain 0 与环回网卡 lo）
 ~/Documents/unitree_h1/unitree_mujoco/simulate/build/unitree_mujoco \
     -i 0 -n lo -r h1_2 -s scene.xml
 ```
@@ -179,4 +192,7 @@ export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gn
   - **排查与解决**：利用 `ps -ef | grep unitree_mujoco` 检查正在运行的进程参数，确保命令行中附带 `-i 0`。同时检查控制端在启动时也传入了 `lo` 网卡参数以确保走本地环回。
 - **问题 3：仿真器启动即发生段错误 (Segmentation Fault)**
   - **原因**：在无显示器的 Headless 服务器上直接运行了物理 GUI 渲染启动；或是由于 `LD_LIBRARY_PATH` 错绑了系统的低版本 GLFW 库。
-  - **排查与解决**：无头模式下必须确认 Xvfb 后台服务正在运行，且正确执行了 `export DISPLAY=:101`。并在运行命令前，将隔离依赖路径 `local_deps/usr/lib/x86_64-linux-gnu` 添加到 `LD_LIBRARY_PATH` 的最前端以拥有最高加载优先级。
+  - **排查与解决**：确认有可用的 DISPLAY（如 Xrdp 会话 `:10`）：
+    ```bash
+    export DISPLAY=:10   # 使用已有 Xrdp 会话，无需 sudo 安装 Xvfb
+    ```
diff --git "a/04 \347\212\266\346\200\201\345\217\215\351\246\210\344\273\277\347\234\237\345\256\236\351\252\214.md" "b/04 \347\212\266\346\200\201\345\217\215\351\246\210\344\273\277\347\234\237\345\256\236\351\252\214.md"
index b935a1d..fbb59fe 100644
--- "a/04 \347\212\266\346\200\201\345\217\215\351\246\210\344\273\277\347\234\237\345\256\236\351\252\214.md"	
+++ "b/04 \347\212\266\346\200\201\345\217\215\351\246\210\344\273\277\347\234\237\345\256\236\351\252\214.md"	
@@ -315,7 +315,7 @@ target_link_libraries(h1_arm_lowstate_monitor PRIVATE unitree_sdk2)
 ```bash
 cd ~/Documents/unitree_h1/custom_tools/arm_lowstate_monitor
 mkdir -p build && cd build
-cmake -DCMAKE_PREFIX_PATH=/usr/local/lib/cmake/unitree_sdk2 ..
+cmake -DCMAKE_PREFIX_PATH=~/Documents/unitree_h1/local_deps/usr/lib/cmake/unitree_sdk2 ..
 make -j4
 ```
 
@@ -324,9 +324,8 @@ make -j4
 ```bash
 cd ~/Documents/unitree_h1/unitree_mujoco/simulate/build
 
-export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:${LD_LIBRARY_PATH}
-export DISPLAY=:0
-export XAUTHORITY=/run/user/1000/gdm/Xauthority
+export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:${LD_LIBRARY_PATH}
+export DISPLAY=:10
 
 # 后台拉起仿真器（锁定 Domain 0，网卡 lo，加载默认 H1_2 场景）
 ./unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml \
@@ -340,7 +339,8 @@ export XAUTHORITY=/run/user/1000/gdm/Xauthority
 在另一个终端或后台启动我们编译的监控器。将采样时长设定为 **15秒**，这为交互留出了充足的时间。
 
 ```bash
-export LD_LIBRARY_PATH=/usr/local/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
+export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
+export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6  # conda 环境需绕过 libstdc++ 冲突
 
 ~/Documents/unitree_h1/custom_tools/arm_lowstate_monitor/build/bin/h1_arm_lowstate_monitor \
     lo \
@@ -386,7 +386,7 @@ Successfully connected to topic.
 [Time: 13.5879s] Joints -> left_shoulder_pitch: -0.0399 | left_shoulder_roll: -0.0921 | right_shoulder_pitch:  0.4547 | right_shoulder_roll:  0.0125
 [Time: 14.0908s] Joints -> left_shoulder_pitch: -0.1188 | left_shoulder_roll:  0.1733 | right_shoulder_pitch:  0.1875 | right_shoulder_roll:  0.0602
 [Time: 14.5942s] Joints -> left_shoulder_pitch:  0.0415 | left_shoulder_roll: -0.0975 | right_shoulder_pitch: -0.3912 | right_shoulder_roll: -0.1203
-Saved monitor data to /home/meme/Documents/unitree_h1/artifacts/h1_2_arm_lowstate_feedback.csv
+Saved monitor data to /home/jianlirong/Documents/unitree_h1/artifacts/h1_2_arm_lowstate_feedback.csv
 ```
 
 可以发现，打印出来的四个关节角度都发生了变化，证明数据通道是打通的。
diff --git "a/06 \351\253\230\345\261\202\346\211\213\350\207\202\346\216\247\345\210\266\344\273\277\347\234\237\345\256\236\351\252\214.md" "b/06 \351\253\230\345\261\202\346\211\213\350\207\202\346\216\247\345\210\266\344\273\277\347\234\237\345\256\236\351\252\214.md"
index cac7486..3bbf36c 100644
--- "a/06 \351\253\230\345\261\202\346\211\213\350\207\202\346\216\247\345\210\266\344\273\277\347\234\237\345\256\236\351\252\214.md"	
+++ "b/06 \351\253\230\345\261\202\346\211\213\350\207\202\346\216\247\345\210\266\344\273\277\347\234\237\345\256\236\351\252\214.md"	
@@ -1,5 +1,5 @@
 
-本实验在《[03 mujoco仿真实验](file:///home/meme/Documents/笔记/精简版本笔记/03%20mujoco%E4%BB%BF%E7%9C%9F%E5%AE%9E%E9%AA%8C.md)》与《[04 状态反馈仿真实验](file:///home/meme/Documents/笔记/精简版本笔记/04%20%E7%8A%B6%E6%80%81%E5%8F%8D%E9%A6%88%E4%BB%BF%E7%9C%9F%E5%AE%9E%E9%AA%8C.md)》的基础之上，聚焦于 H1_2 上肢双臂的高层 DDS 轨迹控制与仿真实现。为了严格遵守“不修改官方仓库源码与配置”、“直接运行自带手臂控制例程”的零侵入式 Sim-to-Real 开发规范，本实验通过在外部目录中构建自定义仿真器，打通手臂控制信号。
+本实验在《[03 mujoco仿真实验](file:///home/jianlirong/Documents/笔记/精简版本笔记/03%20mujoco%E4%BB%BF%E7%9C%9F%E5%AE%9E%E9%AA%8C.md)》与《[04 状态反馈仿真实验](file:///home/jianlirong/Documents/笔记/精简版本笔记/04%20%E7%8A%B6%E6%80%81%E5%8F%8D%E9%A6%88%E4%BB%BF%E7%9C%9F%E5%AE%9E%E9%AA%8C.md)》的基础之上，聚焦于 H1_2 上肢双臂的高层 DDS 轨迹控制与仿真实现。为了严格遵守“不修改官方仓库源码与配置”、“直接运行自带手臂控制例程”的零侵入式 Sim-to-Real 开发规范，本实验通过在外部目录中构建自定义仿真器，打通手臂控制信号。
 
 ---
 
@@ -71,10 +71,10 @@ void ApplyArmSdk() {
 具体 XML 内容如下：
 ```xml
 <mujoco model="Unitree H1-2 Arm Demo (External)">
-  <compiler meshdir="/home/meme/Documents/unitree_h1/unitree_mujoco/unitree_robots/h1_2/meshes/" />
+  <compiler meshdir="/home/jianlirong/Documents/unitree_h1/unitree_mujoco/unitree_robots/h1_2/meshes/" />
 
   <!-- 引入官方的 H1_2 无手版动力学模型 -->
-  <include file="/home/meme/Documents/unitree_h1/unitree_mujoco/unitree_robots/h1_2/h1_2_handless.xml" />
+  <include file="/home/jianlirong/Documents/unitree_h1/unitree_mujoco/unitree_robots/h1_2/h1_2_handless.xml" />
   
   <statistic center="0 0 1.0" extent="1.8" />
 
@@ -110,14 +110,14 @@ void ApplyArmSdk() {
 ### 3.1 软链接解决网格资源解析
 为防止展开 include 的动力学文件时找不到 STL 网格资源，需在 `custom_tools/` 外置目录下建立软链接：
 ```bash
-ln -sf /home/meme/Documents/unitree_h1/unitree_mujoco/unitree_robots/h1_2/meshes /home/meme/Documents/unitree_h1/custom_tools/meshes
+ln -sf /home/jianlirong/Documents/unitree_h1/unitree_mujoco/unitree_robots/h1_2/meshes /home/jianlirong/Documents/unitree_h1/custom_tools/meshes
 ```
 
 ### 3.2 重新编译自定义仿真器
 在编译前，建议先清理陈旧的 CMake 缓存及编译目录，确保局部 GLFW 开发库能被 CMake 脚本正确优先捕获：
 ```bash
 # 重新编译自定义仿真器
-cd /home/meme/Documents/unitree_h1/custom_tools/custom_mujoco
+cd /home/jianlirong/Documents/unitree_h1/custom_tools/custom_mujoco
 mkdir -p build && cd build
 rm -rf CMakeCache.txt CMakeFiles # 清理旧缓存
 cmake ..
@@ -133,25 +133,27 @@ make -j4
 ### 4.1 步骤一：在终端 1 中启动 GUI 仿真器
 ```bash
 # 声明本地编译依赖的动态库加载路径 (库路径绑定说明参见 03)
-export LD_LIBRARY_PATH=/home/meme/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu:/home/meme/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:/usr/local/lib:$LD_LIBRARY_PATH
-export DISPLAY=:0
+export LD_LIBRARY_PATH=/home/jianlirong/Documents/unitree_h1/local_deps/usr/lib:/home/jianlirong/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:/home/jianlirong/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
+export DISPLAY=:10
+export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6  # conda libstdc++ 冲突绕过
 
 # 启动仿真器（以本地回环 lo 监听 DDS，加载 custom_scene_arm_demo.xml）
-/home/meme/Documents/unitree_h1/custom_tools/custom_mujoco/build/unitree_mujoco \
-  -i 0 -n lo -r h1_2 -s /home/meme/Documents/unitree_h1/custom_tools/custom_scene_arm_demo.xml
+/home/jianlirong/Documents/unitree_h1/custom_tools/custom_mujoco/build/unitree_mujoco \
+  -i 0 -n lo -r h1_2 -s /home/jianlirong/Documents/unitree_h1/custom_tools/custom_scene_arm_demo.xml
 ```
 将弹出一个 MuJoCo 仿真窗口，机器人直立悬挂在半空中，双臂自然垂下。
 
 ### 4.2 （可选）步骤二：在终端 2 中启动数值监视器
 ```bash
 # 采样记录数据至 CSV 中，便于后续数据验证
-/home/meme/Documents/unitree_h1/custom_tools/arm_lowstate_monitor/build/bin/h1_arm_lowstate_monitor lo /home/meme/Documents/unitree_h1/artifacts/arms_demo_monitor.csv 12
+/home/jianlirong/Documents/unitree_h1/custom_tools/arm_lowstate_monitor/build/h1_arm_lowstate_monitor lo /home/jianlirong/Documents/unitree_h1/artifacts/arms_demo_monitor.csv 12
 ```
 
 ### 4.3 步骤三：在终端 3 中运行官方手臂控制例程
 ```bash
-export LD_LIBRARY_PATH=/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
-/home/meme/Documents/unitree_h1/unitree_sdk2/build/bin/h1_2_arm_sdk_dds_example lo
+export LD_LIBRARY_PATH=/home/jianlirong/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
+export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
+/home/jianlirong/Documents/unitree_h1/unitree_sdk2/build/bin/h1_2_arm_sdk_dds_example lo
 ```
 此时终端 3 控制台会输出提示信息：
 
diff --git "a/10 \345\272\225\345\261\202\346\216\247\345\210\266\344\276\213\347\250\213\344\273\277\347\234\237\345\256\236\351\252\214.md" "b/10 \345\272\225\345\261\202\346\216\247\345\210\266\344\276\213\347\250\213\344\273\277\347\234\237\345\256\236\351\252\214.md"
index 79c4257..b46d1b9 100644
--- "a/10 \345\272\225\345\261\202\346\216\247\345\210\266\344\276\213\347\250\213\344\273\277\347\234\237\345\256\236\351\252\214.md"	
+++ "b/10 \345\272\225\345\261\202\346\216\247\345\210\266\344\276\213\347\250\213\344\273\277\347\234\237\345\256\236\351\252\214.md"	
@@ -1,6 +1,6 @@
 # 10 底层控制例程仿真实验
 
-本实验在本地回环网卡（`lo`）上，将官方底层控制例程 [h1_27dof_example.cpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/example/h1/low_level/h1_27dof_example.cpp) 桥接至 MuJoCo 仿真器，运行闭环阻抗控制测试。
+本实验在本地回环网卡（`lo`）上，将官方底层控制例程 [h1_27dof_example.cpp](file:///home/jianlirong/Documents/unitree_h1/unitree_sdk2/example/h1/low_level/h1_27dof_example.cpp) 桥接至 MuJoCo 仿真器，运行闭环阻抗控制测试。
 
 ## 1. 编译官方底层控制例程
 底层例程集成在官方 SDK 示例中，直接开启编译开关构建：
@@ -19,12 +19,15 @@ make -j4
 1. **拉起 GUI 仿真器**（终端 1）：
    *(库路径环境变量 LD_LIBRARY_PATH 见 03)*
    ```bash
-   /home/meme/Documents/unitree_h1/unitree_mujoco/simulate/build/unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml
+   export DISPLAY=:10
+   export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6  # conda 环境绕过
+   /home/jianlirong/Documents/unitree_h1/unitree_mujoco/simulate/build/unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml
    ```
 2. **运行底层控制例程**（终端 2）：
    ```bash
-   export LD_LIBRARY_PATH=/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
-   /home/meme/Documents/unitree_h1/unitree_sdk2/build/bin/h1_27dof_example lo
+   export LD_LIBRARY_PATH=/home/jianlirong/Documents/unitree_h1/local_deps/usr/lib:/home/jianlirong/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
+   export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
+   /home/jianlirong/Documents/unitree_h1/unitree_sdk2/build/bin/h1_27dof_example lo
    ```
 3. **观察与交互**：
    - 启动后，悬吊状态下的 H1_2 机器人所有关节会迅速挺直锁死在零位。随后，双脚踝关节的 Pitch 和 Roll 轴执行正弦往复运动，躯干保持平衡直立。
@@ -37,39 +40,38 @@ make -j4
 ---
 
 ## 3. Headless 自动化联调测试
-在云服务器或无屏环境下，可使用虚拟桌面 Xvfb 运行无头测试。
 
-一键联调脚本 `tools/run_low_level_simulation.sh`（精简版）：
+在云服务器或无屏环境下，若已有运行的 X 会话（如 Xrdp `:10`），直接复用：
+
+一键联调脚本（精简版）：
 ```bash
 #!/bin/bash
 set -e
-export LD_LIBRARY_PATH=/home/meme/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu:/home/meme/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:/usr/local/lib:$LD_LIBRARY_PATH
-
-# 1. 开启虚拟屏幕 :102
-Xvfb :102 -screen 0 1280x1024x24 > /dev/null 2>&1 &
-XVFB_PID=$!
-sleep 1
+export DISPLAY=:10
+export LD_LIBRARY_PATH=/home/jianlirong/Documents/unitree_h1/local_deps/usr/lib:/home/jianlirong/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:/home/jianlirong/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
+export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
 
-# 2. 启动仿真器
-DISPLAY=:102 /home/meme/Documents/unitree_h1/unitree_mujoco/simulate/build/unitree_mujoco \
-  -i 0 -n lo -r h1_2 -s scene.xml > /dev/null 2>&1 &
+# 1. 启动仿真器
+./unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml > /dev/null 2>&1 &
 MUJOCO_PID=$!
 sleep 4
 
-# 3. 运行底层控制例程
-export LD_LIBRARY_PATH=/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:$LD_LIBRARY_PATH
-/home/meme/Documents/unitree_h1/unitree_sdk2/build/bin/h1_27dof_example lo > /home/meme/Documents/unitree_h1/artifacts/h1_27dof_run.log 2>&1 &
+# 2. 运行底层控制例程
+h1_27dof_example lo > /home/jianlirong/Documents/unitree_h1/artifacts/h1_27dof_run.log 2>&1 &
 CTRL_PID=$!
 
-# 4. 运行 5 秒后截图
+# 3. 运行 5 秒后截图
 sleep 5
-DISPLAY=:102 xwd -root -silent -out /home/meme/Documents/unitree_h1/artifacts/h1_2_low_during.xwd
-python3 /home/meme/Documents/unitree_h1/tools/xwd_to_png.py /home/meme/Documents/unitree_h1/artifacts/h1_2_low_during.xwd /home/meme/Documents/unitree_h1/artifacts/h1_2_low_during.png
+xwd -root -silent -out /home/jianlirong/Documents/unitree_h1/artifacts/h1_2_low_during.xwd
+python3 /home/jianlirong/Documents/unitree_h1/tools/xwd_to_png.py \
+  /home/jianlirong/Documents/unitree_h1/artifacts/h1_2_low_during.xwd \
+  /home/jianlirong/Documents/unitree_h1/artifacts/h1_2_low_during.png
 
-# 5. 停止控制与仿真，并清理
-kill $CTRL_PID $MUJOCO_PID $XVFB_PID || true
+# 4. 清理
+kill $CTRL_PID $MUJOCO_PID || true
 ```
-*(注：图片裁剪与 Side-by-Side 对比拼接 python 脚本的编写逻辑详见 06 仿真实验。)*
+
+> **注意**：若确实无 DISPLAY，可安装 Xvfb：`sudo apt-get install -y xvfb`，然后将 `DISPLAY=:10` 替换为 `DISPLAY=:99` 并前置启动 `Xvfb :99 -screen 0 1280x1024x24 &`。
 
 ---
