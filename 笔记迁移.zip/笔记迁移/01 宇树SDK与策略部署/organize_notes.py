#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import shutil
from datetime import datetime

def organize_markdown_notes():
    # 获取当前脚本所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 定义源 assets 目录与目标 assets 目录
    relative_src_assets = os.path.abspath(os.path.join(current_dir, "../assets"))
    absolute_src_assets = "/home/meme/Documents/笔记/assets"
    
    if os.path.exists(relative_src_assets):
        src_assets_dir = relative_src_assets
    else:
        src_assets_dir = absolute_src_assets
        
    dest_assets_dir = os.path.join(current_dir, "assets")
    
    print(f"[*] 源资源目录 (src_assets): {src_assets_dir}")
    print(f"[*] 目标资源目录 (dest_assets): {dest_assets_dir}")
    
    if not os.path.exists(src_assets_dir):
        print(f"[!] 警告: 源资源目录不存在: {src_assets_dir}")
    
    # 确保目标 assets 目录存在
    if not os.path.exists(dest_assets_dir):
        os.makedirs(dest_assets_dir, exist_ok=True)
        print(f"[*] 已创建目标资源目录: {dest_assets_dir}")

    # 查找当前目录下的所有 .md 文件
    md_files = [f for f in os.listdir(current_dir) if f.endswith(".md") and f != "organize_notes.py"]
    print(f"[*] 找到 {len(md_files)} 个 Markdown 笔记文件进行处理\n")

    # 正则表达式匹配 Obsidian 图片链接: ![[filename.png]] 或 ![[filename.png|300]]
    obsidian_img_pattern = re.compile(r'!\[\[([^\]|]+)(?:\|[^\]]*)?\]\]')
    # 正则表达式匹配标准 Markdown 图片链接: ![alt](path)
    standard_img_pattern = re.compile(r'!\[(?P<alt>[^\]]*)\]\((?P<path>[^\)]+)\)')

    # 全局映射字典，用于避免多次处理同一个物理文件而导致时间戳或计数器不一致
    path_to_new_name = {}
    used_new_names = set()
    referenced_assets = set()  # 记录所有 md 文件中最终引用的新资源文件名，用于后续垃圾清理

    def get_normalized_name(src_path):
        """生成规范的、不含空格的时间戳文件名，例如 20260615153503.png"""
        if src_path in path_to_new_name:
            return path_to_new_name[src_path]
        
        filename = os.path.basename(src_path)
        name_part, ext = os.path.splitext(filename)
        
        # 1. 尝试从文件名本身寻找 14 位数字的时间戳
        ts_match = re.search(r'\d{14}', name_part)
        if ts_match:
            base_ts = ts_match.group(0)
        else:
            # 2. 如果文件名不含时间戳，使用文件最后修改时间
            mtime = os.path.getmtime(src_path)
            base_ts = datetime.fromtimestamp(mtime).strftime('%Y%m%d%H%M%S')
            
        # 防止同一秒内或原文件名相同冲突，若冲突则追加序号
        candidate = f"{base_ts}{ext}"
        counter = 1
        while candidate in used_new_names:
            candidate = f"{base_ts}_{counter}{ext}"
            counter += 1
            
        path_to_new_name[src_path] = candidate
        used_new_names.add(candidate)
        return candidate

    def process_image(raw_img_path):
        """寻找物理图片文件并计算规范化后的新文件名"""
        raw_img_path = raw_img_path.strip(' <>')  # 清除可能包裹的 <> 符号与空格
        
        # 过滤掉网络链接
        if raw_img_path.startswith(('http://', 'https://')):
            return None, None
            
        # 过滤非图片后缀
        _, ext = os.path.splitext(raw_img_path.lower())
        if ext not in ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg', '.webp'):
            return None, None
            
        img_filename = os.path.basename(raw_img_path)
        found_src_path = None
        
        # 1. 尝试直接在源 assets 目录中拼接查找
        path_src_direct = os.path.join(src_assets_dir, img_filename)
        # 2. 尝试解析子路径在源目录中查找
        path_src_sub = os.path.join(src_assets_dir, raw_img_path.replace('assets/', '', 1))
        
        if os.path.exists(path_src_direct) and os.path.isfile(path_src_direct):
            found_src_path = path_src_direct
        elif os.path.exists(path_src_sub) and os.path.isfile(path_src_sub):
            found_src_path = path_src_sub
        else:
            # 3. 尝试在目标 assets 目录下查找已经存在的文件（可能上一轮已经拷贝过）
            path_dest_direct = os.path.join(dest_assets_dir, img_filename)
            if os.path.exists(path_dest_direct) and os.path.isfile(path_dest_direct):
                found_src_path = path_dest_direct
            else:
                # 4. 递归在源 assets 目录中寻找同名文件
                for root, _, files in os.walk(src_assets_dir):
                    if img_filename in files:
                        found_src_path = os.path.join(root, img_filename)
                        break
                        
        # 如果彻底找不到物理文件
        if not found_src_path:
            # 检查它是否已经是规范的时间戳格式，且已经在 dest_assets_dir 里了
            if re.match(r'^\d{14}(_\d+)?\..+$', img_filename):
                return img_filename, None
            return None, None
            
        new_filename = get_normalized_name(found_src_path)
        return new_filename, found_src_path

    total_paths_replaced = 0
    total_links_cleaned = 0
    total_imgs_converted = 0
    total_imgs_copied = 0

    for file_name in md_files:
        file_path = os.path.join(current_dir, file_name)
        print(f"==================================================")
        print(f"[*] 正在处理文件: {file_name}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        changed = False

        # 1. 替换 /home/meme/ 为 ~/
        replaced_count = content.count('/home/meme/')
        if replaced_count > 0:
            content = content.replace('/home/meme/', '~/')
            total_paths_replaced += replaced_count
            changed = True
            print(f"    [-] 替换了 {replaced_count} 处 '/home/meme/' 为 '~/'")

        # 修复可能存在的丢失斜杠的 ~[路径] 格式（如 ~Documents, ~unitree_h1 修复为 ~/Documents, ~/unitree_h1）
        fix_pattern = re.compile(r'~([a-zA-Z0-9])')
        fixed_content, fix_count = fix_pattern.subn(r'~/\1', content)
        if fix_count > 0:
            content = fixed_content
            changed = True
            print(f"    [-] 修复了 {fix_count} 处丢失斜杠的 '~[路径]'")

        # 2. 清洗本地 file:// 超链接 [显示文本](file://...) 为纯文本
        file_link_pattern = re.compile(r'\[([^\]]+)\]\(file://[^\)]+\)')
        fixed_content, link_replaced_count = file_link_pattern.subn(r'\1', content)
        if link_replaced_count > 0:
            content = fixed_content
            changed = True
            total_links_cleaned += link_replaced_count
            print(f"    [-] 清洗了 {link_replaced_count} 处本地 'file://' 超链接为纯文本")

        # 3 & 4. 匹配图片链接、执行重命名并复制资源
        local_converted_count = 0
        local_copied_count = 0

        def copy_file_to_dest(src_path, new_name):
            nonlocal local_copied_count
            dest_file_path = os.path.join(dest_assets_dir, new_name)
            try:
                if not os.path.exists(dest_file_path):
                    shutil.copy2(src_path, dest_file_path)
                    local_copied_count += 1
                    print(f"    [+] 复制并规范化资源: {new_name} 来自 {os.path.basename(src_path)}")
                elif os.path.getmtime(src_path) > os.path.getmtime(dest_file_path):
                    shutil.copy2(src_path, dest_file_path)
                    local_copied_count += 1
                    print(f"    [+] 复制并覆盖更新的资源: {new_name} 来自 {os.path.basename(src_path)}")
                else:
                    pass
            except Exception as e:
                print(f"    [x] 复制资源失败: {new_name}, 错误: {e}")

        # A. 替换 Obsidian 格式的链接 ![[xxx]]
        def replace_obsidian_img(match):
            nonlocal local_converted_count
            raw_img_path = match.group(1).strip()
            new_name, src_path = process_image(raw_img_path)
            
            if new_name:
                if src_path:
                    copy_file_to_dest(src_path, new_name)
                referenced_assets.add(new_name)
                local_converted_count += 1
                return f"![{new_name}](assets/{new_name})"
            else:
                img_filename = os.path.basename(raw_img_path)
                print(f"    [!] 无法定位资源文件: {img_filename}")
                referenced_assets.add(img_filename)
                local_converted_count += 1
                return f"![{img_filename}](assets/{img_filename})"

        # B. 替换标准 Markdown 格式的链接 ![alt](path)
        def replace_standard_img(match):
            nonlocal local_converted_count
            alt_text = match.group('alt')
            raw_img_path = match.group('path').strip()
            
            new_name, src_path = process_image(raw_img_path)
            
            if new_name:
                if src_path:
                    copy_file_to_dest(src_path, new_name)
                referenced_assets.add(new_name)
                
                orig_filename = os.path.basename(raw_img_path)
                if orig_filename != new_name:
                    local_converted_count += 1
                    new_alt = alt_text if alt_text and "Pasted image" not in alt_text else new_name
                    return f"![{new_alt}](assets/{new_name})"
                else:
                    return match.group(0)
            else:
                referenced_assets.add(os.path.basename(raw_img_path))
                return match.group(0)

        # 执行正则处理
        content_after_obsidian = obsidian_img_pattern.sub(replace_obsidian_img, content)
        content_after_all = standard_img_pattern.sub(replace_standard_img, content_after_obsidian)

        if local_converted_count > 0:
            changed = True
            content = content_after_all
            
        total_imgs_converted += local_converted_count
        total_imgs_copied += local_copied_count

        # 写回文件
        if changed:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"    [√] 文件处理完成并已保存。")
        else:
            print(f"    [~] 文件内容无变化，无需保存。")

    # 5. 清理垃圾资源
    print(f"\n==================================================")
    print(f"[*] 正在进行垃圾资源回收 (Garbage Collection)...")
    cleanup_count = 0
    if os.path.exists(dest_assets_dir):
        for root, dirs, files in os.walk(dest_assets_dir):
            for file in files:
                file_path = os.path.join(root, file)
                if file not in referenced_assets:
                    try:
                        os.remove(file_path)
                        cleanup_count += 1
                        print(f"    [-] 清理未引用的陈旧资源: {file}")
                    except Exception as e:
                        print(f"    [x] 清理资源 {file} 失败: {e}")

    print(f"\n==================================================")
    print(f"[√] 整理与规范化命名脚本运行完毕！")
    print(f"    - 替换/修复路径数量: {total_paths_replaced}")
    print(f"    - 清洗本地超链接数量: {total_links_cleaned}")
    print(f"    - 规范化/转换图片链接数量: {total_imgs_converted}")
    print(f"    - 新复制与规范化资源文件数量: {total_imgs_copied}")
    print(f"    - 清理陈旧垃圾资源数量: {cleanup_count}")

if __name__ == "__main__":
    organize_markdown_notes()
