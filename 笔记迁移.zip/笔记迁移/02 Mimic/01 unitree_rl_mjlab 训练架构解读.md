# 01 unitree_rl_mjlab 训练架构解读

> **系列定位**：本篇独立于机器人机型，梳理 `unitree_rl_mjlab` 的通用训练框架。理解本架构后，可继续阅读 [02 G1 探索](file:///home/meme/Documents/笔记/02%20Mimic/02%20G1%20Mimic%20%E7%AD%96%E7%95%A5%E4%BB%BF%E7%9C%9F%E6%8E%A2%E7%B4%A2.md)（了解 G1 实践）。

---

## 1. 总体架构

```
scripts/train.py                     ← 入口脚本
    │
    ├── TrainConfig                 ← 合并 env_cfg + agent_cfg
    │   ├── env  (ManagerBasedRlEnvCfg)
    │   └── agent (RslRlOnPolicyRunnerCfg)
    │
    └── launch_training()
        ├── ManagerBasedRlEnv       ← 构建 MuJoCo 仿真环境
        │   ├── scene (Entities, Sensors)
        │   ├── observations (actor/critic)
        │   ├── actions (JointPositionAction)
        │   ├── commands (MotionCommand)
        │   ├── events (domain randomization)
        │   ├── rewards
        │   └── terminations
        │
        ├── RslRlVecEnvWrapper       ← RSL-RL VecEnv 接口适配
        │
        └── MotionTrackingOnPolicyRunner ← MjlabOnPolicyRunner 子类
            └── runner.learn()        ← PPO 训练循环
```

训练框架基于 **RSL-RL**（PPO 算法实现）+ **mjlab**（MuJoCo 仿真抽象层）。

### 依赖关系

```
setup.py → mjlab==1.2.0, mujoco-warp==3.5.0
src/     → 用户自定义任务代码（观测、奖励、配置等）
```

`src/tasks/__init__.py` 使用 `import_packages()` 自动发现并导入所有子模块。

---

## 2. 任务注册系统

所有可用任务通过 `register_mjlab_task()` 注册到全局 registry。命令行通过 `tyro` 解析任务 ID：

```python
# src/tasks/tracking/config/h1_2/__init__.py
register_mjlab_task(
  task_id="Unitree-H1_2-Tracking",
  env_cfg=unitree_h1_2_flat_tracking_env_cfg(),
  play_env_cfg=unitree_h1_2_flat_tracking_env_cfg(play=True),
  rl_cfg=unitree_h1_2_tracking_ppo_runner_cfg(),
  runner_cls=MotionTrackingOnPolicyRunner,
)
```

`train.py` 启动时 `import src.tasks` 触发所有 `__init__.py` 执行，完成注册。

可用任务列表（H1_2 相关）：

| 任务 ID | 类型 | 说明 |
| :--- | :--- | :--- |
| `Unitree-H1_2-Tracking` | tracking | 动作模仿（有状态估计） |
| `Unitree-H1_2-Tracking-No-State-Estimation` | tracking | 动作模仿（无状态估计） |
| `Unitree-H1_2-Flat` | velocity | 平地速度跟踪 |
| `Unitree-H1_2-Rough` | velocity | 崎岖地形速度跟踪 |

---

## 3. 双层任务体系

项目包含**两个独立的任务体系**，共享同一套框架：

### Velocity Tracking（速度跟踪）

| 文件 | 路径 |
| :--- | :--- |
| Base 配置 | [velocity_env_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/velocity_env_cfg.py) |
| 观测实现 | [observations.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/mdp/observations.py) |
| 奖励实现 | [rewards.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/mdp/rewards.py) |
| 终止条件 | [terminations.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/mdp/terminations.py) |
| 指令生成 | [velocity_command.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/mdp/velocity_command.py) |
| 课程学习 | [curriculums.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/mdp/curriculums.py) |
| Runner | [runner.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/rl/runner.py) |
| 机器人配置(H1_2) | [h1_2/env_cfgs.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/config/h1_2/env_cfgs.py) |
| RL 超参(H1_2) | [h1_2/rl_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/config/h1_2/rl_cfg.py) |

### Motion Tracking / Mimic（动作模仿）

| 文件 | 路径 |
| :--- | :--- |
| Base 配置 | [tracking_env_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/tracking_env_cfg.py) |
| 观测实现 | [observations.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/observations.py) |
| 奖励实现 | [rewards.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/rewards.py) |
| 终止条件 | [terminations.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/terminations.py) |
| 指令生成(MotionCommand) | [commands.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/commands.py) |
| 评估指标 | [metrics.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/metrics.py) |
| Runner | [runner.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/rl/runner.py) |
| 机器人配置(H1_2) | [h1_2/env_cfgs.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py) |
| RL 超参(H1_2) | [h1_2/rl_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/rl_cfg.py) |

---

## 4. Velocity 任务详解

### 4.1 动作空间

```python
actions = {
    "joint_pos": JointPositionActionCfg(
        entity_name="robot",
        actuator_names=(".*",),
        scale=0.25,        # 各机器人覆盖此值
        use_default_offset=True,  # 动作输出 = default_joint_pos + action
    )
}
```

动作输出为**关节位置目标**，加上 `default_joint_pos` 偏移后发送给 PD 控制器。

### 4.2 Actor 观测（8 组）

| 观测项 | 维度 | 来源 | 噪声 |
|--------|:----:|------|:----:|
| `base_ang_vel` | 3 | IMU 角速度（本体坐标系） | ±0.2 |
| `projected_gravity` | 3 | 重力向量投影到本体坐标系 | ±0.05 |
| `command` | 3 | 速度指令 (vx, vy, ωz) | 无 |
| `phase` | 2 | 步态相位 (sin, cos, period=0.6s) | 无 |
| `joint_pos` | N | 关节位置（相对 default） | ±0.01 |
| `joint_vel` | N | 关节速度 | ±1.5 |
| `actions` | N | 上一步动作 | 无 |
| `height_scan` | 187 | 地形高度扫描（射线传感器阵列 1.6m×1.0m, 0.1m 分辨率） | ±0.1 |

> N = 机器人关节数（H1_2 为 27 维）

### 4.3 Critic 观测（特权信息）

Critic 拥有全部 actor 观测（除 `height_scan` 无噪声外），还额外增加：

| 观测项 | 维度 | 来源 |
|--------|:----:|------|
| `base_lin_vel` | 3 | IMU 线速度（无噪声） |
| `foot_height` | 4 | 四足足端高度 |
| `foot_air_time` | 4 | 四足离地时间 |
| `foot_contact` | 4 | 四足触地状态（0/1） |
| `foot_contact_forces` | 12 | 四足接触力（log1p 压缩，3 轴 × 4 足） |

### 4.4 奖励函数（15 项）

定义在 [velocity/mdp/rewards.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/mdp/rewards.py)：

#### 正向奖励（最大化）

| 奖励项 | 权重 | 函数 | 含义 |
|--------|:----:|:----:|------|
| `track_linear_velocity` | +1.0 | `exp(-error²/std²)` | 跟踪 x/y 线速度指令，z 速度惩罚 2x |
| `track_angular_velocity` | +1.0 | `exp(-error²/std²)` | 跟踪 ωz 指令，xy 角速度 0.05x 弱惩罚 |
| `pose` | +1.0 | `exp(-mean(error²/std²))` | 三段速度依赖的姿态保持，按关节分组配置标准差 |
| `foot_gait` | +0.5 | 相位匹配准确率 | Trot 步态（offset=[0.0, 0.5]），要求触地/离地匹配 |

#### 负向奖励（惩罚/最小化）

| 奖励项 | 权重 | 含义 |
|--------|:----:|------|
| `body_orientation_l2` | -1.0 | 机身 xy 方向倾斜惩罚 |
| `body_ang_vel` | -0.05 | 机身角速度（xy 方向） |
| `angular_momentum` | -0.025 | 全身角动量（促进自然摆臂） |
| `is_terminated` | -200.0 | 提前终止惩罚（大权重防止"自杀"） |
| `joint_acc_l2` | -2.5e-7 | 关节加速度平滑 |
| `joint_pos_limits` | -10.0 | 关节超限位惩罚 |
| `action_rate_l2` | -0.05 | 动作变化率平滑 |
| `foot_clearance` | -1.0 | 离地高度偏差 × 脚速度（惩罚扫腿） |
| `foot_slip` | -0.25 | 触地时脚滑动 |
| `soft_landing` | -1e-3 | 落地冲击力 |
| `stand_still` | -1.0 | 静止时姿势偏差 |

#### `variable_posture` 奖励的三种速度模式

根据指令 `|v| + |ω|` 分三档，每档使用不同的关节标准差，配置在 [h1_2/env_cfgs.py#L94-L128](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/config/h1_2/env_cfgs.py#L94-L128)：

| 模式 | 速度阈值 | 标准差(std)范围 | 含义 |
|:----|:--------:|:--------------:|------|
| standing | < 0.1 | 0.05（所有关节） | 站立时严格保持 default pose |
| walking | [0.1, 1.5) | 膝/髋 0.5，踝 0.1-0.15，肩肘 0.1-0.15 | 行走时中等自由度 |
| running | >= 1.5 | walking x 1.5-2x | 跑步时更大自由度 |

### 4.5 终止条件

| 条件 | 触发 |
|:----|:----|
| `time_out` | 回合达到 20s |
| `fell_over` | 机身倾斜 > 70° |

### 4.6 域随机化

| 事件 | 时机 | 内容 |
|:----|:----:|------|
| `reset_base` | reset | 随机重置机器人位置/朝向 |
| `reset_robot_joints` | reset | 重置关节位置/速度 |
| `push_robot` | interval (5-6s) | 随机施加线速度/角速度扰动 |
| `foot_friction` | startup | 足部摩擦系数 [0.3, 1.6] 随机 |
| `encoder_bias` | startup | 编码器偏置 ±0.015 rad |
| `base_com` | startup | 机身 CoM 偏移 ±0.05m |

### 4.7 课程学习

| 课程 | 机制 |
|:----|:----|
| `terrain_levels` | 走够距离 → 升级到更难地形 |
| `command_vel` | 5000 step 后扩大速度指令范围 |

### 4.8 PPO 超参

配置在 [rl_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/config/h1_2/rl_cfg.py)：

| 参数 | 值 |
| :--- | :--- |
| Actor/Critic 网络 | (512, 256, 128) ELU |
| Actor 分布 | GaussianDistribution, init_std=1.0, scalar std |
| 学习率 | 1e-3 (adaptive schedule, target KL=0.01) |
| 折扣因子 γ | 0.99 |
| GAE λ | 0.95 |
| PPO clip | 0.2 |
| 熵系数 | 0.01 |
| value_loss_coef | 1.0 |
| 每 env 步数 | 24 |
| mini-batches | 4 |
| epochs | 5 |
| 最大迭代 | 10001 |
| 保存间隔 | 100 iter |

---

## 5. Tracking / Mimic 任务详解

### 5.1 MotionCommand 机制

核心组件 [MotionCommand](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/commands.py)：

1. **加载 NPZ**：`MotionLoader` 从 `.npz` 文件加载完整运动轨迹
2. **按 time_step 索引**：每个环境维护 `time_steps` tensor，逐帧推进
3. **参考数据**：

```python
# NPZ 包含的数据
joint_pos       # (T, N_joints)    参考关节位置
joint_vel       # (T, N_joints)    参考关节速度
body_pos_w      # (T, N_bodies, 3) 参考身体位置（世界系）
body_quat_w     # (T, N_bodies, 4) 参考身体朝向（四元数）
body_lin_vel_w  # (T, N_bodies, 3) 参考身体线速度
body_ang_vel_w  # (T, N_bodies, 3) 参考身体角速度
```

4. **RSI（Residual Stage-wise Imitation）**：resample 时对参考运动施加随机噪声（pose ±0.05m, velocity ±0.5m/s, joint ±0.1rad），提高鲁棒性

5. **三种采样模式**：

| 模式 | 用途 | 说明 |
|:----|:----|:----|
| `start` | play 模式 | 始终从第 0 帧开始 |
| `uniform` | demo 或训练 | 随机均匀采样起始帧 |
| `adaptive` | 训练（默认） | 根据失败率自适应采样，困难片段更高概率被采样 |

**自适应采样**：将运动轨迹分为 `bin_count` 个 bin，每个 bin 记录该段的失败次数（`adaptive_alpha=0.001` 做 EMA 平滑），通过 `torch.multinomial` 加权采样。

### 5.2 动作空间

与 velocity 任务一致，`JointPositionActionCfg`，scale 按机器人分别设置（H1_2 为 `H1_2_ACTION_SCALE`）。

### 5.3 Actor 观测

| 观测项 | 维度 | 来源 | 噪声 |
|--------|:----:|------|:----:|
| `command` | 2N | 参考关节 pos 和 vel 拼接 | 无 |
| `motion_anchor_pos_b` | 3 | 参考锚点位置（本体坐标系） | ±0.25 |
| `motion_anchor_ori_b` | 6 | 参考锚点朝向（旋转矩阵前 2 行） | ±0.05 |
| `base_lin_vel` | 3 | IMU 线速度 | ±0.5 |
| `base_ang_vel` | 3 | IMU 角速度 | ±0.2 |
| `joint_pos` | N | 关节位置（含 bias 噪声） | ±0.01 |
| `joint_vel` | N | 关节速度 | ±0.5 |
| `actions` | N | 上一步动作 | 无 |

### 5.4 Critic 观测（特权信息）

包含全部 actor 观测（无噪声），额外增加：

| 观测项 | 维度 | 含义 |
|--------|:----:|------|
| `body_pos` | 3K | 各身体部位在锚点坐标系下的位置（K=参考 body 数） |
| `body_ori` | 6K | 各身体部位在锚点坐标系下的朝向（旋转矩阵前 2 行） |

### 5.5 观测维度计算（H1_2，N_joints=N_bodies=27）

**Actor 观测**：
```
command:    2×27 = 54
anchor_pos: 3
anchor_ori: 6
base_lin_vel: 3
base_ang_vel: 3
joint_pos:  27
joint_vel:  27
actions:    27
-------------------
Total:      150
```

**Critic 观测**：
```
actor 全部: 150
body_pos:   3×27 = 81
body_ori:   6×27 = 162
-------------------
Total:      393
```

### 5.6 has_state_estimation 的区别

在 [h1_2/env_cfgs.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py#L74-L85) 中通过 `has_state_estimation` 参数控制：

```python
def unitree_h1_2_flat_tracking_env_cfg(
  has_state_estimation: bool = True,
  play: bool = False,
) -> ManagerBasedRlEnvCfg:
```

| 模式 | 注册任务 ID | has_state_estimation | Actor 观测差异 |
|:----|:-----------|:--------------------:|:--------------|
| **Estimate** | `Unitree-H1_2-Tracking` | `True`（默认） | 完整 150 维，含 `motion_anchor_pos_b`(3) 和 `base_lin_vel`(3) |
| **No-Estimate** | `Unitree-H1_2-Tracking-No-State-Estimation` | `False` | 移除 `motion_anchor_pos_b` 和 `base_lin_vel` → 144 维 |

**含义**：
- **Estimate**：假设机器人具备状态估计能力（如视觉里程计、线性速度观测），actor 可以直接观测到本体线速度和参考锚点相对位置
- **No-Estimate**：不提供线速度和锚点位置观测，策略必须仅从关节传感器、IMU（角速度+重力）和动作参考数据中隐式推断状态。这更接近真实机器人部署场景（特别是低成本机器人）

两种模式的 RL 超参完全相同（共用 `unitree_h1_2_tracking_ppo_runner_cfg()`）。

### 5.7 奖励函数（9 项）

定义在 [tracking/mdp/rewards.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/rewards.py)：

全部使用指数型 `exp(-error²/std²)` 将误差映射到 [0,1]：

| 奖励项 | 权重 | std | 含义 |
|--------|:----:|:---:|------|
| `motion_global_root_pos` | +0.5 | 0.3 | 锚点位置误差（世界系） |
| `motion_global_root_ori` | +0.5 | 0.4 | 锚点朝向误差（四元数误差幅度） |
| `motion_body_pos` | +1.0 | 0.3 | 各 body 位置误差（相对锚点系） |
| `motion_body_ori` | +1.0 | 0.4 | 各 body 朝向误差（相对锚点系） |
| `motion_body_lin_vel` | +1.0 | 1.0 | 各 body 线速度误差（世界系） |
| `motion_body_ang_vel` | +1.0 | 3.14 | 各 body 角速度误差（世界系） |
| `action_rate_l2` | -0.1 | — | 动作变化率 L2 惩罚 |
| `joint_limit` | -10.0 | — | 关节超限位惩罚 |
| `self_collisions` | -10.0 | — | 自碰撞惩罚（force > 10N） |

**映射关系**：body_pos/body_ori/body_lin_vel/body_ang_vel 的 `body_names` 在 [h1_2/env_cfgs.py#L43-L58](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py#L43-L58) 配置，H1_2 使用 14 个参考 body：

```
pelvis, left_hip_roll_link, left_knee_link, left_ankle_roll_link,
right_hip_roll_link, right_knee_link, right_ankle_roll_link,
torso_link,
left_shoulder_roll_link, left_elbow_link, left_wrist_yaw_link,
right_shoulder_roll_link, right_elbow_link, right_wrist_yaw_link
```

### 5.8 终止条件

| 条件 | 触发阈值 | 含义 |
|:----|:--------:|------|
| `time_out` | 10s | 回合超时 |
| `anchor_pos` | z 偏差 > 0.25m | 锚点高度偏离参考 |
| `anchor_ori` | 重力投影差 > 0.8 | 锚点朝向偏离参考 |
| `ee_body_pos` | z 偏差 > 0.25m | 末端执行器高度偏离（有配置：`left_ankle_roll_link`, `right_ankle_roll_link`, `left_wrist_yaw_link`, `right_wrist_yaw_link`） |

### 5.9 PPO 超参

与 velocity 任务略有不同（追踪任务使用更小的熵系数和更长的训练周期）：

| 参数 | Velocity | Tracking |
|:----|:--------:|:--------:|
| 熵系数 | 0.01 | 0.005 |
| 最大迭代 | 10001 | 30001 |
| 保存间隔 | 100 | 500 |

其余超参（网络结构、学习率、clip、γ、λ 等）相同。

---

## 6. 训练循环流程

```python
train.py → launch_training()
  │
  ├─ ManagerBasedRlEnv(cfg.env)    → 创建 MuJoCo 场景 × num_envs
  │   ├─ scene (entities, sensors, terrain)
  │   ├─ 各 manager 初始化
  │   └─ 首次 reset()
  │
  ├─ RslRlVecEnvWrapper(env)       → 包装为 rsl_rl VecEnv 接口
  │
  ├─ MotionTrackingOnPolicyRunner(env, agent_cfg, log_dir, device)
  │   ├─ 创建 PPO 算法实例
  │   │   ├─ ActorNetwork(obs_dim → action_dim)
  │   │   ├─ CriticNetwork(obs_dim → 1)
  │   │   └─ RolloutStorage(num_steps_per_env=24)
  │   └─ 可选: runner.load(resume_path) ← 恢复 checkpoint
  │
  └─ runner.learn(max_iterations)
      │
      for iteration in range(max_iterations):
        │
        ├─ [采集阶段]
        │   for step in range(num_steps_per_env):
        │     actions = alg.actor(observations)
        │     env.step(actions) → next_obs, rewards, dones, infos
        │     alg.process_env_step(rewards, dones, infos)
        │
        ├─ [学习阶段]
        │   alg.compute_returns(lam=0.95, gamma=0.99)
        │   for epoch in range(num_learning_epochs):
        │     for batch in range(num_mini_batches):
        │       alg.update(batch) → PPO loss
        │
        ├─ [自适应学习率]
        │   根据 KL 散度调整学习率
        │
        └─ [保存/导出]
            if iteration % save_interval == 0:
              runner.save(checkpoint_path)  ← 含 ONNX 导出
```

### 关键时序参数

| 参数 | 值 | 含义 |
|:----|:--:|------|
| 物理步长 dt | 0.005s | MuJoCo 仿真步长 |
| decimation | 4 | 控制降采样因子 |
| 控制步长 | 0.02s | decimation × dt |
| num_steps_per_env | 24 | 每次 PPO update 前采集步数 |
| 每 iter 轨迹长度 | 24 × 0.02 = 0.48s |
| episode_length_s | 20s (vel) / 10s (tracking) |

---

## 7. ONNX 导出机制

`MotionTrackingOnPolicyRunner.save()` 在每次保存 checkpoint 时自动导出：

### 7.1 简单策略 ONNX

```python
export_policy_to_onnx() → policy.onnx
# 输入: obs (150 维)
# 输出: actions (27 维)
```

### 7.2 含 Motion Buffer 的复合 ONNX

```python
export_motion_policy_to_onnx() → {run_name}.onnx
# 使用 _OnnxMotionModel 包装
```

```
_OnnxMotionModel.forward(obs, time_step):
    actions = policy(obs)
    # 同时输出当前 time_step 的完整参考运动
    return actions, joint_pos[t], joint_vel[t],
           body_pos_w[t], body_quat_w[t],
           body_lin_vel_w[t], body_ang_vel_w[t]
```

| 输入 | 维度 | 说明 |
|:----|:----:|------|
| `obs` | (B, 150) | actor 观测 |
| `time_step` | (B, 1) int64 | 运动时间步索引 |

| 输出 | 维度 | 说明 |
|:----|:----:|------|
| `actions` | (B, 27) | 策略输出的关节位置目标 |
| `joint_pos` | (B, 27) | 参考关节位置 |
| `joint_vel` | (B, 27) | 参考关节速度 |
| `body_pos_w` | (B, 14, 3) | 参考 body 位置（世界系） |
| `body_quat_w` | (B, 14, 4) | 参考 body 朝向 |
| `body_lin_vel_w` | (B, 14, 3) | 参考 body 线速度 |
| `body_ang_vel_w` | (B, 14, 3) | 参考 body 角速度 |

部署时只需运行 ONNX 模型，无需 Python 环境和 NPZ 文件。

---

## 8. 如何引入新的奖励

要添加新的奖励项，需修改 **3 个文件**：

### Step 1：实现奖励函数

在对应的 `mdp/rewards.py` 中添加。

**函数签名**（两种形式）：

```python
# 形式 A：无状态函数
def my_new_reward(
    env: ManagerBasedRlEnv,
    param1: type,
    ...
) -> torch.Tensor:
    """返回 shape (num_envs,) 的 tensor。"""
    return result

# 形式 B：有状态类（需要 __init__ 做初始化）
class my_new_reward:
    def __init__(self, cfg: RewardTermCfg, env: ManagerBasedRlEnv):
        # 初始化缓存、累加器等状态
        self.counter = torch.zeros(env.num_envs, device=env.device)

    def __call__(self, env, ...) -> torch.Tensor:
        return result
```

**可用 API**：

| API | 返回 | 说明 |
|:----|:----|------|
| `env.scene["robot"]` | `Entity` | 机器人实体，提供运动学/动力学数据 |
| `entity.data.joint_pos` | (B, N) | 关节位置 |
| `entity.data.root_link_lin_vel_b` | (B, 3) | 本体线速度 |
| `entity.data.root_link_ang_vel_b` | (B, 3) | 本体角速度 |
| `entity.data.projected_gravity_b` | (B, 3) | 重力方向投影 |
| `entity.data.body_link_pos_w` | (B, K, 3) | 各 body 世界坐标 |
| `entity.data.site_pos_w` | (B, M, 3) | 各 site 世界坐标 |
| `env.command_manager.get_command(name)` | (B, D) | 指令 tensor |
| `env.scene[sensor_name]` | `ContactSensor` | 触地传感器数据 |
| `env.episode_length_buf` | (B,) | 当前步数 |
| `env.step_dt` | float | 物理步长 |
| `env.num_envs` | int | 并行环境数 |
| `env.extras["log"][key]` | — | 记录 metrics 到 wandb |

### Step 2：在 Base 配置中注册

```python
# velocity_env_cfg.py 或 tracking_env_cfg.py
rewards = {
    ...
    "my_new_reward": RewardTermCfg(
        func=mdp.my_new_reward,       # 或类 mdp.MyNewReward()
        weight=1.0,                   # 正=奖励，负=惩罚
        params={
            "param1": value1,
            ...
        },
    ),
}
```

### Step 3：在机器人具体配置中微调参数

```python
# config/h1_2/env_cfgs.py
cfg.rewards["my_new_reward"].weight = 2.0
cfg.rewards["my_new_reward"].params["param1"] = new_value
```

---

## 9. 关键设计要点

1. **Asymmetric Actor-Critic**：actor 使用带噪声的受限观测（`enable_corruption=True`），critic 使用无噪声的特权信息，这是标准隐式域随机化做法

2. **MotionCommand 全量缓存**：NPZ 轨迹在初始化时完全载入显存，按 time_step 索引，零 IO 开销

3. **自适应采样**（tracking 任务）：根据历史失败率对运动轨迹片段加权采样，困难片段更多被训练到

4. **三段式姿态奖励**（velocity 任务）：根据指令速度自动切换关节容忍度，实现平滑的站立→行走→奔跑过渡

5. **多 GPU 支持**：通过 `torchrunx` 实现数据并行，每个 worker 独立的 MuJoCo 实例，`CUDA_VISIBLE_DEVICES` 控制可见 GPU

6. **Play 模式差异**：禁用域随机化、无限 episode 长度、固定 motion 起始帧（`sampling_mode="start"`）
