# 02 G1 Mimic 策略仿真探索

> **系列定位**：本篇为 Mimic 系列的第二篇，以 G1 机器人为载体首次探索 `unitree_rl_mjlab` 的全身动作模仿（Tracking）框架。

**本篇目的**：
探索并分析基于 [unitree_rl_mjlab](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab) 框架导出的 **Unitree G1 机器人**全身动作模仿（Mimic / Tracking）的特征结构与仿真播放验证流程。分析 G1 机器人的动作模仿网络输入输出细节，为后续更深入的多关节机器人控制流程进行理论铺垫。

---

## 1. 实验基本设计

为了在仿真中验证人形机器人的全身动作模仿，本实验引入了基于 MuJoCo 的动作模仿框架：

- **动作模仿框架**：[unitree_rl_mjlab](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab)
  - **网络地址**：https://github.com/unitreerobotics/unitree_rl_mjlab
  - **核心功能**：基于 `mjlab` 结合了 `Isaac Lab` 与 `MuJoCo` 引擎构建的机器人强化学习框架。提供了对全身模仿（BeyondMimic 方案）的原生支持，能够加载 csv/npz 动作数据进行轨迹匹配训练，并导出实机部署所需的 ONNX 模型与元数据。在本篇中，我们以官方内置的 G1 机器人及其预训练模型与动捕轨迹作为实验载体。

---

## 2. G1 神经网络结构与输入输出核对

根据 [tracking_env_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/tracking_env_cfg.py) 源码以及对 G1 机器人模型的解析，G1 机器人的动作模仿任务 `Unitree-G1-Tracking-No-State-Estimation`（无状态估计版本）包含 **154 维状态输入** 和 **29 维全身动作输出**。

### 2.1 动作输出：`actions` (29 维)

G1 策略输出的 29 维动作向量作用于 G1 的 **29 个主动自由度**。输出动作会乘以 scale 并加到对应关节的默认角度上：
$$q_{\text{target}} = a \cdot \text{action\_scale} + q_{\text{default}}$$

这 29 个输出维度与 G1 关节的排布顺序一致，涵盖双腿双臂及躯干：
- 左右腿各 6 关节 = 12 自由度
- 腰部 3 关节（`waist_yaw_joint`, `waist_roll_joint`, `waist_pitch_joint`）= 3 自由度
- 左右臂各 7 关节 = 14 自由度
- 总计 29 个主动关节。

### 2.2 状态输入：`obs` (154 维)

在无状态估计的情况下，G1 的 154 维状态输入依次包含以下几个观测指标：
- **参考运动关节位置与速度** (58 维)：`motion_ref_pos` (29维) + `motion_ref_vel` (29维)，当前时间步目标参考轨迹的期望关节角度和速度。
- **相对根节点姿态** (6 维)：`motion_anchor_ori_b`，参考轨迹中的根节点旋转与当前机器人 Pelvis 姿态的相对旋转。
- **基座角速度** (3 维)：`base_ang_vel`，IMU 的角速度。
- **实际关节位置** (29 维)：`joint_pos`，当前各关节角度与默认角度的偏差。
- **实际关节速度** (29 维)：`joint_vel`，当前各关节角速度。
- **上一次动作缓冲** (29 维)：`actions`。
- **总计**：58 + 6 + 3 + 29 + 29 + 29 = 154 维。

### 2.3 动作轨迹数据准备与 NPZ 格式转换

CSV→NPZ 转换流程与脚本说明：使用 `scripts/csv_to_npz.py` 脚本，通过 MuJoCo 物理引擎运行前向动力学（`sim.forward()`），为每个刚体 link 生成世界坐标系下的位置、姿态和速度，并以 `wxyz` 四元数格式保存为 `.npz`。G1 版本使用 `--robot g1` 参数，输出目录为 `src/assets/motions/g1/`。

---

## 3. 仿真与隔离环境部署说明

在运行仿真前，需配置环境并完成包的安装。

### 3.1 Conda 环境确认与依赖安装

复用既有的 `/home/meme/.conda/envs/unitree-rl-sim2sim-py310` 虚拟环境，安装 onnxruntime 相关工具：
```bash
conda activate unitree-rl-sim2sim-py310

# 安装 onnxruntime 解析支持
pip install onnxruntime -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 3.2 克隆与可编辑安装 unitree_rl_mjlab

为了在 Python 仿真中无缝导入而无需挪动目录，采用 `--no-deps` 参数对 `unitree_rl_mjlab` 进行零侵入的可编辑安装（可避开 `setup.py` 中如 `isaacgym` 等重量级物理引擎的安装）：
```bash
cd /home/meme/Documents/unitree_h1
git clone https://github.com/unitreerobotics/unitree_rl_mjlab.git

# 在虚拟环境中可编辑安装，仅注册包路径
conda activate unitree-rl-sim2sim-py310
env -u PYTHONPATH pip install -e /home/meme/Documents/unitree_h1/unitree_rl_mjlab --no-deps
```

---

## 4. 原生 Python 推导仿真播放实验 (Play)

### 4.1 补齐虚拟环境依赖与版本对齐

在既有的 `unitree-rl-sim2sim-py310` 虚拟环境中，采用针对性的小包增量安装策略补齐依赖，并对齐 `mujoco` 版本为 3.5.0：
```bash
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab
conda activate unitree-rl-sim2sim-py310

# 增量安装中间依赖与渲染可视化工具，排除大包的写锁冲突
pip install tyro prettytable viser mediapy imageio-ffmpeg tensordict onnxscript wandb trimesh tqdm ipython --no-deps

# 安装 mjlab 底层核心框架与 warp 编译器
pip install mjlab==1.2.0 mujoco-warp==3.5.0 --no-deps

# 关键版本对齐：mujoco-warp 3.5.0 与最新 mujoco 3.9.0 存在 IntFlag 属性兼容问题，需将 mujoco 强制对齐到 3.5.0
pip install mujoco==3.5.0 --no-deps
```

### 4.2 验证环境注册与原生推导播放 (zero-agent)

在启动完整的训练模型播放前，通常通过指定 `viser` Web 可视化浏览器渲染，并先使用 `zero-agent` 绕过对预训练 checkpoint 的硬性要求，启动最基础的空回放来验证环境。

> [!TIP]
> 使用 `--agent zero` 时，由于控制输入全为 0，真实的物理机器人会迅速摔倒，这会立刻触发环境的终止条件（如 `ee_body_pos` 或 `anchor_pos` 偏离过大），从而导致环境被频繁重置（Reset）。在渲染画面中，这表现为“似乎一直在重放最开始的一个极短片段”。
> 
> 为了能完整地观看动作轨迹（使半透明的 Ghost 幽灵机器人把整个舞蹈跳完），应该附带 `--no-terminations True` 参数以禁用所有终止重置条件（由于命令行解析库的配置要求，布尔类型的开关需显式指定其值为 `True`）。

```bash
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab
python scripts/play.py Unitree-G1-Tracking-No-State-Estimation \
  --motion_file deploy/robots/g1/config/policy/mimic/dance1_subject2/params/dance1_subject2.npz \
  --agent zero \
  --viewer viser \
  --no-terminations True
```

### 4.3 加载 ONNX 策略进行仿真播放

官方仓库仅包含导出的 ONNX 策略而不含原始 PyTorch 权重。为支持 `.onnx` 格式的评估，需要扩展 `play.py` 新增 `_OnnxPolicy` 类和 `--agent onnx` 模式。G1 用法与 H1_2 类似：

```bash
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab
python scripts/play.py Unitree-G1-Tracking-No-State-Estimation \
  --agent onnx \
  --onnx_file deploy/robots/g1/config/policy/mimic/dance1_subject2/exported/policy.onnx \
  --motion_file deploy/robots/g1/config/policy/mimic/dance1_subject2/params/dance1_subject2.npz \
  --viewer viser \
  --no-terminations True
```

---

## 5. 仿真进程清理

仿真结束后，可以运行以下命令强制杀掉残留的仿真进程，释放占用端口：

```bash
# 终止 play.py python 仿真进程
pkill -f "play.py"

# 或者通过释放 Viser 占用的网络端口来清理进程
fuser -k 8080/tcp
fuser -k 8081/tcp
fuser -k 8082/tcp
# ....
```
