# 03 H1_2 Mimic 训练适配

> **系列定位**：在 [02 G1 Mimic 策略仿真探索](file:///home/meme/Documents/笔记/02%20Mimic/02%20G1%20Mimic%20%E7%AD%96%E7%95%A5%E4%BB%BF%E7%9C%9F%E6%8E%A2%E7%B4%A2.md) 完成 G1 验证后，本篇记录将训练流程适配到 H1_2 机器人所需的配置与代码修改。



---

## 1. 适配概览

官方仓库仅内置 G1（29 关节）和 G1_23dof（23 关节）的 tracking 训练配置。为支持 H1_2（27 关节）训练，需要新增：

1. **机器人资源配置**：H1_2 的 MJCF 模型、actuator 参数、碰撞配置
2. **环境配置**：指定机器人 entity、body 映射、动作 scale、自碰撞
3. **算法配置**：PPO 超参数（与 G1 共享架构，但独立配置）
4. **任务注册**：将上述配置注册为可训练任务

---

## 2. 机器人资源配置

### 2.1 MJCF 模型

文件：[h1_2.xml](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/assets/robots/unitree_h1_2/xmls/h1_2.xml)

H1_2 与 G1 的关节差异：

| 项目 | G1 | H1_2 |
| :--- | :--- | :--- |
| 关节总数 | 29 | 27 |
| 腰部 | waist_yaw + waist_roll + waist_pitch | 仅 torso_joint (yaw) |
| 手腕 | 无 wrist_pitch/wrist_yaw (仅 roll) | 有 left/right_wrist_pitch + wrist_yaw |
| 自由度分布 | 腿部 12 + 腰部 3 + 手臂 14 | 腿部 12 + 腰部 1 + 手臂 14 |

### 2.2 Actuator 参数

文件：[h1_2_constants.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/assets/robots/unitree_h1_2/h1_2_constants.py)

H1_2 使用 4 组不同规格的 actuator：

| Actuator 组 | 关节 | stiffness | damping | effort_limit |
| :--- | :--- | :--- | :--- | :--- |
| M107_24_2 | hip_yaw/pitch/roll, torso | 98.7 | 6.3 | 200 Nm |
| M107_24_1 | knee | 157.7 | 10.1 | 300 Nm |
| GO2HV_1 | ankle_pitch/roll, shoulder_pitch/roll | 19.7 | 1.3 | 40 Nm |
| GO2HV_2 | shoulder_yaw, elbow, wrist_* | 7.9 | 0.5 | 18 Nm |

### 2.3 Action Scale 计算

```python
H1_2_ACTION_SCALE[n] = 0.25 * effort_limit / stiffness
```

这使得每个关节的 action 输出范围与其物理能力匹配：强关节（knee）允许更大偏移，弱关节（wrist）限制动作范围。实际下发目标位置公式：

$$ q_{\text{target}} = a \cdot 0.25 \cdot \frac{\tau_{\max}}{k_p} + q_{\text{default}} $$

### 2.4 默认站姿

```python
HOME_KEYFRAME = EntityCfg.InitialStateCfg(
  pos=(0, 0, 1.02),           # 骨盆离地 1.02m
  joint_pos={
    ".*_hip_pitch_joint": -0.2,
    ".*_knee_joint": 0.5,
    ".*_ankle_pitch_joint": -0.3,
    ".*_shoulder_pitch_joint": 0.28,
    ".*_elbow_joint": 0.52,
  },
)
```

机器人以微蹲姿态初始化，手臂自然下垂微曲。

---

## 3. 环境配置适配

文件：[env_cfgs.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py)

### 3.1 关键修改点

对比 G1 环境配置，H1_2 的差异化配置：

```python
# 1. 机器人 entity
cfg.scene.entities = {"robot": get_h1_2_robot_cfg()}

# 2. 动作 scale（每个关节独立计算）
joint_pos_action.scale = H1_2_ACTION_SCALE

# 3. Anchor body（参考根节点）
motion_cmd.anchor_body_name = "torso_link"   # G1: "pelvis"

# 4. 14 个参考 body（与 G1 不同）
motion_cmd.body_names = (
    "pelvis",
    "left_hip_roll_link", "left_knee_link", "left_ankle_roll_link",
    "right_hip_roll_link", "right_knee_link", "right_ankle_roll_link",
    "torso_link",
    "left_shoulder_roll_link", "left_elbow_link", "left_wrist_yaw_link",
    "right_shoulder_roll_link", "right_elbow_link", "right_wrist_yaw_link",
)
# G1 有 waist_roll_link 而 H1_2 无

# 5. 自碰撞 sensor
self_collision_cfg = ContactSensorCfg(
    primary=ContactMatch(mode="subtree", pattern="pelvis", entity="robot"),
    secondary=ContactMatch(mode="subtree", pattern="pelvis", entity="robot"),
)

# 6. 足部几何体正则（H1_2 foot 几何命名不同）
cfg.events["foot_friction"].params["asset_cfg"].geom_names = \
    r"^(left|right)_foot[1-7]_collision$"
# G1: r"^(left|right)_ankle_roll_collision$"

# 7. 末端约束 body 名称
cfg.terminations["ee_body_pos"].params["body_names"] = (
    "left_ankle_roll_link", "right_ankle_roll_link",
    "left_wrist_yaw_link", "right_wrist_yaw_link",
)

# 8. 视角跟随
cfg.viewer.body_name = "torso_link"
```

### 3.2 无状态估计变体（**用于训练的版本**）

额外注册了 `Unitree-H1_2-Tracking-No-State-Estimation` 任务，移除 `motion_anchor_pos_b`（3 维）和 `base_lin_vel`（3 维）观测（从 150 维降至 144 维），用于模拟无 VIO/里程计的场景。

> **⚠️ 重要 — 观测维度匹配问题**
>
> 官方 deploy 端（C++ 实机/仿真部署）期望的 obs 维度来自 **No-State-Estimation** 版本（144 维）。如果使用带状态估计的 `Unitree-H1_2-Tracking`（150 维）训练模型并部署，obs 维度不匹配会使脏数据输入，导致机器人剧烈抽搐或断电。
>
> **无论训练还是仿真回放，始终使用 `Unitree-H1_2-Tracking-No-State-Estimation` 任务**。详见 [Issue #23](https://github.com/klavier1127/unitree_rl_mjlab/issues/23) / [#25](https://github.com/klavier1127/unitree_rl_mjlab/issues/25)。

---

## 4. 训练算法配置

文件：[rl_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/rl_cfg.py)

| 参数 | H1_2 值 | G1 值 | 差异说明 |
| :--- | :--- | :--- | :--- |
| 网络结构 | (512, 256, 128) | (512, 256, 128) | 相同 |
| 激活函数 | ELU | ELU | 相同 |
| 学习率 | 1e-3 adaptive | 1e-3 adaptive | 相同 |
| num_steps_per_env | 24 | 24 | 相同 |
| max_iterations | 30001 | 20001 | H1_2 多 10000 轮 |
| save_interval | 500 | 400 | H1_2 保存频率略低 |
| experiment_name | h1_2_tracking | g1_tracking | 日志分离 |

---

## 5. 任务注册

文件：[__init__.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/__init__.py)

注册两个任务变体：

```python
# 完整观测（150 维）— 仅用于无部署需求的实验对比
register_mjlab_task(
  task_id="Unitree-H1_2-Tracking",
  runner_cls=MotionTrackingOnPolicyRunner,
)

# 无状态估计（144 维）— **训练和部署都用这个**
register_mjlab_task(
  task_id="Unitree-H1_2-Tracking-No-State-Estimation",
  env_cfg=unitree_h1_2_flat_tracking_env_cfg(has_state_estimation=False),
)
```

> **注意**：只有 `No-State-Estimation` 版本（144 维 obs）与官方 deploy 端 C++ 代码兼容。

两个任务共享同一个 `MotionTrackingOnPolicyRunner`，该 runner 在保存 checkpoint 时自动导出两种 ONNX：
- `policy.onnx`：纯策略推理（obs → action）
- `{name}.onnx`：含 motion buffer 的复合模型（obs + time_step → action + motion data）

---

## 6. 与 G1 适配的核心差异总结

| 适配维度 | G1 | H1_2 |
| :--- | :--- | :--- |
| 关节数 | 29 | 27 |
| 腰部自由度 | 3 (yaw/roll/pitch) | 1 (yaw) |
| 手腕自由度 | 1 (roll) | 3 (roll/pitch/yaw) |
| Anchor body | pelvis | torso_link |
| 参考 body 数 | 15 | 14 |
| 足部碰撞几何 | ankle_roll_collision | foot[1-7]_collision |
| Actuator 组 | M107 + G1 专用 | M107 + GO2HV |
