# unitree_rl_mjlab 训练系统改进分析报告（修正版）

> 基于对 `unitree_rl_mjlab` 训练代码 + mjlab 框架源码的深度阅读，对照 `whole_body_tracking`（BeyondMimic 官方训练库）实现，结合《人形机器人 Mimic 与 Sim2Real 技术全景》综述中的最佳实践。
> **本报告已根据源码审核修正所有事实错误**。
> 审核日期：2026-07-01

---

## 目录

1. [执行器延迟模拟](#1-执行器延迟模拟)
2. [域随机化增强](#2-域随机化增强)
3. [观测空间改进](#3-观测空间改进)
4. [课程学习](#4-课程学习)
5. [奖励函数体系](#5-奖励函数体系)
6. [终止条件增强](#6-终止条件增强)
7. [训练基建与工程化](#7-训练基建与工程化)
8. [Sim2Sim 验证工具链](#8-sim2sim-验证工具链)
9. [整体改进优先级矩阵](#9-整体改进优先级矩阵)

---

## 1. 执行器延迟模拟

### 1.1 现状

`unitree_rl_mjlab` 目前**未使用延迟执行器**。tracking 的 action 配置为标准 `JointPositionActionCfg`，不包含延迟参数。

### 1.2 mjlab 框架能力（关键发现）

**mjlab 已内置 `DelayedActuator`**（[源码](file:///home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/mjlab/actuator/delayed_actuator.py)），功能完整：

- `DelayedActuatorCfg` 包装任意 Actuator，添加可配置的延迟
- 延迟以物理步数为单位量化（如 lag=2 @ 500Hz 物理步 = 4ms）
- 支持 `delay_min_lag` / `delay_max_lag` 随机延迟范围
- 支持 `delay_hold_prob` 控制延迟保持概率（模拟缓慢变化的延迟）
- 支持 `delay_update_period` 控制延迟更新周期
- 支持 `per_env_phase` 各环境独立相位

配套的 `dr.sync_actuator_delays()` 函数可对所有环境统一采样延迟值。

### 1.3 对照

同步对比 `whole_body_tracking` 的 `DelayedImplicitActuator`：
- whole_body_tracking 实现了自定义 actuator，延迟以控制步为单位
- mjlab 的 `DelayedActuator` 以物理步为单位，更精细（200Hz vs 50Hz）
- mjlab 的 DR 函数 `sync_actuator_delays` 与 whole_body_tracking 的 `events.py` 中 action_delay 功能对等

### 1.4 影响

综述（§2.2）明确指出**控制延迟是 Critical 级**的 Sim2Real gap。真实机器人延迟 5-20ms，不模拟延迟的策略在真机上容易出现震荡。

### 1.5 改进方案

利用 mjlab 已有的 `DelayedActuatorCfg`，在 `tracking_env_cfg.py` 中修改 action 配置：

```python
from mjlab.actuator.delayed_actuator import DelayedActuatorCfg
from mjlab.envs.mdp import dr

# 在 tracking_env_cfg.py 的 action 配置中
actions = {
    "joint_pos": JointPositionActionCfg(
        entity_name="robot",
        actuator_names=(".*",),
        scale=0.25,
        use_default_offset=True,
        # 方案 A: 直接在 ActionCfg 中启用延迟（如果 mjlab 支持）
        # 需检查 JointPositionActionCfg 是否转发到 actuator 配置
    ),
}

# 如果 ActionCfg 不支持直接配置，则：
# 方案 B: 在场景配置中使用 DelayedActuatorCfg 包装执行器
# 在 MySceneCfg 中：
actuators = [
    DelayedActuatorCfg(
        base_cfg=ImplicitActuatorCfg(
            stiffness={".*": stiffness},
            damping={".*": damping},
        ),
        delay_min_lag=0,       # 0 ms
        delay_max_lag=10,      # 10 物理步 @200Hz = 50ms
        delay_hold_prob=0.9,   # 延迟缓慢变化
        delay_update_period=4, # 每 4 物理步更新一次延迟
        delay_per_env_phase=True,
    ),
]

# 方案 C: 在 events 中使用 DR 函数
events = {
    "action_delay": EventTermCfg(
        func=dr.sync_actuator_delays,  # ← 此函数确实存在
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "lag_range": (0, 10),  # 0-10 物理步延迟
        },
    ),
}
```

> 实际选择方案需根据 tracking 的 actuator 配置结构确定。

### 1.6 对比 whole_body_tracking

| 维度 | whole_body_tracking | mjlab |
|------|-------------------|-------|
| 是否支持延迟 | ✅ `DelayedImplicitActuator` | ✅ `DelayedActuator`（框架内置） |
| 延迟单位 | 控制步（50Hz） | 物理步（200Hz） |
| DR 随机化 | startup 级，随机选择延迟步数 | `sync_actuator_delays` + `hold_prob` |
| tracking 是否启用 | ✅ 已配置 `actuator.py` | ❌ **未启用** |

**结论**：mjlab 的延迟支持能力甚至比 whole_body_tracking 更完整，只是 tracking 任务未启用。

---

## 2. 域随机化增强

### 2.1 现状

mjlab tracking 当前的 DR 配置（4 项）：

| 随机化项 | 模式 | 参数 | 对应 mjlab 函数 |
|---------|------|------|-----------------|
| `push_robot` | interval 1-3s | 速度扰动 | 自定义（非 DR 模块） |
| `base_com` | startup | CoM 偏移 ±5cm | `dr.body_com_offset()` |
| `encoder_bias` | startup | 关节偏置 ±0.01rad | `dr.encoder_bias()` |
| `foot_friction` | startup | 摩擦 0.3~1.2 | `dr.geom_friction()` |

### 2.2 mjlab 框架能力（关键发现）

**mjlab 的 DR 模块远比预期丰富**，以下函数均可直接使用：

**刚体（Body）类：**
| 函数 | 功能 | 说明 |
|------|------|------|
| `dr.body_mass()` | 随机化 body 质量 | 带 warn（惯性不跟随） |
| `dr.body_com_offset()` | 随机化 COM 偏移 | 等价于 `dr.body_ipos` |
| `dr.pseudo_inertia()` | **推荐** 惯性+质量联合随机化 | 物理一致性，共 10 参数 |
| `dr.body_quat()` | 随机化 body 朝向 | RPY 角度扰动 |

**关节（Joint）类：**
| 函数 | 功能 | 说明 |
|------|------|------|
| `dr.joint_damping()` | 关节阻尼 | `dof_damping` 字段 |
| `dr.joint_friction()` | 关节摩擦 | `dof_frictionloss` 字段 |
| `dr.joint_stiffness()` | 关节刚度 | `jnt_stiffness` 字段 |
| `dr.joint_limits()` | 关节限位 | `jnt_range` 字段 |
| `dr.joint_default_pos()` | 默认位置 | `qpos0` 字段 |

**执行器（Actuator）类：**
| 函数 | 功能 | 说明 |
|------|------|------|
| `dr.pd_gains()` | PD 增益随机化 | 支持 scale/abs，kp+ kd |
| `dr.effort_limits()` | 力矩限制随机化 | 支持 scale/abs |
| `dr.sync_actuator_delays()` | 执行器延迟同步 | 配合 DelayedActuator |

**几何（Geom）类：**
| 函数 | 功能 | 说明 |
|------|------|------|
| `dr.geom_friction()` | 摩擦系数随机化 | ✅ 已使用 |
| `dr.geom_size()` | 几何尺寸随机化 | 自动更新包围盒 |

### 2.3 缺失项分析与建议

| 缺失项 | 推荐 mjlab 函数 | 参数建议 | 依据 |
|-------|-----------------|---------|------|
| PD 增益 | `dr.pd_gains()` | kp=(0.75, 1.5), kd=(0.3, 3.0) | Isaac Lab 共识 |
| 力矩限制 | `dr.effort_limits()` | (0.85, 1.15) scale | vnrobo, unitree |
| 关节阻尼 | `dr.joint_damping()` | (0.5, 2.0) scale | HOVER 共识 |
| 惯性随机化 | `dr.pseudo_inertia()` | alpha=(-0.15, 0.15) | 物理一致性最高 |
| 执行器延迟 | `dr.sync_actuator_delays()` | lag=(0, 10) | 综述 Critical 级 |

### 2.4 改进方案

```python
# 在 tracking_env_cfg.py 中增强 DR
from mjlab.envs.mdp import dr
from mjlab.managers.event_manager import EventTermCfg
from mjlab.managers.scene_entity_config import SceneEntityCfg

events = {
    # 保留已有项
    "foot_friction": EventTermCfg(
        func=dr.geom_friction,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "ranges": (0.3, 1.6),  # 与 velocity 统一
        },
    ),
    "base_com": EventTermCfg(
        func=dr.body_com_offset,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "ranges": (-0.05, 0.05),
        },
    ),
    "encoder_bias": EventTermCfg(
        func=dr.encoder_bias,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "bias_range": (-0.01, 0.01),
        },
    ),
    
    # 新增：PD 增益随机化
    "pd_gains": EventTermCfg(
        func=dr.pd_gains,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "kp_range": (0.75, 1.5),
            "kd_range": (0.3, 3.0),
            "operation": "scale",
        },
    ),
    
    # 新增：惯性/质量联合随机化（物理一致）
    "pseudo_inertia": EventTermCfg(
        func=dr.pseudo_inertia,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "alpha_range": (-0.15, 0.15),   # mass scale ±15%
            "t_range": (-0.02, 0.02),       # COM shift ±2cm
            "d_range": (-0.1, 0.1),         # inertia axis stretch
        },
    ),
    
    # 保留 push_robot 但增强力度
    "push_robot": EventTermCfg(
        func=mdp.push_by_setting_velocity,
        mode="interval",
        interval_range_s=(1.0, 3.0),
        params={
            "velocity_range": {
                "x": (-1.0, 1.0),
                "y": (-1.0, 1.0),
                "z": (-0.5, 0.5),
                "roll": (-0.52, 0.52),
                "pitch": (-0.52, 0.52),
                "yaw": (-0.78, 0.78),
            },
        },
    ),
}
```

### 2.5 反模式警告

- `dr.body_mass()` 带 warn——只改质量不改惯性不物理，应优先用 `dr.pseudo_inertia()`
- 摩擦范围不应超出物理可能（如 [0.01, 10.0]），否则策略无法收敛
- 参数独立随机化可能产生现实中不存在的组合（如重物低摩擦）

---

## 3. 观测空间改进

### 3.1 验证：6D 旋转矩阵表示已正确使用

通过读取 [observations.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/observations.py) 源码确认：

```python
def motion_anchor_ori_b(env, command_name):
    _, ori = subtract_frame_transforms(...)
    mat = matrix_from_quat(ori)
    return mat[..., :2].reshape(mat.shape[0], -1)  # 6D表示
```

`motion_anchor_ori_b` 和 `robot_body_ori_b` 均使用旋转矩阵前两列（6D），与 whole_body_tracking 一致。**此方面无差距**。

### 3.2 实际改进点 1：增加历史帧堆叠

**现状**：tracking 当前 `ObservationGroupCfg(history_length=1)`，无历史堆叠。

**依据**：综述（§5.3）指出使用过去 5-10 帧的观测序列有助于策略隐式估计速度和接触状态。velocity 任务也使用了 `history_length` 配置。

**改进方案**：

```python
observations = {
    "actor": ObservationGroupCfg(
        terms=actor_terms,
        concatenate_terms=True,
        enable_corruption=True,
        history_length=5,  # 从 1 增加到 5
    ),
    "critic": ObservationGroupCfg(
        terms=critic_terms,
        concatenate_terms=True,
        enable_corruption=False,
        history_length=5,  # 从 1 增加到 5
    ),
}
```

> **注意**：增加 `history_length` 会改变观测向量维度，需要同步更新：
> 1. PPO 策略网络的 `input_size`
> 2. ONNX 导出的输入维度
> 3. C++ 部署端的观测组装

### 3.3 实际改进点 2：增加 `biased=True` 影响分析

tracking 的 `joint_pos_rel` 使用了 `biased=True`：

```python
"joint_pos_rel": ObservationTermCfg(
    func=mdp.joint_pos_rel,
    params={"biased": True},
),
```

这意味着**观测值 = 编码器偏置后的关节位置 − 默认关节位置**。加上 `encoder_bias` DR 层的 startup 随机化，相当于做了**两层建模**：
1. startup 级：`dr.encoder_bias()` 随机设置 `asset.data.encoder_bias`
2. 观测级：`joint_pos_rel(biased=True)` 读取偏置后的值

这与 whole_body_tracking 的设计一致。当前实现正确，无需修改。

### 3.4 实际改进点 3：critic 观测可扩展

当前 tracking 的 critic/privileged 观测如下，已包含 `body_pos` 和 `body_ori`，与 whole_body_tracking 一致：

```
actor:  command + motion_anchor_pos_b + motion_anchor_ori_b + base_lin_vel
        + base_ang_vel + joint_pos_rel + joint_vel_rel + actions
critic: actor + body_pos + body_ori
```

可考虑增加的观测项（参考 velocity 任务）：
- `接触力`：`foot_contact_forces` 或 `feet_ground_contact`
- `地形扫描`：`height_scan`（用于不平坦地形）

> 但这两项都会增大观测维度，且脱离 flat terrain 假设，应留待后续拓展。

### 3.5 补充：GRU 与盲态观测裁剪机制分析（03.10）

#### 3.5.1 三种模式的任务注册架构

当前 tracking 任务在注册时被拆分为三个独立的 task_id，每种模式在注册时就固定了 env_cfg 和 rl_cfg 的参数：

| task_id | `use_gru` | `has_state_estimation` | Actor 网络类型 |
|---------|:---------:|:---------------------:|:-------------:|
| `Unitree-H1_2-Tracking` | `False` | `True` | MLP (512→256→128) |
| `Unitree-H1_2-Tracking-No-State-Estimation` | `False` | `False` | MLP (512→256→128) |
| `Unitree-H1_2-Tracking-GRU` | `True` | `True` | RNN (GRU, hidden=128, 1 layer) |

对应注册代码见 [__init__.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/__init__.py#L7-L29)。

#### 3.5.2 观测裁剪的两层机制

观测裁剪发生在两个层级：

**第一层：基类工厂函数 `make_tracking_env_cfg()`**

见 [tracking_env_cfg.py#L42-L93](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/tracking_env_cfg.py#L42-L93)。当 `use_gru=True` 时，在构造 actor 观测字典后立即 pop 掉 `base_lin_vel`：

```python
if use_gru:
    actor_terms.pop("base_lin_vel")
```

此时 `motion_anchor_pos_b` 仍然保留。这一步仅移除线速度，意图是让 GRU 从历史中推断速度。

**第二层：机器人特化配置 `unitree_h1_2_flat_tracking_env_cfg()`**

见 [env_cfgs.py#L163-L197](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py#L163-L197)。无论 `No-Estimate` 还是 `GRU`，最终都会把 actor 观测中的 `motion_anchor_pos_b` 和 `base_lin_vel` 一并移除，并重建 ObservationGroup：

```python
new_actor_terms = {
    k: v
    for k, v in cfg.observations["actor"].terms.items()
    if k not in ["motion_anchor_pos_b", "base_lin_vel"]
}
cfg.observations["actor"] = ObservationGroupCfg(terms=new_actor_terms, ...)
```

对于 GRU 模式，`base_lin_vel` 已经在第一层被 pop，第二层的过滤是冗余但无害的。这样做的结果是：**GRU 模式下 actor 同时失去全局位置（anchor_pos）和线速度（base_lin_vel）两个关键信息**。

#### 3.5.3 GRU 网络配置

见 [rl_cfg.py#L30-L36](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/rl_cfg.py#L30-L36)：

```python
if use_gru:
    actor_cfg.class_name = "RNNModel"
    actor_cfg.extra_kwargs = {
        "rnn_type": "gru",
        "rnn_hidden_dim": 128,
        "rnn_num_layers": 1,
    }
```

关键参数：
- 单层 GRU，hidden state 维度 128
- 前接 MLP（`hidden_dims=(512, 256, 128)`）作为观测编码器
- Critic 始终为纯 MLP（保留完整特权信息），不变
- `obs_normalization=True`（对所有模式均启用）

#### 3.5.4 盲态 Actor 的学习能力边界

**Actor 的观测空间**

盲态 actor（GRU / No-Estimate）的观测仅包含：
```
command + motion_anchor_ori_b(6D) + base_ang_vel(3) 
+ joint_pos(27, biased) + joint_vel(27) + last_action(27)
```

它无法直接获得：
- 全局位置 `(x, y, z)` — 无任何全局坐标观测
- 线速度 `(vx, vy, vz)` — 训练时已被移除
- 各 body 在世界系中的真实位置/朝向 — 那是 critic 的专属观测

**非对称 Actor-Critic 的弥补机制**

Critic 看到完整特权状态（`body_pos`, `body_ori`, `motion_anchor_pos_b`, `base_lin_vel` 等，无噪声），见 [tracking_env_cfg.py#L94-L131](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/tracking_env_cfg.py#L94-L131)：

```python
critic_terms = {
    ...                                      # 与 actor 相同的项
    "body_pos": ObservationTermCfg(...),      # ← actor 没有
    "body_ori": ObservationTermCfg(...),      # ← actor 没有
    "base_lin_vel": ObservationTermCfg(...),  # ← GRU actor 没有
    "motion_anchor_pos_b": ObservationTermCfg(...),  # ← GRU actor 没有
}
observations = {
    "actor":  ObservationGroupCfg(enable_corruption=True),   # 有噪声
    "critic": ObservationGroupCfg(enable_corruption=False),  # 无噪声
}
```

PPO 通过 Critic 的价值函数间接传递信息：Critic 看到"机器人正在远离原点 → 低价值"→ 更新后的策略会倾向于产出不漂移的动作。Actor 看不到位置，但学到的策略输出恰好使机器人留在原处的动作。这是标准的**非对称 Actor-Critic（Teacher-Student）范式**。

**盲态 Actor 学不到什么（关键风险）**

1. **无法闭环修正位置**：actor 没有全局观测来闭合反馈环。位置信息只能通过 `root_stay_in_place` 奖励间接约束，但这是开环的——策略只能"记住别乱动"，而不是"知道自己在哪里然后纠正"。

2. **GRU 隐状态 = 开环积分**：GRU 的 hidden state 可以编码时序信息（如"我最近两步在向前摆动"），但这本质上是一种开环积分——没有外部观测来纠正积分漂移。随着序列变长，隐状态误差会累积。准确的估计需要闭环观测（VSLAM / 滤波器持续修正），而盲态 actor 只能依靠策略记住的动作模式。

3. **GRU vs No-Estimate 的能力差异**：
   | 维度 | No-Estimate (MLP) | GRU |
   |------|:-----------------:|:---:|
   | 网络结构 | MLP，单帧映射 | RNN，时序建模 |
   | 位置感知 | 仅通过奖励间接获得 | 奖励 + 隐状态时序推断 |
   | 速度推断 | ❌ 无法推断 | ✅ 能从历史关节/角速度变化推断 |
   | 开环积分漂移 | 不适用（无记忆） | ⚠️ 随序列长度累积 |
   | 部署复杂度 | 低（无状态维护） | 高（需管理 GRU hidden state） |

**本质差异**：有状态估计器是**闭环观测**（持续用传感器数据修正漂移），盲态 actor 是**开环学习**（没有观测修正，全靠策略记住什么动作不出错）。这就是为什么 `root_stay_in_place` + 紧 termination 阈值 + 特权奖励缺一不可。

#### 3.5.5 辅助奖励的激活

见 [env_cfgs.py#L35-L65](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py#L35-L65)。`_activate_aux_rewards()` 在两个盲态模式下均被调用：

| 奖励 | 权重 | 作用 | 依赖的特权量 |
|------|:----:|------|:-----------:|
| `root_stay_in_place` | +0.45 | 世界系 XY 高斯奖励，约束漂移 | `body_link_pos_w` 世界坐标 |
| `foot_slip` | -2.0 | 惩罚足底世界系滑动 | `body_link_lin_vel_w` 世界速度 |
| `body_orientation` | -2.0 | 通过 `projected_gravity_b` 惩罚倾斜 | `projected_gravity_b`（IMU 直接可测） |
| `body_ang_vel` | -0.1 | 抑制躯干无意义晃动 | `root_link_ang_vel_b`（IMU 直接可测） |
| `contact_mode_match` | -0.5 | 惩罚仿真与参考运动的接触不一致 | `command.body_pos_w` 参考世界位置 |
| `contact_vel_matching` | -1.0 | 支撑相足底速度惩罚 | 同上 |

注意：`body_orientation` 和 `body_ang_vel` 仅使用本体 IMU 可测的量（`projected_gravity_b`, `root_link_ang_vel_b`），并不属于 Critic 独占的特权信息。更准确的说法是——这些辅助奖励**大量依赖 Actor 不可见的环境内部状态**，其中一部分与 Critic 可见的特权量重合，但不完全是"Critic 专属"。

两个盲态模式的差异：
- **No-Estimate**：`relaxed_tracking=True`（tracking std 放大：body_pos 0.45, body_ori 0.55, root_pos 0.40），`cam_sigma=5.0`。同时调整 termination 阈值：`anchor_pos` 收紧（0.25→0.15），`ee_body_pos` 放宽（0.25→0.35），见 [env_cfgs.py#L177-L181](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py#L177-L181)
- **GRU**：`relaxed_tracking=False`（tracking std 保持默认），`cam_sigma=3.0`。termination 阈值保持默认。因为 GRU 保留 `motion_anchor_ori_b` 且能通过时序推断位置，方向信息充足，不需要放松跟踪要求

#### 3.5.6 部署一致性

三种模式在训练/部署的观测一致性：

| 模式 | 训练观测 | 部署观测 | 一致性 | 额外要求 |
|:----:|:--------:|:--------:|:------:|:--------:|
| Default | 全量观测 | 硬件提供（假设有状态估计） | ✅ | 无 |
| No-Estimate | 移除 `anchor_pos` + `base_lin_vel` | 硬件不提供这两项（返回零） | ✅ | 无 |
| GRU | 同上 + RNN 网络 | 同上 + 需维护 GRU hidden state | ✅ | 需 ONNX 导出 stateful 推理 |

#### 3.5.7 已知问题与风险

1. **GRU 部署状态管理**：`rnn_hidden_dim=128`，hidden state 形状为 `(num_layers, batch, 128)` = `(1, batch, 128)`。ONNX 导出时需要正确处理 stateful 推理，在推理框架（TensorRT / ONNX Runtime）中显式维护初始状态。如果每次推理都重置 hidden state，GRU 将退化为 MLP。

2. **No-Estimate 收敛困难**：同时失去位置和线速度，仅靠 6 个辅助奖励和收紧的 termination 约束行为。策略搜索空间大，收敛难度显著高于 Default 模式。

3. **未使用历史帧堆叠**：当前所有模式 `history_length=1`。对于 MLP 模式的 No-Estimate，增加 `history_length` 可以让单帧观测包含更多上下文（等效于"伪 GRU"）。但对于 GRU 模式意义不大——RNN 本身就处理时序。

4. **GRU 在 rsl_rl 中的实现验证**：当前 PPO runner 使用 `RslRlVecEnvWrapper`。rsl_rl 的 `RNNModel` 实现是否正确处理了：
   - episode reset 时 hidden state 置零
   - 多环境并行时 hidden state 的分离维护
   - 这些需要通过实际训练验证，静态代码无法完全确认。

5. **`cam_tracking` 在盲态下的 sigma 调整**：`cam_tracking` 的 sigma 在 No-Estimate 下放大到 5.0（更大容忍度），GRU 下设为 3.0（默认），这与 tracking std 的松弛策略保持一致。

---

## 4. 课程学习

### 4.1 现状

tracking 任务**没有课程学习**。`tracking_env_cfg.py` 返回的 `ManagerBasedRlEnvCfg` 不含 `curriculum` 配置项。

### 4.2 与 velocity 的对比

velocity 的课程学习存储在 `velocity/mdp/curriculums.py`：
- `terrain_levels_vel`：地形难度递进
- `commands_vel`：速度指令范围递进

但 velocity 的课程机制**不能直接复用**到 tracking：
- tracking 的地形固定为平面（`terrain_type="plane"`）
- tracking 的命令是 NPZ 运动数据，不是速度指令
- tracking 已通过 `MotionCommand` 的自适应采样实现了隐式课程

### 4.3 motion tracking 的课程学习方案

motion tracking 的课程学习应围绕**运动难度递进**设计：

**方案 A：基于自适应采样的隐式课程（推荐）**

`MotionCommand` 已包含 `bin_failed_count` 和自适应采样机制。这是 whole_body_tracking 的设计方式——隐式课程已经足够，不需要独立的 `CurriculumCfg`。**现状即为合理设计**。

**方案 B：显式奖励权重课程（可选增强）**

如果发现训练初期不稳定，可以添加**奖励权重课程**：

```python
# 新增 tracking 的课程文件：tracking/mdp/curriculums.py
from mjlab.managers.curriculum_manager import CurriculumTermCfg

def reward_scale_curriculum(env, env_ids, reward_name, stage):
    """根据训练进度缩放奖励权重。"""
    progress = env.common_step_counter / env.max_episode_length
    if progress < 0.1:  # Phase 1: 0-10%
        env.reward_manager.terms[reward_name].cfg.weight = 0.1
    elif progress < 0.3:  # Phase 2: 10-30%
        env.reward_manager.terms[reward_name].cfg.weight = 0.5
    else:  # Phase 3: 30%+
        env.reward_manager.terms[reward_name].cfg.weight = 1.0
```

**工作量评估**：方案 A 工作量 = 0（已实现）。方案 B 需要新建 `curriculums.py` 和调整 `tracking_env_cfg.py`，工作量中等。

---

## 5. 奖励函数体系

### 5.1 核心跟踪奖励对比

| 奖励项 | whole_body_tracking | mjlab tracking | 差异 |
|-------|-------------------|---------------|------|
| `motion_global_anchor_pos` | w=0.5, σ=0.3 | w=0.5, σ=0.3 | 相同 |
| `motion_global_anchor_ori` | w=0.5, σ=0.4 | w=0.5, σ=0.4 | 相同 |
| `motion_body_pos` | w=1.0, σ=0.3 | w=1.0, σ=0.3 | 相同 |
| `motion_body_ori` | w=1.0, σ=0.4 | w=1.0, σ=0.4 | 相同 |
| `motion_body_lin_vel` | w=1.0, σ=1.0 | w=1.0, σ=1.0 | 相同 |
| `motion_body_ang_vel` | w=1.0, σ=3.14 | w=1.0, σ=3.14 | 相同 |
| `action_rate_l2` | w=-0.1 | w=-0.1 | 相同 |
| `joint_limit` | w=-10.0 | w=-10.0 | 相同 |

**6 项核心跟踪奖励完全一致**，无差距。

### 5.2 辅助奖励对比

| 奖励项 | whole_body_tracking | mjlab tracking | 分析 |
|-------|-------------------|---------------|------|
| `self_collision` | ❌ 无 | ✅ w=-10.0, force_history=3 | **mjlab 更强** |
| `feet_contact_time` | ⚠️ 定义但未启用 | ❌ 无 | 两者都不启用 |
| `undesired_contacts` | ❌ 不存在 | ❌ 不存在 | 两者都不存在 |
| `joint_acc_l2` | ❌ 无 | ❌ tracking 未用（⬆ velocity 有） | 框架可用未引用 |

**说明**：
- `undesired_contacts` 在 **两个仓库中都不存在**。原文分析 §5.1 声称 whole_body_tracking 有此函数，经源码核实为错误。
- `joint_acc_l2` 是 mjlab 框架内置函数（[rewards.py:50](file:///home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/mjlab/envs/mdp/rewards.py#L50-L55)），velocity 已使用（w=-2.5e-7），但 tracking 未引用。

### 5.3 建议新增的辅助奖励

**建议 1：启用 `joint_acc_l2`**

```python
"joint_acc_l2": RewardTermCfg(
    func=mdp.joint_acc_l2,
    weight=-2.5e-7,  # 参考 velocity 的配置
    params={"asset_cfg": SceneEntityCfg("robot")},
),
```

**建议 2：启用 `feet_contact_time`**

脚部接触奖励（接触时间 > 阈值时奖励）。mjlab 没有内置的 `feet_contact_time` 函数，需要新建。velocity 使用 `ContactSensorCfg(track_air_time=True)`，tracking 需要增加类似的接触传感器配置。

**建议 3：启用 `flat_orientation_l2`**

mjlab 框架内置函数：

```python
"flat_orientation": RewardTermCfg(
    func=mdp.flat_orientation_l2,
    weight=-0.5,
    params={"asset_cfg": SceneEntityCfg("robot")},
),
```

### 5.4 已实施：全身角动量对齐奖励（CAM Tracking）

在 H1_2 tracking 上已新增 **Centroidal Angular Momentum (CAM) Alignment** 奖励项。

#### 物理背景

机器人绕全身质心（CoM）的角动量 $H_G$ 由两部分组成：

$$H_G = \underset{H_{\text{orbital}}}{\underbrace{\sum_{i} \boldsymbol{r}_i \times (m_i \boldsymbol{v}_i)}} + \underset{H_{\text{rotational}}}{\underbrace{\sum_{i} \boldsymbol{R}_i (\boldsymbol{I}_{\text{local},i} (\boldsymbol{R}_i^T \boldsymbol{\omega}_i))}}$$

- **轨道角动量（Orbital）**：各连杆相对 CoM 的平移运动贡献
- **自转角动量（Rotational）**：各连杆绕自身质心的自转贡献

#### 实现要点

- 纯 PyTorch 实现，完全 GPU 并行化，不依赖任何第三方 C++ 库
- 利用对角惯性张量的特性，将本地坐标系下矩阵-向量乘积退化为 element-wise 乘法，极大提升 GPU 效率
- 正确使用 `body_iquat`（principal axes → body frame），确保 rotational angular momentum 的计算物理严格正确
- 通过 `model.body_mass` / `model.body_inertia` / `model.body_iquat` 读取惯性参数，自动兼容域随机化（DR）的逐环境扰动

#### 代码位置

| 文件 | 函数 | 说明 |
|------|------|------|
| [rewards.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/rewards.py#L317-L426) | `_compute_centroidal_angular_momentum()` | CAM 计算核心函数 |
| [rewards.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/rewards.py#L378-L426) | `cam_tracking_reward()` | 指数型 CAM 对齐奖励 |
| [tracking_env_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/tracking_env_cfg.py#L365-L371) | `RewardTermCfg` 注册 | 默认 `weight=0.0` |
| [env_cfgs.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/config/h1_2/env_cfgs.py#L113-L145) | H1_2 启用配置 | `weight=0.1`, `sigma=2.0` |

#### 配置参数

| 参数 | Estimate 模式 | No-Estimate 模式 |
|------|:------------:|:----------------:|
| `weight` | 0.1 | 0.1 |
| `sigma` | 2.0 | 5.0（更大容忍度） |

#### 预期效果

加入 `cam_tracking` 后，最显著的变化是：机器人在落地或急停时，**会本能地通过甩动双臂、扭转躯干来代偿和对冲下肢产生的多余旋转动量**，即人类跳跃和舞蹈中的动态代偿（Windmilling）行为。

### 5.5 不推荐的修改

- **`undesired_contacts`**：两个仓库都没有此函数，且 tracking 已有 `self_collision`（force_history 参数提供更精细的接触检测），不需要新建。
- **`contact_pattern` / `foot_clearance`**：这些是步态相关奖励，对 motion tracking 任务的核心目标（跟谁参考运动）贡献有限，且引入后需要额外调参。建议不作为优先改进。

---

## 6. 终止条件增强

### 6.1 现状

mjlab tracking 的终止条件（[terminations.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/terminations.py)）：

| 条件 | 阈值 | 说明 |
|------|------|------|
| `time_out` | 10.0s | 回合超时 |
| `bad_anchor_pos_z_only` | 0.25m | anchor body Z 轴偏差 |
| `bad_anchor_ori` | 0.8 | 重力方向投影偏差 |
| `bad_motion_body_pos_z_only` | 0.25m | 手脚末端 Z 轴偏差 |

### 6.2 可增强项

**`bad_orientation` 终止条件**

mjlab 框架已内置（[terminations.py:24](file:///home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/mjlab/envs/mdp/terminations.py#L24-L32)），velocity 已使用，但 tracking 未启用：

```python
from mjlab.envs.mdp import terminations as mdp_terms

terminations = {
    # ... 现有项
    "bad_orientation": TerminationTermCfg(
        func=mdp_terms.bad_orientation,
        params={"limit_angle": math.radians(70.0)},
    ),
    # 可选：高度检测（防止摔倒后模拟继续）
    "root_height": TerminationTermCfg(
        func=mdp_terms.root_height_below_minimum,
        params={"minimum_height": 0.3},
    ),
}
```

### 6.3 影响

- `bad_orientation`：在躯干倾斜 >70° 时终止，避免训练时间浪费在已摔倒的环境上
- `root_height_below_minimum`：防止奇异姿态下的无效仿真
- 这两个条件在 velocity 任务中都使用了，tracking 可以放心复用

---

## 7. 训练基建与工程化

### 7.1 `num_envs` 默认值问题

**重要发现**：`tracking_env_cfg.py` 返回的 `ManagerBasedRlEnvCfg` 中：

```python
return ManagerBasedRlEnvCfg(
    scene=SceneCfg(terrain=TerrainEntityCfg(terrain_type="plane"), num_envs=1),
    ...
)
```

`num_envs=1` 是默认值，意味着**如果训练脚本不覆盖此配置，tracking 环境将只有 1 个并行环境**，根本无法进行有效训练。

**建议**：在子类配置中显式设置：

```python
# config/g1/env_cfgs.py
class G1TrackingEnvCfg(G1FlatEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 4096  # 或由训练参数传入
```

### 7.2 无混合精度训练（AMP）

mjlab 基于 PyTorch，未显式启用 AMP。需要确认训练入口是否使用 `torch.cuda.amp`。如果当前是全精度训练，启用 AMP 可减少 30-50% 显存占用，或扩大并行环境数。

### 7.3 PPO 超参数说明

核心配置与 whole_body_tracking 对比如下：

| 参数 | whole_body_tracking | mjlab tracking | 评估 |
|------|-------------------|---------------|------|
| `actor_hidden_dims` | [512, 256, 128] | [512, 256, 128] | 相同 |
| `critic_hidden_dims` | [512, 256, 128] | [512, 256, 128] | 相同 |
| `activation` | ELU | ELU | 相同 |
| `learning_rate` | 1e-3 adaptive | 1e-3 adaptive | 相同 |
| `desired_kl` | 0.01 | 0.01 | 相同 |
| `entropy_coef` | 0.005 | 0.005 | 相同 |
| `num_learning_epochs` | 5 | 5 | 相同 |
| `num_mini_batches` | 4 | 4 | 相同 |

**所有 PPO 超参数完全一致**。

`desired_kl=0.01` 是 rsl_rl 的默认值，属于保守设定。需要调整的依据是训练中 KL 散度是否经常超过 0.01。建议先保留现状。

### 7.4 W&B 运动数据管理

whole_body_tracking 使用 W&B Artifact 自动下载运动数据。mjlab 目前使用本地文件路径。

**建议**：可选增加 W&B 支持，但保持本地文件作为默认加载方式：

```python
# scripts/train.py 
motion_path = args.motion_file
if motion_path.startswith("wandb://"):
    # 从 W&B 下载
    run = wandb.init()
    artifact = run.use_artifact(motion_path.replace("wandb://", ""), type="motion")
    motion_path = artifact.download()
```

### 7.5 Ghost 可视化的计算开销

当前 Ghost 实现每步调用 `copy.deepcopy(mujoco.MjModel)`，在 4096 环境 + Ghost 场景下可能带来显著开销。

**建议**：在 `tracking_env_cfg.py` 中增加条件编译：

```python
viewer = ViewerConfig(
    ...
    # 训练时关闭 ghost 渲染
    debug_vis=os.environ.get("TRACKING_DEBUG_VIS", "0") == "1",
)
```

---

## 8. Sim2Sim 验证工具链

### 8.1 当前状态

deploy 端（C++）已有数值对齐验证工具，但训练端（Python）没有。mjlab 使用 MuJoCo 作为训练和部署的物理引擎，规避了跨引擎不一致的问题（与 whole_body_tracking 的 Isaac Lab → MuJoCo 不同），但仍需验证 Python 训练端和 C++ 部署端的观测/奖励计算一致性。

### 8.2 建议工具

| 工具 | 用途 | 输入 | 输出 |
|------|------|------|------|
| `capture_rollout.py` | 录制训练端 rollout 数据 | env + policy + num_steps | NPZ 文件 |
| `verify_obs_assembly.py` | 验证 C++ 端观测组装 | NPZ 文件 + C++ dump | 数值误差报告 |

### 8.3 综述强调

> Sim2Sim 验证环节往往比 Sim2Real 本身更容易出问题 [jzssuanfa-2026]

虽然 mjlab 跨引擎一致性问题较 Isaac Lab 方案小，但仍然需要部署前的数值对齐验证。

---

## 9. 整体改进优先级矩阵

| 优先级 | 改进项 | 影响 | 工作量 | 依据 |
|-------|-------|------|-------|------|
| **P0** | 启用 `DelayedActuator` + `sync_actuator_delays` | **Critical** Sim2Real 成功率 | 小（配置项已存在） | mjlab 框架已支持，tracking 未启用 |
| **P0** | 增强域随机化（PD 增益、惯性） | **High** 缩小 Sim2Real gap | 小（新增 2 个 EventTerm） | `dr.pd_gains()` 和 `dr.pseudo_inertia()` 已存在 |
| **P0** | 修复 `num_envs` 默认值 | **Critical** 否则单环境无法训练 | 极小（1 行代码） | 追踪到的配置缺陷 |
| **P1** | 启用 `bad_orientation` 终止 | **High** 节省训练时间 | 极小（1 行代码） | mjlab 框架已存在 |
| **P1** | 启用 `joint_acc_l2` 奖励 | **Medium** 平滑动作 | 极小（1 行代码） | mjlab 框架已存在 |
| **P1** | 观测历史帧堆叠 | **Medium** 提升策略性能 | 小（配置项） | 需同步更新 ONNX/C++ |
| **P2** | Sim2Sim 验证工具链 | **Medium** 部署前质检 | 中（需实现脚本） | 需配合 deploy 验证 |
| **P2** | 课程学习（显式） | **Medium** 训练稳定性 | 中（新建函数） | 隐式课程已存在 |
| **P2** | 启用 `root_height_below_minimum` | **Medium** 防止无效仿真 | 极小（1 行代码） | mjlab 框架已存在 |
| **P3** | W&B 运动数据管理 | **Low** 便利性 | 小 | 补充功能 |
| **P3** | 混合精度训练 | **Low** 性能优化 | 小（配置项） | 需基准测试 |
| **P3** | Ghost 可视化条件编译 | **Low** 训练性能 | 小（环境变量） | 多数场景无需关闭 |

### 与原始报告的差异说明

本修正版与原始报告的关键差异：

1. **延迟模拟**：原始报告声称需要新建 `DelayedActionWrapper`（有 bug），但实际上 mjlab 已有完备的 `DelayedActuator` 框架——只需要在 tracking 中启用即可。
2. **域随机化**：原始报告建议使用不存在的 `dr.action_delay` 和 `dr.motor_strength`。修正版全部替换为确实存在的函数。
3. **`undesired_contacts`**：原始报告声称两个仓库都有此函数，源码核实均不存在。修正版改为建议启用已有的 `joint_acc_l2`。
4. **课程学习**：原始报告方案使用不存在的函数。修正版指出隐式课程已够用，显式课程作为可选增强。
5. **终止条件**：原始报告说"复用 velocity 的 `bad_orientation`"，修正为"mjlab 框架内置"。
6. **PPO 超参数**：原始报告说 `desired_kl=0.01` 是"非常保守"，修正为"与 whole_body_tracking 一致"。

---

## 总结

`unitree_rl_mjlab` 的 tracking 训练代码实现了 BeyondMimic 的核心功能，**6 项核心跟踪奖励与 PPO 超参数与 whole_body_tracking 完全一致**。mjlab 框架自身提供了丰富的 DR 功能和 `DelayedActuator`，但 tracking 任务**没有充分利用这些现有能力**。

**最关键的 3 项改进**：
1. **启用 `DelayedActuator`**（已存在于框架，未启用）
2. **扩展域随机化**（`dr.pd_gains` + `dr.pseudo_inertia` 已存在）
3. **修复 `num_envs=1` 默认值**（否则单环境无法训练）

这三项的共同特点是：**mjlab 框架已提供完整支持，仅需在 tracking 任务配置中启用**。

---

*报告生成日期: 2026-07-01（修正版）*
*源码审核范围: unitree_rl_mjlab/src/ + mjlab 框架源码 `site-packages/mjlab/`*
*对照仓库: HybridRobotics/whole_body_tracking (基于分析报告)*
