# 04 H1_2 Mimic 训练过程

> **系列定位**：承接 [03 训练适配](file:///home/meme/Documents/笔记/02%20Mimic/03%20H1_2%20Mimic%20%E8%AE%AD%E7%BB%83%E9%80%82%E9%85%8D.md) 的环境配置，本篇记录 H1_2 Motion Mimic 策略的实际训练流程与 ONNX 导出机制。

---

## 1. 训练前准备

### 1.1 前置条件

- [x] 任务已注册：`Unitree-H1_2-Tracking-No-State-Estimation`（详见 [03 H1_2 Mimic 训练适配](file:///home/meme/Documents/笔记/02%20Mimic/03%20H1_2%20Mimic%20%E8%AE%AD%E7%BB%83%E9%80%82%E9%85%8D.md)）
- [x] 参考轨迹 NPZ 已生成：`src/assets/motions/h1_2/dance1_subject2_h1_2.npz`
- [x] Python 环境：`unitree-rl-sim2sim-py310`

### 1.2 训练数据

训练使用单个 motion file 作为参考轨迹。MotionCommand 在环境初始化时完整加载 NPZ 到内存/显存，按 `time_step` 索引查询每帧参考状态。

---

## 2. 启动训练

> **⚠️ 重要 — 必须使用 No-State-Estimation 任务**
>
> 官方 deploy 端 C++ 代码期望的 obs 维度为 144 维（No-State-Estimation 版本）。如果使用 `Unitree-H1_2-Tracking`（150 维 obs）训练，部署时维度不匹配会导致脏数据输入，引发机器人剧烈抽搐或断电。**始终使用 `Unitree-H1_2-Tracking-No-State-Estimation`**。

```bash
conda activate unitree-rl-sim2sim-py310
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab

# CPU 训练（单进程）
PYTHONPATH=. python scripts/train.py Unitree-H1_2-Tracking-No-State-Estimation \
  --motion_file src/assets/motions/h1_2/dance1_subject2_h1_2.npz \
  --agent.max_iterations 30001

# GPU 训练（单卡）
CUDA_VISIBLE_DEVICES=0 PYTHONPATH=. python scripts/train.py \
  Unitree-H1_2-Tracking-No-State-Estimation \
  --motion_file src/assets/motions/h1_2/dance1_subject2_h1_2.npz
```

### 2.1 关键参数说明

| 参数 | 说明 |
| :--- | :--- |
| `--motion_file` | 参考轨迹 NPZ 路径（tracking 任务必需） |
| `--agent.max_iterations` | 覆盖默认的 30001 轮训练迭代 |
| `--env.decimation` | 控制频率：`decimation=4`，sim dt=0.005s → 控制频率 50Hz |
| `--env.episode_length_s` | 每 episode 时长（默认 10s = 500 步） |
| `--video` | 启用训练视频录制 |
| `--enable_nan_guard` | 启用 NaN 检测（调试用） |

---

## 3. 训练流程验证

> ✅ **2026-06-24 实验验证**：以下命令与结果已实际跑通。

为验证训练管道可用，使用 10 次迭代进行快速测试（CPU 模式 + TensorBoard logger）：

```bash
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab

CUDA_VISIBLE_DEVICES="" PYTHONPATH=. python scripts/train.py \
  Unitree-H1_2-Tracking-No-State-Estimation \
  --motion_file src/assets/motions/h1_2/dance1_subject2_h1_2.npz \
  --agent.max_iterations 10 \
  --agent.save_interval 10 \
  --agent.logger tensorboard
```

> **注意**：
> - 无 GPU 环境需设 `CUDA_VISIBLE_DEVICES=""` 强制 CPU 模式，否则 `select_gpus()` 会因 `torch.cuda.device_count()=0` 而崩溃
> - 默认 logger 为 `wandb`，需 `wandb login` 认证。本地测试使用 `--agent.logger tensorboard` 避免认证

**验证结果**：

| 检查项 | 状态 | 详情 |
| :--- | :--- | :--- |
| 环境构建 | 通过 | H1_2 robot + plane terrain, num_envs=1 |
| Motion 加载 | 通过 | dance1_subject2_h1_2.npz, 10955 frames |
| MuJoCo 仿真 | 通过 | timestep=0.005, decimation=4, 50Hz control |
| 网络结构 | 通过 | Actor: 144→512→256→128→27, Critic: 270→512→256→128→1 |
| PPO rollout 采样 | 通过 | 24 steps/env, 约 2.0s collection + 0.1s learning per iter |
| PPO update | 通过 | 5 epochs × 4 mini-batches |
| reward 计算 | 正常 | 9 项 reward 均有数值输出（初始 total ≈ -1.06） |
| checkpoint 保存 | 通过 | model_0.pt, model_9.pt |
| ONNX 导出 | 通过 | policy.onnx (982KB) + {timestamp}.onnx (含 motion buffer) |
| TensorBoard 日志 | 通过 | events.out.tfevents.* 文件正常写入 |

**初始训练指标**（iter 9/10）：

| 指标 | 值 |
| :--- | :--- |
| Mean reward | -1.06 |
| Mean episode length | 7.38s (episode 上限 10s) |
| ee_body_pos termination 率 | 100% （末端位置偏离 > 0.25m 触发终止） |
| error_joint_pos | 2.44 rad |
| error_anchor_pos | 0.18 m |
| error_body_pos | 0.20 m |
| error_body_rot | 0.65 rad |

> 10 轮迭代远不足以收敛（默认 30001 轮），reward 为负且频繁触发终止是未训练策略的正常表现。

---

## 4. 训练日志与监控

### 4.1 日志目录结构

```
logs/rsl_rl/h1_2_tracking/
└── 2026-06-23_XX-XX-XX/
    ├── params/
    │   ├── env.yaml          ← 环境配置快照
    │   └── agent.yaml        ← 算法配置快照
    ├── model_<iter>.pt       ← RSL-RL checkpoint
    ├── model_<iter>.onnx     ← 含 motion buffer 的复合 ONNX（由 `export_motion_policy_to_onnx()` 导出）
    ├── policy.onnx           ← 纯策略 ONNX（由 `export_policy_to_onnx()` 导出）
    └── wandb/                ← Weights & Biases 日志（如启用）
```

> 两种 ONNX 的导出代码均位于 [`src/tasks/tracking/rl/runner.py`](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/rl/runner.py)，在 `save()` 方法中按序调用：先导出 motion-bundled 复合模型 → 再导出纯策略模型。详见[第 5.1 节](#51-onnx-导出机制与预处理)。

### 4.2 关键指标

训练过程关注以下 reward 分量：

| 指标 | 说明 | 目标 |
| :--- | :--- | :--- |
| `motion_global_root_pos` | 根节点位置跟踪误差（指数衰减） | → 1.0 |
| `motion_global_root_ori` | 根节点姿态跟踪误差 | → 1.0 |
| `motion_body_pos` | 14 个 body link 相对位置误差 | → 1.0 |
| `motion_body_ori` | body link 姿态误差 | → 1.0 |
| `action_rate_l2` | 动作平滑性惩罚 | → 0 |
| `joint_limit` | 关节限位惩罚（-10 权重） | → 0 |

训练正常时，total reward 随迭代逐渐上升并收敛。

---

## 5. 训练产出

训练完成后，产物位于 `logs/rsl_rl/h1_2_tracking/<timestamp>/`：

1. **`model_<iter>.pt`**：RSL-RL checkpoint，可用于 resume 训练或 play.py 播放
2. **`policy.onnx`**：纯策略推理模型（obs → action），用于 C++ 部署
3. **`model_<iter>.onnx`**：含运动参考数据的复合模型，用于部署时参考轨迹查询

部署用法：将 `policy.onnx`（或 `model_<iter>.onnx`）放入实机控制器目录 `config/policy/mimic/v0/exported/`，配合 `deploy.yaml` 中的观测/动作维度配置即可在 H1_2 实机上运行。

### 5.1 ONNX 导出机制与预处理

ONNX 导出的通用机制详见 [01 训练架构解读](file:///home/meme/Documents/笔记/02%20Mimic/01%20unitree_rl_mjlab%20%E8%AE%AD%E7%BB%83%E6%9E%B6%E6%9E%84%E8%A7%A3%E8%AF%BB.md) §5。此处补充 H1_2 训练产出的具体参数：

**纯策略 `policy.onnx`：**

| 参数 | 值 |
| :--- | :--- |
| `opset_version` | 18 |
| `dynamic_axes` | `{}`（静态 batch size = 1） |
| Input name | `"obs"`，形状 `(1, 144)` |
| Output name | `"actions"`，形状 `(1, 27)` |

**复合模型 `{timestamp}.onnx`：**

| 参数 | 值 |
| :--- | :--- |
| Input names | `["obs" (1, 144), "time_step" (1, 1)]` |
| Output names | `["actions", "joint_pos", "joint_vel", "body_pos_w", "body_quat_w", "body_lin_vel_w", "body_ang_vel_w"]` |
| `opset_version` | 18，`dynamic_axes` = `{}` |

Motion buffer 捆绑的 6 组参考数据维度：

| Buffer 字段 | 维度 | 说明 |
| :--- | :--- | :--- |
| `joint_pos` | (N, 27) | 参考关节角度 |
| `joint_vel` | (N, 27) | 参考关节角速度 |
| `body_pos_w` | (N, B, 3) | 各 link 世界系位置 |
| `body_quat_w` | (N, B, 4) | 各 link 世界系姿态（wxyz） |
| `body_lin_vel_w` | (N, B, 3) | 各 link 世界系线速度 |
| `body_ang_vel_w` | (N, B, 3) | 各 link 世界系角速度 |

> 其中 N 为总帧数，B 为 H1_2 的刚体 link 数量。

---

## 6. 常见问题

### 6.1 CUDA out of memory

默认 `num_envs=1`，但 motion buffer 较大（10955 帧 × 27 维 × 4B ≈ 1.2MB 关节数据，加上 body 数据约 20MB+）。若显存不足，使用 CPU 训练：

```bash
CUDA_VISIBLE_DEVICES="" python scripts/train.py ...
```

### 6.2 NaN in rewards

若出现 NaN，可能是 motion file 数据问题或关节限位触发。启用 NaN guard：

```bash
--enable_nan_guard
```

### 6.3 收敛慢

- 增大 `num_envs`（需修改 `tracking_env_cfg.py` 中的 `num_envs`）
- 调整 `num_steps_per_env`（当前 24）
- 减少 `desired_kl`（当前 0.01）使更新更激进

          
## TensorBoard 日志系统完整分析

以下是 `unitree_rl_mjlab` 代码库中 TensorBoard 日志系统的完整分析结果。关键依赖文件位于 conda 环境 `/home/meme/.conda/envs/unitree-rl-sim2sim-py310` 中。

---

### 1. RSL-RL Logger -- TensorBoard Writer 创建

**文件**: `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/utils/logger.py`

- **`Logger.__init__()`** (第 23-61 行): 初始化缓冲区，包括奖励缓冲 `rewbuffer` (deque, maxlen=100)、回合长度缓冲 `lenbuffer`、当前回合累积奖励 `cur_reward_sum`、回合长度 `cur_episode_length`，以及可选的 RND 相关缓冲。
- **`Logger.init_logging_writer()`** (第 63-95 行): **关键的 writer 初始化方法**。它根据配置 `cfg["logger"]` 的值决定后端：
  - `"tensorboard"` (默认): 使用 `torch.utils.tensorboard.SummaryWriter(log_dir)` (第 80-82 行)
  - `"wandb"`: 使用 `rsl_rl.utils.wandb_utils.WandbSummaryWriter` (继承自 `SummaryWriter`)
  - `"neptune"`: 使用 `rsl_rl.utils.neptune_utils.NeptuneSummaryWriter` (继承自 `SummaryWriter`)
  - 同时还会保存 git diff 到日志目录。

```python
# 第 69-82 行
self.logger_type = self.cfg.get("logger", "tensorboard")  # 默认为 tensorboard
if self.logger_type == "tensorboard":
    from torch.utils.tensorboard import SummaryWriter
    self.writer = SummaryWriter(log_dir=self.log_dir, flush_secs=10)
```

---

### 2. RSL-RL OnPolicyRunner -- 训练循环与日志调用

**文件**: `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/runners/on_policy_runner.py`

- **`__init__()`** (第 26-50 行): 创建 PPO 算法和 Logger 实例。
- **`learn()`** (第 56-134 行): 主训练循环：

  1. **(第 74 行)** 调用 `self.logger.init_logging_writer()` -- 创建 SummaryWriter
  2. **(第 82-98 行)** rollout 阶段: 在每个环境步之后调用 `self.logger.process_env_step(rewards, dones, extras)` 收集指标
  3. **(第 108 行)** 策略更新: `loss_dict = self.alg.update()`
  4. **(第 114-125 行)** 日志记录: 调用 `self.logger.log(..., loss_dict, learning_rate=self.alg.learning_rate, action_std=...)`

```python
# 第 82-98 行 -- Rollout 循环中的日志收集
for _ in range(self.cfg["num_steps_per_env"]):
    actions = self.alg.act(obs)
    obs, rewards, dones, extras = self.env.step(actions.to(self.env.device))
    self.alg.process_env_step(obs, rewards, dones, extras)
    intrinsic_rewards = self.alg.intrinsic_rewards if self.cfg["algorithm"]["rnd_cfg"] else None
    self.logger.process_env_step(rewards, dones, extras, intrinsic_rewards)
```

---

### 3. Logger.log() -- 写入 TensorBoard 的完整指标

**文件**: `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/utils/logger.py` (第 132-264 行)

`Logger.log()` 方法在每个训练迭代被调用，写入以下标量 (scalar) 到 TensorBoard:

| TensorBoard 路径 | 值 | 行号 |
|---|---|---|
| `Episode/*` | 环境 `extras` 中的每个 key，加前缀 `Episode/` | 第 174-179 行 |
| `Loss/value` | 价值损失 | 第 183 行 |
| `Loss/surrogate` | 策略替代损失 | 第 183 行 |
| `Loss/entropy` | 熵损失 | 第 183 行 |
| `Loss/rnd` | (可选) RND 预测损失 | 第 183 行 |
| `Loss/symmetry` | (可选) 对称性损失 | 第 183 行 |
| `Loss/learning_rate` | 当前学习率 | 第 184 行 |
| `Policy/mean_std` | 动作标准差的均值 | 第 187 行 |
| `Perf/total_fps` | 每秒帧数 (FPS) | 第 191 行 |
| `Perf/collection_time` | 数据收集时间 | 第 192 行 |
| `Perf/learning_time` | 策略学习时间 | 第 193 行 |
| `Train/mean_reward` | 最近 100 个回合的平均奖励 | 第 201 行 |
| `Train/mean_episode_length` | 最近 100 个回合的平均长度 | 第 202 行 |
| `Train/mean_reward/time` | 按累计时间 (非迭代) 的奖励 (非 wandb) | 第 204-206 行 |
| `Train/mean_episode_length/time` | 按累计时间的回合长度 (非 wandb) | 第 207-209 行 |
| `Rnd/mean_extrinsic_reward` | (可选) 外部奖励 | 第 198 行 |
| `Rnd/mean_intrinsic_reward` | (可选) 内部奖励 | 第 199 行 |
| `Rnd/weight` | (可选) RND 权重 | 第 200 行 |

---

### 4. PPO 算法 -- loss_dict 的生成

**文件**: `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/algorithms/ppo.py`

- **`PPO.update()`** (第 211-416 行):
  - 计算 **value loss** (第 305-311 行): 支持 clipped value loss
  - 计算 **surrogate loss** (第 297-302 行): PPO 的 clipped surrogate objective
  - 计算 **entropy** (第 266 行): 策略分布熵
  - **KL 散度** (第 269-294 行): 在 `adaptive` 学习率调度下计算，用于自适应调整学习率。但 **`kl_divergence` 没有写入 TensorBoard**，仅用于调整 `self.learning_rate`。
  - **explained_variance**: **没有**在 PPO 算法中计算或记录。
  - **loss_dict** 的构造 (第 406-416 行):
    ```python
    loss_dict = {
        "value": mean_value_loss,
        "surrogate": mean_surrogate_loss,
        "entropy": mean_entropy,
    }
    if self.rnd:
        loss_dict["rnd"] = mean_rnd_loss
    if self.symmetry:
        loss_dict["symmetry"] = mean_symmetry_loss
    ```

---

### 5. 奖励分解 -- RewardManager

**文件**: `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/managers/reward_manager.py`

**奖励分解流程**:

1. **`__init__()`** (第 52-74 行): 初始化每个奖励项的 `_episode_sums` 字典 (key 为奖励项名称)。

2. **`compute(dt)`** (第 115-130 行): 每个环境步调用，计算所有奖励项并累加到 `_episode_sums`。

3. **`reset(env_ids)`** (第 99-113 行): 在环境重置时调用，**计算每个奖励项的平均值并返回字典**:
   ```python
   # 第 106-108 行
   extras["Episode_Reward/" + key] = episodic_sum_avg / self._env.max_episode_length_s
   ```
   每个奖励项的累积和在 episode 结束时除以最大 episode 长度 (秒) 进行归一化。

**奖励项配置** (tracking 任务, `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/tasks/tracking/tracking_env_cfg.py` 第 209-251 行):

| 奖励项名称 | 权重 | 含义 |
|---|---|---|
| `motion_global_root_pos` | 0.5 | 根位置误差 (指数衰减) |
| `motion_global_root_ori` | 0.5 | 根姿态误差 (指数衰减) |
| `motion_body_pos` | 1.0 | 身体位置误差 (指数衰减) |
| `motion_body_ori` | 1.0 | 身体姿态误差 (指数衰减) |
| `motion_body_lin_vel` | 1.0 | 身体线速度误差 (指数衰减) |
| `motion_body_ang_vel` | 1.0 | 身体角速度误差 (指数衰减) |
| `action_rate_l2` | -1e-1 | 动作平滑惩罚 |
| `joint_limit` | -10.0 | 关节限位惩罚 |
| `self_collisions` | -10.0 | 自碰撞惩罚 |

---

### 6. MetricsManager -- 自定义指标记录

**文件**: `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/managers/metrics_manager.py`

与 RewardManager 类似，但:
- 没有权重和 dt 缩放
- episode 结束时计算的是**逐步平均值** (sum / step_count)
- 写入 TensorBoard 时使用 `Episode_Metrics/*` 前缀

---

### 7. 数据流总结

```
ManagerBasedRlEnv._reset_idx() 
  -> reward_manager.reset() 返回 {"Episode_Reward/term_name": avg_value}
  -> metrics_manager.reset() 返回 {"Episode_Metrics/term_name": avg_value}
  -> 所有这些被合并到 self.extras["log"] 字典

RslRlVecEnvWrapper.step() 
  -> 返回 extras (包含 self.extras["log"])

OnPolicyRunner.learn() 
  -> self.logger.process_env_step(rewards, dones, extras)
     (存储 extras["log"] 到 self.ep_extras)
  -> self.logger.log(it, ...)
     (遍历 ep_extras, 调用 self.writer.add_scalar("Episode/" + key, ...))

PPO.update() 
  -> 返回 loss_dict (value, surrogate, entropy, 可选的 rnd, symmetry)
  -> 写入 Loss/* 标量
```

---

### 8. 主要文件索引

| 文件路径 | 作用 |
|---|---|
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/utils/logger.py` | RSL-RL Logger 类，创建 SummaryWriter，核心日志逻辑 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/runners/on_policy_runner.py` | 训练主循环，调用 Logger 方法 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/algorithms/ppo.py` | PPO 算法，计算 loss_dict，KL 散度自适应学习率 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/rl/runner.py` | MjlabOnPolicyRunner，继承 OnPolicyRunner |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/managers/reward_manager.py` | 奖励分解，生成 `Episode_Reward/*` 指标 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/managers/metrics_manager.py` | 自定义指标，生成 `Episode_Metrics/*` 指标 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/envs/manager_based_rl_env.py` | 环境主类，`_reset_idx()` 组装 extras["log"] |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/rl/vecenv_wrapper.py` | RSL-RL VecEnv 适配器，包装 step 返回 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/utils/log_writer.py` | LogWriter 抽象基类 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/utils/wandb_utils.py` | WandbSummaryWriter (继承 SummaryWriter) |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.10/site-packages/rsl_rl/utils/neptune_utils.py` | NeptuneSummaryWriter (继承 SummaryWriter) |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/tasks/tracking/tracking_env_cfg.py` | tracking 任务配置，定义具体奖励项 |
| `/home/meme/.conda/envs/unitree-rl-sim2sim-py310/lib/python3.1/site-packages/mjlab/tasks/tracking/mdp/rewards.py` | 奖励函数实现 |
| `/home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/rl/runner.py` | 用户项目的 MotionTrackingOnPolicyRunner |
| `/home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/rl/runner.py` | 用户项目的 VelocityOnPolicyRunner |
| `/home/meme/Documents/unitree_h1/unitree_rl_mjlab/scripts/train.py` | 训练入口脚本 |

---

### 9. 要点总结

- **TensorBoard Writer 创建**: 在 `Logger.init_logging_writer()` 中完成，默认使用 `torch.utils.tensorboard.SummaryWriter`，也支持 W&B 和 Neptune。
- **默认日志后端**: `cfg["logger"]` 配置项决定，默认值为 `"tensorboard"`。
- **奖励分解**: 通过 `RewardManager` 在 episode 结束时计算每个奖励项的累积平均值，以 `Episode_Reward/<term_name>` 写入 TensorBoard。
- **PPO 日志**: `loss_dict` 包含 `value`、`surrogate`、`entropy` (以及可选的 `rnd` 和 `symmetry`)，写入 `Loss/*`。
- **未记录的指标**: `explained_variance` 没有在任何地方计算或记录；`kl_divergence` 在 PPO.update() 中计算但**仅用于自适应学习率调度**，没有写入 TensorBoard。
- **学习率**: 以 `Loss/learning_rate` 记录。
- **动作标准差**: 以 `Policy/mean_std` 记录。
- **日志目录**: 默认为 `logs/rsl_rl/<experiment_name>/<YYYY-MM-DD_HH-MM-SS>/`，在 `scripts/train
        


# 05 TensorBoard 指标解读

基于代码分析，以下是 TensorBoard 中各指标的完整解读指南。


## TensorBoard 指标解读

训练启动后，运行 `tensorboard --logdir logs/rsl_rl` 即可打开。日志目录结构为 `logs/rsl_rl/<task_name>/<timestamp>/`，你看到的标量按以下分组组织：

---

### 1. `Episode/Reward/*` — 奖励分解（核心指标）

这是最重要的分组，每个 episode 结束时记录一次，反映策略在各项 reward 上的表现。

| 指标路径 | 含义 | 方向 |
|---|---|---|
| `Episode/Reward/motion_global_root_pos` | 根节点位置跟踪误差奖励（权重 0.5，指数衰减） | ↑ 趋近 0.5 |
| `Episode/Reward/motion_global_root_ori` | 根节点姿态跟踪误差奖励（权重 0.5） | ↑ 趋近 0.5 |
| `Episode/Reward/motion_body_pos` | 14 个 body link 位置跟踪误差奖励（权重 1.0） | ↑ 趋近 1.0 |
| `Episode/Reward/motion_body_ori` | body link 姿态跟踪误差奖励（权重 1.0） | ↑ 趋近 1.0 |
| `Episode/Reward/motion_body_lin_vel` | body 线速度跟踪误差奖励（权重 1.0） | ↑ 趋近 1.0 |
| `Episode/Reward/motion_body_ang_vel` | body 角速度跟踪误差奖励（权重 1.0） | ↑ 趋近 1.0 |
| `Episode/Reward/action_rate_l2` | 动作平滑性惩罚（权重 -0.1），动作变化越剧烈值越负 | ↑ 趋近 0 |
| `Episode/Reward/joint_limit` | 关节限位惩罚（权重 -10），触发关节限位时显著变负 | ↑ 趋近 0 |
| `Episode/Reward/self_collisions` | 自碰撞惩罚（权重 -10） | ↑ 趋近 0 |

**怎么看**：
- **总趋势**：各奖励项随训练应逐渐收敛到其权重值附近（如 `motion_body_pos` → 1.0），说明跟踪误差在缩小
- **关注异常**：`joint_limit` 和 `self_collisions` 在正常策略下应接近 0，若长期明显为负说明策略产生不合理关节角度
- **权重含义**：每个奖励项的值 = 奖励函数输出 × 权重，所以上限 = 权重值

---

### 2. `Episode/Metrics/*` — 自定义指标

来自 `MetricsManager`，同样是 episode 结束时记录的**逐帧平均值**，反映策略执行质量。

你在训练笔记中看到的这些指标就在这里记录：

| 指标路径 | 含义 | 解读 |
|---|---|---|
| `Episode/Metrics/error_joint_pos` | 关节角度与参考轨迹的平均误差 (rad) | 训练初期 ~2+ rad，收敛后应 < 0.5 |
| `Episode/Metrics/error_anchor_pos` | 锚点（torso_link）位置误差 (m) | 反映躯干位置跟踪精度，应趋近 0 |
| `Episode/Metrics/error_body_pos` | body link 位置平均误差 (m) | 应持续下降 |
| `Episode/Metrics/error_body_rot` | body link 姿态平均误差 (rad) | 应持续下降 |
| `Episode/Metrics/ee_body_pos_termination` | 末端位置偏离导致终止的比例 (0~1) | 训练初期 1.0（总是终止），后期应趋近 0 |
| `Episode/Metrics/total_reward` | 各奖励项之和 | 反映整体策略质量 |

**怎么看**：
- 这些是**物理含义明确的误差值**，比 reward 更直观
- 重点关注 `error_joint_pos` 和 `ee_body_pos_termination`，这是策略能否有效跟踪动作的直接体现
- `ee_body_pos_termination` 从 1.0 降到接近 0 是策略学会跟踪的第一个里程碑

---

### 3. `Loss/*` — PPO 训练损失

来自 `PPO.update()` 返回的 `loss_dict`，仅在策略更新时记录。

| 指标 | 含义 | 正常范围 |
|---|---|---|
| `Loss/value` | Critic 价值网络的 MSE 损失（clipped） | 应持续下降，但不能降到 0（否则可能过拟合） |
| `Loss/surrogate` | PPO clipped surrogate 目标函数 | 初期 ~0，随训练变为负值，绝对值反映策略改进幅度 |
| `Loss/entropy` | 策略分布的熵（乘熵系数 0.005） | 应保持稳定正值，若降到 ~0 说明策略过早确定性 |
| `Loss/learning_rate` | 当前学习率（自适应调度） | 初始 1e-3，基于 KL 散度自适应调整 |

**怎么看**：
- `value` 持续下降说明 critic 在学习估计价值
- `entropy` 若骤降或为 0，说明策略崩溃到确定性，需要调大熵系数或减小 `desired_kl`
- `learning_rate` 的波动反映 KL 散度偏离目标的程度

---

### 4. `Train/*` — 训练汇总统计

| 指标 | 含义 |
|---|---|
| `Train/mean_reward` | 最近 100 个 episode 的平均总奖励（最常用的收敛指标） |
| `Train/mean_episode_length` | 最近 100 个 episode 的平均长度（步数），反映是否频繁提前终止 |
| `Train/mean_reward/time` | 同上，但横轴为累计训练时间而非迭代次数 |
| `Train/mean_episode_length/time` | 同上 |

**怎么看**：
- `Train/mean_reward` 是整个训练**最重要的收敛曲线**。训练初期为负值（频繁触发终止+惩罚项），随学习逐渐上升为正。如果达到 plateau 说明收敛
- `Train/mean_episode_length` 如果远小于最大 episode 长度，说明策略频繁触发 `ee_body_pos_termination` 等终止条件

---

### 5. `Policy/*` — 策略统计

| 指标 | 含义 |
|---|---|
| `Policy/mean_std` | Actor 输出高斯分布的标准差的均值（对所有动作维度取平均） |

**怎么看**：
- 反映策略的**探索程度**，训练初期较大，随收敛逐渐减小
- 若过早降至接近 0 → 策略缺乏探索 → 容易陷入局部最优

---

### 6. `Perf/*` — 性能统计

| 指标 | 含义 |
|---|---|
| `Perf/total_fps` | 每秒环境帧数（仿真+推理+学习） |
| `Perf/collection_time` | 每轮 rollout 数据收集耗时 (s) |
| `Perf/learning_time` | 每轮 PPO 更新耗时 (s) |

**怎么看**：主要是性能监控，fps 稳定说明训练正常，异常下降可能提示资源瓶颈。

---

### 7. 训练进程的快速判断

| 训练阶段 | 典型指标表现 |
|---|---|
| **初期**（前几百 iter） | `mean_reward` 为负（~-1），`ee_body_pos_termination`=1.0，`error_joint_pos`>2 rad |
| **学习期** | `mean_reward` 逐渐上升转正，`error_joint_pos` 下降到 <1 rad，termination 率开始下降 |
| **接近收敛** | `mean_reward` 趋近平稳 plateau，`error_joint_pos` < 0.5 rad，termination 率 < 0.1，各奖励项接近其权重上限 |
| **过拟合/崩溃** | `entropy` 骤降至 0，或 `mean_reward` 突然大幅下跌 |

---

### 常用查看命令

```bash
# 启动 TensorBoard（默认端口 6006）
tensorboard --logdir logs/rsl_rl

# 指定端口
tensorboard --logdir logs/rsl_rl --port 8888
```

在 TensorBoard UI 中，建议勾选 **"Smoothing"** 设为 0.6~0.8 来观察趋势，单个 episode 的波动可能较大。