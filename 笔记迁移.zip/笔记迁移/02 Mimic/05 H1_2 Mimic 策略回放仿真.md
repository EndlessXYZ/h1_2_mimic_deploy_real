# 05 H1_2 Mimic 策略回放仿真

> **系列定位**：承接 [04 H1_2 Mimic 训练过程](file:///home/meme/Documents/笔记/02%20Mimic/04%20H1_2%20Mimic%20%E8%AE%AD%E7%BB%83%E8%BF%87%E7%A8%8B.md) 的训练产出，本篇记录 H1_2 Mimic 策略的仿真回放验证，涵盖 ONNX 策略的输入输出核对、动作模仿环境注册、参考轨迹转换、Viser 仿真播放，以及实际数据下载、转换与仿真的验证结果和踩坑记录。

04 使用 PPO 在 MuJoCo 中训练 Motion Tracking 策略，并在每轮 checkpoint 保存时由 [`MotionTrackingOnPolicyRunner.save()`](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/rl/runner.py) 自动导出两种 ONNX 模型：

- **`policy.onnx`**（纯策略）：`obs` → `actions`，obs normalizer / MLP 权重 / deterministic output 已烘焙进计算图，详见 04 §5.1.1
- **`{experiment_name}.onnx`**（复合模型）：`obs` + `time_step` → `actions` + 6 组 motion reference buffer，详见 04 §5.1.2

本文以 `mimic_policy_01.onnx`（即 `policy.onnx` 类型）为例，梳理其 144 维状态输入与 27 维动作输出的物理含义，并通过扩展后的 `play.py` 在 Viser 仿真器中加载该 ONNX 策略，驱动 H1_2 机器人播放舞蹈参考轨迹。

---

## 1. H1_2 神经网络结构与输入输出核对

经 ONNX Runtime 工具解析以及对 [tracking_env_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/tracking_env_cfg.py) 的源码核对，[mimic_policy_01.onnx](file:///home/meme/Documents/unitree_h1/weight/mimic_policy_01.onnx) 包含的 144 维状态输入和 27 维动作输出的物理细节梳理如下：

> **关于观测维度**：deploy 端 C++ 代码期望 144 维 obs（来自 `No-State-Estimation` 任务）。`Unitree-H1_2-Tracking`（150 维）多出的 6 维（`motion_anchor_pos_b` + `base_lin_vel`）在 C++ 端没有来源，会导致脏数据输入。详见 [03 §3.2](file:///home/meme/Documents/笔记/02%20Mimic/03%20H1_2%20Mimic%20%E8%AE%AD%E7%BB%83%E9%80%82%E9%85%8D.md#32-%E6%97%A0%E7%8A%B6%E6%80%81%E4%BC%B0%E8%AE%A1%E5%8F%98%E4%BD%93%E7%94%A8%E4%BA%8E%E8%AE%AD%E7%BB%83%E7%9A%84%E7%89%88%E6%9C%AC)。

### 1.1 动作输出：`actions` (27 维)

与仅控制下肢 12 关节的速度策略不同，Mimic 策略输出 of 27 维向量直接作用于 H1_2 人形机器人的**全身 27 个主动自由度**。在 C++ 侧，推理输出的 `actions` 会被乘以 `action_scale` 并加到对应关节的默认角度（或参考位置）上，构成目标 PD 控制位置：
$$q_{\text{target}} = a \cdot \text{action\_scale} + q_{\text{default}}$$

这 27 个输出维度与 H1_2 模型描述文件 [h1_2.xml](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/assets/robots/unitree_h1_2/xmls/h1_2.xml) 中定义的关节标准顺序完全一致：

|  输出索引  | 物理关节名称                      |  输出索引  | 物理关节名称                       |
| :----: | :-------------------------- | :----: | :--------------------------- |
| **0**  | `left_hip_yaw_joint`        | **14** | `left_shoulder_roll_joint`   |
| **1**  | `left_hip_pitch_joint`      | **15** | `left_shoulder_yaw_joint`    |
| **2**  | `left_hip_roll_joint`       | **16** | `left_elbow_joint`           |
| **3**  | `left_knee_joint`           | **17** | `left_wrist_roll_joint`      |
| **4**  | `left_ankle_pitch_joint`    | **18** | `left_wrist_pitch_joint`     |
| **5**  | `left_ankle_roll_joint`     | **19** | `left_wrist_yaw_joint`       |
| **6**  | `right_hip_yaw_joint`       | **20** | `right_shoulder_pitch_joint` |
| **7**  | `right_hip_pitch_joint`     | **21** | `right_shoulder_roll_joint`  |
| **8**  | `right_hip_roll_joint`      | **22** | `right_shoulder_yaw_joint`   |
| **9**  | `right_knee_joint`          | **23** | `right_elbow_joint`          |
| **10** | `right_ankle_pitch_joint`   | **24** | `right_wrist_roll_joint`     |
| **11** | `right_ankle_roll_joint`    | **25** | `right_wrist_pitch_joint`    |
| **12** | `torso_joint` (腰部偏航)        | **26** | `right_wrist_yaw_joint`      |
| **13** | `left_shoulder_pitch_joint` |        |                              |

### 1.2 状态输入：`obs` (144 维)

根据 [tracking_env_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/tracking_env_cfg.py) 中 `actor_terms` 的拼接规则，144 维状态输入依次包含以下 7 大类观测指标（相比 150 维版本移除了 `motion_anchor_pos_b` 和 `base_lin_vel`，这两项在 deploy 端无数据来源）。在部署时，必须在 C++ 或 Python 运行循环中以完全相同的顺序与标度对其进行组装：

|     索引区间      | 观测项名称              | 维度  | 物理含义与组装计算规则                                                       |
| :-----------: | :----------------- | :-: | :---------------------------------------------------------------- |
|  **0 ~ 26**   | `motion_ref_pos`   | 27  | **参考运动关节位置**：当前控制时刻，目标参考轨迹中 27 个关节的期望角度。                          |
|  **27 ~ 53**  | `motion_ref_vel`   | 27  | **参考运动关节速度**：当前控制时刻，目标参考轨迹中 27 个关节的期望角速度。                         |
|  **54 ~ 59**  | `motion_anchor_ori_b` |  6  | **相对根节点姿态**：参考轨迹中的根节点旋转与当前机器人 Pelvis 姿态的相对旋转矩阵的前两列向量。 |
|  **60 ~ 62**  | `base_ang_vel`     |  3  | **基座角速度**：IMU 传感器直接读取的角速度，一般乘以 `ang_vel_scale`。                |
|  **63 ~ 89**  | `joint_pos`        | 27  | **实际关节位置**：机器人当前的 27 关节角度与默认角度的差值，通常乘以 `dof_pos_scale`。        |
|  **90 ~ 116** | `joint_vel`        | 27  | **实际关节速度**：机器人当前的 27 关节的实测角速度，通常乘以 `dof_vel_scale`。            |
| **117 ~ 143** | `actions`          | 27  | **上一次动作缓冲 (Last Actions)**：前一控制周期输入到关节 PD 控制器中的 27 维动作输出向量。    |


---

## 2. H1_2 动作模仿环境注册与轨迹数据转换

由于官方仓库仅内置了 G1 机器人的仿真配置，为了让 H1_2 机器人也能在 `unitree_rl_mjlab` 仿真环境中测试全身模仿策略，我们需要在本地进行以下扩展：

### 2.1 注册 H1_2 动作模仿环境任务 (Task)

环境注册配置详见 [03 H1_2 Mimic 训练适配](file:///home/meme/Documents/笔记/02%20Mimic/03%20H1_2%20Mimic%20%E8%AE%AD%E7%BB%83%E9%80%82%E9%85%8D.md) §3 和 §5。此处确认已成功注册 `Unitree-H1_2-Tracking-No-State-Estimation`（无状态估计，对应 144 维 obs）任务。

### 2.2 转换 H1_2 动作参考轨迹 (NPZ)

动作参考轨迹数据来源于 HuggingFace 上的 [LAFAN1_Retargeting_Dataset](https://huggingface.co/datasets/lvhaidong/LAFAN1_Retargeting_Dataset)，该数据集已为 H1_2 机器人做了运动重定向（retargeting），直接提供 H1_2 原生 34 列的 CSV 轨迹文件，无需手动从 G1 格式重映射。下载后存放于：

```
deploy/robots/h1_2/config/policy/mimic/
├── dance1_subject2/params/dance1_subject2.csv   (34 列, 6573 行)
└── dance2_subject1/params/dance2_subject1.csv   (34 列)
```

每行 CSV 的 34 列结构为：前 3 维 Root 位置 + 3~6 维 Root 四元数 `xyzw` + 后续 27 维 H1_2 关节角度值（顺序与 [h1_2.xml](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/assets/robots/unitree_h1_2/xmls/h1_2.xml) 中关节定义一致）。

> [!TIP]
> 相比之前从 G1 (29 关节) 手动重映射的方案，使用 LAFAN1 数据集直接提供的 H1_2 原生 CSV 避免了关节名映射出错、G1/H1_2 骨骼比例不一致导致 body link 轨迹偏差等问题。

#### 数据准备

从 HuggingFace 下载的 CSV 文件存放于 [mimic/](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/config/policy/mimic/) 目录：

| 动作名称            | CSV 路径                                                                                                                                                                                  | 说明     |
| :-------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----- |
| dance1_subject2 | [dance1_subject2/params/dance1_subject2.csv](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/config/policy/mimic/dance1_subject2/params/dance1_subject2.csv) | 舞蹈动作 1 |
| dance2_subject1 | [dance2_subject1/params/dance2_subject1.csv](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/config/policy/mimic/dance2_subject1/params/dance2_subject1.csv) | 舞蹈动作 2 |

#### CSV -> NPZ 转换

> ✅ **2026-06-24 实验验证**：以下命令与结果已实际跑通。

使用已扩展支持 `h1_2` 的 [csv_to_npz.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/scripts/csv_to_npz.py) 脚本进行转换。该脚本通过 MuJoCo 物理引擎运行前向动力学（`sim.forward()`），为 H1_2 的每个刚体 link 生成世界坐标系下的位置、姿态和速度，并以 `wxyz` 四元数格式保存为 `.npz`：

```bash
# 激活仿真环境并切换工作目录
conda activate unitree-rl-sim2sim-py310
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab

# 转换 dance1_subject2（约需 3 分钟，建议设置超时 ≥180s）
PYTHONPATH=. python scripts/csv_to_npz.py \
  --robot h1_2 \
  --input_file deploy/robots/h1_2/config/policy/mimic/dance1_subject2/params/dance1_subject2.csv \
  --output_name dance1_subject2_h1_2.npz \
  --output_fps 50.0 \
  --device cpu

# 转换 dance2_subject1
PYTHONPATH=. python scripts/csv_to_npz.py \
  --robot h1_2 \
  --input_file deploy/robots/h1_2/config/policy/mimic/dance2_subject1/params/dance2_subject1.csv \
  --output_name dance2_subject1_h1_2.npz \
  --output_fps 50.0 \
  --device cpu
```

**转换结果汇总**：

| 动作 | CSV 帧数 | 输出帧数 @50fps | NPZ 大小 |
| :--- | :--- | :--- | :--- |
| dance1_subject2 | 6573 | 10955 (≈219s) | ~18 MB |
| dance2_subject1 | 未记录 | 11284 (≈226s) | ~18 MB |

**实验验证结果**（dance1_subject2）：

| 检查项 | 状态 | 详情 |
| :--- | :--- | :--- |
| 脚本执行 | 通过 | 10955 帧全部处理完成 |
| 输出文件 | 通过 | `dance1_subject2_h1_2_v2.npz`, 18.3MB |
| `fps` | 通过 | `[50.]` |
| `joint_pos` | 通过 | (10955, 27) — 27 关节角度 |
| `joint_vel` | 通过 | (10955, 27) — 27 关节角速度 |
| `body_pos_w` | 通过 | (10955, 28, 3) — **28 个 body link** |
| `body_quat_w` | 通过 | (10955, 28, 4) — wxyz 四元数 |

> **注意**：H1_2 有 28 个 body link（含 world 和 pelvis 等），转换过程需要 MuJoCo warp 在 CPU 上逐帧前向动力学计算，10955 帧约需 3 分钟，建议设置 `timeout 300` 防止超时中断。

输出的 NPZ 文件保存于 `src/assets/motions/h1_2/` 目录（由脚本硬编码），包含 1 个标量 `fps` 和 6 个数组：

| 字段 | 维度 | 说明 |
| :--- | :--- | :--- |
| `fps` | 标量 | 输出帧率（50 Hz） |
| `joint_pos` | (N, 27) | 27 个关节角度 |
| `joint_vel` | (N, 27) | 27 个关节角速度 |
| `body_pos_w` | (N, B, 3) | 每个 link 在世界系的位置 |
| `body_quat_w` | (N, B, 4) | 每个 link 在世界系的姿态 (wxyz) |
| `body_lin_vel_w` | (N, B, 3) | 每个 link 在世界系的线速度 |
| `body_ang_vel_w` | (N, B, 3) | 每个 link 在世界系的角速度 |

> 其中 N 为总帧数，B 为 H1_2 的刚体 link 数量。

---

## 3. play.py 扩展以支持 ONNX 仿真播放

原生 `play.py` 仅支持加载 `.pt` 格式的 PyTorch state_dict。我们扩展了 `PlayConfig` 增加 `--agent onnx` 模式，通过 ONNX Runtime 加载 `.onnx` 格式策略。

### 3.1 ONNX 推理适配 (_OnnxPolicy)

[play.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/scripts/play.py) 中新增的 `_OnnxPolicy` 类负责：

1. **解包 TensorDict**：仿真环境返回的 `obs` 是 TensorDict 对象，需提取 `obs["actor"]` 特征项（No-State-Estimation 任务的 144 维观测）再转为 numpy 数组送入 ONNX Runtime
2. **可选 time_step 输入**：部分策略需要 `time_step` 作为额外输入，`_OnnxPolicy` 自动检测并注入
3. **设备转换**：推理结果从 numpy 转为 PyTorch 张量并迁移到仿真物理设备

关键代码逻辑（已精简，完整实现见源码）：
```python
class _OnnxPolicy:
  def __call__(self, obs) -> torch.Tensor:
    if isinstance(obs, TensorDict):
      obs_tensor = obs["actor"]           # 提取 actor 观测组
    elif hasattr(obs, "keys"):
      obs_tensor = obs.get("actor", obs)  # 兼容 dict-like obs
    else:
      obs_tensor = obs                    # 已是 tensor
    obs_np = obs_tensor.detach().cpu().numpy().astype(np.float32)
    feed: dict[str, np.ndarray] = {"obs": obs_np}
    if self._needs_time_step:             # 自动检测 time_step 输入
      feed["time_step"] = np.full((obs_np.shape[0], 1), self._step, dtype=np.int64)
      self._step += 1
    outputs = self.session.run(None, feed)
    return torch.from_numpy(outputs[self._action_idx]).to(self.device)
```

---

## 4. 启动 H1_2 动作模仿仿真

在完成环境注册和轨迹转换后，使用以下命令启动 H1_2 机器人模仿舞蹈动作的仿真：

> **⚠️ 注意**：必须使用 `Unitree-H1_2-Tracking-No-State-Estimation` 任务（144 维 obs），与训练阶段保持一致。详见 [03 §3.2](file:///home/meme/Documents/笔记/02%20Mimic/03%20H1_2%20Mimic%20%E8%AE%AD%E7%BB%83%E9%80%82%E9%85%8D.md#32-%E6%97%A0%E7%8A%B6%E6%80%81%E4%BC%B0%E8%AE%A1%E5%8F%98%E4%BD%93%E7%94%A8%E4%BA%8E%E8%AE%AD%E7%BB%83%E7%9A%84%E7%89%88%E6%9C%AC)。

```bash
conda activate unitree-rl-sim2sim-py310
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab

# 播放 dance1_subject2
python scripts/play.py Unitree-H1_2-Tracking-No-State-Estimation \
  --agent onnx \
  --onnx_file /home/meme/Documents/unitree_h1/weight/mimic_policy_01.onnx \
  --motion_file src/assets/motions/h1_2/dance1_subject2_h1_2.npz \
  --viewer viser \
  --no-terminations True

# 播放 dance2_subject1
python scripts/play.py Unitree-H1_2-Tracking-No-State-Estimation \
  --agent onnx \
  --onnx_file /home/meme/Documents/unitree_h1/weight/mimic_policy_01.onnx \
  --motion_file src/assets/motions/h1_2/dance2_subject1_h1_2.npz \
  --viewer viser \
  --no-terminations True
```

Viser 启动后，会在终端输出监听地址（如 `http://localhost:8082`）。直接在浏览器中打开即可拖动视角，观察 H1_2 机器人舞蹈运动的连贯性与动力学表现。

**Viser 仿真验证结果**：

| 项目 | 状态 |
| :--- | :--- |
| ONNX 模型加载 | 成功（`mimic_policy_01.onnx`，144 维 obs → 27 维 action） |
| NPZ 轨迹加载 | 成功（dance1_subject2: 10955 帧） |
| MuJoCo 仿真 | 正常，robot 正确初始化为默认姿态并开始跟踪 |
| ONNX Runtime 推理 | 正常，`_OnnxPolicy` 正确解包 144 维 `obs["actor"]` → numpy |
| Viser 可视化 | 正常，浏览器可拖动视角观察 |

---

## 5. 关键问题与解决

### 5.1 `--no-terminations` 需要显式传值

`tyro` 解析 `bool` 类型参数时要求显式传 `True`/`False`：
```bash
# 错误
--no-terminations
# 正确
--no-terminations True
```

### 5.2 ONNX Runtime GPU 警告（无害）

```
GPU device discovery failed: Failed to open file: "/sys/class/drm/card0/device/vendor"
```
CPU 推理模式，可安全忽略。

---

## 6. 仿真进程清理

仿真结束后，可以运行以下命令强制杀掉残留的仿真进程，释放占用端口：

```bash
# 终止 play.py python 仿真进程
pkill -f "play.py"

# 强行释放占用端口
fuser -k 8080/tcp
fuser -k 8081/tcp
fuser -k 8082/tcp
```
