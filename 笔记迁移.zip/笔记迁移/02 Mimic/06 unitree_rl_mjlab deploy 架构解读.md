# 06 unitree_rl_mjlab deploy 架构解读

> **系列定位**：前 05 篇完成了训练与仿真验证，本篇转入 C++ 部署 SDK 的架构解读。

**本篇目的**：
对宇树官方开源仓库 `unitree_rl_mjlab/deploy` 的 C++ 部署 SDK 进行全面系统级架构解读。该 SDK 是宇树新一代机器人 RL 策略部署框架，相比旧版 CppSDK（如 `h1_2_walk_deploy_real` 中基于 LibTorch + 自旋锁 + 手写观测组装的架构），新版 SDK 采用了**基于 IsaacLab 风格的 Manager-Env 解耦架构**、**ONNX Runtime 单后端推理**、**YAML 驱动的声明式观测/动作配置**以及**有限状态机（FSM）+ 遥控器 DSL 表达式驱动的状态转换**等现代化设计。本篇将从系统数据流、FSM 生命周期、观测/动作管理器、ONNX 推理引擎、关节体抽象层以及手柄 DSL 六大维度进行深度剖析。

**在部署系列中的顺序与承接关系**：
在前面几篇完成了旧版 CppSDK 解读与 H1-2 机型迁移后，本篇对官方新版 deploy 框架进行全面解读，为后续基于此框架进行 H1-2 实机适配与功能扩展提供理论基础。

---

## 第一章：系统级架构总览与数据流

### 1.1 新旧架构对比

旧版 CppSDK（如 `g1_deploy_real`）的架构特征：
- **推理后端**：LibTorch（JIT ScriptModule），加载 `motion.pt`
- **观测组装**：在 `Controller::run()` 中手写 Eigen 矩阵运算，逐元素填充 `obs` 向量
- **线程同步**：自研 `AFLock` 自旋锁 + `DataBuffer` 模板缓冲区
- **双速率解耦**：DDS 接收 500Hz / 算法 50Hz / DDS 发送 500Hz 三线程
- **状态机**：手写 `if-else` 分支 + 手柄按键硬编码

新版 `unitree_rl_mjlab/deploy` 的架构特征：
- **推理后端**：ONNX Runtime C++ SDK，加载 `policy.onnx`
- **观测组装**：YAML 声明式配置 + `ObservationManager` 自动化计算
- **线程同步**：`std::mutex`（通过 DDS wrapper 内建的 `mutex_`）
- **双速率解耦**：FSM 线程 1kHz / 策略线程 50Hz 两线程
- **状态机**：`CtrlFSM` 泛型状态机 + YAML 驱动的 DSL 转换条件

### 1.2 系统数据流架构

```mermaid
graph TD
    subgraph "DDS 通信层 (unitree_sdk2)"
        A["rt/lowstate DDS 订阅"] -->|"回调写入"| B["LowState_t (含 mutex_)"]
        C["LowCmd_t (含 mutex_)"] -->|"发布"| D["rt/lowcmd DDS 发布"]
    end

    subgraph "FSM 控制线程 (1kHz)"
        B -->|"pre_run: lowstate->update()"| E["BaseArticulation::update()"]
        E -->|"读取 IMU + 关节状态"| F["ArticulationData (Eigen 向量)"]
        F -->|"run: 状态特定逻辑"| G["State_Passive / FixStand / RLBase"]
        G -->|"post_run: lowcmd->unlockAndPublish()"| C
    end

    subgraph "RL 策略线程 (50Hz, 仅 RLBase 状态)"
        F -->|"robot->update()"| H["ObservationManager::compute()"]
        H -->|"YAML 驱动逐项计算"| I["obs_map (string -> vector)"]
        I -->|"ONNX 推理"| J["OrtRunner::act()"]
        J -->|"action vector"| K["ActionManager::process_action()"]
        K -->|"scale + offset + clip"| L["processed_actions"]
        L -->|"写入 lowcmd"| G
    end

    subgraph "配置层 (YAML)"
        M["config.yaml (FSM + 关节参数)"] -->|"加载"| G
        N["deploy.yaml (观测/动作/命令)"] -->|"加载"| H
        N -->|"加载"| K
    end
```

**核心数据流路径**：
1. **状态采集**：DDS 底层线程接收 `rt/lowstate`，写入 `LowState_t`（含互斥锁保护）
2. **状态更新**：FSM 线程以 1kHz 调用 `pre_run()` → `lowstate->update()` → `BaseArticulation::update()`，将原始 DDS 数据转换为 `ArticulationData` 中的 Eigen 向量
3. **策略推理**（仅 RLBase 状态）：独立策略线程以 50Hz 调用 `env->step()` → `ObservationManager::compute()` → `OrtRunner::act()` → `ActionManager::process_action()`
4. **指令下发**：FSM 线程在 `run()` 中将处理后的动作写入 `LowCmd_t`，在 `post_run()` 中调用 `lowcmd->unlockAndPublish()` 发送

### 1.3 目录结构

```
deploy/
├── include/                          # 公共头文件
│   ├── FSM/                          # 有限状态机框架
│   │   ├── BaseState.h               # 状态基类 + 工厂注册宏
│   │   ├── CtrlFSM.h                 # FSM 控制器
│   │   ├── FSMState.h                # 带 DDS 通信的状态基类
│   │   ├── State_Passive.h           # 被动阻尼状态
│   │   ├── State_FixStand.h          # 插值站立状态
│   │   └── State_RLBase.h            # RL 策略状态
│   ├── isaaclab/                     # IsaacLab 风格框架
│   │   ├── algorithms/               # ONNX 推理引擎
│   │   ├── assets/articulation/      # 关节体抽象
│   │   ├── devices/keyboard/         # 键盘输入
│   │   ├── envs/                     # 环境封装
│   │   │   ├── manager_based_rl_env.h
│   │   │   └── mdp/                  # 观测/动作/终止条件
│   │   ├── manager/                  # 管理器
│   │   │   ├── observation_manager.h
│   │   │   ├── action_manager.h
│   │   │   └── manager_term_cfg.h
│   │   └── utils/                    # 工具函数
│   ├── LinearInterpolator.h          # 线性插值器
│   ├── param.h                       # 参数加载与命令行解析
│   └── unitree_joystick_dsl.hpp      # 手柄 DSL 解析器
├── robots/                           # 各机型实现
│   ├── h1_2/                         # H1-2 人形机器人
│   ├── g1/                           # G1 人形机器人
│   ├── go2/                          # Go2 四足机器人
│   ├── a2/                           # A2 四足机器人
│   └── r1/                           # R1 轮式机器人
└── thirdparty/                       # 第三方依赖
    ├── cnpy/                         # NumPy 数据加载
    ├── onnxruntime-linux-x64-1.22.0/
    └── onnxruntime-linux-aarch64-1.22.0/
```

---

## 第二章：有限状态机（FSM）框架

### 2.1 状态基类与工厂注册

`BaseState.h` 定义了 FSM 的基础框架：

```cpp
class BaseState
{
public:
    BaseState(int state, std::string state_string);
    virtual void enter() {}
    virtual void pre_run() {}
    virtual void run() {}
    virtual void post_run() {}
    virtual void exit() {}

    std::vector<std::pair<std::function<bool()>, int>> registered_checks;
};
```

关键设计：
- **`registered_checks`**：每个状态注册一组「检查函数 → 目标状态ID」对，FSM 主循环在每个周期遍历这些检查，若某条件为真则触发状态转换
- **工厂注册宏 `REGISTER_FSM`**：利用 C++ 静态初始化机制，在 `main()` 执行前自动将状态类注册到全局工厂映射 `getFsmMap()` 中

```cpp
#define REGISTER_FSM(Derived) \
    inline std::shared_ptr<BaseState> __factory_##Derived(int s, std::string ss) { \
        return std::make_shared<Derived>(s, ss); \
    } \
    inline struct __registrar_##Derived { \
        __registrar_##Derived() { getFsmMap()[#Derived] = __factory_##Derived; } \
    } __registrar_instance_##Derived;
```

这种设计使得新增状态类只需在头文件中声明 `REGISTER_FSM(State_MyNewState)`，无需修改 `CtrlFSM` 或 `main.cpp` 中的任何代码。

#### 2.1.1 模糊名称匹配（Fuzzy Name Matching）

在实际部署中，尤其是在多运动（multi-motion）场景下，同一个 FSM 状态类可能需要管理多个运动变体（如 `Mimic_Dance1`、`Mimic_Walk`），但注册时只有单一的 `State_Mimic` 类。为此，`BaseState.h` 新增了 `fsm_id_from_name` 函数实现模糊名称匹配：

```cpp
inline int fsm_id_from_name(const std::string& name)
{
    // 1. 精确匹配
    auto it = FSMStringMap.right.find(name);
    if (it != FSMStringMap.right.end())
        return it->second;

    // 2. 前缀匹配：检查 |name| 是否以某个注册名开头
    for (auto& entry : FSMStringMap.right)
    {
        const std::string& registered = entry.first;
        if (name.compare(0, registered.size(), registered) == 0)
            return entry.second;
    }
    return -1;
}
```

**匹配策略**：先尝试精确匹配（`"Mimic"` → 精确命中），若失败则进行前缀匹配（`"Mimic_Dance1"` → 匹配注册名 `"Mimic"`）。这种机制使得 YAML 配置的 timed schedule 或多运动命名可以携带后缀变体，而 FSM 仍能正确路由到对应的状态类实例。

### 2.2 FSMState：带 DDS 通信的状态基类

`FSMState.h` 继承 `BaseState`，增加了与底层硬件通信的静态成员：

```cpp
class FSMState : public BaseState
{
public:
    FSMState(int state, std::string state_string);
    void pre_run() { lowstate->update(); if(keyboard) keyboard->update(); }
    void post_run() { lowcmd->unlockAndPublish(); }

    static std::unique_ptr<LowCmd_t> lowcmd;
    static std::shared_ptr<LowState_t> lowstate;
    static std::shared_ptr<Keyboard> keyboard;
};
```

**关键设计要点**：

1. **静态共享资源**：`lowcmd`、`lowstate`、`keyboard` 为静态成员，所有状态实例共享同一份硬件通信句柄，避免了资源竞争和重复初始化

2. **转换条件 DSL 解析**：在构造函数中，从 YAML 配置的 `transitions` 字段解析手柄按键组合表达式，编译为可执行谓词函数：

```cpp
auto transitions = param::config["FSM"][state_string]["transitions"];
for(auto it = transition_map.begin(); it != transition_map.end(); ++it) {
    std::string condition = it->second;  // 如 "LT + up.on_pressed"
    unitree::common::dsl::Parser p(condition);
    auto ast = p.Parse();
    auto func = unitree::common::dsl::Compile(*ast);
    registered_checks.emplace_back(
        std::make_pair(
            [func]()->bool{ return func(FSMState::lowstate->joystick); },
            fsm_id
        )
    );
}
```

3. **通用超时保护**：所有状态自动注册 DDS 通信超时检查，若底层连接断开则自动回退到 Passive 状态：

```cpp
registered_checks.emplace_back(
    std::make_pair(
        []()->bool{ return lowstate->isTimeout(); },
        FSMStringMap.right.at("Passive")
    )
);
```

### 2.3 CtrlFSM：状态机控制器

`CtrlFSM` 是整个状态机的驱动引擎，以 1kHz 频率执行状态循环：

```cpp
class CtrlFSM
{
public:
    CtrlFSM(YAML::Node cfg) {
        auto fsms = cfg["_"]; // 从 YAML 的 "_" 字段读取启用的状态列表
        for (auto it = fsms.begin(); it != fsms.end(); ++it) {
            std::string fsm_type = it->second["type"] ? it->second["type"].as<std::string>() : fsm_name;
            auto fsm_class = getFsmMap().find("State_" + fsm_type);
            auto state_instance = fsm_class->second(id, fsm_name);
            add(state_instance);
        }
    }

    void start() {
        currentState = states[0]; // 始终从第一个状态（Passive）开始
        currentState->enter();
        fsm_thread_ = std::make_shared<unitree::common::RecurrentThread>(
            "FSM", 0, this->dt * 1e6, &CtrlFSM::run_, this);
    }

private:
    const double dt = 0.001; // 1ms 周期 = 1kHz

    void run_() {
        currentState->pre_run();
        currentState->run();
        currentState->post_run();

        // 检查状态转换条件
        for(auto& check : currentState->registered_checks) {
            if(check.first()) {
                // 找到目标状态，执行 exit() + enter()
                currentState->exit();
                currentState = target_state;
                currentState->enter();
                break;
            }
        }
    }
};
```

**状态转换流程**：

```mermaid
stateDiagram-v2
    [*] --> Passive: 程序启动
    Passive --> FixStand: LT + up.on_pressed
    FixStand --> Passive: LT + B.on_pressed
    FixStand --> Velocity: RT + A.on_pressed
    Velocity --> Passive: LT + B.on_pressed
    Passive --> Passive: DDS 超时
    FixStand --> Passive: DDS 超时
    Velocity --> Passive: DDS 超时 / 跌倒
```

### 2.4 三大核心状态实现

#### 2.4.1 State_Passive：被动阻尼状态

```cpp
class State_Passive : public FSMState {
    void enter() {
        for(int i(0); i < kd.size(); ++i) {
            motor.kp() = 0;      // 零刚度
            motor.kd() = kd[i];  // 仅微分阻尼
            motor.dq() = 0;
            motor.tau() = 0;
        }
    }
    void run() {
        // 跟随当前关节位置（零力矩模式）
        lowcmd->msg_.motor_cmd()[i].q() = lowstate->msg_.motor_state()[i].q();
    }
};
```

Passive 状态是系统的安全基态。在此状态下，所有电机以纯阻尼模式运行（Kp=0, Kd=5~6），关节位置目标跟随当前实际位置，电机不产生主动力矩。这是机器人上电后的初始状态，也是任何异常（通信超时、跌倒）后的回退状态。

#### 2.4.2 State_FixStand：插值站立状态

```cpp
class State_FixStand : public FSMState {
    void enter() {
        // 设置高刚度 PD 增益
        motor.kp() = kp[i];  // 250~600
        motor.kd() = kd[i];  // 0.4~10
        // 记录当前关节位置作为插值起点
        qs_[0] = q0;  // 当前位置
    }
    void run() {
        float t = current_time - t0_;
        auto q = linear_interpolate(t, ts_, qs_);
        lowcmd->msg_.motor_cmd()[i].q() = q[i];
    }
};
```

FixStand 状态通过 `LinearInterpolator` 实现从当前关节位置到默认站立姿态的平滑过渡。YAML 配置中的 `ts` 和 `qs` 定义了插值时间轴和关键帧：

```yaml
FixStand:
    ts: [0, 3]          # 0秒和3秒两个关键帧
    qs: [
        [],             # 0秒：当前位置（enter时填充）
        [0, -0.3, ...]  # 3秒：默认站立姿态
    ]
```

`linear_interpolate` 函数实现一阶线性插值：

```cpp
inline std::vector<float> linear_interpolate(float t, const std::vector<float>& ts,
                                              const std::vector<std::vector<float>>& ys) {
    if (t <= ts[0]) return ys[0];
    if (t >= ts[ts.size() - 1]) return ys[ts.size() - 1];
    for (int i = 0; i < ts.size() - 1; ++i) {
        if (t >= ts[i] && t <= ts[i + 1]) {
            float alpha = (t - ts[i]) / (ts[i + 1] - ts[i]);
            result[j] = ys[i][j] * (1 - alpha) + ys[i + 1][j] * alpha;
        }
    }
}
```

#### 2.4.3 State_RLBase：RL 策略状态

State_RLBase 是整个框架中最复杂的状态，它管理着一个独立的策略推理线程：

```cpp
class State_RLBase : public FSMState {
    void enter() {
        // 设置策略指定的 PD 增益
        lowcmd->msg_.motor_cmd()[i].kp() = env->robot->data.joint_stiffness[i];
        lowcmd->msg_.motor_cmd()[i].kd() = env->robot->data.joint_damping[i];

        env->robot->update();
        policy_thread_running = true;
        policy_thread = std::thread([this]{
            const std::chrono::duration<double> desiredDuration(env->step_dt);
            env->reset();
            while (policy_thread_running) {
                env->step();
                std::this_thread::sleep_until(sleepTill);
                sleepTill += dt;
            }
        });
    }

    void run() {
        auto action = env->action_manager->processed_actions();
        for(int i(0); i < env->robot->data.joint_ids_map.size(); i++) {
            lowcmd->msg_.motor_cmd()[env->robot->data.joint_ids_map[i]].q() = action[i];
        }
    }

    void exit() {
        policy_thread_running = false;
        if (policy_thread.joinable()) policy_thread.join();
    }
};
```

**关键设计**：
- **双线程解耦**：策略推理在独立线程中以 50Hz（`step_dt=0.02`）运行，FSM 主线程以 1kHz 运行
- **写入时机**：策略线程计算 `processed_actions()`，FSM 线程在 `run()` 中将动作写入 `lowcmd`。由于 `processed_actions()` 返回的是 `std::vector<float>` 的值拷贝，且 FSM 线程只读不写，因此无需额外互斥保护
- **动作历史初始化（Action Reset）**：在 `enter()` 中，执行完 `env->reset()` 后立即初始化动作历史。具体做法是从配置中读取 `action_scale` 和 `action_offset`，将当前关节位置（`joint_pos`）反算为归一化动作向量，然后通过三步操作刷新状态：
  1. `set_action(initial_action)` — 将初始动作写入 ActionManager 的缓存
  2. `recompute_term_history("last_action")` — 通知 ObservationManager 用新值重建 `last_action` 的历史帧
  3. `process_action(initial_action)` — 生成处理后的动作目标

  这确保了策略推理的第一帧有合理的 `last_action` 输入（而非全零或垃圾值），避免初次推理时动作跳变导致机器人失稳。
- **安全退出**：`exit()` 中先置 `policy_thread_running = false`，再 `join()` 等待线程结束，确保不会在策略推理中途被销毁

---

### 2.5 定时调度模式（Timed Schedule）

标准的 FSM 状态转换由**手柄 DSL 条件**驱动（如 `LT + A.on_pressed`），依赖操作员实时干预。Timed Schedule 模式则提供了**完全自动化的状态转换方式**，通过命令行参数 `--timed` 指定一个按时序排列的状态序列，FSM 在每个状态驻留固定时间后自动推进到下一个状态。

#### 2.5.1 调度入口

在 `main.cpp` 中解析 `--timed` 命令行参数：

```cpp
if (vm.count("timed"))
{
    std::string timed_str = vm["timed"].as<std::string>();
    std::vector<CtrlFSM::TimedScheduleEntry> schedule;

    std::istringstream ss(timed_str);
    std::string token;
    while (std::getline(ss, token, ','))
    {
        auto colon_pos = token.find(':');
        // 格式："StateName:seconds"
        std::string state_name = token.substr(0, colon_pos);
        double duration = std::stod(token.substr(colon_pos + 1));
        schedule.push_back({state_name, duration});
    }
    fsm->setTimedSchedule(schedule);
}
```

使用示例：

```bash
./h1_2_ctrl --timed "FixStand:3,Velocity:10"
```

#### 2.5.2 调度执行逻辑

`CtrlFSM` 内部维护了 `timed_schedule_` 向量和 `timed_schedule_index_` 指针。在 `start()` 中，首先检查第一个调度条目并立即执行状态切换：

1. **状态切换**：通过 `fsm_id_from_name()`（模糊匹配）找到目标状态 ID，如果与当前状态不同则执行 `exit()` + `enter()` 切换
2. **计时推进**：在 FSM 主循环的每次 `run_()` 调用中累加 `elapsed_time_in_state_`，当驻留时间超过当前条目指定的 `duration` 时，递增 `timed_schedule_index_` 并切换到下一状态
3. **调度完结**：当所有调度条目执行完毕后，FSM 回到标准的手柄 DSL 控制模式（`use_timed_schedule = false`），操作员可通过手柄接替控制

**与模糊名称匹配的协同**：`timed_schedule_` 中的状态名经过 `fsm_id_from_name()` 解析，因此 `--timed "Mimic_Walk:30"` 会自动匹配到注册名 `Mimic`，无需修改任何 C++ 代码即可驱动不同运动变体。

#### 2.5.3 应用场景

- **自动化演示**：编写固定时序的演示流程（Passive → FixStand → Mimic），无人值守运行
- **批量测试**：结合日志录制，在 CI 环境中自动运行不同运动、定时间隔的回归测试
- **多运动编排**：将不同运动按时间顺序串联，实现运动序列的自动切换（如先行走 30 秒，再站立 10 秒，再挥手 10 秒）

### 2.6 State_Mimic — Mimic 运动跟踪状态

`State_Mimic` 是专门为 Motion Tracking/Mimic 任务设计的状态类，继承自 `FSMState`（而非 `State_RLBase`），因为 Mimic 任务需要额外管理**参考运动数据**（NPZ 文件）和**运动帧索引**。它位于 `deploy/robots/h1_2/include/State_Mimic.h` 和 `deploy/robots/h1_2/src/State_Mimic.cpp`。

#### 2.6.1 MotionLoader_：C++ 端的参考运动加载器

`State_Mimic` 内嵌了 `MotionLoader_` 内部类，负责在 C++ 端加载 NPZ 格式的参考运动数据：

```cpp
class MotionLoader_
{
public:
    MotionLoader_(std::string motion_file) {
        load_data_from_npz(motion_file);
        num_frames = dof_positions.size();
        dt = 1.0f / fps;
        duration = num_frames * dt;
        update(0.0f);
    }
    // ...
};
```

**数据加载流程**：
1. 通过 `cnpy::npz_load` 读取 NPZ 文件，提取 `body_pos_w`、`body_quat_w`、`joint_pos`、`joint_vel`、`fps` 五个数组
2. **FPS 类型检测**：NPZ 中的 FPS 数据可能是 float64 或 float32 存储。代码通过 `word_size` 运行时判断类型，调用对应的 `data<float>()` 或 `data<double>()` 读取——避免因类型不匹配读到 0 值导致 `dt = 1/0 = inf`
3. 将原始帧数据逐帧转换为 `Eigen::VectorXf` / `Eigen::Quaternionf` 向量
4. 通过 `update(float time)` 根据当前时间计算帧索引

**帧索引的浮点精度修复**：

```cpp
void update(float time)
{
    float phase = std::fmod(time, duration);
    float f = phase / dt;
    frame = static_cast<int>(std::floor(f + 1e-4f));
    frame = std::min(frame, num_frames - 1);
}
```

关键细节是 `+ 1e-4f` epsilon 修正。由于 float32 精度的累积误差，当经过 N 步后 `N * dt / dt` 可能略小于 N（如 `27 * 0.02f / 0.02f = 26.999...`），导致 `floor` 结果比正确帧索引少 1。epsilon 值 `1e-4f` 大于 float32 累积误差上限（约 `4e-7`），且小于 1 帧间距（约 `0.02`），确保整数附近的浮点误差被正确归整。

#### 2.6.2 YAML 配置与 FSM 注册

在 `config.yaml` 中，Mimic 状态通过在状态名后加**后缀变体**进行多运动注册——利用模糊名称匹配（2.1.1 节）自动路由：

```yaml
FSM:
  _:
    Passive:  {id: 1}
    FixStand: {id: 2}
    Mimic_Dance1_subject2:
      id: 5
      type: Mimic     # type: Mimic → 注册名为 State_Mimic
  # ...
  Mimic_Dance1_subject2:
    transitions:
      Passive: LT + B.on_pressed
      FixStand: RT + A.on_pressed
    motion_file: config/policy/mimic/v0/params/dance1_subject2.npz
    policy_dir: config/policy/mimic/v0/
    time_start: 0.0
    time_end: 1000.0
    dump_enabled: false
```

**关键配置项**：
- `type: Mimic`：告诉 CtrlFSM 使用 `State_Mimic` 类（而非拼接 `State_` + 状态名的默认规则）
- `motion_file`：参考运动 NPZ 文件路径（绝对或相对项目根目录）
- `policy_dir`：策略 ONNX 模型和 deploy.yaml 所在目录，通过 `param::parser_policy_dir()` 自动查找 `exported/` 子目录
- `time_start` / `time_end`：运动片段的时间范围（秒），允许截取运动的一部分播放
- `dump_enabled`：CSV 调试日志开关，开启后每步写入 `/tmp/mimic_dump.csv`（含观测、动作、电机状态）

状态名 `"Mimic_Dance1_subject2"` 通过 `fsm_id_from_name()` 的前缀匹配逻辑（2.1.1 节）匹配到注册名 `"Mimic"`，因此 `REGISTER_FSM(State_Mimic)` 注册的工厂函数能够正确创建实例。

#### 2.6.3 构造函数：策略环境初始化

构造函数执行以下步骤：

1. **解析策略目录**：通过 `param::parser_policy_dir()` 定位 `exported/policy.onnx` 和 `params/deploy.yaml`
2. **创建关节体**：实例化 `unitree::BaseArticulation`，复用 DDS 通信层
3. **加载运动数据**：创建 `MotionLoader_` 实例，读取 NPZ 运动文件，记录持续时间
4. **解析时间范围**：读取 `time_start` 和 `time_end` 配置，裁剪运动片段
5. **构造 RL 环境**：创建 `ManagerBasedRLEnv`，加载 `deploy.yaml` 观测/动作配置
6. **初始化推理引擎**：创建 `OrtRunner`，加载 ONNX 模型
7. **注册终止检查**：
   - **超时终止**：当 `episode_length * step_dt > time_range_[1]` 时，切换到 `end_state`（默认 `FixStand`）
   - **姿态异常终止**：`bad_orientation` 检测躯干倾斜超过阈值时，切回 `Passive` 状态

#### 2.6.4 enter()：Mimic 状态的启动序列

`enter()` 方法实现了 Mimic 任务最关键的初始化序列，包含多个步骤来确保策略推理的第一帧具有正确的状态上下文。具体流程如下：

> **与 State_RLBase 的关键区别**：State_RLBase 的 `enter()` 以当前关节位置作为初始动作（当前位置反算 + reset），而 State_Mimic 以**参考运动的第一帧**作为初始动作，因为这正是策略应该跟踪的目标。

**第一步：偏航对齐计算**

```cpp
auto ref_torso_quat = motion->root_quaternion()
    * Eigen::AngleAxisf(motion->joint_pos()[12], Eigen::Vector3f::UnitZ());
auto ref_yaw_quat = isaaclab::yawQuaternion(ref_torso_quat);
auto robot_yaw_quat = isaaclab::yawQuaternion(env->robot->data.root_quat_w);
init_quat = robot_yaw_quat * ref_yaw_quat.conjugate();
```

`init_quat` 存储了机器人躯干（IMU 测量值）与参考运动躯干（pelvis 四元数乘以 waist yaw 关节角度）之间的偏航差异。这里对参考运动做了与 Python 训练侧相同的 `pelvis → torso` 变换：`ref_torso_quat = root_quat * Rz(waist_yaw)`。`init_quat` 在后续每步的 `motion_anchor_ori_b` 观测计算中使用，确保参考运动的朝向与机器人当前朝向在偏航方向上对齐。

**第二步：关节位置对齐**

```cpp
env->robot->data.default_joint_pos = env->robot->data.joint_pos;
```

将 `default_joint_pos` 覆盖为当前关节位置，使得 `joint_pos_rel = current - default ≈ 0`。这确保策略在第一帧看到的是一个"零偏差"的关节状态，无论机器人在进入 Mimic 状态前处于什么姿态（如 Passive 的跟随姿态或 FixStand 的站立姿态）。

**第三步：动作历史初始化**

```cpp
auto action_scale = env->cfg["actions"]["JointPositionAction"]["scale"].as<std::vector<float>>();
auto action_offset = env->cfg["actions"]["JointPositionAction"]["offset"].as<std::vector<float>>();
auto motion_joint_pos = motion->joint_pos();
std::vector<float> initial_action(motion_joint_pos.size());
for(size_t i = 0; i < motion_joint_pos.size(); ++i) {
    initial_action[i] = (motion_joint_pos[i] - action_offset[i]) / action_scale[i];
}
```

将参考运动的第一帧关节位置**反算**为归一化动作向量：`initial_action = (motion_joint_pos - offset) / scale`。这样策略输入的 `last_action` 观测对应的是参考运动的目标位置，而不是全零值，避免首次推理时动作跳变导致机器人失稳。

**第四步：环境重置与历史刷新**

```cpp
env->reset();
env->action_manager->set_action(initial_action);
env->observation_manager->recompute_term_history("last_action");
env->action_manager->process_action(initial_action);
```

- `set_action()`（[action_manager.h](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/include/isaaclab/manager/action_manager.h#L67)）：直接覆写 ActionManager 的 `_action` 缓存，不经过 scale/offset 处理
- `recompute_term_history()`（[observation_manager.h](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/include/isaaclab/manager/observation_manager.h#L53)）：重新计算指定观测项（`"last_action"`）并用新值填充其历史缓冲区，使历史帧（`history_length` 帧）全部为初始动作值而非零值
- `process_action()`：生成处理后的动作目标（scale + offset + clip），作为 FSM 线程写入 lowcmd 的关节目标

这三步操作的目的是确保 `last_action` 观测在第一帧就有正确的参考值，而非默认的零值。对于 GRU 时序网络（训练侧使用 `use_gru=True`），这种初始化尤为重要——GRU 的隐状态会受历史输入影响，错误的 `last_action` 历史会导致 GRU 状态发散。

#### 2.6.5 策略线程与观测计算

策略线程以 `step_dt = 0.02s（50Hz）` 运行，与训练侧的动作频率一致。每步执行三个核心操作：

```cpp
// 1. 更新关节状态（从 DDS lowstate 读取）
env->robot->update();
// 2. 推进运动帧（累计时间 → 帧索引）
motion->update(env->episode_length * env->step_dt + time_range_[0]);
// 3. 观测计算 → ONNX 推理 → 动作映射
env->step();
```

`FSM` 线程则以 1kHz 频率调用 `State_Mimic::run()`，将 `action_manager->processed_actions()` 写入 `lowcmd` 下发到电机。

#### 2.6.6 Mimic 的观测配置（150/144 维）

Mimic 任务使用独立的 `deploy.yaml`（`deploy/robots/h1_2/config/policy/mimic/v0/params/deploy.yaml`），观测配置与 Velocity 任务有显著差异：

| 观测项 | 维度 | 数据源 | 说明 |
|:-------|:----:|:-------|:-----|
| `motion_command` | 54 | MotionLoader_ | 参考运动关节位置(27) + 速度(27)，Mimic 核心观测 |
| `motion_anchor_pos_b` | 3 | 填零占位 | DDS 不含机器人全局位置，返回 `[0,0,0]` |
| `motion_anchor_ori_b` | 6 | MotionLoader_ + IMU | 参考锚点相对于机器人锚点的 6D 朝向 |
| `base_lin_vel` | 3 | 填零占位 | DDS 不含线速度，返回 `[0,0,0]` |
| `base_ang_vel_pelvis` | 3 | IMU + waist yaw 补偿 | 将躯干 IMU 角速度变换到骨盆坐标系 |
| `joint_pos_rel` | 27 | 编码器 | `current_pos - default_joint_pos` |
| `joint_vel_rel` | 27 | 编码器 | `current_vel - default_joint_vel` |
| `last_action` | 27 | ActionManager | 上一帧动作输出 |
| **总计** | **150** | | 其中 6 维为填零占位，有效观测 144 维 |

**关键设计要点**：

1. **`motion_anchor_pos_b` 和 `base_lin_vel` 填零**：DDS 底层通信不提供机器人全局位姿和线速度信息（这两者需要通过视觉里程计或 GPS 额外估计），因此 C++ 端将这两项填零。这与训练侧的 No-Estimate 模式对应——ONNX 模型在此模式下训练（144 维输入），推理时这两项填零不影响策略行为。

2. **`base_ang_vel_pelvis` 替代 `base_ang_vel`**：H1_2 的 IMU 安装在躯干（torso）上，但策略在骨盆（pelvis）坐标系下训练。通过 waist yaw 关节角度进行坐标变换：`ω_pelvis = Rz(waist_yaw) · ω_torso`，同时补偿 waist yaw 自身的角速度分量（`ω_pelvis[2] -= waist_yaw_omega`）。

3. **`motion_anchor_ori_b` 的偏航对齐**：在观测计算中，参考锚点的四元数通过 `init_quat` 进行全局偏航补偿，再与机器人当前 IMU 四元数做差，提取 6D 旋转表示。数学推导：
   ```
   rot = (init_quat * ref_quat).conjugate() * real_quat
   6D = rot.toRotationMatrix().transpose() → 取前两列
   ```
   这确保策略对偏航漂移不敏感——机器人朝向不同时，观测值自动校准。

4. **无 `velocity_commands` 和 `gait_phase`**：Mimic 任务不需要速度指令和步态相位，因为参考运动已包含完整的关节轨迹。

#### 2.6.7 CMakeLists.txt 的扩展

为支持 Mimic 状态，CMakeLists.txt 增加了以下依赖和配置：

```cmake
set(CMAKE_CXX_STANDARD 17)            # C++17（std::filesystem 支持）
find_package(ZLIB REQUIRED)           # cnpy 的底层压缩依赖
add_library(cnpy_lib STATIC ...)      # NPZ 文件读取库
link_libraries(... cnpy_lib ZLIB::ZLIB)
```

与 Velocity 任务相比，Mimic 新增了 `cnpy`（NPZ 加载）和 `ZLIB`（压缩解压）依赖。所有 `src/*.cpp` 通过 `file(GLOB_RECURSE)` 自动包含，因此 `State_Mimic.cpp` 无需在 CMakeLists.txt 中显式添加。此外，`set(CMAKE_INSTALL_RPATH_USE_LINK_PATH TRUE)` 确保 ONNX Runtime 动态库在运行时能被正确找到。

---

## 第三章：IsaacLab 风格环境框架

### 3.1 ManagerBasedRLEnv：环境封装

`ManagerBasedRLEnv` 是整个 RL 策略推理的核心协调者，模仿 IsaacLab 的 `ManagerBasedRLEnv` 设计：

```cpp
class ManagerBasedRLEnv {
public:
    ManagerBasedRLEnv(YAML::Node cfg, std::shared_ptr<Articulation> robot_)
    : cfg(cfg), robot(std::move(robot_)) {
        this->step_dt = cfg["step_dt"].as<float>();
        robot->data.joint_ids_map = cfg["joint_ids_map"].as<std::vector<float>>();
        robot->data.default_joint_pos = Eigen::VectorXf::Map(...);
        robot->data.joint_stiffness = cfg["stiffness"].as<std::vector<float>>();
        robot->data.joint_damping = cfg["damping"].as<std::vector<float>>();
        robot->update();
        action_manager = std::make_unique<ActionManager>(cfg["actions"], this);
        observation_manager = std::make_unique<ObservationManager>(cfg["observations"], this);
    }

    void reset() {
        global_phase = 0;
        episode_length = 0;
        robot->update();
        action_manager->reset();
        observation_manager->reset();
    }

    void step() {
        episode_length += 1;
        robot->update();
        auto obs = observation_manager->compute();
        auto action = alg->act(obs);
        action_manager->process_action(action);
    }
};
```

**step() 的完整执行流程**：

```mermaid
sequenceDiagram
    participant PT as 策略线程 (50Hz)
    participant Env as ManagerBasedRLEnv
    participant Robot as BaseArticulation
    participant ObsMgr as ObservationManager
    participant Alg as OrtRunner
    participant ActMgr as ActionManager

    PT->>Env: step()
    Env->>Robot: update()
    Note over Robot: 从 LowState_t 读取 IMU + 关节数据<br/>转换为 Eigen 向量
    Env->>ObsMgr: compute()
    Note over ObsMgr: 遍历 YAML 声明的观测项<br/>逐项计算 + 缩放 + 裁剪 + 历史堆叠
    ObsMgr-->>Env: obs_map {group_name: vector}
    Env->>Alg: act(obs_map)
    Note over Alg: ONNX Runtime 前向推理<br/>输入: 多个命名张量<br/>输出: action vector
    Alg-->>Env: action
    Env->>ActMgr: process_action(action)
    Note over ActMgr: scale * raw + offset<br/>clip 限幅
```

### 3.2 ArticulationData：关节体数据结构

`ArticulationData` 是机器人状态的数据容器，存储了策略推理所需的全部物理量：

```cpp
struct ArticulationData {
    Eigen::Vector3f GRAVITY_VEC_W = Eigen::Vector3f(0.0f, 0.0f, -1.0f);
    Eigen::Vector3f FORWARD_VEC_B = Eigen::Vector3f(1.0f, 0.0f, 0.0f);

    std::vector<float> joint_stiffness;     // PD 控制刚度
    std::vector<float> joint_damping;       // PD 控制阻尼
    Eigen::VectorXf joint_pos;             // 当前关节位置
    Eigen::VectorXf default_joint_pos;     // 默认关节位置
    Eigen::VectorXf joint_vel;            // 当前关节速度
    Eigen::Vector3f root_ang_vel_b;        // 机身角速度（体坐标系）
    Eigen::Vector3f projected_gravity_b;   // 投影重力向量（体坐标系）
    Eigen::Quaternionf root_quat_w;       // 机身姿态四元数（世界坐标系）
    std::vector<float> joint_ids_map;      // 关节 ID 映射
    unitree::common::UnitreeJoystick* joystick; // 遥控器手柄
};
```

### 3.3 BaseArticulation：硬件抽象层

`BaseArticulation` 是连接 DDS 通信层与 IsaacLab 框架的桥梁：

```cpp
template <typename LowStatePtr>
class BaseArticulation : public isaaclab::Articulation {
public:
    BaseArticulation(LowStatePtr lowstate_) : lowstate(lowstate_) {
        data.joystick = &lowstate->joystick;
    }

    void update() override {
        std::lock_guard<std::mutex> lock(lowstate->mutex_);
        // 1. 机身角速度
        for(int i(0); i<3; i++)
            data.root_ang_vel_b[i] = lowstate->msg_.imu_state().gyroscope()[i];
        // 2. 投影重力向量
        data.root_quat_w = Eigen::Quaternionf(
            lowstate->msg_.imu_state().quaternion()[0], // w
            lowstate->msg_.imu_state().quaternion()[1], // x
            lowstate->msg_.imu_state().quaternion()[2], // y
            lowstate->msg_.imu_state().quaternion()[3]  // z
        );
        data.projected_gravity_b = data.root_quat_w.conjugate() * data.GRAVITY_VEC_W;
        // 3. 关节位置与速度
        for(int i(0); i < data.joint_ids_map.size(); i++) {
            data.joint_pos[i] = lowstate->msg_.motor_state()[data.joint_ids_map[i]].q();
            data.joint_vel[i] = lowstate->msg_.motor_state()[data.joint_ids_map[i]].dq();
        }
    }
};
```

**投影重力向量的数学推导**：

设世界坐标系下重力向量为 $\boldsymbol{g}^W = [0, 0, -1]^T$，机身姿态四元数为 $\boldsymbol{q}_W^B$（从世界系到机身系的旋转），则重力在机身坐标系下的投影为：

$$\boldsymbol{g}^B = \boldsymbol{q}_W^B \otimes \boldsymbol{g}^W \otimes \bar{\boldsymbol{q}}_W^B$$

在代码中，`root_quat_w` 实际存储的是 $\boldsymbol{q}_B^W$（从机身系到世界系），因此需要取共轭（逆旋转）：

```cpp
data.projected_gravity_b = data.root_quat_w.conjugate() * data.GRAVITY_VEC_W;
```

这与旧版 CppSDK 中通过旋转矩阵第三行取反的方式在数学上等价：

$$\boldsymbol{g}^B = -\begin{bmatrix} R(2,0) \\ R(2,1) \\ R(2,2) \end{bmatrix} = \boldsymbol{R}^T \begin{bmatrix} 0 \\ 0 \\ -1 \end{bmatrix} = \bar{\boldsymbol{q}} \otimes \boldsymbol{g}^W \otimes \boldsymbol{q}$$

---

## 第四章：观测管理器（ObservationManager）

### 4.1 YAML 声明式观测配置

观测管理器的核心创新在于**通过 YAML 配置文件声明观测向量**，而非在 C++ 代码中手写组装逻辑。以 H1-2 的 `deploy.yaml` 为例：

```yaml
observations:
  base_ang_vel:
    params: {}
    clip: null
    scale: [1.0, 1.0, 1.0]
    history_length: 1
  projected_gravity:
    params: {}
    clip: null
    scale: [1.0, 1.0, 1.0]
    history_length: 1
  velocity_commands:
    params: {command_name: base_velocity}
    clip: null
    scale: [1.0, 1.0, 1.0]
    history_length: 1
  gait_phase:
    params: {period: 0.6}
    clip: null
    scale: [1.0, 1.0]
    history_length: 1
  joint_pos_rel:
    params: {}
    clip: null
    scale: [1.0, 1.0, ...]  # 27维
    history_length: 1
  joint_vel_rel:
    params: {}
    clip: null
    scale: [1.0, 1.0, ...]  # 27维
    history_length: 1
  last_action:
    params: {}
    clip: null
    scale: [1.0, 1.0, ...]  # 27维
    history_length: 1
```

每个观测项包含：
- **`params`**：传递给观测计算函数的参数
- **`clip`**：裁剪范围 `[min, max]`，`null` 表示不裁剪
- **`scale`**：缩放系数，逐元素乘
- **`history_length`**：历史堆叠长度（1=仅当前帧）

### 4.2 观测项注册机制

观测项通过 `REGISTER_OBSERVATION` 宏注册到全局映射表：

```cpp
#define REGISTER_OBSERVATION(name) \
    inline std::vector<float> name(ManagerBasedRLEnv* env, YAML::Node params); \
    inline struct name##_registrar { \
        name##_registrar() { observations_map()[#name] = name; } \
    } name##_registrar_instance; \
    inline std::vector<float> name(ManagerBasedRLEnv* env, YAML::Node params)
```

使用示例：

```cpp
REGISTER_OBSERVATION(base_ang_vel)
{
    auto & data = env->robot->data.root_ang_vel_b;
    return std::vector<float>(data.data(), data.data() + data.size());
}
```

### 4.3 观测计算流程

`ObservationManager::compute()` 的执行流程：

1. **遍历所有观测组**：YAML 中可以定义多个观测组（对应 ONNX 模型的多个输入），每个组生成一个独立的 `std::vector<float>`
2. **逐项计算**：对组内每个观测项，调用注册的计算函数获取原始数据
3. **缩放与裁剪**：根据 `scale_first` 标志决定先缩放还是先裁剪
4. **历史堆叠**：将最近 `history_length` 帧的数据按时间顺序拼接

```cpp
void add(std::vector<float> obs) {
    for(int j = 0; j < obs.size(); ++j) {
        if(scale_first) {
            if(!scale.empty()) obs[j] *= scale[j];
            if(!clip.empty()) obs[j] = std::clamp(obs[j], clip[0], clip[1]);
        } else {
            if(!clip.empty()) obs[j] = std::clamp(obs[j], clip[0], clip[1]);
            if(!scale.empty()) obs[j] *= scale[j];
        }
    }
    buff_.push_back(obs);
    if (buff_.size() > history_length) buff_.pop_front();
}
```

### 4.4 H1-2 观测向量物理映射

根据 `deploy.yaml` 配置，H1-2 的观测向量总维度为：

| 观测项 | 维度 | 物理含义 | 数据源 |
|--------|------|----------|--------|
| `base_ang_vel` | 3 | 机身角速度 | IMU 陀螺仪 |
| `projected_gravity` | 3 | 投影重力向量 | IMU 四元数→共轭旋转 |
| `velocity_commands` | 3 | 用户速度指令 | 遥控器摇杆 + 限幅 |
| `gait_phase` | 2 | 步态相位 sin/cos | 全局相位计数器 |
| `joint_pos_rel` | 27 | 关节位置相对默认值偏差 | 电机编码器 - default_joint_pos |
| `joint_vel_rel` | 27 | 关节角速度 | 电机编码器微分 |
| `last_action` | 27 | 上一帧动作输出 | ActionManager 缓存 |

**总计：3 + 3 + 3 + 2 + 27 + 27 + 27 = 92 维**

### 4.5 关键观测项的物理数学

#### 4.5.1 velocity_commands：速度指令映射

```cpp
REGISTER_OBSERVATION(velocity_commands)
{
    std::vector<float> obs(3);
    auto & joystick = env->robot->data.joystick;
    const auto cfg = env->cfg["commands"]["base_velocity"]["ranges"];
    obs[0] = std::clamp(joystick->ly(), cfg["lin_vel_x"][0].as<float>(), cfg["lin_vel_x"][1].as<float>());
    obs[1] = std::clamp(-joystick->lx(), cfg["lin_vel_y"][0].as<float>(), cfg["lin_vel_y"][1].as<float>());
    obs[2] = std::clamp(-joystick->rx(), cfg["ang_vel_z"][0].as<float>(), cfg["ang_vel_z"][1].as<float>());
    return obs;
}
```

注意符号约定：
- 前向速度 `lin_vel_x`：摇杆左 Y 轴 `ly()`（正=前进）
- 横移速度 `lin_vel_y`：摇杆左 X 轴 `-lx()`（正=左移，取负是因为 DDS 摇杆 X 轴方向相反）
- 偏航角速度 `ang_vel_z`：摇杆右 X 轴 `-rx()`（同理取负）

限幅范围来自 YAML 配置：
```yaml
commands:
  base_velocity:
    ranges:
      lin_vel_x: [-0.5, 1.0]   # 后退0.5 ~ 前进1.0 m/s
      lin_vel_y: [-0.5, 0.5]    # 左右0.5 m/s
      ang_vel_z: [-0.5, 0.5]    # 偏航0.5 rad/s
```

#### 4.5.2 gait_phase：步态相位编码

```cpp
REGISTER_OBSERVATION(gait_phase)
{
    float period = params["period"].as<float>();  // 0.6s
    float delta_phase = env->step_dt * (1.0f / period);
    env->global_phase += delta_phase;
    env->global_phase = std::fmod(env->global_phase, 1.0f);

    auto cmd = isaaclab::mdp::velocity_commands(env, params);
    float cmd_norm = std::sqrt(cmd[0]*cmd[0] + cmd[1]*cmd[1] + cmd[2]*cmd[2]);

    std::vector<float> obs(2);
    obs[0] = std::sin(env->global_phase * 2 * M_PI);
    obs[1] = std::cos(env->global_phase * 2 * M_PI);

    if (cmd_norm < 0.1f) { obs[0] = 0.0f; obs[1] = 0.0f; }
    return obs;
}
```

步态相位使用 sin/cos 编码而非线性相位，有两个好处：
1. **周期连续性**：相位从 $2\pi$ 回到 0 时，sin/cos 值自然连续，不会产生跳变
2. **静止归零**：当速度指令为零（`cmd_norm < 0.1`）时，相位归零，策略网络学会在静止时保持站立

---

## 第五章：动作管理器（ActionManager）

### 5.1 动作处理流水线

动作管理器将神经网络输出的原始动作转换为物理关节目标：

```mermaid
graph LR
    A["ONNX 输出<br/>raw_action (27维)"] --> B["scale 缩放<br/>a_i * scale_i"]
    B --> C["offset 偏移<br/>+ offset_i"]
    C --> D["clip 限幅<br/>clamp(min, max)"]
    D --> E["processed_action<br/>q_des (27维)"]
```

对应代码：

```cpp
void process_actions(std::vector<float> actions) {
    _raw_actions = actions;
    for(int i(0); i<_action_dim; ++i) {
        if(!_scale.empty()) _processed_actions[i] = _raw_actions[i] * _scale[i];
        else _processed_actions[i] = _raw_actions[i];
        if(!_offset.empty()) _processed_actions[i] += _offset[i];
    }
    if(!_clip.empty()) {
        for(int i(0); i<_action_dim; ++i)
            _processed_actions[i] = std::clamp(_processed_actions[i], _clip[i][0], _clip[i][1]);
    }
}
```

### 5.2 H1-2 动作配置解析

```yaml
actions:
  JointPositionAction:
    clip: null
    joint_names: [.*]
    scale: [0.51, 0.51, 0.51, 0.48, 0.51, 0.51, 0.51, 0.51, 0.51, 0.48, 0.51, 0.51, 0.51,
            0.51, 0.51, 0.57, 0.57, 0.57, 0.57, 0.57, 0.51, 0.51, 0.57, 0.57, 0.57, 0.57, 0.57]
    offset: [0,-0.2,0,0.5,-0.3,0, 0,-0.2,0,0.5,-0.3,0,  0,  0.28,0,0,0.52,0,0,0, 0.28,0,0,0.52,0,0,0]
```

**物理含义**：
- **`scale`**：动作增量缩放因子，约 0.5，意味着网络输出 ±1 对应约 ±0.5 rad 的关节角度变化
- **`offset`**：默认站立姿态关节角度，即 `default_joint_pos`
- **`clip: null`**：不进行额外限幅（ONNX 输出本身已在 ±1 范围内，经 scale 后约 ±0.5 rad）

最终物理关节目标角度为：

$$q_{des, i} = a_i \cdot \text{scale}_i + \text{offset}_i$$

这与旧版 CppSDK 中的 `act(i) * action_scale + default_angles[i]` 完全等价。

### 5.3 关节 ID 映射

`joint_ids_map` 定义了从策略空间到 DDS 空间的关节索引映射：

```yaml
joint_ids_map: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]
```

H1-2 共 27 个关节（12 腿部 + 1 腰部 + 14 手臂），此映射为恒等映射，表示策略输出的 27 维动作与 DDS 通道一一对应。

---

## 第六章：ONNX Runtime 推理引擎

### 6.1 OrtRunner 架构

`OrtRunner` 封装了 ONNX Runtime C++ API，提供统一的推理接口：

```cpp
class OrtRunner : public Algorithms {
public:
    OrtRunner(std::string model_path) {
        env = Ort::Env(ORT_LOGGING_LEVEL_WARNING, "onnx_model");
        session_options.SetGraphOptimizationLevel(ORT_ENABLE_EXTENDED);
        session = std::make_unique<Ort::Session>(env, model_path.c_str(), session_options);

        // 解析输入形状
        for (size_t i = 0; i < session->GetInputCount(); ++i) {
            input_shapes.push_back(input_type.GetTensorTypeAndShapeInfo().GetShape());
            input_names.push_back(session->GetInputNameAllocated(i, allocator).release());
        }
        // 解析输出形状
        output_shape = session->GetOutputTypeInfo(0).GetTensorTypeAndShapeInfo().GetShape();
    }

    std::vector<float> act(std::unordered_map<std::string, std::vector<float>> obs) {
        // 创建输入张量
        for(int i(0); i<input_names.size(); ++i) {
            auto& input_data = obs.at(input_names[i]);
            auto input_tensor = Ort::Value::CreateTensor<float>(
                memory_info, input_data.data(), input_sizes[i],
                input_shapes[i].data(), input_shapes[i].size());
            input_tensors.push_back(std::move(input_tensor));
        }
        // 执行推理
        auto output_tensor = session->Run(Ort::RunOptions{nullptr}, ...);
        // 拷贝输出
        std::memcpy(action.data(), floatarr, output_shape[1] * sizeof(float));
        return action;
    }
};
```

### 6.2 多输入支持

与旧版 LibTorch 的单输入张量不同，ONNX 模型支持**多个命名输入**。`ObservationManager::compute()` 返回的是 `std::unordered_map<std::string, std::vector<float>>`，其中键名与 ONNX 模型的输入端口名一一对应。

这意味着：
- 如果 ONNX 模型有单个输入 `obs`（形状 `[1, 92]`），则 `obs_map` 中有一个键 `"obs"`，值为 92 维向量
- 如果 ONNX 模型有多个输入（如 `base_ang_vel`、`projected_gravity` 等），则 `obs_map` 中有多个键，每个键对应一个分组观测向量

`OrtRunner` 在推理前会检查所有输入名是否存在于 `obs` 映射中：

```cpp
for (const auto& name : input_names) {
    if (obs.find(name) == obs.end()) {
        throw std::runtime_error("Input name " + std::string(name) + " not found in observations.");
    }
}
```

### 6.3 与旧版 LibTorch 对比

| 特性 | 旧版 LibTorch | 新版 ONNX Runtime |
|------|-------------|-------------------|
| 模型格式 | `motion.pt` (JIT) | `policy.onnx` |
| 输入方式 | 单张量 `torch::Tensor` | 多命名张量 |
| 依赖大小 | ~200MB (LibTorch CPU) | ~30MB (ONNX Runtime) |
| 推理延迟 | ~3-5ms | ~1-2ms |
| 跨平台 | 需匹配 CUDA/CPU 版本 | 统一 C API |
| 模型导出 | `torch.jit.script` | `torch.onnx.export` |

---

## 第七章：手柄 DSL（Domain Specific Language）

### 7.1 设计动机

旧版 CppSDK 中，手柄按键判断是硬编码在 C++ 源码中的：

```cpp
// 旧版：硬编码
if (joy.btn.components.start) { ... }
if (joy.btn.components.A) { ... }
```

新版 SDK 引入了手柄 DSL，允许在 YAML 配置中用字符串表达式定义按键组合条件：

```yaml
FixStand:
    transitions:
      Passive: LT + B.on_pressed
      Velocity: RT + A.on_pressed
```

这种设计使得**状态转换逻辑完全可配置**，无需修改 C++ 代码即可调整按键映射。

### 7.2 DSL 语法规范

DSL 支持以下语法元素：

| 语法 | 含义 | 示例 |
|------|------|------|
| `KEY` | 按键按下 | `A`, `LT`, `up` |
| `KEY.on_pressed` | 按键刚按下（单帧触发） | `A.on_pressed` |
| `KEY.on_released` | 按键刚松开（单帧触发） | `B.on_released` |
| `KEY(Ns)` | 按键长按超过 N 秒 | `LT(2s)` |
| `+` | 逻辑与 | `LT + A` |
| `\|` | 逻辑或 | `A \| B` |
| `!` | 逻辑非 | `!A` |
| `()` | 分组 | `(LT + A) \| (RT + B)` |

### 7.3 DSL 编译流程

DSL 的执行分为三个阶段：

1. **词法分析（Lexer）**：将字符串拆分为 Token 流
2. **语法分析（Parser）**：递归下降解析，构建 AST
3. **编译（Compile）**：将 AST 编译为 `std::function<bool(const UnitreeJoystick&)>` 可执行谓词

```cpp
// 使用示例
unitree::common::dsl::Parser p("LT + up.on_pressed");
auto ast = p.Parse();
auto func = unitree::common::dsl::Compile(*ast);
bool result = func(joystick);  // 运行时求值
```

AST 节点类型：
- `kAtom`：原子按键条件（如 `A.on_pressed`）
- `kNot`：逻辑非
- `kAnd`：逻辑与（`+` 运算符）
- `kOr`：逻辑或（`|` 运算符）

---

## 第八章：参数加载与命令行解析

### 8.1 param 模块

`param.h` 提供了全局参数加载与命令行解析功能：

```cpp
namespace param {
    inline std::filesystem::path bin_path;     // 可执行文件路径
    inline std::filesystem::path proj_dir;     // 项目根目录
    inline std::filesystem::path config_dir;   // 配置文件目录
    inline YAML::Node config;                  // 全局配置
}
```

**配置文件定位逻辑**：
1. 通过 `/proc/self/exe` 获取可执行文件路径
2. 如果可执行文件在 `bin/` 或 `build/` 目录下，则项目根目录为上一级
3. 否则，项目根目录为可执行文件所在目录
4. 配置文件为 `config_dir / "config.yaml"`

### 8.2 策略目录定位

`parser_policy_dir()` 实现了智能的策略目录查找：

```cpp
inline std::filesystem::path parser_policy_dir(std::filesystem::path policy_dir) {
    if (policy_dir.is_relative()) policy_dir = param::proj_dir / policy_dir;
    // 如果没有 exported/ 目录，则查找所有子目录，取最后一个有 exported/ 的
    if (!std::filesystem::exists(policy_dir / "exported")) {
        auto dirs = std::filesystem::directory_iterator(policy_dir);
        std::vector<std::filesystem::path> dir_list;
        for (const auto& entry : dirs) {
            if (entry.is_directory()) dir_list.push_back(entry.path());
        }
        std::sort(dir_list.begin(), dir_list.end());
        for (auto it = dir_list.rbegin(); it != dir_list.rend(); ++it) {
            if (std::filesystem::exists(*it / "exported")) {
                policy_dir = *it;
                break;
            }
        }
    }
    return policy_dir;
}
```

这意味着 YAML 中配置 `policy_dir: config/policy/velocity` 时，会自动查找 `config/policy/velocity/v0/exported/` 目录下的 ONNX 模型。

### 8.3 命令行参数

```cpp
po::options_description desc("Unitree Controller");
desc.add_options()
    ("help,h", "produce help message")
    ("version,v", "show version")
    ("log", "record log file")
    ("network,n", po::value<std::string>()->default_value(""), "dds network interface")
    ("timed", po::value<std::string>(), "timed state schedule: State1:seconds,State2:seconds,...")
;
```

- `--network`：指定 DDS 通信网卡（如 `eth0`）
- `--log`：启用日志文件记录（写入 `log/log.txt`，5MB 轮转，最多 5 个文件）
- `--timed`：定时状态调度，指定一个由逗号分隔的状态时间序列。格式为 `"状态名:秒数,状态名:秒数,..."`，例如 `--timed "FixStand:3,Velocity:10"`。FSM 将按顺序在指定时间后自动切换状态，**无需手柄干预**。配合模糊名称匹配，可驱动不同后缀的运动变体（如 `--timed "Mimic_Walk:30,Mimic_Wave:10"`）。详见第 2.5 节。

---

## 第九章：H1-2 机型适配分析

### 9.1 H1-2 的物理特性

H1-2 是宇树的全尺寸人形机器人，共 27 个自由度：
- **腿部**（12 DOF）：左右各 6 个关节（髋3 + 膝1 + 踝2）
- **腰部**（1 DOF）：躯干偏航旋转
- **手臂**（14 DOF）：左右各 7 个关节（肩3 + 肘2 + 腕2）

### 9.2 Types.h 类型别名

```cpp
#include "unitree/dds_wrapper/robots/go2/go2.h"
#include "unitree/dds_wrapper/robots/g1/g1.h"

using LowCmd_t = unitree::robot::g1::publisher::LowCmd;
using LowState_t = unitree::robot::g1::subscription::LowState;
```

H1-2 复用了 G1 的 DDS 消息类型，因为两者共享相同的底层通信协议。`mode_machine` 值为 6（G1 29DOF 为 5），用于标识机器人型号。

### 9.3 config.yaml 配置

```yaml
FSM:
  _:
    Passive:  {id: 1}
    FixStand: {id: 2}
    Velocity: {id: 3, type: RLBase}
  Passive:
    mode: [1,1,1,1,1,1, 1,1,1,1,1,1, 1, 1,1,1,1,1,1,1, 1,1,1,1,1,1,1]
    kd: [5,5,5,5,2,2, 5,5,5,5,2,2, 6, 2,2,2,2,2,2,2, 2,2,2,2,2,2,2]
  FixStand:
    kp: [250,250,250,400,80,40, 250,250,250,400,80,40, 600, 250,400,80,80,20,20,20, 250,400,80,80,20,20,20]
    kd: [6.5,6.5,6.5,10,1.5,0.4, 6.5,6.5,6.5,10,1.5,0.4, 6, 6,10,2,2,0.5,0.5,0.5, 6,10,2,2,0.5,0.5,0.5]
    ts: [0, 3]
    qs: [[], [0,-0.3,0,0.5,-0.2,0, 0,-0.3,0,0.5,-0.2,0, 0, 0.28,0,0,0.52,0,0,0, 0.28,0,0,0.52,0,0,0]]
  Velocity:
    policy_dir: config/policy/velocity
```

**PD 增益分析**：
- **腿部髋关节**：Kp=250, Kd=6.5（高刚度，确保支撑稳定）
- **腿部膝关节**：Kp=400, Kd=10（最高刚度，承重关节）
- **腿部踝关节**：Kp=80/40, Kd=1.5/0.4（较低刚度，允许柔顺触地）
- **腰部**：Kp=600, Kd=6（最高刚度，防止躯干晃动）
- **手臂**：Kp=250/80/20, Kd=6/2/0.5（递减刚度，肩>肘>腕）

### 9.4 当前缺失与待完善项

1. **ONNX 模型文件缺失**：`config/policy/velocity/v0/` 目录下没有 `exported/policy.onnx`
2. **Mimic 状态未实现**：`config/policy/mimic/` 下有 CSV 数据但没有对应的 `State_Mimic` 实现和 ONNX 模型
3. **CMakeLists.txt 可能需要调整**：确保 ONNX Runtime 路径正确

---

## 第十章：与旧版 CppSDK 的架构对比总结

### 10.1 核心差异对比表

| 维度 | 旧版 CppSDK | 新版 deploy SDK |
|------|------------|----------------|
| 推理后端 | LibTorch (JIT) | ONNX Runtime |
| 观测组装 | 手写 Eigen 代码 | YAML 声明 + ObservationManager |
| 动作映射 | 手写 scale+offset | YAML 声明 + ActionManager |
| 状态机 | if-else 硬编码 | CtrlFSM + 工厂注册 |
| 状态转换 | 手柄按键硬编码 | DSL 表达式 + YAML 配置 |
| 线程同步 | 自旋锁 AFLock | std::mutex (DDS wrapper 内建) |
| 双速率 | 3线程 (500Hz/50Hz/500Hz) | 2线程 (1kHz FSM / 50Hz 策略) |
| 关节映射 | 硬编码索引 | joint_ids_map 配置 |
| 新增机型 | 大量修改 C++ 代码 | 仅需新增 robot 子目录 + YAML |
| 新增观测 | 修改 Controller::run() | 新增 REGISTER_OBSERVATION 函数 |
| 新增动作 | 修改 Controller::run() | 新增 REGISTER_ACTION 类 |

### 10.2 架构优势

1. **配置驱动**：观测向量、动作映射、状态转换全部通过 YAML 配置，C++ 代码零修改
2. **可扩展性**：工厂注册宏使得新增状态/观测/动作只需在头文件中添加，无需修改框架代码
3. **多输入支持**：ONNX 的命名输入机制天然支持多组观测，便于模型结构优化
4. **轻量部署**：ONNX Runtime 比 LibTorch 小一个数量级，更适合嵌入式部署
5. **DSL 表达力**：手柄 DSL 支持复杂的按键组合逻辑，且完全可配置

### 10.3 架构局限

1. **无自旋锁**：使用 `std::mutex` 而非自旋锁，在高频 DDS 通信场景下可能引入微秒级延迟
2. **FSM 频率固定 1kHz**：无法像旧版一样独立控制 DDS 发送频率（500Hz）
3. **bad_orientation 被禁用**：`terminations.h` 中跌倒检测始终返回 `false`，实机部署需重新启用
4. **缺少 CRC 校验**：旧版 SDK 在 DDS 发送线程中计算 CRC32 校验和，新版依赖 DDS wrapper 内建机制

---

## 第十一章：系统时序流程

### 11.1 完整运行时序

```mermaid
sequenceDiagram
    autonumber
    actor User as 开发人员
    participant Main as main()
    participant FSM as CtrlFSM (1kHz)
    participant Passive as State_Passive
    participant FixStand as State_FixStand
    participant RLBase as State_RLBase
    participant PolicyThread as 策略线程 (50Hz)
    participant Robot as 机器人 (DDS)

    Note over User, Robot: 【第一阶段：系统初始化】
    User->>Main: ./h1_2_ctrl --network eth0
    Main->>Main: param::helper() 加载 config.yaml
    Main->>Main: ChannelFactory::Init(0, "eth0")
    Main->>Main: init_fsm_state() 初始化 DDS 通信
    Main->>Main: lowcmd->msg_.mode_machine() = 6 (H1-2)
    Main->>FSM: CtrlFSM(config["FSM"])
    FSM->>Passive: 实例化并注册 State_Passive
    FSM->>FixStand: 实例化并注册 State_FixStand
    FSM->>RLBase: 实例化并注册 State_RLBase
    FSM->>Passive: start() → enter()

    Note over User, Robot: 【第二阶段：被动阻尼 (Passive)】
    loop 每隔 1ms (1kHz)
        FSM->>Passive: pre_run() → lowstate->update()
        FSM->>Passive: run() → q_cmd = q_current (零力矩跟随)
        FSM->>Passive: post_run() → lowcmd->unlockAndPublish()
        Passive->>Robot: 发送阻尼指令
    end
    User->>Robot: 按下 LT + Up

    Note over User, Robot: 【第三阶段：插值站立 (FixStand)】
    FSM->>FixStand: enter() → 设置高刚度 PD + 记录初始位置
    loop 3秒内 (1kHz)
        FSM->>FixStand: pre_run() → 读取状态
        FSM->>FixStand: run() → linear_interpolate(t, ts, qs)
        FSM->>FixStand: post_run() → 发送插值位置
        FixStand->>Robot: 平滑过渡到站立姿态
    end
    User->>Robot: 按下 RT + A

    Note over User, Robot: 【第四阶段：策略控制 (Velocity)】
    FSM->>RLBase: enter() → 设置策略 PD + 启动策略线程
    loop 每隔 20ms (50Hz)
        PolicyThread->>PolicyThread: robot->update() 读取传感器
        PolicyThread->>PolicyThread: observation_manager->compute() 计算观测
        PolicyThread->>PolicyThread: ort_runner->act(obs) ONNX 推理
        PolicyThread->>PolicyThread: action_manager->process_action() 动作映射
    end
    loop 每隔 1ms (1kHz)
        FSM->>RLBase: pre_run() → 读取状态
        FSM->>RLBase: run() → 写入 processed_actions 到 lowcmd
        FSM->>RLBase: post_run() → 发送指令
        RLBase->>Robot: 下发关节目标
    end

    Note over User, Robot: 【第五阶段：安全退出】
    User->>Robot: 按下 LT + B
    FSM->>Passive: enter() → 恢复阻尼模式
```

---

## 第十二章：CMake 构建系统

### 12.1 h1_2 的 CMakeLists.txt

```cmake
cmake_minimum_required(VERSION 3.12)
project(h1_2_controller)

find_package(Boost REQUIRED COMPONENTS program_options)
find_package(yaml-cpp REQUIRED)

if(CMAKE_SYSTEM_PROCESSOR STREQUAL "x86_64")
    set(ONNXRUNTIME_DIR "${PROJECT_SOURCE_DIR}/../../thirdparty/onnxruntime-linux-x64-1.22.0")
elseif(CMAKE_SYSTEM_PROCESSOR STREQUAL "aarch64")
    set(ONNXRUNTIME_DIR "${PROJECT_SOURCE_DIR}/../../thirdparty/onnxruntime-linux-aarch64-1.22.0")
endif()
```

**关键设计**：
- **架构自适应**：根据 `CMAKE_SYSTEM_PROCESSOR` 自动选择 x64 或 aarch64 版本的 ONNX Runtime
- **第三方库内嵌**：ONNX Runtime 预编译库放在 `thirdparty/` 目录下，无需系统级安装
- **静态链接**：`libboost_program_options.a` 和 `libyaml-cpp.a` 使用静态链接，减少运行时依赖

### 12.2 依赖关系

```
h1_2_ctrl
├── unitree_sdk2          # 宇树 DDS 通信 SDK
├── ddsc / ddscxx         # CycloneDDS C/C++ 库
├── libonnxruntime.so     # ONNX Runtime 推理引擎
├── libyaml-cpp.a         # YAML 配置解析
├── libboost_program_options.a  # 命令行参数解析
├── fmt                   # 日志格式化
├── rt                    # POSIX 实时扩展
└── pthread               # 多线程
```

---

## 总结

`unitree_rl_mjlab/deploy` 框架代表了宇树 RL 策略部署从"手写硬编码"到"配置驱动声明式"的架构演进。其核心创新在于：

1. **YAML 驱动的观测/动作配置**：将策略的输入输出定义从 C++ 代码中解耦，使得同一套 C++ 框架可以适配不同维度、不同物理含义的策略模型
2. **工厂注册宏**：通过 C++ 静态初始化机制实现零侵入的状态/观测/动作扩展
3. **手柄 DSL**：将状态转换条件从硬编码提升为可配置的表达式语言
4. **ONNX Runtime**：以更轻量的推理引擎替代 LibTorch，降低部署体积和延迟
5. **IsaacLab 风格架构**：ObservationManager + ActionManager 的设计使得框架与训练侧的 IsaacLab 环境保持概念一致性，降低 Sim2Real 的认知负担

理解本框架的架构设计，是后续针对 H1-2 机型进行实机适配、功能扩展与调试优化的理论基础。
