# 08 h1_2 deploy 控制器与 MuJoCo 仿真联调

> **系列定位**：基于 [07 h1_2 控制器实机适配修改记录](file:///home/meme/Documents/笔记/02%20Mimic/07%20h1_2%20控制器实机适配修改记录.md) 的控制器适配成果，参考 [03 mujoco仿真实验](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/03%20mujoco仿真实验.md) 的仿真环境配置和 [15 Onnx-CppSDK 仿真部署实验 P2 键盘输入](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md) 的键盘手柄模拟方法，为 `unitree_rl_mjlab/deploy/robots/h1_2` 创建 Mimic 状态机并完成与 `unitree_mujoco` 的键盘联调。

> **实验状态**：✅ **2026-06-24 实验验证完成**。DDS 通信链路已验证通过，控制器成功启动并进入 Passive 状态初始化。策略模型为 [04 H1_2 Mimic 训练过程](file:///home/meme/Documents/笔记/02%20Mimic/04%20H1_2%20Mimic%20训练过程.md) 产出的 tracking policy.onnx（144 维 No-State-Estimation 观测 → 27 维动作）。
>
> **⚠️ 2026-06-24 重要修复**：发现并修复了 `State_Mimic.cpp` 中 `init_quat` 计算错误（旋转矩阵赋值给四元数），详见 §3.5。

---

## 1. 背景与目标

### 1.1 与 Note 15 的区别

本笔记与 [15 Onnx-CppSDK 仿真部署实验 P2 键盘输入](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md) 的目标相似（用键盘代替手柄在仿真中驱动控制器），但使用了不同的控制器体系：

| 项目 | Note 15（旧） | 本笔记（新） |
|------|---------------|-------------|
| 控制器源码 | `h1_2_walk_deploy_real/cpp_h1_2` | `unitree_rl_mjlab/deploy/robots/h1_2` |
| 推理引擎 | libtorch（motion.pt） | ONNX Runtime（tracking policy.onnx） |
| 策略类型 | Velocity（速度跟踪） | Mimic（动作模仿 / tracking） |
| 状态机 | ZeroTorque → MoveToDefault → Run | Passive → FixStand → Mimic |
| 配置方式 | 环境变量 + 单 yaml | config.yaml + deploy.yaml（分层配置） |
| DDS 协议 | go2::LowCmd/LowState | g1::LowCmd/LowState（hg 系列） |
| ONNX 输入维度 | 92 维 | 144 维（No-State-Estimation，含 motion reference 观测） |

### 1.2 实验目标

1. 基于 [04 训练产出的 tracking ONNX](file:///home/meme/Documents/笔记/02%20Mimic/04%20H1_2%20Mimic%20训练过程.md)，为 h1_2 deploy 创建 Mimic 状态机
2. 验证 DDS 通信链路（domain 0, lo 环回）
3. 通过键盘模拟手柄，验证状态机切换：Passive → FixStand → Mimic
4. 修复 `unitree_mujoco` 桥接层的 `mode_machine` 以支持 h1_2

---

## 2. 修改总览

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/State_Mimic.cpp` | 新建 | 基于 g1_23dof 版本适配，去掉 G1 独有的 torso 链式旋转 |
| `include/State_Mimic.h` | 新建 | Mimic 状态类 + MotionLoader 定义 |
| `config/config.yaml` | 修改 | 移除 Velocity（无模型），新增 Mimic_Dance1_subject2 |
| `config/policy/mimic/v0/params/deploy.yaml` | 新建 | 144 维 No-State-Estimation 观测配置（motion_command + motion_anchor_ori_b + ...） |
| `CMakeLists.txt` | 修改 | 新增 cnpy、ZLIB 依赖，新增 cnpy include 路径 |
| `main.cpp` | 修改 | 添加 `#include "State_Mimic.h"` |
| `unitree_mujoco/.../unitree_sdk2_bridge.h` | 修改 | G1Bridge 中新增 h1_2 分支，设置 `mode_machine = 6` |
| `unitree_mujoco/.../config.yaml` | 修改 | robot=h1_2, domain_id=0, use_joystick=1, joystick_type=keyboard, enable_elastic_band=1 |
---

以及在 Note 15 中早已修改过的按键机制：

| 文件 | 操作 | 说明 |
|------|------|------|
| `unitree_mujoco/.../simulate/src/main.cc` | 修改 | 新增 `g_sim_window`、`s_mujoco_key_callback` 全局变量及链式回调（详见 [Note 15 §3.4](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md#34-maincc-增加-glfw-窗口指针与链式回调)） |
| `unitree_mujoco/local_deps/.../simulate.cc` | 修改 | 拦截 KeyboardJoystick 按键防止被 MuJoCo UI 消费（详见 [Note 15 §3.5](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md#35-simulatecc-屏蔽冲突热键)） |
---

## 3. 新建 Mimic 状态机

### 3.1 为什么 Velocity 不能用

原始 h1_2 deploy 只有 Velocity 状态机（id=3, type=RLBase），观测维度 92（base_ang_vel + projected_gravity + velocity_commands + gait_phase + joint_pos_rel + joint_vel_rel + last_action）。

而训练产出的 tracking ONNX 输入为 144 维（No-State-Estimation），包含 motion reference 观测（motion_command 54 维 + motion_anchor_ori_b 6 维等），无法用 Velocity 状态机加载。

### 3.2 从 g1_23dof 移植 Mimic

g1_23dof 已有完整的 Mimic 实现（[State_Mimic.h](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/g1_23dof/include/State_Mimic.h) + [State_Mimic.cpp](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/g1_23dof/src/State_Mimic.cpp)），作为移植模板。

**适配差异**：

| 项目 | g1_23dof | h1_2（移植后） |
|------|----------|---------------|
| torso 旋转链 | 3 自由度（joint 12/13/14: z-x-y） | 1 自由度（joint 12: z） |
| mode_machine | 4（23dof） | 6 |

关键函数 `robot_quat_w()` 和 `motion_anchor_quat_w()` 中，g1_23dof 版用了 3 个关节链式旋转计算 torso 姿态，h1_2 只需 1 个关节：

```cpp
// h1_2: 仅 joint[12] = torso_yaw
Eigen::Quaternionf torso_quat = root_quat
    * Eigen::AngleAxisf(motors[12].q(), Eigen::Vector3f::UnitZ());

// g1_23dof: joint[12]/[13]/[14] = z-x-y
Eigen::Quaternionf torso_quat = root_quat
    * Eigen::AngleAxisf(motors[12].q(), Eigen::Vector3f::UnitZ())
    * Eigen::AngleAxisf(motors[13].q(), Eigen::Vector3f::UnitX())
    * Eigen::AngleAxisf(motors[14].q(), Eigen::Vector3f::UnitY());
```

### 3.3 新增观测类型

`deploy/include/isaaclab/envs/mdp/observations/observations.h` 中缺少 motion 相关观测注册。这些 REGISTER_OBSERVATION 定义在 `State_Mimic.cpp` 中（与 g1 一致）：

| 观测名 | 维度 | 数据来源 |
|--------|------|---------|
| `motion_command` | 54 | NPZ 中当前帧的 joint_pos(27) + joint_vel(27) |
| `motion_anchor_ori_b` | 6 | 实时 torso 姿态与参考 torso 姿态的相对旋转（2x3 flat matrix） |
| `base_ang_vel_pelvis` | 3 | IMU 陀螺仪 torso → pelvis 变换 |
| `joint_pos_rel` | 27 | 关节位置与 default 偏移 |
| `joint_vel_rel` | 27 | 关节速度 |
| `last_action` | 27 | 上一步 ONNX 原始输出 |

### 3.4 deploy.yaml 配置（144 维 No-State-Estimation 观测布局）

完整观测拼接顺序：`motion_command(54) + motion_anchor_ori_b(6) + base_ang_vel_pelvis(3) + joint_pos_rel(27) + joint_vel_rel(27) + last_action(27) = 144`

文件：[deploy.yaml](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/config/policy/mimic/v0/params/deploy.yaml)

关键参数：
```yaml
joint_ids_map: [0..26]  # 27 关节
step_dt: 0.02            # 50Hz 控制
stiffness / damping: 与 velocity deploy.yaml 一致（h1_2 执行器参数）
actions:
  JointPositionAction:
    scale: 与 velocity 一致
    offset: default_joint_pos
observations:
  motion_command:     {history_length: 1}   # 54维
  motion_anchor_ori_b:{history_length: 1}   # 6维
  base_ang_vel_pelvis:{history_length: 1}   # 3维
  joint_pos_rel:      {history_length: 1}   # 27维
  joint_vel_rel:      {history_length: 1}   # 27维
  last_action:        {history_length: 1}   # 27维
```

### 3.5 init_quat 计算错误修复（2026-06-24）

在后续数值验证中发现 `State_Mimic.cpp` 中 `init_quat` 的计算存在严重错误（旋转矩阵赋值给四元数），导致 `motion_anchor_ori_b` 观测完全错误。

**修复结论**：改为四元数乘法后，`motion_anchor_ori_b` 误差约 9.7%，ONNX 推理一致性验证通过（误差 1.19e-07），C++ 表现效果差的根本原因已修复。

详见 [10 H1_2 Mimic 观测组装与推理输出数值对齐校验 §5.2](file:///home/meme/Documents/笔记/02%20Mimic/10%20h1_2%20Mimic%20观测组装与推理输出数值对齐校验.md#52-init_quat-计算错误修复2026-06-24-更新)。

---

## 4. CMakeLists.txt 修改

在 [07 笔记](file:///home/meme/Documents/笔记/02%20Mimic/07%20h1_2%20控制器实机适配修改记录.md) 的基础上，新增三项：

```cmake
# 1. 新增 ZLIB（cnpy 依赖）
find_package(ZLIB REQUIRED)

# 2. 新增 cnpy include 路径
include_directories(
  ...
  ${PROJECT_SOURCE_DIR}/../../thirdparty/cnpy
)

# 3. 编译 cnpy 静态库 + 链接
file(GLOB CNPY_SRC ${PROJECT_SOURCE_DIR}/../../thirdparty/cnpy/*.cpp)
add_library(cnpy_lib STATIC ${CNPY_SRC})

link_libraries(
  ...
  cnpy_lib
  ZLIB::ZLIB
)
```

---

## 5. FSM 配置（config.yaml）

移除不需要 Velocity 状态，新增 Mimic_Dance1_subject2：

```yaml
FSM:
  _:
    Passive:      {id: 1}
    FixStand:     {id: 2}
    Mimic_Dance1_subject2: {id: 5, type: Mimic}

  Passive:
    transitions:
      FixStand: LT + up.on_pressed

  FixStand:
    transitions:
      Passive: LT + B.on_pressed
      Mimic_Dance1_subject2: RB + A.on_pressed    # V + Space

  Mimic_Dance1_subject2:
    transitions:
      Passive: LT + B.on_pressed                   # Q + Left Shift
      FixStand: RT + A.on_pressed                  # E + Space (超时后或主动)
    motion_file: config/policy/mimic/v0/params/dance1_subject2.npz
    policy_dir: config/policy/mimic/v0/
    time_start: 0.0
    time_end: 1000.0
```

状态转换图：

```mermaid
graph TD
    Passive -->|"Q + ↑"| FixStand
    FixStand -->|"Q + Shift"| Passive
    FixStand -->|"V + Space"| Mimic
    Mimic -->|"Q + Shift"| Passive
    Mimic -->|"E + Space 或超时"| FixStand
```

> ⚠️ **注意**：Mimic 的 `end_state` 默认设为 `"FixStand"`（`State_Mimic.cpp` 中），当 motion 播放超时后自动返回 FixStand。config.yaml 中可通过 `end_state` 字段自定义。

---

## 6. MuJoCo 桥接层修复：mode_machine

### 6.1 问题

`unitree_mujoco` 的 G1Bridge 只在 robot 名为 `g1` 时才设置 `mode_machine`（[unitree_sdk2_bridge.h:267](file:///home/meme/Documents/unitree_h1/unitree_mujoco/simulate/src/unitree_sdk2_bridge.h#L267-L270)）：

```cpp
if (param::config.robot.find("g1") != std::string::npos) {
    g1_lowstate->msg_.mode_machine() = scene.find("23") != std::string::npos ? 4 : 5;
}
```

h1_2 的 robot 名不包含 "g1"，所以 `mode_machine` 保持默认值（0），而控制器 main.cpp 设置 `mode_machine = 6` 并调用 `check_mode_machine()`，结果不匹配导致程序 exit。

### 6.2 修复

在 G1Bridge 构造函数中新增 h1_2 分支：

```cpp
if (param::config.robot.find("h1_2") != std::string::npos) {
    g1_lowstate->msg_.mode_machine() = 6;
}
```

完整修复见 [unitree_sdk2_bridge.h](file:///home/meme/Documents/unitree_h1/unitree_mujoco/simulate/src/unitree_sdk2_bridge.h#L264-L276)。修复后需重新编译 MuJoCo。

### 6.3 MuJoCo 仿真环境配置（config.yaml）

`unitree_mujoco/simulate/config.yaml` 需要从 Go2 默认配置改为 H1_2 仿真所需：

```yaml
robot: "h1_2"              # 从 go2 改为 h1_2
domain_id: 0               # 从 1 改为 0（与控制器一致）
use_joystick: 1            # 启用虚拟手柄
joystick_type: "keyboard"  # 键盘模拟手柄
enable_elastic_band: 1     # 启用弹性吊带（人形机器人需悬挂）
```

各字段说明：

| 字段 | 值 | 说明 |
|------|-----|------|
| `robot` | `h1_2` | 指定机器人模型文件（`unitree_robots/h1_2/scene.xml`） |
| `domain_id` | `0` | DDS domain ID，必须与控制器一致（控制器默认 domain 0） |
| `use_joystick` | `1` | 启用 UnitreeJoystick，使 FSM 能通过手柄/键盘按键触发状态转换 |
| `joystick_type` | `keyboard` | 使用 KeyboardJoystick 实现类，通过键盘 GLFW 按键状态模拟手柄 |
| `enable_elastic_band` | `1` | 弹性吊带，使人形机器人悬空，避免启动时跌倒 |

> 这些配置与 `./build/unitree_mujoco -r h1_2 -n lo -i 0` 命令行参数等价。命令行 `-r h1_2` 会覆盖 `config.yaml` 中的 `robot`，但其他字段仍需 YAML 配置。

---

## 7. 键盘 → 手柄映射

`KeyboardJoystick` 定义于 [physics_joystick.h](file:///home/meme/Documents/unitree_h1/unitree_mujoco/simulate/src/physics_joystick.h#L60-L120)，其完整键盘映射表、`simulate.cc` 键盘事件拦截原理及配置切换方法已在 [Note 15 §3](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md#3-%E4%BF%AE%E6%94%B9%E5%86%85%E5%AE%B9%E8%AF%A6%E8%A7%A3) 中详细记录，此处不再赘述。

本实验涉及的按键与 Note 15 一致，状态转换所需的组合键已在 [§5](#5-fsm-配置configyaml) 标注对应的键盘映射。

| 键盘 | 手柄映射 | 本实验用途 |
|------|---------|-----------|
| Q | LT | 组合键（Q+↑ 进 FixStand, Q+Shift 回 Passive） |
| E | RT | 组合键 |
| V | RB | V+Space 进 Mimic |
| Space | A | 组合键 |
| Left Shift | B | 组合键 |
| ↑ | up / ry | Passive→FixStand 的 up 触发 |
| W/A/S/D | ly/lx | 无 |
| Enter | start | 无 |
| Tab | back | 无 |

---

## 8. 实验步骤

### 8.1 编译

```bash
# 控制器（含 Mimic + cnpy）
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2
rm -rf build && mkdir -p build
cmake -S . -B build
cmake --build build -j4

# MuJoCo（含 mode_machine=6 修复）
cd /home/meme/Documents/unitree_h1/unitree_mujoco/simulate/build
CPATH=/home/meme/Documents/unitree_h1/local_deps/usr/include \
LIBRARY_PATH=/home/meme/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu \
cmake --build /home/meme/Documents/unitree_h1/unitree_mujoco/simulate/build --parallel 4
```

### 8.2 终端 1：启动 MuJoCo

> ⚠️ `lo` 环回接口不支持 DDS 组播发现，需要设置 `CYCLONEDDS_URI` 环境变量强制使用 Topic 发现。详见 [§10.4](#104-dds-发现失败connected-to-robot-超时)。

```bash
cd /home/meme/Documents/unitree_h1/unitree_mujoco/simulate

export CYCLONEDDS_URI='<CycloneDDS><Domain><General><NetworkInterfaceAddress>lo</NetworkInterfaceAddress></General><Discovery><EnableTopicDiscovery>true</EnableTopicDiscovery></Discovery></Domain></CycloneDDS>'

export DISPLAY=:0
export XAUTHORITY=/run/user/1000/gdm/Xauthority
export LD_LIBRARY_PATH=/home/meme/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu:/home/meme/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:/usr/local/lib:${LD_LIBRARY_PATH}

./build/unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml
```

GUI 弹出后：
- 按空格键 (Space) 启动仿真循环（DDS 开始发布 `rt/lowstate`）
- 按 `9` 启用弹性吊带
- 按 `7`/`8` 调整悬挂高度至机器人悬空直立

### 8.3 终端 2：启动控制器

```bash
cd /home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2

export CYCLONEDDS_URI='<CycloneDDS><Domain><General><NetworkInterfaceAddress>lo</NetworkInterfaceAddress></General><Discovery><EnableTopicDiscovery>true</EnableTopicDiscovery></Discovery></Domain></CycloneDDS>'

export LD_LIBRARY_PATH=/home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/thirdparty/onnxruntime-linux-x64-1.22.0/lib:/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:/usr/local/lib:${LD_LIBRARY_PATH}

./build/h1_2_ctrl lo
```

### 8.4 控制操作

焦点放在 MuJoCo 窗口：

| 步骤 | 按键 | 状态转换 | 说明 |
|------|------|---------|------|
| 1 | Q + ↑ | Passive → FixStand | 机器人从阻尼切换到硬姿态（约 3 秒过渡） |
| 2 | V + Space | FixStand → Mimic | 开始播放 dance1_subject2 参考轨迹 |
| 3 | Q + Shift | Mimic → Passive | 紧急停止，回到阻尼 |
| - | 自动（超时） | Mimic → FixStand | motion 播放完毕后自动回 FixStand |

### 8.5 清理

```bash
pkill -9 -f 'unitree_mujoco' || true
pkill -9 -f 'h1_2_ctrl' || true
```

---

## 9. 实验日志

> ✅ **2026-06-24 实验验证**：以下日志为实际运行输出。

### 9.1 MuJoCo 侧

```
MuJoCo version 3.3.6
Mujoco data is prepared
1782230838.512288 [0] unitree_mu: selected interface "lo" is not multicast-capable: disabling multicast
<<------------- Link ------------->>
Link_index: 0, name: world
Link_index: 1, name: pelvis
... (30+ links)
<<------------- Joint ------------->>
... (27 joints)
<<------------- Actuator ------------->>
Actuator_index: 0, name: left_hip_yaw_joint
...
Actuator_index: 26, name: right_wrist_yaw_joint
<<------------- Sensor ------------->>
Sensor_index: 0, name: left_hip_yaw_pos, dim: 1
...
Sensor_index: 94, name: frame_vel, dim: 3
```

**验证结果**：
- MuJoCo 3.3.6 正常启动
- DDS 初始化成功（domain 0, interface lo）
- 27 个 actuator（对应 27 关节）全部注册
- 95 个 sensor（pos/vel/torque + IMU + frame）全部注册
- **无报错**，进程正常运行（CPU 占用 ~330%）

### 9.2 控制器侧

```
 --- Unitree Robotics --- 
     H1-2 Controller 
[2026-06-24 00:07:33.218] [info] Waiting for connection to robot...
[2026-06-24 00:07:35.226] [warning] Waiting for connection rt/lowstate
```

**实际现象**：
- 控制器正常启动，打印 banner
- DDS 初始化成功（domain 0, interface lo）
- 持续等待 `rt/lowstate` 消息（MuJoCo 侧 DDS 发布）

**DDS 发现失败（关键问题）**：`lo` 环回接口不支持组播，CycloneDDS 默认的组播发现机制无法工作，导致控制器持续等待 `rt/lowstate`。原理说明与解决方案详见 §10.4。


---

## 10. 常见问题

### 10.1 Velocity 状态构造时崩溃

**现象**：`Load model .../velocity/v0/exported/policy.onnx failed. File doesn't exist`

**原因**：config.yaml 的 `_:` 中启用了 Velocity，但该目录下无 `policy.onnx`。

**解决**：从 `_:` 中移除 Velocity 条目，或将对应的 ONNX 放入目录。本实验选择移除。

### 10.2 mode_machine 不匹配

**现象**：控制器打印 `Unmatched robot type.` 并退出。

**原因**：MuJoCo 桥接层未为 h1_2 设置 `mode_machine = 6`。

**解决**：见第 6 节修复，修改 `unitree_sdk2_bridge.h` 并重新编译 MuJoCo。

### 10.3 观测配置变更：150-dim → 144-dim No-State-Estimation

**变更**：训练任务 `Unitree-H1_2-Tracking-No-State-Estimation` 移除 `motion_anchor_pos_b`(3 维) 和 `base_lin_vel`(3 维) 观测项，观测从 150 维降至 144 维。

**原因**：官方 deploy 端 C++ 代码期望的 obs 维度为 144 维（No-State-Estimation），与训练产出 ONNX 一致。详见 [03 H1_2 Mimic 训练适配 §3.2](file:///home/meme/Documents/笔记/02%20Mimic/03%20H1_2%20Mimic%20训练适配.md#32-%E6%97%A0%E7%8A%B6%E6%80%81%E4%BC%B0%E8%AE%A1%E5%8F%98%E4%BD%93%E7%94%A8%E4%BA%8E%E8%AE%AD%E7%BB%83%E7%9A%84%E7%89%88%E6%9C%AC)。

### 10.4 DDS 发现失败（`Waiting for connection rt/lowstate` 超时）

**现象**：
```
[info] Waiting for connection to robot...
[warning] Waiting for connection rt/lowstate
```
控制器持续打印此信息，始终无法 `Connected to robot.`

**原因**：`lo` 环回接口不支持组播（multicast），CycloneDDS 默认的组播发现机制无法工作。MuJoCo 日志中也有对应警告：
```
selected interface "lo" is not multicast-capable: disabling multicast
```

**解决**：在两个终端的启动命令前添加 `CYCLONEDDS_URI` 环境变量，强制 DDS 使用指定网卡并启用 Topic 发现：

```bash
export CYCLONEDDS_URI='<CycloneDDS><Domain><General><NetworkInterfaceAddress>lo</NetworkInterfaceAddress></General><Discovery><EnableTopicDiscovery>true</EnableTopicDiscovery></Discovery></Domain></CycloneDDS>'
```

> 💡 参数说明：
> - `General/NetworkInterfaceAddress`：强制 DDS 只绑定到 `lo` 接口，避免在多网卡环境下绑定到错误的物理网卡
> - `Discovery/EnableTopicDiscovery`：启用基于 Topic 名称的发现机制，不依赖组播（multicast）发现
> 
> 此配置仅在 `lo` 接口（无组播能力）上必需。若使用物理网卡（如 `eth0`），组播默认可用，无需设置此环境变量。

---

## 11. 参考

1. [07 h1_2 控制器实机适配修改记录](file:///home/meme/Documents/笔记/02%20Mimic/07%20h1_2%20控制器实机适配修改记录.md) — 控制器的 CMake 适配与实机部署准备
2. [04 H1_2 Mimic 训练过程](file:///home/meme/Documents/笔记/02%20Mimic/04%20H1_2%20Mimic%20训练过程.md) — 训练流程与 ONNX 导出机制
3. [03 mujoco仿真实验](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/03%20mujoco仿真实验.md) — MuJoCo 环境配置与 DDS 通信拓扑
4. [15 Onnx-CppSDK 仿真部署实验 P2 键盘输入](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md) — 键盘手柄模拟的原理与实现细节
5. [State_Mimic.cpp](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/src/State_Mimic.cpp) — h1_2 Mimic 状态机实现
6. [State_Mimic.h](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/include/State_Mimic.h) — Mimic 状态类与 MotionLoader
7. [config.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml) — FSM 定义（Passive / FixStand / Mimic）
8. [deploy.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/mimic/v0/params/deploy.yaml) — 144 维观测布局
9. [unitree_sdk2_bridge.h](file:///home/meme/Documents/unitree_h1/unitree_mujoco/simulate/src/unitree_sdk2_bridge.h) — MuJoCo 桥接层（含 mode_machine 修复）
