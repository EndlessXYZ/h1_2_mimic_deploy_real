# 09 h1_2 LocoVelocity 步态SDK集成

> **系列定位**：在 [08 h1_2 deploy 控制器与 MuJoCo 仿真联调](file:///home/meme/Documents/笔记/02%20Mimic/08%20h1_2%20deploy%20控制器与%20MuJoCo%20仿真联调.md) 完成 Mimic 状态机与仿真联调的基础上，将 `deploy` 代码库独立出 `h1_2_mimic_deploy_real` 分支，接入宇树高层步态 SDK（LocoClient），新增摇杆驱动行走的 `LocoVelocity` FSM 状态，面向**真机实机部署**。

> **实验状态**：✅ **2026-06-24 代码完成、编译通过**。真机上机测试待进行。

---

## 1. 背景与目标

### 1.1 与 Note 08 的架构差异

| 项目 | Note 08（Mimic/RL 部署） | 本笔记（LocoVelocity） |
|------|---------------------------|------------------------|
| 控制层级 | **低层**（Low-Level）：500Hz 下发关节位置 | **高层**（High-Level）：10~50Hz 下发语义指令 |
| 控制主体 | 用户侧 ONNX 策略推理 → `lowcmd` DDS 发布 | 机载 PC1 的 `loco_service`（WBC + MPC 闭环） |
| 通信方式 | DDS 话题发布（`rt/lowcmd`, `rt/lowstate`） | DDS + RPC 请求/应答（`rt/api/loco/request`） |
| 策略模型 | ONNX（150 维 → 27 维动作） | 无外部模型，使用固件内置步态算法 |
| 运行环境 | **MuJoCo 仿真**（可与真机互通 DDS） | **真机实机**（依赖机载 `loco_service`） |
| 摇杆数据来源 | `KeyboardJoystick` 键盘模拟（仿真桥接层） | DDS `rt/lowstate` 中的真实手柄数据 |

### 1.2 为什么需要 LocoVelocity

Note 08 的 Mimic 状态机是**轨迹回放**模式（播放预录的 dance1_subject2 动作），机器人没有自主移动能力。`LocoVelocity` 填补了这一空缺：

- 利用机载 `loco_service` 的高层 FSM 控制器（`Damp → StandUp → Start`）
- 通过摇杆实时控制机器人前后/左右/旋转行走
- 摇杆数据从 DDS `rt/lowstate` 中读取（真机场景下手柄通过遥控器/上位机 DDS 发布）
- 无需 ONNX 模型，无需 500Hz 实时线程——所有底层动力学由机载固件闭环

### 1.3 代码库分支

基于 [unitree_rl_mjlab/deploy](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy) 拷贝出独立副本：

```bash
cp -r unitree_h1/unitree_rl_mjlab/deploy unitree_h1/h1_2_mimic_deploy_real
```

此后在 [h1_2_mimic_deploy_real](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real) 上独立开发，不影响原 `unitree_rl_mjlab/deploy`。

---

## 2. 修改总览

| 文件 | 操作 | 说明 |
|------|------|------|
| [include/FSM/State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) | **新建** | LocoVelocity FSM 状态类，集成 `MotionSwitcherClient` + `LocoClient` 完成高层/低层控制权切换 |
| [robots/h1_2/main.cpp](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/main.cpp#L6) | 修改 | 新增 `#include "FSM/State_LocoVelocity.h"`，更新控制台提示 |
| [robots/h1_2/config/config.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml) | 修改 | 新增 `LocoVelocity` 状态定义（id=6），删除旧 Velocity。FixStand 新增 `RB + X` 跳转 |

> `CMakeLists.txt` **无需修改**：`MotionSwitcherClient` 和 `LocoClient` 头文件均在 `unitree_sdk2` 系统安装路径下（[motion_switcher_client.hpp](file:///usr/local/include/unitree/robot/b2/motion_switcher/motion_switcher_client.hpp)、[h1_loco_client.hpp](file:///usr/local/include/unitree/robot/h1/loco/h1_loco_client.hpp)），且 `unitree_sdk2` 库已在 `link_libraries` 中。

---

## 3. 核心架构：两个 FSM 的"双向"并存

理解本架构的关键点：[State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) 代码内**同时存在两个 FSM**——本地的 `CtrlFSM` 和远程的 `loco_service` FSM。

### 3.1 本地 CtrlFSM（deploy 框架层）

定义于 [CtrlFSM.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/CtrlFSM.h)，负责机器人安全状态管理，与 Mimic 状态共享：

```
Passive (id=1) → FixStand (id=2) → LocoVelocity (id=6)
                                      ↕ (摇杆控制期间)
                                   LocoVelocity → Passive (退出)
```

`CtrlFSM` 在 1kHz 线程中运行 `pre_run() → run() → post_run()`（参见 [CtrlFSM.h#L68](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/CtrlFSM.h#L68-L87)）。在 `LocoVelocity` 中，`post_run()` 被覆写为空（参见 [State_LocoVelocity.h#L185-L190](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L185-L190)）——因为关节控制由 `loco_service` 接管，不应再通过 `lowcmd` 下发。

### 3.2 远程 loco_service FSM（机载固件层）

定义于 [h1_loco_client.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_client.hpp#L210-L224)，在 `State_LocoVelocity::enter()` 中通过 RPC 逐级驱动：

```
ZeroTorque (id=0) → Damp (1) → StandUp (2) → Start (204) → [ContinuousGait + Velocity 指令]
```

```mermaid
graph TD
    subgraph "本地 CtrlFSM (deploy 框架 1kHz)"
        A[Passive] -->|"LT + up"| B[FixStand]
        B -->|"RB + X"| C[LocoVelocity]
        C -->|"LT + B"| A
    end

    subgraph "远程 loco_service FSM (机载 PC1)"
        D[ZeroTorque 0] --> E[Damp 1]
        E --> F[StandUp 2]
        F --> G[Start 204]
        G -->|"SetVelocity()"| G
        G -->|"StopMove"| E
    end

    C -.->|"enter(): RPC 调用"| E
```

### 3.3 高层/低层控制权切换：三种途径与安全红线

`State_LocoVelocity`（高层 RPC 控制）与 Passive/FixStand（底层 `lowcmd` 控制）可以相互切换，但在实际运行中，这种切换必须严格遵循安全状态机和物理过渡协议。如果处理不当，极易导致机器人失去平衡瘫倒或因"总线争夺"而损坏硬件。

基于宇树 `unitree_sdk2` 的架构设计，切换机制分为以下三种途径：

#### 途径一：代码级 MotionSwitcherClient 动态剥离与释放（本实现采用）

宇树 SDK 提供了专门的 `MotionSwitcherClient`（运动切换服务客户端，定义于 [motion_switcher_client.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/b2/motion_switcher/motion_switcher_client.hpp)），允许在代码运行时动态地开启或关闭官方高层运动服务。官方用法参考 [go2_stand_example.cpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/example/go2/go2_stand_example.cpp#L53-L68)。

**高层切底层（接管控制权）**：
在启动底层 RL 策略前，必须在代码中调用 `msc.ReleaseMode()`（参见 [motion_switcher_client.hpp#L26](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/b2/motion_switcher/motion_switcher_client.hpp#L26)）来主动终止 `sport_mode`。一旦高层服务被挂起，底层通信总线就被彻底释放，程序即可向 `rt/lowcmd` 发布高频底层指令。

**底层切高层（交还控制权）**：
当底层 RL 任务结束时，停止发送 `LowCmd` 指令。要恢复官方高层控制，需调用 `msc.SelectMode("normal")`（参见 [motion_switcher_client.hpp#L25](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/b2/motion_switcher/motion_switcher_client.hpp#L25)）重新激活 `sport_mode`，然后通过 `LocoClient` 下发 Damp → StandUp → Start 序列。

本实现在 `State_LocoVelocity::enter()`（[State_LocoVelocity.h#L39-L66](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L39-L66)）中执行 `SelectMode("normal")`，在 `exit()`（[State_LocoVelocity.h#L171-L180](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L171-L180)）中执行 `ReleaseMode()`：

```cpp
// enter(): 底层 → 高层  (State_LocoVelocity.h#L39-L66)
msc_.Init();
msc_.ReleaseMode();     // 先释放残留的低层服务
msc_.SelectMode("normal"); // 激活 sport_mode / loco_service
sleep(2s);
// 之后 LocoClient RPC 调用才能生效

// exit(): 高层 → 底层  (State_LocoVelocity.h#L171-L180)
client_.StopMove();
client_.Damp();          // loco_service 内先回到阻尼
sleep(500ms);
msc_.ReleaseMode();      // 释放 sport_mode，归还总线给底层 FSM
```

#### 途径二：遥控器硬件级强制切换（调试与急停）

在实机部署（特别是 Sim-to-Real 下地）时，开发者更常使用遥控器的物理按键来进行两个层级间的瞬间夺权与交接：

| 操作 | 效果 |
|------|------|
| 长按 **L2 + R2** | 强制挂起 PC1 上的 `loco_service`，释放总线进入 Debug/Develop 模式 |
| **L2 + B** | 进入安全阻尼 |
| **L2 + UP** | StandUp 起立准备 |
| **R2 + X** | 重新激活官方高层自适应平衡运动控制 |

#### 途径三：局部控制的"无缝混合叠加"（上半身 RL + 下半身步态）

如果你的应用场景是一边让机器人保持站立/行走，一边用自研 RL 策略控制上半身（如挥臂、抓取），完全不需要相互切换或关闭高层服务。底层固件支持按身体部位物理划分控制权：
- 下半身平衡步态由机载高层 `loco_service` 独占
- 上半身 RL 策略将指令发布到 `rt/arm_sdk` 话题（而非 `rt/lowcmd`）
- 通过指令包中的**过渡权重**（weight 0.0→1.0），底层硬件自动完成高层平衡指令与底层手臂操作指令的线性叠加

#### 致命红线

1. **绝对禁止"直接抢断"**：如果高层 `sport_mode` 仍在运行，直接向 `rt/lowcmd` 高频发送 RL 策略指令，会导致机器人同时响应两组冲突的控制流（控制权竞争），引发电机数百赫兹的剧烈发抖、啸叫发热，严重时直接扫齿损坏减速器。
2. **必须有"阻尼安全岛"**：由于高层步态姿态与 RL 策略期望姿态往往存在 Gap，瞬间的完全接管或完全撒手会产生巨大的力矩阶跃。无论是从高层切底层，还是底层切回高层，都先让机器人进入纯阻尼模式（`Kp=0, Kd≈5.0`），在消除瞬态冲击后再平滑放开刚度。本实现中 `enter()` 和 `exit()` 均先调用 `Damp()` 作为安全岛（[State_LocoVelocity.h#L76-L78](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L76-L78)、[State_LocoVelocity.h#L162-L165](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L162-L165)）。

### 3.4 控制权交接：post_run() 覆写

默认 `FSMState::post_run()`（参见 [FSMState.h#L55-L57](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/FSMState.h#L55-L57)）会调用 `lowcmd->unlockAndPublish()`，将关节命令发布到 DDS。但在 `LocoVelocity` 中覆写为空（[State_LocoVelocity.h#L185-L190](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L185-L190)）：

```cpp
// State_LocoVelocity.h#L185-L190
void post_run()
{
    // 空覆写 — loco_service 内部控制电机，不通过 lowcmd 发布关节指令
    // 与 §3.3 途径一的 MotionSwitcherClient 配合，双重保障防止总线争夺
}
```

如果不覆写，`CtrlFSM` 的 1kHz 线程会持续发布上一状态（FixStand）的关节位姿到 `rt/lowcmd`，与 `loco_service` 产生竞态，导致电机抖震或失控。

> **已知限制（真机前应知）**：`CtrlFSM::run_()` 在 1kHz 的 `RecurrentThread` 中**同一线程内**调用 `currentState->exit()` 与 `nextState->enter()`（见 [CtrlFSM.h#L100-L106](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/CtrlFSM.h#L100-L106)）。`State_LocoVelocity::enter()/exit()` 内含多个 `sleep_for`（2s + 500ms + 最长约 11s 的 StandUp 两阶段轮询 + 退出侧最多约 3.7s 的 Stop/Damp/ReleaseMode），进入与离开期间整个 FSM 线程被阻塞，**摇杆不会更新、`LT + B` 急停在 3-8s 的 enter() 过程中无法被响应**。缓解建议：真机调试时先用遥控器 `L2 + R2` 释放高层再进本状态，并把 enter() 中的长 sleep 放到独立线程或改为事件驱动；在 stabilize（StandUp 完成）之前不要松开物理急停或吊带。

---

## 4. State_LocoVelocity 源码深度解析

完整源码：[State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h)

### 4.1 构造函数：参数加载（[State_LocoVelocity.h#L13-L27](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L13-L27)）

```cpp
State_LocoVelocity(int state, std::string state_string = "LocoVelocity")
: FSMState(state, state_string)
{
    auto cfg = param::config["FSM"][state_string];

    max_vx_    = cfg["max_vx"]    ? cfg["max_vx"].as<float>()    : 0.5f;
    max_vy_    = cfg["max_vy"]    ? cfg["max_vy"].as<float>()    : 0.3f;
    max_omega_ = cfg["max_omega"] ? cfg["max_omega"].as<float>() : 0.5f;
    swing_height_ = cfg["swing_height"] ? cfg["swing_height"].as<float>() : 0.08f;
    stand_height_ = cfg["stand_height"] ? cfg["stand_height"].as<float>() : 0.0f;
    send_interval_ms_ = cfg["send_interval_ms"] ? cfg["send_interval_ms"].as<int>() : 20;
}
```

所有参数从 [config.yaml 的 LocoVelocity 段](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml#L57-L66) 读取，带默认值回退。这意味着真机上无需重新编译即可通过修改 YAML 调整速度上限。

### 4.2 enter()：Mode Switch + 启动远程 loco_service FSM（[State_LocoVelocity.h#L29-L121](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L29-L121)）

```cpp
void enter()
{
    // ================================================================
    // Phase 0: Mode Switch via MotionSwitcherClient (§3.3 途径一)
    // 底层 → 高层：必须激活 sport_mode，否则 LocoClient RPC 无效
    // ================================================================
    msc_.SetTimeout(10.0f);
    msc_.Init();

    // 0a. Release 任何残留的低层运动服务（幂等操作）
    std::string form, motion_name;
    msc_.CheckMode(form, motion_name);
    if (!motion_name.empty()) {
        for (int i = 0; i < 5; ++i) {
            if (msc_.ReleaseMode() == 0) break;
            sleep(1s);
        }
    }

    // 0b. 激活 sport_mode → loco_service 上线
    msc_.SelectMode("normal");
    sleep(2s);  // 等待服务完全启动

    // ================================================================
    // Phase 1: LocoClient Init + Damping Safety Island
    // ================================================================
    client_.Init();         // 参见 h1_loco_client.hpp#L48-L69
    client_.SetTimeout(10.f);
    client_.Damp();         // 阻尼安全岛，h1_loco_client.hpp#L210
    sleep(500ms);

    // Phase 2: StandUp (异步，两阶段轮询)
    client_.StandUp();      // h1_loco_client.hpp#L212
    int fsm_id = 0;

    // Phase A: 确认 loco_service 真的进入 StandUp (fsm_id == 2)
    // 避免 RPC 尚未生效、fsm_id 仍为 0 时提前 break
    bool entered_standup = false;
    for (int i = 0; i < 25; ++i) {
        if (client_.GetFsmId(fsm_id) == 0 && fsm_id == 2) {
            entered_standup = true;
            break;
        }
        sleep(200ms);
    }
    if (!entered_standup) {
        // 警告但继续，部分固件版本可能跳过 2 直接进入运行态
    }

    // Phase B: 等待 loco_service 自主离开 StandUp (fsm_id != 2)
    for (int i = 0; i < 30; ++i) {
        if (client_.GetFsmId(fsm_id) == 0 && fsm_id != 2) break;
        sleep(200ms);
    }

    // Phase 3: Start Locomotion
    client_.Start();        // h1_loco_client.hpp#L211

    // Phase 4: Gait Parameters
    client_.ContinuousGait(true);  // h1_loco_client.hpp#L227
    client_.SetSwingHeight(swing_height_);
    client_.EnableOdom();          // h1_loco_client.hpp#L196
}
```

**时序关键点**：
- `SelectMode("normal")` 是让 `loco_service` 从"已释放/挂起"状态恢复到"运行"状态的 RPC 调用（[motion_switcher_client.hpp#L25](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/b2/motion_switcher/motion_switcher_client.hpp#L25)）。**没有这一步，后续所有 `LocoClient` RPC 调用都会超时或返回错误码**。
- `StandUp()` 是异步的（[h1_loco_client.hpp#L212](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_client.hpp#L212)）——RPC 调用立即返回，但机器人需要 2-5 秒才能物理完成站立。采用**两阶段轮询** `GetFsmId()`（[h1_loco_client.hpp#L73](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_client.hpp#L73)）：阶段 A 先确认 `loco_service` 真的进入了 StandUp（`fsm_id == 2`），阶段 B 再等待它自主离开 StandUp（`fsm_id != 2`）。原单循环 `if (fsm_id != 2) break` 因初始 `fsm_id=0` 且 RPC 尚未生效会在第一次就提前退出，过早调用 `Start()`。

### 4.3 run()：摇杆速度映射（[State_LocoVelocity.h#L124-L149](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L124-L149)）

```cpp
void run()
{
    if (!client_initialized_) return;

    // 频率限制：每 send_interval_ms_(20ms) 发送一次 → 50Hz
    auto elapsed = now() - last_send_time_;
    if (elapsed < send_interval_ms_) return;
    last_send_time_ = now();

    // 摇杆轴映射 — 数据从 lowstate->joystick 读取
    // joystick 类型为 unitree::common::UnitreeJoystick
    // 参见 unitree_joystick.hpp#L130-L172
    // 轴符合 RES 机器人坐标系约定（与 observations.h 一致）：
    //   vx  = +ly          (向前为正)
    //   vy  = -lx          (向左为正；摇杆右侧推 lx>0 → vy<0 即右移)
    //   ω   = -rx          (逆时针为正；摇杆右侧推 rx>0 → 顺时针转向)
    float vx    = lowstate->joystick.ly() * max_vx_;      // 左摇杆上下 → 前进/后退
    float vy    = -lowstate->joystick.lx() * max_vy_;     // 左摇杆左右 → 横移（向左为正）
    float omega = -lowstate->joystick.rx() * max_omega_;  // 右摇杆左右 → 旋转（CCW 为正）

    // 持续时间：3x 发送间隔 + 缓冲
    float duration = std::max(0.5f, send_interval_ms_ * 3.0f / 1000.0f);
    // API ID 8105, 见 h1_loco_client.hpp#L165-L172
    client_.SetVelocity(vx, vy, omega, duration);
}
```

**为什么需要 `duration`？** `loco_service` 的安全保护机制要求每条速度指令都带有效期。若 `duration = 0.5`，意味着 0.5 秒内未收到新的速度指令则自动降速为零，防止客户端卡死导致机器人无限前行。参见 [JsonizeVelocityCommand](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_api.hpp#L51-L66) 的序列化结构。

### 4.4 exit()：安全退出 + 归还总线（[State_LocoVelocity.h#L151-L183](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L151-L183)）

```cpp
void exit()
{
    // 改用短 timeout（2s），避免 DDS 断连时 FSM 线程被 RPC 超时阻塞 10s
    client_.SetTimeout(2.0f);

    // StopMove / DisableOdom / Damp 无条件执行，不依赖 client_initialized_
    // 这样即使 enter() 中途失败（Start() 未调用），sport_mode 也能释放、
    // 机器人仍能回到阻尼安全岛
    client_.StopMove();     // h1_loco_client.hpp#L216
    sleep(200ms);

    client_.DisableOdom();  // h1_loco_client.hpp#L201
    client_.Damp();         // 阻尼安全岛，h1_loco_client.hpp#L224
    sleep(500ms);

    client_initialized_ = false;

    // Release sport_mode — 归还总线给底层 FSM（§3.3 途径一）
    msc_.SetTimeout(2.0f);
    for (int i = 0; i < 3; ++i) {
        if (msc_.ReleaseMode() == 0) break;  // motion_switcher_client.hpp#L26
        sleep(1s);
    }
}
```

退出后机器人回到安全阻尼状态，`rt/lowcmd` 总线已释放。即使 `enter()` 中途失败，也能确保上述清理被执行。

---

## 5. config.yaml 配置详解

完整配置：[config.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml)

### 5.1 FSM 注册（`_:`）（[config.yaml#L1-L10](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml#L1-L10)）

```yaml
_:
  Passive:
    id: 1
  FixStand:
    id: 2
  Mimic_Dance1_subject2:
    id: 5
    type: Mimic
  LocoVelocity:
    id: 6
    type: LocoVelocity       # ← 匹配 REGISTER_FSM(State_LocoVelocity)
```

`CtrlFSM` 构造函数（[CtrlFSM.h#L30-L42](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/CtrlFSM.h#L30-L42)）通过 `getFsmMap().find("State_LocoVelocity")` 找到对应的工厂函数，实例化状态对象。`REGISTER_FSM(State_LocoVelocity)` 宏展开定义于 [BaseState.h#L49-L54](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/BaseState.h#L49-L54)。

### 5.2 状态跳转（[config.yaml#L31-L35](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml#L31-L35)）

```yaml
FixStand:
  transitions:
    Passive: LT + B.on_pressed
    Mimic_Dance1_subject2: RB + A.on_pressed
    LocoVelocity: RB + X.on_pressed          # ← 新增
```

DSL 解析器定义于 [unitree_joystick_dsl.hpp](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/unitree_joystick_dsl.hpp)，`RB + X.on_pressed` 表示"RB 被按住 + X 被按下的一帧"。在真机遥控器上，`RB` = 右肩键（R1），`X` = X 键。

### 5.3 LocoVelocity 参数（[config.yaml#L57-L66](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml#L57-L66)）

```yaml
LocoVelocity:
  transitions:
    Passive: LT + B.on_pressed               # 紧急停止
  max_vx: 0.5          # 最大前进速度 (m/s)，摇杆 ly=1.0 时
  max_vy: 0.3          # 最大横移速度 (m/s)，摇杆 lx=1.0 时
  max_omega: 0.5       # 最大旋转角速度 (rad/s)，摇杆 rx=1.0 时
  swing_height: 0.08   # 摆动腿离地高度 (m)
  stand_height: 0.0    # 站立高度 (m)，0 表示使用默认
  send_interval_ms: 20 # 速度指令发送间隔 (ms)，即 50Hz
```

可在真机部署时按需调整这些参数（如降低 `max_vx` 以保守测试）。

---

## 6. 编译

```bash
cd /home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2
rm -rf build && mkdir -p build
cmake -S . -B build
cmake --build build -j$(nproc)
```

产物：`build/h1_2_ctrl`

> ✅ **2026-06-24 编译通过**。

---

## 7. 真机部署流程

> ⚠️ **安全警告**：LocoVelocity 依赖机载 `loco_service`，**仅支持真机实机运行**，无法在 MuJoCo 仿真中测试。部署前务必：
> - 确认机器人处于吊架悬挂状态（安全绳/吊车）
> - 确认急停开关可用
> - 首次测试使用较低的 `max_vx` / `max_vy`

### 7.1 真机拓扑

```
[遥控器/手柄] ──(DDS)──> [PC1 (loco_service)]
                              ↑
                         (DDS + RPC)
                              │
[用户上位机] ──(以太网)──> [交换机] ──> [机器人]
  (运行 h1_2_ctrl)
```

### 7.2 启动命令

```bash
# 在用户上位机上执行（需与机器人同一网络）
cd /home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2

export LD_LIBRARY_PATH=\
/home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/thirdparty/onnxruntime-linux-x64-1.22.0/lib:\
/home/meme/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:\
/usr/local/lib:${LD_LIBRARY_PATH}

./build/h1_2_ctrl --network=eth0   # 根据实际网卡名调整
```

### 7.3 操作步骤

| 步骤 | 手柄操作 | 状态转换 | 说明 |
|------|---------|---------|------|
| 1 | — | 启动进入 Passive | 控制器连接 DDS，等待手柄输入 |
| 2 | LT + ↑ | Passive → FixStand | 机器人从阻尼过渡到硬姿态（约 3s） |
| 3 | RB + X | FixStand → LocoVelocity | `loco_service` 执行 Damp→StandUp→Start 全流程（约 5-8s） |
| 4 | 左摇杆 | 速度行走 | `ly` 控制前后，`lx` 控制横移，`rx` 控制旋转 |
| 5 | LT + B | LocoVelocity → Passive | 紧急回阻尼 |

### 7.4 启动日志参考（预期）

```
[info] Waiting for connection to robot...
[info] Connected to robot.
[info] FSM: Start Passive
[info] Initializing State_LocoVelocity ... max_vx=0.5, max_vy=0.3, max_omega=0.5
[info] FSM: Change state from FixStand to LocoVelocity
[info] State_LocoVelocity: Initializing LocoClient...
[info] State_LocoVelocity: Standing up...
[info] State_LocoVelocity: Starting locomotion mode...
[info] State_LocoVelocity: Ready. Use joystick to control velocity.
```

---

## 8. 关键 SDK API 速查表

### 8.1 MotionSwitcherClient（控制权切换）

定义于 [motion_switcher_client.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/b2/motion_switcher/motion_switcher_client.hpp)。官方用法参考 [go2_stand_example.cpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/example/go2/go2_stand_example.cpp#L53-L68)。

| 方法 | 用途 | 定义位置 |
|------|------|---------|
| `msc.Init()` | 初始化 MotionSwitcherClient，注册 RPC API | motion_switcher_client.hpp#L22 |
| `msc.SetTimeout(10.f)` | 设置 RPC 超时（秒） | 继承自 ClientBase |
| `msc.SelectMode("normal")` | **激活 sport_mode / loco_service**（底层→高层） | motion_switcher_client.hpp#L25 |
| `msc.ReleaseMode()` | **释放运动服务**（高层→底层，归还 `lowcmd` 总线） | motion_switcher_client.hpp#L26 |
| `msc.CheckMode(form, name)` | 查询当前活跃的运动服务名；name 为空 = 无服务活跃 | motion_switcher_client.hpp#L24 |

### 8.2 LocoClient（高层步态 RPC）

定义于 [h1_loco_client.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_client.hpp)、API ID 与载荷结构体定义于 [h1_loco_api.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_api.hpp)。**仅在 `sport_mode` 激活后有效**。

| 方法 | API ID | 参数 | 用途 | 定义位置 |
|------|--------|------|------|---------|
| `Damp()` | 8101 | fsm_id=1 | 进入安全阻尼（Kp=0） | h1_loco_client.hpp#L210 |
| `StandUp()` | 8101 | fsm_id=2 | 缓慢站立初始化 | h1_loco_client.hpp#L212 |
| `Start()` | 8101 | fsm_id=204 | 激活行走模式 | h1_loco_client.hpp#L211 |
| `GetFsmId()` | 8001 | — | 查询当前 loco_service FSM 状态 | h1_loco_client.hpp#L73-L83 |
| `SetVelocity(vx,vy,ω,dur)` | 8105 | 速度向量 + 有效期 | 控制行走速度 | h1_loco_client.hpp#L165-L172 |
| `StopMove()` | 8105 | vx=vy=ω=0 | 停止移动 | h1_loco_client.hpp#L216 |
| `ContinuousGait(bool)` | 8102 | balance_mode=0/1 | 原地踏步开关 | h1_loco_client.hpp#L227 |
| `SetSwingHeight(h)` | 8103 | 高度(m) | 设置摆腿高度 | h1_loco_client.hpp#L148-L152 |
| `SetStandHeight(h)` | 8104 | 高度(m) | 设置站立高度 | h1_loco_client.hpp#L155-L159 |
| `EnableOdom()` | 8201 | — | 开启里程计 | h1_loco_client.hpp#L196 |
| `DisableOdom()` | 8202 | — | 关闭里程计 | h1_loco_client.hpp#L201 |

### 8.3 摇杆数据源（UnitreeJoystick）

定义于 [unitree_joystick.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/dds_wrapper/common/unitree_joystick.hpp#L130-L172)。`LocoVelocity::run()` 读取的 `lowstate->joystick` 即此类型：

| 成员 | 类型 | 范围 | 映射到 `run()` 中的变量 |
|------|------|------|----------------------|
| `joystick.ly()` | Axis | [-1, 1] | `vx`（前进/后退） |
| `joystick.lx()` | Axis | [-1, 1] | `vy`（横移） |
| `joystick.rx()` | Axis | [-1, 1] | `omega`（偏航旋转） |

---

## 9. 常见问题

### 9.1 为什么 MuJoCo 仿真无法运行 LocoVelocity？

`LocoClient` 通过 RPC 与机载 `loco_service` 通信，`MotionSwitcherClient` 同理。两者均定义于 [unitree_sdk2](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_client.hpp)，MuJoCo 仿真中不存在对应服务进程，RPC 调用会超时返回错误码。如需在仿真中测试行走，可使用 Velocity 类型（`State_RLBase` + 速度跟踪 ONNX 策略）。

### 9.2 LocoClient RPC 调用全部超时（ret != 0）

**根因**：`sport_mode` / `loco_service` 未激活。检查：
1. 是否已调用 `msc_.SelectMode("normal")` 并等待 2 秒？（[State_LocoVelocity.h#L59-L66](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L59-L66)）
2. 机器人是否处于 Debug 模式（长按 L2+R2 可退出）？
3. 上位机与机器人网络是否通畅（ping PC1）？

### 9.3 "直接抢断"会导致什么后果？

如果 `sport_mode` 仍在运行而程序向 `rt/lowcmd` 发布关节指令，电机固件会同时收到两组冲突的目标值（一组来自 `loco_service` 的 WBC 输出，一组来自 `lowcmd` DDS），导致：
- 电机数百赫兹剧烈抖震
- 线圈啸叫、驱动器发热
- 严重时减速器扫齿（不可逆机械损伤）

**本实现的双重防护**：
1. `MotionSwitcherClient::ReleaseMode()` 程序级释放 `sport_mode`（[State_LocoVelocity.h#L170-L180](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L170-L180)）
2. `post_run()` 空覆写，防止 `lowcmd` 竞争（[State_LocoVelocity.h#L185-L190](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h#L185-L190)）

### 9.4 StandUp 等待逻辑中 fsm_id != 2 是什么意思？

`StandUp()`（[h1_loco_client.hpp#L212](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_client.hpp#L212)）调用后，`loco_service` 内部进入 FSM id=2（缓慢站立），站立完成后自动离开。实现用两阶段轮询：阶段 A 等 `GetFsmId()` 返回 `==2`（确认进入站立），阶段 B 等它变为 `!=2`（自主离开），即可安全调用 `Start()`。这样避免了"RPC 还没生效、`fsm_id` 仍是 0，单循环一次性 break"导致过早 `Start()` 的风险。

### 9.5 摇杆输入无响应？

检查真机手柄是否已配对并通过 DDS 发布到 `rt/lowstate`。`lowstate->joystick.ly()` 等从 `LowState` 消息中提取手柄数据（数据类型参见 [unitree_joystick.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/dds_wrapper/common/unitree_joystick.hpp#L130-L172)）。确认 `mode_machine = 6` 已匹配。

### 9.6 编译错误找不到 motion_switcher_client.hpp？

确认 `unitree_sdk2` 已安装到系统路径：

```bash
ls /usr/local/include/unitree/robot/b2/motion_switcher/
# 应包含: motion_switcher_client.hpp
ls /usr/local/include/unitree/robot/h1/loco/
# 应包含: h1_loco_api.hpp  h1_loco_client.hpp  h1_loco_error.hpp
```

如缺失，重新编译安装 [unitree_sdk2](file:///home/meme/Documents/unitree_h1/unitree_sdk2)。

---

## 10. 总结

| 维度 | 内容 |
|------|------|
| **代码库** | [h1_2_mimic_deploy_real](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real)（独立于 `unitree_rl_mjlab/deploy`） |
| **核心源码** | [State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) |
| **配置文件** | [config.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml) |
| **切换协议** | Phase 0: `MotionSwitcherClient::SelectMode("normal")` 激活 sport_mode |
| **安全防护** | ① MotionSwitcherClient 程序级切换 ② `post_run()` 空覆写 ③ `Damp()` 阻尼安全岛 |
| **运行环境** | **仅真机实机**（依赖机载 `loco_service` + `MotionSwitcherClient`） |
| **编译结果** | ✅ 通过 |

### 文件清单

```
h1_2_mimic_deploy_real/
├── include/FSM/
│   └── State_LocoVelocity.h    ← 新建
├── include/FSM/
│   ├── CtrlFSM.h               ← 本地 FSM 框架
│   ├── BaseState.h             ← REGISTER_FSM 宏
│   └── FSMState.h              ← post_run() 基类
└── robots/h1_2/
    ├── config/config.yaml      ← 修改
    ├── main.cpp                ← 修改
    └── build/h1_2_ctrl         ← 编译产物
```

---

## 附录 A. 修改记录

| 日期 | 文件 | 修改 |
|------|------|------|
| 2026-06-24 | [State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) | **原实现**：首次编写，编译通过 |
| 2026-06-24 | [State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) | **修复**：摇杆轴 `vy` / `omega` 符号反转（`-lx` / `-rx`），与 `observations.h` 机器人坐标系约定对齐 |
| 2026-06-24 | [State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) | **修复**：`StandUp` 单循环轮询竞争（`if (fsm_id != 2) break` 因 RPC 未生效提前退出）。改为两阶段：先确认进入 `fsm_id == 2`，再等自主离开 `fsm_id != 2` |
| 2026-06-24 | [State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) | **修复**：`exit()` 中 StopMove/DisableOdom/Damp 不再依赖 `client_initialized_` 守卫，确保中途失败也能清理；退出 RPC 改用短 timeout（2s）避免 DDS 断连时阻塞 FSM 线程 |

---

## 参考

- [07 高层步态例程解读](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/07%20高层步态例程解读.md) — LocoClient API 完整教程
- [07 h1_2 控制器实机适配修改记录](file:///home/meme/Documents/笔记/02%20Mimic/07%20h1_2%20控制器实机适配修改记录.md) — 控制器适配基础
- [08 h1_2 deploy 控制器与 MuJoCo 仿真联调](file:///home/meme/Documents/笔记/02%20Mimic/08%20h1_2%20deploy%20控制器与%20MuJoCo%20仿真联调.md) — Mimic 状态与仿真
- [h1_loco_client.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_client.hpp) — LocoClient 接口定义
- [h1_loco_api.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/h1/loco/h1_loco_api.hpp) — API ID 与载荷结构体定义
- [motion_switcher_client.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/robot/b2/motion_switcher/motion_switcher_client.hpp) — MotionSwitcherClient 接口定义
- [unitree_joystick.hpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/include/unitree/dds_wrapper/common/unitree_joystick.hpp) — 摇杆数据类型定义
- [go2_stand_example.cpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/example/go2/go2_stand_example.cpp) — ReleaseMode / SelectMode 官方用法参考
- [h1_loco_client_example.cpp](file:///home/meme/Documents/unitree_h1/unitree_sdk2/example/h1/high_level/h1_loco_client_example.cpp) — LocoClient 高层步态官方例程
- [State_LocoVelocity.h](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/include/FSM/State_LocoVelocity.h) — 本笔记核心源码
- [config.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml) — 完整 FSM 配置
