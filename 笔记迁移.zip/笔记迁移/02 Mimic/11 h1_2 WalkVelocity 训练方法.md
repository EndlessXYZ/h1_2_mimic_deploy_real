# 11 h1_2 WalkVelocity 训练方法（MJLab 标准流程）

> **系列定位**：在 [09 h1_2 LocoVelocity 步态SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/09%20h1_2%20LocoVelocity%20步态SDK集成.md) 和 [12 h1_2 WalkVelocity 策略SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/12%20h1_2%20WalkVelocity%20策略SDK集成.md) 之间，专门介绍 WalkVelocity 所需策略模型的训练方法。本文讲解如何在 `unitree_rl_mjlab` 中用 MJLab 框架训练 H1_2 行走策略，涵盖任务配置、PPO 超参数、奖励设计和模型导出。

> **实验状态**：⏳ 本机 CUDA Driver 12.2 低于 `mujoco_warp` 要求的 12.4，暂无法直接训练，需在 CUDA 12.4+ 环境执行。

---

## 1. 概述

### 1.1 训练流程全景

```
train.py                     # 训练入口
  └─ Unitree-H1_2-Flat       # 任务 ID（平地行走）
       ├─ env_cfgs.py        # 环境配置（仿真参数、观测、动作、奖励）
       └─ rl_cfg.py          # PPO 算法参数
            └─ runner.learn() → logs/rsl_rl/h1_2_velocity/<timestamp>/
                                      ├─ model_100.pt, model_200.pt, ...
                                      └─ policy.onnx (自动导出)
```

训练完成后，`policy.onnx` 即可用于 [12 WalkVelocity 策略SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/12%20h1_2%20WalkVelocity%20策略SDK集成.md) 的真机部署。

### 1.2 代码库结构

```
unitree_rl_mjlab/
├── scripts/
│   ├── train.py              # 训练入口
│   └── play.py               # 可视化/推理入口
├── src/
│   ├── tasks/velocity/       # Velocity 任务
│   │   ├── config/h1_2/      # H1_2 特定配置
│   │   │   ├── __init__.py   # 任务注册
│   │   │   ├── env_cfgs.py   # 环境配置
│   │   │   └── rl_cfg.py     # PPO 配置
│   │   ├── velocity_env_cfg.py  # 通用 Velocity 基础配置
│   │   └── rl/runner.py      # 自动 ONNX 导出
│   └── assets/robots/unitree_h1_2/
│       ├── h1_2_constants.py # 执行器参数、ACTION_SCALE
│       └── xmls/h1_2.xml     # MuJoCo 模型（27 DOF）
├── logs/rsl_rl/h1_2_velocity/ # 训练产物（自动生成）
└── deploy/robots/h1_2/       # 部署配置（与训练配置分离）
```

---

## 2. 任务注册与配置

### 2.1 两个预置任务

在 [src/tasks/velocity/config/h1_2/__init__.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/config/h1_2/__init__.py) 中注册了两个任务：

| 任务 ID | 地形 | 用途 |
|---------|------|------|
| `Unitree-H1_2-Rough` | 程序化生成地形（崎岖） | 训练鲁棒行走 |
| `Unitree-H1_2-Flat` | 平面地形 | 基础行走、真机部署 |

部署到真机时使用 **Flat** 版本。两个任务共享同一组 PPO 超参数。

### 2.2 配置继承链

```
make_velocity_env_cfg()            # velocity_env_cfg.py — 通用基础
  └─ unitree_h1_2_rough_env_cfg()  # env_cfgs.py — H1_2 特定
       └─ unitree_h1_2_flat_env_cfg()  # 平面覆盖
```

`unitree_h1_2_flat_env_cfg()` 在 `rough` 基础上做了以下修改：

| 项目 | Rough | Flat |
|------|-------|------|
| 地形类型 | `terrain_generator`（程序化） | `"plane"`（平面） |
| 地形扫描传感器 | 有 | 移除 |
| 高度扫描观测 | 有 | 移除 |
| 地形课程学习 | 有 | 禁用 |
| 仿真参数 | `nconmax=48, njmax=1500` | `njmax=300` |
| play 模式速度范围 | 继承训练值 | `lin_vel_x=[-0.5, 1.0]` 等（缩小） |

---

## 3. 仿真环境

### 3.1 仿真参数

| 参数 | 值 | 含义 |
|------|-----|------|
| `sim.timestep` | 0.005 s | MuJoCo 仿真步长（5 ms） |
| `decimation` | 4 | 控制周期 = 4 × 0.005 = 0.02 s（50 Hz） |
| `episode_length_s` | 20.0 s | 每个 episode 时长（= 1000 步） |
| `scene.num_envs` | 1（默认） | 并行环境数，训练时用 `--num-envs 4096` |

### 3.2 场景实体

- **机器人**：`get_h1_2_robot_cfg()` 加载的 27 DOF H1_2 模型
- **传感器**：足地接触传感器（`feet_ground_contact`）、自碰撞传感器（`self_collision`）
- **地形**：Flat 模式为无限平面；Rough 模式为程序化地形网格

### 3.3 随机化事件（Domain Randomization）

| 事件 | 时机 | 说明 |
|------|------|------|
| `reset_base` | reset | 均匀随机重置基座位姿 |
| `reset_robot_joints` | reset | 重置关节位置/速度 |
| `push_robot` | interval (5~6s) | 训练中施加随机推力的干扰 |
| `foot_friction` | startup | 足部摩擦系数随机化 |
| `encoder_bias` | startup | 编码器偏置噪声 |
| `base_com` | startup | 质心偏移随机化 |

---

## 4. 观测空间

### 4.1 Actor 观测（92 维）

策略网络输入共 92 维，由 7 组观测拼接而成：

| 观测项 | 维度 | 来源 | 噪声 | 含义 |
|--------|------|------|------|------|
| `base_ang_vel` | 3 | IMU gyroscope | ±0.2 | torso 坐标系角速度 |
| `projected_gravity` | 3 | IMU accelerometer | ±0.05 | 重力在 torso 坐标系投影 |
| `velocity_commands` | 3 | 命令生成器 | — | 线速度 x/y + 角速度 z |
| `gait_phase` | 2 | 相位生成器 | — | sin/cos(2πt/T)，T=0.6s |
| `joint_pos_rel` | 27 | 关节编码器 | ±0.01 | 关节位置相对默认值 |
| `joint_vel_rel` | 27 | 关节编码器 | ±1.5 | 关节速度 |
| `last_action` | 27 | 上一帧策略输出 | — | 动作记忆 |

> **注意**：所有观测项 `history_length=1`（无帧堆叠），且 `enable_corruption=True`（训练时叠加噪声，部署时关闭）。

### 4.2 Critic 附加观测

Critic 网络额外使用以下观测（不参与策略推理，仅用于价值估计）：

- `base_lin_vel`（3 维）— 线速度
- `height_scan`（187 维）— 地形扫描（Flat 模式无此项）
- `foot_height`（2 维）— 双足高度
- `foot_air_time`（2 维）— 双足腾空时间
- `foot_contact`（2 维）— 双足触地标志
- `foot_contact_forces`（6 维）— 接触力

---

## 5. 动作空间

### 5.1 动作定义

策略输出 27 维连续动作，每个维度对应一个关节的位置增量：

$$a_i \in \mathbb{R}^{27}, \quad q_{des,i} = a_i \cdot \text{scale}_i + \text{offset}_i$$

| 参数 | 来源 | 说明 |
|------|------|------|
| `scale` | `H1_2_ACTION_SCALE` | 由执行器参数自动计算：`0.25 × effort_limit / stiffness` |
| `offset` | `use_default_offset=True` | 使用 MJCF 模型中的默认关节位置 |

### 5.2 关节映射

27 个关节包括：

| 身体部位 | 关节 | 数量 |
|----------|------|------|
| 左腿 | hip_yaw/pitch/roll, knee, ankle_pitch/roll | 6 |
| 右腿 | hip_yaw/pitch/roll, knee, ankle_pitch/roll | 6 |
| 腰部 | torso_joint | 1 |
| 左臂 | shoulder_pitch/roll/yaw, elbow, wrist_roll/pitch/yaw | 7 |
| 右臂 | shoulder_pitch/roll/yaw, elbow, wrist_roll/pitch/yaw | 7 |

### 5.3 执行器参数

| 执行器类型 | 刚度 `k` | 阻尼 `d` | 力矩极限 | 使用位置 |
|-----------|---------|---------|---------|---------|
| `M107_24_2` | 98.7 | 6.3 | 200 N·m | hip 关节 |
| `M107_24_1` | 157.7 | 10.1 | 300 N·m | knee 关节 |
| `GO2HV_1` | 19.7 | 1.3 | 40 N·m | ankle/shoulder |
| `GO2HV_2` | 7.9 | 0.5 | 18 N·m | 手臂末端 |

---

## 6. PPO 超参数

### 6.1 网络结构

```python
actor:   hidden_dims=(512, 256, 128), activation="elu", obs_normalization=True
critic:  hidden_dims=(512, 256, 128), activation="elu", obs_normalization=True
distribution: GaussianDistribution, init_std=1.0, std_type="scalar"
```

### 6.2 算法参数

| 参数 | 值 | 说明 |
|------|-----|------|
| `learning_rate` | 1.0e-3 | 初始学习率 |
| `schedule` | `"adaptive"` | 自适应调整 |
| `num_learning_epochs` | 5 | 每个 iteration 训练 epoch 数 |
| `num_mini_batches` | 4 | mini-batch 分割数 |
| `clip_param` | 0.2 | PPO epsilon |
| `entropy_coef` | 0.01 | 熵正则系数 |
| `value_loss_coef` | 1.0 | 价值损失权重 |
| `gamma` | 0.99 | 折扣因子 |
| `lam` | 0.95 | GAE lambda |
| `desired_kl` | 0.01 | 目标 KL 散度（用于自适应 lr） |
| `max_grad_norm` | 1.0 | 梯度裁剪 |

### 6.3 训练参数

| 参数 | 值 | 说明 |
|------|-----|------|
| `max_iterations` | 10001 | 最大训练 iteration |
| `num_steps_per_env` | 24 | 每次收集的步数 |
| `save_interval` | 100 | 每 100 iteration 保存 checkpoint |
| `experiment_name` | `"h1_2_velocity"` | 日志目录名 |

> 以 4096 并行环境计算：总样本量 ≈ 10001 × 24 × 4096 ≈ 9.8 × 10⁸ 步

---

## 7. 奖励函数

### 7.1 主要奖励

| 奖励项 | 权重 | 说明 |
|--------|------|------|
| `track_linear_velocity` | +1.0 | 线速度跟踪（高斯似然） |
| `track_angular_velocity` | +1.0 | 角速度跟踪 |
| `pose` (variable_posture) | +1.0 | 姿态维持（三档 std：standing/walking/running） |
| `foot_gait` | +0.5 | 步态相位匹配 |

### 7.2 惩罚项

| 惩罚项 | 权重 | 说明 |
|--------|------|------|
| `is_terminated` | -200.0 | 跌倒终止惩罚 |
| `joint_pos_limits` | -10.0 | 关节限位违反 |
| `action_rate_l2` | -0.05 | 动作平滑性 |
| `body_orientation_l2` | -1.0 | 身体倾斜惩罚 |
| `body_ang_vel` | -0.05 | 角速度惩罚 |
| `angular_momentum` | -0.025 | 角动量惩罚 |
| `joint_acc_l2` | -2.5e-7 | 关节加速度惩罚 |
| `foot_clearance` | -1.0 | 足部离地高度惩罚 |
| `foot_slip` | -0.25 | 滑脚惩罚 |
| `soft_landing` | -1e-3 | 落地冲击惩罚 |
| `stand_still` | -1.0 | 小速度时站立偏离惩罚 |
| `self_collisions` | -1.0 | 自碰撞惩罚 |

### 7.3 姿态奖励的关节分组

`pose` 奖励根据运动速度切换三组 std（std 越大，允许偏离默认姿态的程度越大）：

**Walking 模式**（速度 > 0.1 m/s）：

| 关节组 | std | 说明 |
|--------|-----|------|
| hip_yaw/roll, ankle_pitch, torso, shoulder/elbow/wrist | 0.1~0.15 | 较紧，保持稳定性 |
| hip_pitch, knee | 0.5 | 较松，允许腿部自然摆动 |

**Running 模式**（速度 > 1.5 m/s）：std 放大 1.5~2 倍。

---

## 8. 速度指令配置

### 8.1 命令空间

训练时的速度指令由 `UniformVelocityCommandCfg` 生成：

| 维度 | 训练范围 | Flat Play 范围 | WalkVelocity 部署范围 |
|------|---------|---------------|---------------------|
| `lin_vel_x` | [-1.0, 2.0] m/s | [-0.5, 1.0] m/s | [-0.5, 1.0] m/s |
| `lin_vel_y` | [-1.0, 1.0] m/s | [-0.5, 0.5] m/s | [-0.5, 0.5] m/s |
| `ang_vel_z` | [-1.0, 1.0] rad/s | [-0.5, 0.5] rad/s | [-0.5, 0.5] rad/s |

命令每隔 3~8 秒重新采样一次，5% 的环境保持零速度指令。

### 8.2 速度课程

训练前 5000 iteration（约 120k 环境步）使用缩小范围 `lin_vel_x=[-0.5, 1.0]`，之后解锁完整范围。这有助于策略逐步适应高速行走。

---

## 9. 训练执行

### 9.1 基本训练命令

```bash
cd ~/Documents/unitree_h1/unitree_rl_mjlab

# Flat 地形（推荐用于真机部署）
python scripts/train.py Unitree-H1_2-Flat --env.scene.num-envs=4096

# Rough 地形（更鲁棒，但训练更慢）
python scripts/train.py Unitree-H1_2-Rough --env.scene.num-envs=4096
```

> `--env.scene.num-envs=4096` 设置并行环境数。4096 是推荐值，可根据 GPU 显存调整（3090/4090 均可支持）。

### 9.2 训练输出

训练日志位于 `logs/rsl_rl/h1_2_velocity/<timestamp>/`：

```
logs/rsl_rl/h1_2_velocity/
└── 2026-06-30_12-00-00/
    ├── model_100.pt          # checkpoint
    ├── model_200.pt
    ├── ...
    ├── model_10000.pt
    ├── policy.onnx           # 最新导出的 ONNX（每次 save 自动更新）
    └── params/
        ├── env.yaml          # 环境配置快照
        └── agent.yaml        # 算法配置快照
```

### 9.3 训练可视化

```bash
# TensorBoard
tensorboard --logdir logs/rsl_rl/h1_2_velocity

# 使用 play.py 可视化训练结果
python scripts/play.py Unitree-H1_2-Flat \
  --checkpoint-file logs/rsl_rl/h1_2_velocity/<timestamp>/model_5000.pt \
  --num-envs 1
```

### 9.4 从 ONNX 推理验证

```bash
python scripts/play.py Unitree-H1_2-Flat \
  --agent onnx \
  --onnx-file logs/rsl_rl/h1_2_velocity/<timestamp>/policy.onnx \
  --num-envs 1
```

---

## 10. 模型导出

### 10.1 自动导出机制

`VelocityOnPolicyRunner` 在每次 `save()` 时**自动导出 ONNX**：

```python
class VelocityOnPolicyRunner(MjlabOnPolicyRunner):
    def save(self, path, infos=None):
        super().save(path, infos)              # 保存 PyTorch checkpoint
        policy_path = path.split("model")[0]
        self.export_policy_to_onnx(policy_path, "policy.onnx")
        metadata = get_base_metadata(self.env.unwrapped, run_name)
        attach_metadata_to_onnx(onnx_path, metadata)
```

因此训练完成后，`policy.onnx` 已在日志目录中，无需额外导出步骤。

### 10.2 从 checkpoint 重新导出

如需从特定 checkpoint 手动导出：

```bash
python scripts/play.py Unitree-H1_2-Flat \
  --checkpoint-file logs/rsl_rl/h1_2_velocity/<timestamp>/model_5000.pt
```

`play.py` 的 `Trained` agent 模式会在加载时重建 runner，调用 `save()` 会触发 ONNX 导出。但更直接的方式是从日志目录取已自动导出的 `policy.onnx`。

### 10.3 部署文件

将 ONNX 复制到部署目录：

```bash
cp logs/rsl_rl/h1_2_velocity/<timestamp>/policy.onnx \
  ~/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/exported/
```

对应的部署配置文件 [deploy.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/params/deploy.yaml) 需与训练配置保持一致的观测/动作结构（观测组名称、维度、scale 等）。MJLab 框架已保证训练和部署的观测组装逻辑同源。

---

## 11. 常见问题

### 11.1 CUDA Driver 版本不足

`mujoco_warp==3.5.0` 要求 CUDA Driver ≥ 12.4：

```bash
nvidia-smi  # 检查 Driver 版本
```

如低于 12.4，可使用 Docker 或更换 CUDA 兼容环境。

### 11.2 训练不收敛

- 检查 `entropy_coef` 是否过小（默认 0.01 对于 velocity 任务通常合适）
- 确认 `num_envs` 足够大（至少 2048，推荐 4096）
- 观察 TensorBoard 中的 `rew/total` 是否在 2000 iteration 后达到 ~10+
- 若动作幅度异常，检查 `H1_2_ACTION_SCALE` 是否正确

### 11.3 导出的 ONNX 无法在部署端运行

- 确认 `deploy.yaml` 的观测项、维度、顺序与训练侧一致
- 确认 ONNX 使用 CPU 算子（部署端可能无 GPU）
- MJLab 自动导出时已附加观测元数据，可通过 `onnxruntime` 的 `session.get_modelmeta()` 验证

---

## 12. 总结

| 维度 | 内容 |
|------|------|
| **训练框架** | MJLab (unitree_rl_mjlab) |
| **任务** | `Unitree-H1_2-Flat`（平地）/ `Unitree-H1_2-Rough`（崎岖） |
| **控制频率** | 50 Hz（decimation=4, sim timestep=5ms） |
| **观测维度** | 92 维（actor）/ 附加 critic 观测 |
| **动作维度** | 27 维（全身关节位置增量） |
| **算法** | PPO，actor/critic (512,256,128) ELU |
| **训练步数** | 10001 iterations × 24 steps × num_envs |
| **ONNX 导出** | 训练中自动导出（`VelocityOnPolicyRunner.save()`） |
| **部署配置** | `deploy/robots/h1_2/config/policy/velocity/v0/` |
| **CUDA 要求** | Driver ≥ 12.4（`mujoco_warp` 依赖） |

---

## 参考

- [12 h1_2 WalkVelocity 策略SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/12%20h1_2%20WalkVelocity%20策略SDK集成.md) — 训练后 ONNX 的真机部署
- [06 unitree_rl_mjlab deploy 架构解读](file:///home/meme/Documents/笔记/02%20Mimic/06%20unitree_rl_mjlab%20deploy%20架构解读.md) — IsaacLab 风格部署框架
- [src/tasks/velocity/config/h1_2/env_cfgs.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/config/h1_2/env_cfgs.py) — H1_2 环境配置
- [src/tasks/velocity/config/h1_2/rl_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/config/h1_2/rl_cfg.py) — PPO 超参数
- [src/tasks/velocity/velocity_env_cfg.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/velocity_env_cfg.py) — Velocity 基础配置
- [src/tasks/velocity/rl/runner.py](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/velocity/rl/runner.py) — ONNX 自动导出
