# 12 h1_2 WalkVelocity 策略SDK集成（MJLab 标准 RLBase 版）

> **系列定位**：在 [09 h1_2 LocoVelocity 步态SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/09%20h1_2%20LocoVelocity%20步态SDK集成.md) 完成高层步态 SDK 集成的基础上，在 `h1_2_mimic_deploy_real` 中新增摇杆驱动行走的 `WalkVelocity` FSM 状态。本版采用 `unitree_rl_mjlab` 标准训练流程与 `State_RLBase` 基类，**不再使用自定义状态类**。

> **实验状态**：⏳ **代码重构完成、编译通过**。`policy.onnx` 需从 MJLab `Unitree-H1_2-Flat` 任务训练导出，真机上机测试待进行。

---

## 1. 背景与目标

### 1.1 与 Note 09 的架构差异

| 项目 | Note 09（LocoVelocity） | 本笔记（WalkVelocity） |
|------|-------------------------|------------------------|
| 控制层级 | **高层**（High-Level）：10~50Hz 下发语义指令 | **底层**（Low-Level）：50Hz 下发关节位置 |
| 控制主体 | 机载 PC1 的 `loco_service`（WBC + MPC 闭环） | 用户侧 ONNX 策略推理 → `lowcmd` DDS 发布 |
| 通信方式 | DDS + RPC 请求/应答（`rt/api/loco/request`） | DDS 话题发布（`rt/lowcmd`, `rt/lowstate`） |
| 策略模型 | 无外部模型，使用固件内置步态算法 | MJLab 训练导出的 ONNX（全身 27 维动作） |
| 运行环境 | **真机实机**（依赖机载 `loco_service`） | **真机实机**（依赖 DDS lowstate） |
| 摇杆数据来源 | DDS `rt/lowstate` 中的真实手柄数据 | DDS `rt/lowstate` 中的真实手柄数据 |
| 观测维度 | 无观测向量（高层语义指令） | 标准全身观测向量（约 92 维） |
| 动作维度 | 无动作向量（速度指令） | 27 维动作向量（全身关节） |
| FSM 状态类型 | — | `RLBase`（复用框架基类，无自定义类） |

### 1.2 为什么需要 WalkVelocity

Note 09 的 LocoVelocity 状态依赖机载 `loco_service`，无法在 MuJoCo 仿真中测试。`WalkVelocity` 填补了这一空缺：

- 利用 ONNX 策略直接控制关节位置（底层控制）
- 通过摇杆实时控制机器人前后/左右/旋转行走
- 摇杆数据从 DDS `rt/lowstate` 中读取
- 可以在 MuJoCo 仿真中测试（通过 DDS 桥接）
- **采用标准 MJLab 训练流程**，与 `g1` / `go2` 等机器人的 Velocity 部署保持代码同源

### 1.3 代码库分支

基于 [h1_2_mimic_deploy_real](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real) 扩展 WalkVelocity 状态，不影响原有 Mimic/LocoVelocity 功能。

---

## 2. 修改总览

| 文件 | 操作 | 说明 |
|------|------|------|
| ~~`include/FSM/State_WalkVelocity.h`~~ | **删除** | 旧版自定义状态类，已废弃 |
| ~~`robots/h1_2/src/State_WalkVelocity.cpp`~~ | **删除** | 旧版自定义状态实现，已废弃 |
| ~~`robots/h1_2/config/policy/walk_velocity/v0/`~~ | **删除** | 旧版 12 维腿部策略配置，已废弃 |
| [robots/h1_2/config/config.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml) | 修改 | WalkVelocity `type` 改为 `RLBase`，`policy_dir` 指向标准路径 |
| [robots/h1_2/config/policy/velocity/v0/params/deploy.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/params/deploy.yaml) | **保留/确认** | 标准 MJLab 格式，全身 27 维 |
| [robots/h1_2/config/policy/velocity/v0/exported/policy.onnx](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/exported/policy.onnx) | **待生成** | 需从 MJLab `Unitree-H1_2-Flat` 训练导出 |

> **旧实现清理**：上述被删除文件已移至 `h1_2_mimic_deploy_real/ToDelete/`。

---

## 3. 核心架构：标准 RLBase + deploy.yaml

### 3.1 状态基类

WalkVelocity **不创建任何自定义 C++ 类**，直接通过 `config.yaml` 指定 `type: RLBase`：

```yaml
WalkVelocity:
  id: 7
  type: RLBase
  policy_dir: config/policy/velocity/v0/
```

`State_RLBase` 基类自动完成：
- ONNX 模型加载与推理
- ObservationManager / ActionManager 调度
- 周期性运行（由 `step_dt` 控制）
- 姿态异常检测（`bad_orientation`）
- 键盘命令注入（仿真测试用）

### 3.2 观测向量组成（标准全身）

`deploy.yaml` 中声明的观测项与 MJLab 训练侧完全一致：

| 观测项 | 维度 | 物理含义 | Scale |
|--------|------|----------|-------|
| `base_ang_vel` | 3 | torso 坐标系角速度（IMU 原始 gyroscope） | 1.0 |
| `projected_gravity` | 3 | torso 坐标系投影重力 | 1.0 |
| `velocity_commands` | 3 | 摇杆速度指令 | 1.0 |
| `gait_phase` | 2 | 步态相位 sin/cos | 1.0 |
| `joint_pos_rel` | 27 | 全身关节位置相对默认值 | 1.0 |
| `joint_vel_rel` | 27 | 全身关节速度 | 1.0 |
| `last_action` | 27 | 上一帧动作 | 1.0 |

**总观测维度**：约 92 维（具体以 `deploy.yaml` 中 `observations` 顺序为准）。

> **注意**：新版不再使用 `base_ang_vel_pelvis` / `projected_gravity_pelvis`。MJLab 的 H1_2 训练配置直接使用 torso frame IMU 数据，因此 deploy 侧无需 pelvis 变换。

### 3.3 动作映射（27 维 → 全身关节）

ONNX 输出 27 维原始动作，由 ActionManager 映射为关节目标位置：

$$q_{des, i} = a_i \cdot \text{scale}_i + \text{offset}_i$$

其中 `scale` 与 `offset` 在 `deploy.yaml` 的 `actions.JointPositionAction` 中定义，对应 `joint_ids_map` 中的 27 个关节。

### 3.4 全身控制

与旧版 12 维腿部策略不同，标准 RLBase 策略**控制全身 27 个关节**（含手臂与腰部），无需在 FSM 中硬编码 `arm_waist_target` / `arm_waist_kp` / `arm_waist_kd`。

---

## 4. FSM 配置详解

### 4.1 状态注册

```yaml
FSM:
  _: # enabled fsms
    Passive: {id: 1}
    FixStand: {id: 2}
    Mimic_Dance1_subject2: {id: 5, type: Mimic}
    LocoVelocity: {id: 6, type: LocoVelocity}
    WalkVelocity: {id: 7, type: RLBase}  # 复用框架基类
```

### 4.2 状态转换

```yaml
FixStand:
  transitions:
    Passive: LT + B.on_pressed
    Mimic_Dance1_subject2: RB + A.on_pressed
    LocoVelocity: RB + X.on_pressed
    WalkVelocity: RB + Y.on_pressed

WalkVelocity:
  transitions:
    Passive: LT + B.on_pressed       # 紧急停止
    FixStand: RT + Y.on_pressed      # 返回站立
  policy_dir: config/policy/velocity/v0/
```

---

## 5. 模型训练与导出

### 5.1 训练

在 `unitree_rl_mjlab` 目录下执行：

```bash
cd ~/Documents/unitree_h1/unitree_rl_mjlab
python scripts/train.py Unitree-H1_2-Flat --env.scene.num-envs=4096
```

训练产物位于 `logs/rsl_rl/h1_2_velocity/<timestamp>/`。

### 5.2 导出

使用 `scripts/play.py` 从 checkpoint 导出 ONNX：

```bash
python scripts/play.py Unitree-H1_2-Flat \
  --checkpoint_file=logs/rsl_rl/h1_2_velocity/<timestamp>/model_xxx.pt
```

将导出的 `policy.onnx`（及可能的 `.onnx.data`）复制到：

```
h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/exported/
```

> ⚠️ **当前状态**：本机 CUDA Driver 为 12.2，低于 `mujoco_warp` 要求的 12.4，暂无法直接训练。需在 CUDA 12.4+ 环境或兼容机器上执行训练。

---

## 6. 编译

```bash
cd ~/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2
rm -rf build && mkdir -p build
cmake -S . -B build
cmake --build build -j$(nproc)
```

产物：`build/h1_2_ctrl`

> ✅ **编译通过**（旧 `State_WalkVelocity` 引用已从 `main.cpp` 移除）。

---

## 7. 真机部署流程

> ⚠️ **安全警告**：WalkVelocity 依赖 DDS lowstate，**仅支持真机实机运行**。部署前务必：
> - 确认机器人处于吊架悬挂状态（安全绳/吊车）
> - 确认急停开关可用
> - 首次测试使用较低的摇杆输入

### 7.1 启动命令

```bash
# 在用户上位机上执行（需与机器人同一网络）
cd ~/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2

export LD_LIBRARY_PATH=\
~/Documents/unitree_h1/h1_2_mimic_deploy_real/thirdparty/onnxruntime-linux-x64-1.22.0/lib:\
~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:\
/usr/local/lib:${LD_LIBRARY_PATH}

./build/h1_2_ctrl --network=eth0   # 根据实际网卡名调整
```

### 7.2 操作步骤

| 步骤 | 手柄操作 | 状态转换 | 说明 |
|------|---------|---------|------|
| 1 | — | 启动进入 Passive | 控制器连接 DDS，等待手柄输入 |
| 2 | LT + ↑ | Passive → FixStand | 机器人从阻尼过渡到硬姿态（约 3s） |
| 3 | RB + Y | FixStand → WalkVelocity | 进入 MJLab ONNX 策略控制（约 1s） |
| 4 | 左摇杆 | 速度行走 | `ly` 控制前后，`lx` 控制横移，`rx` 控制旋转 |
| 5 | LT + B | WalkVelocity → Passive | 紧急回阻尼 |

---

## 8. 关键文件清单

```
h1_2_mimic_deploy_real/
├── include/FSM/
│   └── State_RLBase.h            ← 复用框架基类（无自定义类）
├── robots/h1_2/
│   ├── config/config.yaml        ← 修改（WalkVelocity type=RLBase）
│   ├── config/policy/velocity/v0/
│   │   ├── params/deploy.yaml    ← 标准 MJLab 配置
│   │   └── exported/policy.onnx  ← 待从 MJLab 训练导出
│   ├── src/State_RLBase.cpp      ← 复用框架基类实现
│   └── build/h1_2_ctrl           ← 编译产物
```

---

## 9. 总结

| 维度 | 内容 |
|------|------|
| **代码库** | [h1_2_mimic_deploy_real](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real) |
| **核心源码** | `State_RLBase`（复用框架基类，无自定义状态类） |
| **配置文件** | [deploy.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/params/deploy.yaml) |
| **观测维度** | 标准全身观测（base_ang_vel + projected_gravity + velocity_commands + gait_phase + joint_pos_rel + joint_vel_rel + last_action） |
| **动作维度** | 27 维（全身关节） |
| **特殊处理** | 无 pelvis 变换（MJLab 训练直接使用 torso frame IMU） |
| **编译结果** | ✅ 通过 |
| **数值校验** | ⏳ 待训练导出模型后进行 |
| **运行环境** | **仅真机实机**（依赖 DDS lowstate） |
| **模型状态** | ⏳ 需从 MJLab `Unitree-H1_2-Flat` 训练导出 |

---

## 参考

- [09 h1_2 LocoVelocity 步态SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/09%20h1_2%20LocoVelocity%20步态SDK集成.md) — 高层步态 SDK 集成
- [06 unitree_rl_mjlab deploy 架构解读](file:///home/meme/Documents/笔记/02%20Mimic/06%20unitree_rl_mjlab%20deploy%20架构解读.md) — IsaacLab 风格部署框架
- [unitree_rl_mjlab/deploy/robots/g1/config/policy/velocity](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/g1/config/policy/velocity) — G1 Velocity 标准部署参考
- [unitree_rl_mjlab/deploy/robots/h1_2/config/policy/velocity](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/config/policy/velocity) — H1_2 Velocity 标准部署参考
