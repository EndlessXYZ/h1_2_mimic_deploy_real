# 13 h1_2 WalkVelocity 仿真联调与数值验证（MJLab 标准 RLBase 版）

> **系列定位**：在 [12 h1_2 WalkVelocity 策略SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/12%20h1_2%20WalkVelocity%20策略SDK集成.md) 完成代码重构的基础上，参考 [08 h1_2 deploy 控制器与 MuJoCo 仿真联调](file:///home/meme/Documents/笔记/02%20Mimic/08%20h1_2%20deploy%20控制器与%20MuJoCo%20仿真联调.md) 的 Mimic 仿真联调经验，将 **标准 RLBase** 风格的 WalkVelocity 状态在 MuJoCo 仿真环境中进行闭环联调验证。

> **实验状态**：⏳ **代码重构完成、编译通过**。`policy.onnx` 需从 MJLab `Unitree-H1_2-Flat` 训练导出后方可进行仿真联调与数值校验。

---

## 1. 背景与目标

### 1.1 为什么需要仿真联调

Note 12 完成了 WalkVelocity 的代码重构（`type: RLBase` + 标准 `deploy.yaml`），但标注"`policy.onnx` 待训练导出"。WalkVelocity 的通信依赖（DDS `rt/lowstate`/`rt/lowcmd`）与 Mimic 状态完全一致，而 Note 08 已经验证了 MuJoCo 仿真环境可以提供完整的 DDS 通信链路。因此，在模型导出后，完全可以在仿真环境中验证：

- 状态机切换逻辑（Passive → FixStand → WalkVelocity）
- DDS 通信链路建立
- ONNX 策略推理启动与运行
- 摇杆指令注入与关节目标下发

### 1.2 与 Note 08/12 的关系

| 项目 | Note 12（SDK 集成） | Note 08（Mimic 联调） | 本笔记（WalkVelocity 联调） |
|------|---------------------|----------------------|---------------------------|
| 阶段 | 代码实现 + 配置确认 | 仿真联调验证 | 仿真联调验证（待模型导出后执行） |
| 策略类型 | WalkVelocity（RLBase） | Mimic（Mimic） | WalkVelocity（RLBase） |
| 观测维度 | 标准全身（约 92 维） | 150 维 | 标准全身（约 92 维） |
| 动作维度 | 27 维（全身） | 27 维（全身） | 27 维（全身） |
| 特殊处理 | 无（标准 RLBase） | motion reference 观测 | 无（标准 RLBase） |
| 运行环境 | 标注"待模型导出" | MuJoCo 仿真 | MuJoCo 仿真 |

### 1.3 实验目标

1. 编译控制器并确认无错误
2. 在 MuJoCo 仿真中与控制器建立 DDS 通信
3. 通过键盘模拟手柄触发状态转换：Passive → FixStand → WalkVelocity
4. 验证 WalkVelocity 策略推理正常运行无崩溃
5. 捕获运行日志，记录完整联调流程
6. 进行数值校验（对标 [deploy-numerical-validation SKILL](file:///home/meme/Documents/.trae/skills/deploy-numerical-validation/SKILL.md)）

---

## 2. 数值校验（待模型导出后执行）

### 2.1 校验层级规划

对标 `deploy-numerical-validation SKILL` 的 A-F 全链路断点方法论：

| 校验层级 | 方法 | 目标 | 状态 |
|:---------|:-----|:-----|:----:|
| L1: 公式等价性 | 随机数据，对比 Python 训练侧 vs C++ deploy 侧观测组装 | 误差 0.00e+00 | ⏳ 待模型导出 |
| L2: 全链路轨迹 | MuJoCo Rollout + 传感器路径重建 + ONNX 推理 | 误差 10⁻⁷ | ⏳ 待模型导出 |
| L3: 跨项目代码对比 | A-F 链路逐层对比（SKILL SOP） | 公式等价 | ⏳ 待模型导出 |
| L4: C++ dump 闭环 | MuJoCo 闭环 + C++ dump + Python 重建 | 设计偏差可解释 | ⏳ 待模型导出 |
| L5: 开环注入 | DDS golden → C++ replay → 逐层对比 | 误差 10⁻⁷ | ⏳ 待模型导出 |
| L6: DDS 数据源验证 | MuJoCo 传感器直读 vs DDS lowstate 双路径对比 | 误差 10⁻⁷ | ⏳ 待模型导出 |

### 2.2 观测向量（标准全身）

`deploy.yaml` 中声明的观测项与 MJLab 训练侧完全一致：

| 观测项 | 维度 | 物理含义 | Scale |
|--------|------|----------|-------|
| `base_ang_vel` | 3 | torso 坐标系角速度（IMU 原始 gyroscope） | 1.0 |
| `projected_gravity` | 3 | torso 坐标系投影重力 | 1.0 |
| `velocity_commands` | 3 | 摇杆速度指令 | 1.0 |
| `gait_phase` | 2 | 步态相位 sin/cos | 1.0 |
| `joint_pos_rel` | 27 | 全身关节位置相对默认值 | 1.0 |
| `joint_vel_rel` | 27 | 全身关节速度 | 1.0 |
| `last_action` | 27 | 上一帧动作 | 1.0 |

**总观测维度**：约 92 维（具体以 `deploy.yaml` 中 `observations` 顺序为准）。

> **注意**：新版不再使用 `base_ang_vel_pelvis` / `projected_gravity_pelvis`。MJLab 的 H1_2 训练配置直接使用 torso frame IMU 数据，因此 deploy 侧无需 pelvis 变换，观测组装逻辑与 `g1` / `go2` 等机器人完全一致。

---

## 3. 编译

### 3.1 编译命令

```bash
cd ~/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2
rm -rf build && mkdir -p build
cmake -S . -B build
cmake --build build -j$(nproc)
```

产物：`build/h1_2_ctrl`

> ✅ **编译通过**（旧 `State_WalkVelocity` 引用已从 `main.cpp` 移除）。

### 3.2 与旧版的差异

旧版需要 `#include "FSM/State_WalkVelocity.h"` 以注册自定义状态类，新版直接复用 `State_RLBase`，`main.cpp` 中无需额外头文件。`CtrlFSM` 通过 `config.yaml` 中的 `type: RLBase` 自动识别并实例化基类。

---

## 4. 仿真联调（待模型导出后执行）

### 4.1 键盘映射

WalkVelocity 的状态转换所需的键盘映射（参考 [Note 15 §3.2](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md#32-键盘到手柄的映射)）：

| 键盘 | 手柄映射 | WalkVelocity 用途 |
|------|---------|-------------------|
| Q | LT | 组合键（Q+↑ 进 FixStand, Q+Shift 回 Passive） |
| E | RT | 组合键 |
| V | RB | V+G 进 WalkVelocity |
| G | Y | 组合键 |
| Space | A | MuJoCo 仿真启动 |
| Left Shift | B | 紧急停止组合键 |
| ↑ | up / ry | Passive→FixStand 触发 |
| W/S/A/D | ly/lx | WalkVelocity 行走控制 |
| 9 | — | 启用弹性吊带 |

### 4.2 键盘模拟方案：Xlib XTEST

由于联调在无实体手柄的远程环境中进行，且 `xdotool` 未安装，本次采用 **Python + python-xlib** 的 XTEST 扩展方案模拟键盘输入。

**安装依赖**：

```bash
pip3 install --user python-xlib
```

**原理**：XTEST 是 X11 的测试扩展，可在 X Server 层级注入键盘事件，效果等同于物理按键。MuJoCo 的 `KeyboardJoystick` 通过 `glfwGetKey()` 轮询按键状态，GLFW 接收 X11 事件后更新内部状态表，因此 XTEST 注入的事件能被正确检测。

**脚本**：复用 `sim_walk_velocity_keyboard.py`（或 `sim_mimic_keyboard.py` 改版）。

核心流程：
1. 通过 Xlib 遍历窗口树，找到标题为 `"MuJoCo : Unitree H1-1"` 的窗口并聚焦
2. 使用 `xtest.fake_input(display, X.KeyPress, keycode)` 注入按键按下事件
3. 等待指定时长后注入 `X.KeyRelease` 释放按键
4. 组合键通过先 hold 第一键、再 press 第二键、最后依次 release 实现

### 4.3 启动命令

#### 终端 1：启动 MuJoCo

```bash
cd ~/Documents/unitree_h1/unitree_mujoco/simulate

export CYCLONEDDS_URI='<CycloneDDS><Domain><General><NetworkInterfaceAddress>lo</NetworkInterfaceAddress></General><Discovery><EnableTopicDiscovery>true</EnableTopicDiscovery></Discovery></Domain></CycloneDDS>'

export DISPLAY=:0
export XAUTHORITY=/run/user/1000/gdm/Xauthority
export LD_LIBRARY_PATH=~/Documents/unitree_h1/local_deps/usr/lib/x86_64-linux-gnu:~/Documents/unitree_h1/unitree_mujoco/simulate/mujoco/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:/usr/local/lib:${LD_LIBRARY_PATH}

./build/unitree_mujoco -i 0 -n lo -r h1_2 -s scene.xml
```

#### 终端 2：启动控制器

```bash
cd ~/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2

export CYCLONEDDS_URI='<CycloneDDS><Domain><General><NetworkInterfaceAddress>lo</NetworkInterfaceAddress></General><Discovery><EnableTopicDiscovery>true</EnableTopicDiscovery></Discovery></Domain></CycloneDDS>'

export LD_LIBRARY_PATH=~/Documents/unitree_h1/h1_2_mimic_deploy_real/thirdparty/onnxruntime-linux-x64-1.22.0/lib:~/Documents/unitree_h1/unitree_sdk2/thirdparty/lib/x86_64:/usr/local/lib:${LD_LIBRARY_PATH}

./build/h1_2_ctrl lo
```

#### 终端 3：运行键盘模拟

```bash
cd ~/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/tools
DISPLAY=:0 python3 sim_walk_velocity_keyboard.py
```

### 4.4 键盘触发流程

脚本自动执行以下 6 步操作：

| 步骤 | 按键 | 状态转换 | 等待时间 |
|------|------|---------|---------|
| 1 | Space | 启动 MuJoCo 仿真循环 | 1.5s |
| 2 | 9 | 启用弹性吊带 | 1.0s |
| 3 | Q + ↑ | Passive → FixStand | 5.0s |
| 4 | V + G (RB + Y) | FixStand → WalkVelocity | 3.0s |
| 5 | W | 驱动前进行走 | 3.0s |
| 6 | Q + Left Shift (LT + B) | WalkVelocity → Passive | 1.0s |

---

## 5. 实验日志（待模型导出后填充）

> ⏳ **待 MJLab 模型训练导出后进行仿真联调，此处预留实验日志区域。**

预期验证项：
- DDS 通信链路建立（`Connected to robot`）
- 状态机切换 Passive → FixStand → WalkVelocity → Passive 全流程通过
- WalkVelocity 策略推理正常运行无崩溃
- 摇杆指令正确注入，机器人按指令行走

---

## 6. 常见问题

### Q1: 控制器报 `policy.onnx not found`

**原因**：`config/policy/velocity/v0/exported/policy.onnx` 缺失。

**解决**：需先从 MJLab `Unitree-H1_2-Flat` 训练并导出模型，复制到上述路径。

### Q2: 训练时报 `Minimum supported CUDA version: 12.4`

**原因**：本机 CUDA Driver 为 12.2，低于 `mujoco_warp` 要求的 12.4。

**解决**：在 CUDA 12.4+ 环境或兼容机器上执行训练。训练命令：

```bash
cd ~/Documents/unitree_h1/unitree_rl_mjlab
python scripts/train.py Unitree-H1_2-Flat --env.scene.num-envs=4096
```

### Q3: 状态机报 `Unknown FSM type RLBase`

**原因**：`main.cpp` 未包含 `State_RLBase.h`（但旧版已包含，因为 Mimic 也使用 RLBase）。

**解决**：确认 `main.cpp` 中已有 `#include "FSM/State_RLBase.h"`。

---

## 7. 修改文件清单

| 文件 | 操作 | 说明 |
|------|------|------|
| ~~`include/FSM/State_WalkVelocity.h`~~ | **删除** | 旧版自定义状态类，已废弃 |
| ~~`robots/h1_2/src/State_WalkVelocity.cpp`~~ | **删除** | 旧版自定义状态实现，已废弃 |
| ~~`robots/h1_2/config/policy/walk_velocity/v0/`~~ | **删除** | 旧版 12 维腿部策略配置，已废弃 |
| [robots/h1_2/config/config.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/config.yaml) | 修改 | WalkVelocity `type` 改为 `RLBase`，`policy_dir` 指向标准路径 |
| [robots/h1_2/config/policy/velocity/v0/params/deploy.yaml](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/params/deploy.yaml) | **保留/确认** | 标准 MJLab 格式，全身 27 维 |
| [robots/h1_2/config/policy/velocity/v0/exported/policy.onnx](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/config/policy/velocity/v0/exported/policy.onnx) | **待生成** | 需从 MJLab `Unitree-H1_2-Flat` 训练导出 |
| [robots/h1_2/main.cpp](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real/robots/h1_2/main.cpp) | 修改 | 移除 `State_WalkVelocity.h` 引用，更新提示语 |

> **旧实现清理**：上述被删除文件已移至 `h1_2_mimic_deploy_real/ToDelete/`。

---

## 8. 总结

| 维度 | 内容 |
|------|------|
| **代码库** | [h1_2_mimic_deploy_real](file:///home/meme/Documents/unitree_h1/h1_2_mimic_deploy_real) |
| **核心源码** | `State_RLBase`（复用框架基类，无自定义状态类） |
| **数值校验** | ⏳ 待训练导出模型后进行（对标 deploy-numerical-validation SKILL） |
| **编译结果** | ✅ 通过 |
| **DDS 通信** | ⏳ 待模型导出后验证 |
| **状态转换** | ⏳ 待模型导出后验证 |
| **策略运行** | ⏳ 待模型导出后验证 |
| **代码修复** | 删除旧 `State_WalkVelocity` 类及引用，改为标准 `RLBase` |
| **键盘方案** | Python + python-xlib XTEST 扩展（复用旧脚本） |
| **运行环境** | MuJoCo 仿真 |
| **模型状态** | ⏳ 需从 MJLab `Unitree-H1_2-Flat` 训练导出 |

---

## 参考

- [12 h1_2 WalkVelocity 策略SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/12%20h1_2%20WalkVelocity%20策略SDK集成.md) — WalkVelocity 重构设计文档
- [08 h1_2 deploy 控制器与 MuJoCo 仿真联调](file:///home/meme/Documents/笔记/02%20Mimic/08%20h1_2%20deploy%20控制器与%20MuJoCo%20仿真联调.md) — Mimic 仿真联调经验
- [09 h1_2 LocoVelocity 步态SDK集成](file:///home/meme/Documents/笔记/02%20Mimic/09%20h1_2%20LocoVelocity%20步态SDK集成.md) — LocoVelocity 高层步态集成
- [15 Onnx-CppSDK 仿真部署实验 P2 键盘输入](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/15%20Onnx-CppSDK%20仿真部署实验%20P2%20键盘输入.md) — 键盘手柄模拟原理
- [16 Onnx-CppSDK 仿真部署实验 P3 检验输出](file:///home/meme/Documents/笔记/01%20宇树SDK与策略部署/16%20Onnx-CppSDK%20仿真部署实验%20P3%20检验输出.md) — 严格数值校验方法论与存档
- [deploy-numerical-validation SKILL](file:///home/meme/Documents/.trae/skills/deploy-numerical-validation/SKILL.md) — 全链路数值对齐校验 SOP
- [unitree_rl_mjlab/deploy/robots/g1/config/policy/velocity](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/g1/config/policy/velocity) — G1 Velocity 标准部署参考
- [unitree_rl_mjlab/deploy/robots/h1_2/config/policy/velocity](file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/deploy/robots/h1_2/config/policy/velocity) — H1_2 Velocity 标准部署参考
