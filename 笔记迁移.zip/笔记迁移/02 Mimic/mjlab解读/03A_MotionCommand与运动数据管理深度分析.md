# 03A MotionCommand 与运动数据管理深度分析

> **核心主题**：围绕 unitree_rl_mjlab 的 MotionCommand 与 MotionLoader 源码，融合 BeyondMimic 论文（arXiv:2508.08241）原文内容，对比 whole_body_tracking、motion_tracking_controller、Mini-Pi-Plus_BeyondMimic、unitree_rl_mjlab 四仓库的异构设计，深度剖析运动数据加载、管理、采样、可视化全链路。

---

## 一、引言

运动数据管理是 Motion Tracking 任务的**根基**。在 BeyondMimic 的框架中，策略所学习的全部行为信息——从简单的步行到极限的空中翻滚——都源自参考运动数据。数据的加载方式、索引机制、采样策略、循环模式，直接决定了训练的收敛效率与部署时的行为质量。

论文 BeyondMimic（arXiv:2508.08241）提出了一个核心主张：

> **"Compact motion-tracking formulation enables mastering a wide range of radically agile behaviors with a single setup and shared hyperparameters."**

这句主张的两个关键点在于：(1) motion-tracking 的公式化设计必须**紧凑**（compact），即数据流从加载到暴露给策略的每一环节都要高效无冗余；(2) 单一超参数集覆盖**广泛**的激进运动类型——这意味着数据管理系统必须具备足够的灵活性和鲁棒性。

此外，论文还特别强调系统实现的重要性：

> **"Carefully model the robot actuation based on classical mechanics principles and ensure proper system implementation to minimize deployment discrepancies, such as delays."**

在运动数据管理层面，"proper system implementation" 体现为三方面：运动数据加载的精度（FPS 一致性）、参考帧索引的同步（训练/部署公式等价）、以及部署时 ONNX 复合模型的数据封装（零数据传输开销）。

本文将以 `unitree_rl_mjlab/src/tasks/tracking/mdp/commands.py` 的 `MotionLoader` 和 `MotionCommand` 为核心，展开深度分析。

---

## 二、四仓库全景概述

在深入源码之前，有必要建立四个仓库的整体认知。这四个仓库分别承担了 BeyondMimic 生态的不同角色：

| 仓库 | 角色 | 主要技术栈 | 核心功能 |
|------|------|-----------|---------|
| **whole_body_tracking** | 官方训练库 | IsaacLab + IsaacSim + RSL-RL | 单 NPZ 运动加载、PPO 训练、ONNX 导出 |
| **motion_tracking_controller** | 官方部署库 | ROS 2 + ONNX Runtime C++ + Pinocchio | 真机/仿真 ONNX 推理、观测组装 |
| **Mini-Pi-Plus_BeyondMimic** | 数据链最完整 | GMR→BVH→CSV→NPZ + MimicKit | 运动重定向全流程、Pi-Plus 机器人适配 |
| **unitree_rl_mjlab** | 宇树训练库 | mjlab + MuJoCo + RSL-RL | 多运动 YAML 配置、FPS 感知、Ghost 可视化 |

这种分离架构本身即是一种设计决策：训练（Python/IsaacLab/IsaacSim）、部署（C++/ROS 2）、数据生产（Python 重定向脚本）各自独立，彼此通过 ONNX 和 NPZ 这两个通用接口连接。

### 2.1 引用源码位置约定

本文所有源码引用使用以下前缀约定：

- `wbt:` → `file:///home/meme/Documents/github_code/whole_body_tracking/source/whole_body_tracking/whole_body_tracking/`
- `mtc:` → `file:///home/meme/Documents/github_code/motion_tracking_controller/`
- `ure:` → `file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/commands.py`
- `mimickit:` → `file:///home/meme/Documents/github_code/MimicKit/`

---

## 三、运动数据加载的全链条设计

### 3.1 从 Human Motion Capture 到 NPZ 的完整流程

一个典型的运动数据加载链路包含以下阶段：

```
Human Motion Capture (Mocap)
    ↓ BVH (BioVision Hierarchy) — 通用人体骨骼动画格式
    ↓ Motion Retargeting — 将人体骨骼映射到机器人骨骼
    ↓ CSV — 重定向后的关节角度序列（每行 = 时间帧 × 关节维度）
    ↓ Forward Kinematics — 通过 MuJoCo/IsaacLab 计算 body 位姿和速度
    ↓ NPZ — 最终训练输入格式
```

`Mini-Pi-Plus_BeyondMimic`（存放在 `github_code/MimicKit/` 中）的 `tools/gmr_to_mimickit/` 提供了最完整的数据链参考。其流程为：

1. **GMR**：Game Motion Retargeting 格式的 `.pkl` 文件，包含原始动捕数据
2. **BVH**：通过 `gmr_to_mimickit.py`（`mimickit:tools/gmr_to_mimickit/gmr_to_mimickit.py`）转换
3. **CSV**：中间格式，每行包含时间戳和关节角度
4. **NPZ**：最终训练格式，由 `csv_to_npz.py`（`wbt:scripts/csv_to_npz.py`）通过 MuJoCo 前向动力学计算 body 数据

`csv_to_npz.py` 脚本的作用尤为关键：原始 CSV 只包含关节角度序列，但策略训练需要 body 级别的位姿和速度数据。该脚本通过 MuJoCo `sim.forward()` 为每个刚体 link 生成世界坐标系下的位置、姿态（四元数 wxyz）和速度，最终打包为 `.npz`。

NPZ 文件内部包含以下字段：

| 字段 | 维度 | 说明 |
|------|------|------|
| `fps` | 标量 | 运动帧率（通常 50Hz） |
| `joint_pos` | (N, D) | D 个关节的角度位置 |
| `joint_vel` | (N, D) | D 个关节的角速度 |
| `body_pos_w` | (N, B, 3) | B 个刚体在世界系中的位置 |
| `body_quat_w` | (N, B, 4) | B 个刚体在世界系中的姿态（wxyz） |
| `body_lin_vel_w` | (N, B, 3) | B 个刚体的世界系线速度 |
| `body_ang_vel_w` | (N, B, 3) | B 个刚体的世界系角速度 |

其中 N 为总帧数，D 为机器人关节数（H1_2 为 27，G1 为 29），B 为刚体数量。

### 3.2 三种运动输入形式

`unitree_rl_mjlab` 的 `MotionLoader`（`ure:45-180`）支持三种运动输入形式，这是区别于 `whole_body_tracking` 单 NPZ 设计的核心差异：

#### 3.2.1 单 NPZ 文件

最直接的输入方式，直接指定 `.npz` 文件路径。所有运动使用默认的 WRAP（循环）模式，权重为 1.0。

```python
MotionLoader("walk.npz", body_indexes, device="cpu", step_dt=0.02)
```

#### 3.2.2 NPZ 元组

传入字符串元组，加载多个运动。所有运动权重均等（`[1.0] * len(file_list)`），循环模式统一为 `WRAP`。

```python
MotionLoader(("walk.npz", "run.npz", "turn.npz"), body_indexes, device="cpu", step_dt=0.02)
```

元组形式的局限性在于无法单独控制每个运动的权重和循环模式。

#### 3.2.3 YAML 配置文件（最灵活）

YAML 格式是 unitree_rl_mjlab 的最大亮点之一，允许为每个运动独立指定 weight、loop_mode 和 name：

```yaml
# motions.yaml
motions:
  - file: "walk.npz"
    weight: 2.0
    loop_mode: "wrap"
    name: "walk"
  - file: "stand.npz"
    weight: 1.0
    loop_mode: "clamp"
    name: "stand"
  - file: "backflip.npz"
    weight: 0.5
    loop_mode: "wrap"
    name: "backflip"
```

`_load_from_yaml` 方法（`ure:159-180`）解析此 YAML 后返回 `(file_list, weights, loop_modes, names)` 四元组。其中 `name` 字段在 ONNX 导出时写入 `deploy.yaml`，用于部署侧多运动选择。

### 3.3 四仓库数据输入对比

| 特性 | whole_body_tracking | motion_tracking_controller | Mini-Pi-Plus | unitree_rl_mjlab |
|------|:---:|:---:|:---:|:---:|
| 单 NPZ | ✅ | ❌（仅 ONNX） | ✅（PKL 格式） | ✅ |
| 多 NPZ | ❌ | ❌ | ✅ | ✅ |
| YAML 配置 | ❌ | ❌ | ✅（dataset YAML） | ✅ |
| 权重控制 | N/A | N/A | ✅ | ✅ |
| 循环模式 | WRAP 唯一 | N/A | WRAP/CLAMP | WRAP/CLAMP |
| 名称字段 | N/A | N/A | ❌ | ✅ |
| 数据格式 | NPZ | ONNX 内嵌 | PKL | NPZ |
| FPS 字段 | NPZ 内 | ONNX 元数据 | 硬编码 | NPZ 内（动态读取） |

**关键观察**：

- `whole_body_tracking` 作为官方训练库，只支持单 NPZ 文件——这与论文 "shared hyperparameters" 的主张看似矛盾，实则因为论文训练的是**单一复合运动**（2.5 小时多样化数据打包为一个 NPZ），而非多运动混合。
- `unitree_rl_mjlab` 的 YAML 配置系统最灵活，适应了宇树机器人多运动切换的部署需求。
- `motion_tracking_controller` 完全不需要直接加载运动数据——因为运动数据已经以 buffer 形式内嵌在 ONNX 复合模型中，由训练时 `exporter.py`（`wbt:utils/exporter.py`）打包。

---

## 四、MotionLoader 核心实现深度分析

### 4.1 拼接张量设计：`_length_starts` 的数学原理

`MotionLoader` 将所有运动的数据拼接到单一连续张量中：

```python
self._joint_pos_all = torch.cat(all_joint_pos, dim=0)
self._joint_vel_all = torch.cat(all_joint_vel, dim=0)
# ... etc for all 6 data arrays
```

同时维护 `_length_starts` 记录每个运动在拼接张量中的起始偏移量：

```python
cumulative = [0]
for nf in motion_num_frames:
    cumulative.append(cumulative[-1] + nf)
self._length_starts = torch.tensor(cumulative[:-1], dtype=torch.long, device=device)
```

这种设计使得帧索引可以通过**统一索引**完成：对于多运动场景，全局帧索引为 `_length_starts[current_motion_idx] + local_frame`。

**为什么用 cat 而非分片（slice）？**

这个设计选择背后有几个关键考量：

1. **GPU 访存连续性**：拼接后的连续张量在 GPU 显存中紧密排列，`frame_idx` 索引时触发的是**连续读取**（coalesced access），而非分片方案的**间接索引**（indexed access）。对于训练中每步数千个环境的并发帧索引，连续读取的带宽利用率高出数倍。

2. **单一索引操作**：单张量只需要一次 `gather` 操作即可完成所有环境的帧索引，而分片方案需要遍历各运动、分别索引再拼接——后者在多运动场景下会引入同步开销。

3. **简化 ONNX 导出**：复合模型导出时只需将单一张量注册为 buffer，无需处理分片逻辑。

### 4.2 FPS 感知机制

FPS 感知是 unitree_rl_mjlab 相对 whole_body_tracking 的关键改进。其数学表达式为：

$$\text{frames\_per\_step} = \text{fps} \times \text{step\_dt}$$

其中 `step_dt` 是环境步长（`env.step_dt`），由控制频率和 decimation 共同决定：

$$\text{step\_dt} = \text{sim.dt} \times \text{decimation}$$

例如对于典型的 H1_2 配置：`sim.dt=0.005`、`decimation=4`，则 `step_dt=0.02s`（50Hz 控制频率）。此时：

- 50FPS 运动：每步推进 `50 × 0.02 = 1.0` 帧
- 100FPS 运动：每步推进 `100 × 0.02 = 2.0` 帧

`_motion_steps` 的计算将总帧数映射为环境步数：

$$\text{motion\_steps} = \left\lceil \frac{\text{num\_frames}}{\text{frames\_per\_step}} \right\rceil$$

`ure:134-136`：

```python
self._frames_per_step = self._motion_fps * self._step_dt
self._motion_steps = (self._motion_num_frames.float() / self._frames_per_step).ceil().long()
```

帧索引的转换在 `_get_step_frame()` 中完成（`ure:281-294`）：

```python
def _get_step_frame(self) -> torch.Tensor:
    fps = self.motion._motion_fps[self.current_motion_idx]
    frame_idx = (self.time_steps.float() * self.motion._step_dt * fps).long()
    # ... clamp and offset for multi-motion
```

对比 `whole_body_tracking` 的 `MotionLoader`（`wbt:mdp/commands.py`），其实现更为简单——直接以帧为单位索引，没有显式的 FPS 感知。这意味着如果训练时的 step_dt 配置与 NPZ 的 FPS 不匹配，whole_body_tracking 需要手工调整。

### 4.3 两种循环模式

#### 4.3.1 WRAP 模式

WRAP 模式在运动播放到末尾后回到第 0 帧，并累加 `wrap_delta`：

```python
if loop_modes[i] == LoopMode.WRAP:
    root_pos_first = bp[0, 0, :3]   # 首帧根位置
    root_pos_last = bp[-1, 0, :3]    # 末帧根位置
    delta = root_pos_last - root_pos_first
    delta[2] = 0.0                   # Z 方向归零
    wrap_deltas.append(delta)
```

`wrap_delta` 的 Z 方向归零是一个非常精巧的设计。其物理含义是：WRAP 模式只补偿水平位移（XY），使得机器人可以持续向前行走；而垂直方向的高度变化（如步态中的重心起伏）由奖励函数和终止条件共同约束，不通过位置偏移来补偿。

在 `_update_command()` 中的处理：

```python
if wrap_mask.any():
    wrap_env_ids = env_ids_at_end[wrap_mask]
    self.time_steps[wrap_env_ids] = 0
    wrap_deltas = self.motion._motion_wrap_delta[self.current_motion_idx[wrap_env_ids]]
    self._wrap_offset[wrap_env_ids] += wrap_deltas
```

这种设计使得 WRAP 模式实际上隐含了一个假设：运动数据的首末帧是**可拼接的**（即末帧的关节角度与首帧接近，只有根位置发生了位移）。如果首末帧不连续（如空中翻滚的落地→起跳），WRAP 会导致状态跳变。

#### 4.3.2 CLAMP 模式

CLAMP 模式播放到末尾后触发 `TerminationType.SUCC`（成功终止）：

```python
if clamp_mask.any():
    clamp_env_ids = env_ids_at_end[clamp_mask]
    self.termination_type[clamp_env_ids] = TerminationType.SUCC
```

SUCC 终止意味着环境会被重置，即"这个运动已经成功播放完毕"。CLAMP 模式适用于有明确终点的运动（如站立、特定舞蹈姿势），而非周期性运动。

### 4.4 与 whole_body_tracking 的 MotionLoader 对比

`whole_body_tracking` 的 `MotionLoader`（`wbt:mdp/commands.py:30-58`）实现极为简洁：

```python
class MotionLoader:
    def __init__(self, motion_file, body_indexes, device="cpu"):
        data = np.load(motion_file)
        self.fps = data["fps"]
        self.joint_pos = torch.tensor(data["joint_pos"], ...)
        # ... load all 6 arrays
        self.time_step_total = self.joint_pos.shape[0]
```

| 对比维度 | whole_body_tracking | unitree_rl_mjlab |
|----------|-------------------|------------------|
| 多运动支持 | ❌ 单 NPZ | ✅ 支持 YAML/元组 |
| 循环模式 | ❌ 无（固定到末帧终止） | ✅ WRAP + CLAMP |
| FPS 感知 | ❌ 帧索引 | ✅ `fps × step_dt` 转换 |
| body 索引 | ✅ property 筛选 | ✅ 加载时筛选 |
| wrap_delta | ❌ | ✅ |
| 多运动权重 | N/A | ✅ `torch.multinomial` |

本质上，`whole_body_tracking` 的 MotionLoader 是一个**轻量级数据容器**，而 unitree_rl_mjlab 的 MotionLoader 则是一个**完整的多运动管理系统**。

---

## 五、RSI（Residual Stage-wise Imitation）扰动机制

### 5.1 三段噪声的数学定义

RSI 是 Motion Tracking 中关键的随机化技术。与域随机化（DR）不同，RSI 作用于**参考运动状态**而非物理参数。它在每个回合开始时对参考运动施加三类噪声：

#### 5.1.1 位姿扰动

$$\begin{aligned}
\mathbf{p}' &= \mathbf{p} + \delta_p, \quad \delta_p \sim \mathcal{U}(-\text{range}_p, \text{range}_p) \\
\mathbf{q}' &= \delta_q \otimes \mathbf{q}, \quad \delta_q \text{ from Euler angles } \delta_\theta \sim \mathcal{U}(-\text{range}_\theta, \text{range}_\theta)
\end{aligned}$$

H1_2 的默认参数（`ure:566-578`）：

| 分量 | 范围 | 物理意义 |
|------|------|---------|
| x, y | ±0.05m | 水平位置偏移 |
| z | ±0.01m | 垂直位置偏移 |
| roll, pitch | ±0.1rad (±5.7°) | 倾斜扰动 |
| yaw | ±0.2rad (±11.5°) | 航向扰动 |

#### 5.1.2 速度扰动

$$ \mathbf{v}' = \mathbf{v} + \delta_v, \quad \delta_v \sim \mathcal{U}(-\text{range}_v, \text{range}_v) $$

| 分量 | 范围 |
|------|------|
| x, y 线速度 | ±0.5m/s |
| z 线速度 | ±0.2m/s |
| roll, pitch 角速度 | ±0.52rad/s |
| yaw 角速度 | ±0.78rad/s |

#### 5.1.3 关节位置扰动

$$ \mathbf{j}' = \text{clip}(\mathbf{j} + \delta_j, \mathbf{l}_{\text{soft}}, \mathbf{u}_{\text{soft}}), \quad \delta_j \sim \mathcal{U}(-0.1, 0.1)\,\text{rad} $$

每个关节位置施加 ±0.1rad 的噪声后，通过 `soft_joint_pos_limits` 裁剪到合法范围内。

### 5.2 与论文 Actuation Modeling 的联系

论文 BeyondMimic 在 actuation modeling 中有这样一段描述：

> **"Carefully model the robot actuation based on classical mechanics principles and ensure proper system implementation to minimize deployment discrepancies, such as delays."**

RSI 是这段话在运动数据层面的具体实现。论文指出，真机部署时机器人的初始状态与参考运动之间存在以下偏差：

1. **位置偏差**：真机落地的精确位置与参考首帧不同
2. **姿态偏差**：机器人可能不是完全水平的
3. **速度偏差**：初始运动速度不匹配
4. **关节偏差**：编码器读数与参考关节角度之间的偏移

RSI 通过在训练时**模拟这些偏差**，迫使策略学会从非理想初始状态**纠正回参考轨迹**的能力。这正是"跟踪"（tracking）而非"开环播放"（open-loop playback）的核心能力。

特别值得注意的是 `write_joint_state_to_sim` 和 `write_root_state_to_sim` —— RSI 通过这两个方法直接写入仿真状态（`ure:603-618`）：

```python
self.robot.write_joint_state_to_sim(joint_pos[env_ids], joint_vel[env_ids], env_ids=env_ids)
root_state = torch.cat([root_pos[env_ids], root_ori[env_ids], root_lin_vel[env_ids], root_ang_vel[env_ids]], dim=-1)
self.robot.write_root_state_to_sim(root_state, env_ids=env_ids)
self.robot.clear_state(env_ids=env_ids)
```

### 5.3 RSI 参数设计依据

RSI 的噪声范围不是随意设定的，而是与真机的物理误差范围密切相关：

- **yaw ±0.2rad**：对应真机落地方向与预期方向的最大航向偏差（约 11.5°）
- **position ±0.05m**：对应足式机器人落足位置的典型误差范围
- **joint_pos ±0.1rad**：对应编码器零位偏移和负载变形的综合误差
- **velocity ±0.5m/s**：对应真机初始状态的速度不确定度

论文特别强调：

> **"Domain randomization only to truly uncertain physical properties."**

这暗示了一个重要设计原则：**不要随机化已经确知的物理属性**。RSI 是对"初始状态的不确定性"这一**认知不确定性**（epistemic uncertainty）建模，而非对"物理参数的不确定性"（aleatoric uncertainty）建模。两者分别通过 RSI 和域随机化处理，各司其职。

---

## 六、三种采样模式的数学原理

`MotionCommand` 支持三种采样模式（`sampling_mode` 参数），控制每个回合起始帧的选择策略。

### 6.1 Start 模式（评估模式）

最简单的模式——始终从第 0 帧开始：

```python
if self.cfg.sampling_mode == "start":
    self.time_steps[env_ids] = 0
```

在 play 配置中，此模式配合 `pose_range` 和 `velocity_range` 清空（禁用 RSI）、`enable_corruption=False`（禁用观测噪声），构成**纯粹的跟踪能力测试**环境。

### 6.2 Uniform 模式（均匀随机）

```python
all_sampled_time_steps[m_env_idx_in_list] = torch.randint(0, ns, (m_count,), device=self.device)
```

每个时间步被选中的概率相等：

$$P(i) = \frac{1}{N}, \quad i \in [0, N-1]$$

简单但无针对性——策略在容易的时段得到过多样本，在困难的时段样本不足。

### 6.3 Adaptive 模式（核心）

自适应采样是 unitree_rl_mjlab 的关键创新，其核心思想是：**给策略经常失败的时段更多采样机会**。

#### 6.3.1 分桶策略

运动被划分为若干个"桶"（bin），每个桶代表一个固定大小的时间窗口：

**`ure:219-238`**：

```python
fps = self.motion._motion_fps[m_idx].item()
frames_per_bin = max(1, int(round(fps * env.step_dt)))
nb = int(nf / frames_per_bin) + 1
```

这里的 `frames_per_bin` 与 FPS 感知机制一致：

$$\text{frames\_per\_bin} = \max(1, \left\lfloor \text{fps} \times \text{step\_dt} \right\rfloor)$$

因此每个桶对应**一个环境步**的时间窗口，这使得桶索引可以直接映射到 `time_steps` 空间，无需帧→步的额外转换。

#### 6.3.2 EMA 失败率追踪

使用指数移动平均（EMA）维护每个桶的失败率：

`**ure:678-684**`：

```python
self._motion_bin_failed_count[m_idx] = (
    self.cfg.adaptive_alpha * self._motion_current_bin_failed[m_idx]
    + (1 - self.cfg.adaptive_alpha) * self._motion_bin_failed_count[m_idx]
)
```

$$\text{fail\_count}_{t+1} = \alpha \cdot \text{current\_fail} + (1-\alpha) \cdot \text{fail\_count}_t$$

`alpha=0.001` 是一个非常小的学习率，意味着失败率的更新非常平滑——单次失败对整体分布的冲击极小，需要数百次失败才能显著改变采样概率。这防止了采样分布过于不稳定地波动。

#### 6.3.3 核平滑

**`ure:249-253`**：

```python
self.kernel = torch.tensor(
    [self.cfg.adaptive_lambda**i for i in range(self.cfg.adaptive_kernel_size)],
    device=self.device,
)
self.kernel = self.kernel / self.kernel.sum()
```

这是一个几何序列核：

$$\text{kernel}[i] = \frac{\lambda^i}{\sum_{j=0}^{K-1} \lambda^j}, \quad i = 0, 1, \dots, K-1$$

其中 $\lambda=0.8$，$K$ 为 `adaptive_kernel_size`。核平滑将邻近桶的失败信息传播到当前桶，确保采样概率分布的平滑性。物理意义是：如果策略在帧 $t$ 失败附近，帧 $t \pm \Delta t$ 也应该是困难的——因为运动状态在时间上是连续的。

#### 6.3.4 均匀混合

```python
sampling_probabilities = (
    self._motion_bin_failed_count[m_idx]
    + self.cfg.adaptive_uniform_ratio / float(nb)
)
```

`adaptive_uniform_ratio=0.1` 给每个桶添加一个固定的均匀概率"底数"，确保没有任何桶的采样概率降至绝对零。这避免了两种失败情况：

1. **过早放弃**：如果策略在某时段连续失败，EMA 失败率可能很高，但即便困难模式也需要偶尔"尝试"看看是否已经学会。
2. **零概率锁定**：如果某个桶从未被尝试过，失败率为 0，但在均匀混合下仍有 $\frac{0.1}{N}$ 的概率被采样。

最终的概率密度函数为：

$$P(i) = \frac{f_i + \frac{\gamma}{N}}{\sum_j (f_j + \frac{\gamma}{N})}$$

其中 $f_i$ 为桶 $i$ 的平滑失败计数，$\gamma=0.1$ 为均匀混合比例，$N$ 为桶数。

#### 6.3.5 信息论指标

自适应采样模块维护三个关键指标：

```python
H = -(sampling_probabilities * (sampling_probabilities + 1e-12).log()).sum()
H_norm = H / math.log(nb) if nb > 1 else 1.0
pmax, imax = sampling_probabilities.max(dim=0)
```

- **归一化熵 $H_{\text{norm}}$**：衡量采样分布的均匀程度。$H_{\text{norm}} \to 1$ 表示接近均匀分布（所有时段难度相当），$H_{\text{norm}} \to 0$ 表示分布极度集中（少数时段特别困难）。
- **Top-1 概率 $p_{\max}$**：最困难桶被采样的概率，用于判断是否有极端困难时段。
- **Top-1 桶位置 $i_{\max}$**：最困难桶在运动中的时间位置。

$1e-12$ 的 epsilon 防止 $\log(0)$。

### 6.4 与 whole_body_tracking 自适应采样的异同

`whole_body_tracking` 的自适应采样（`wbt:mdp/commands.py:207-241`）与 unitree_rl_mjlab 的核心差异如下：

| 特性 | whole_body_tracking | unitree_rl_mjlab |
|------|:---:|:---:|
| 分桶基于 | 环境步数（`bin_count = total_frames / step_dt`） | FPS 感知（`frames_per_bin = fps × step_dt`） |
| 多运动支持 | ❌ 单桶数组 | ✅ 每个运动独立维护 |
| 核平滑 | ✅ 相同几何级数核 | ✅ 相同 |
| EMA alpha | 0.001 | 0.001 |
| 均匀混合 | 0.1 | 0.1 |
| 采样操作 | `torch.multinomial` | `torch.multinomial` |
| 信息论指标 | ✅ 熵 + Top-1 | ✅ 熵 + Top-1（单运动时） |

**关键结论**：两个仓库的自适应采样核心逻辑几乎完全相同，参数也一致。unitree_rl_mjlab 的主要改进是将采样从"帧空间"改为"环境步空间"，并增加了多运动独立维护。

### 6.5 与论文的联系

论文 BeyondMimic 在训练配置中采用 `observation history N=4`、`prediction horizon H=1`：

> 论文未显式使用自适应采样，而是通过 observation history 的 4 帧堆叠来隐式推断运动阶段。

这意味着论文策略能够通过历史观测的时序信息"感知"当前位于运动的哪个阶段（例如通过关节速度模式识别是"起跳阶段"还是"腾空阶段"），从而不需要显式的自适应采样机制来分配训练样本。

unitree_rl_mjlab 在观测系统中同样实现了 N=4 的 observation history（通过 `obs_history_length` 配置），这与论文一致。自适应采样作为一个**补充机制**，进一步提高了训练效率。

---

## 七、多运动混合策略

### 7.1 运动选择权重

当加载多个运动时，每个回合开始时的运动选择通过加权多项式采样完成：

```python
selected_motions = torch.multinomial(
    self.motion._motion_weights, len(env_ids), replacement=True
)
self.current_motion_idx[env_ids] = selected_motions
```

权重在 `MotionLoader` 中归一化：

```python
total_weight = sum(weights)
self._motion_weights = torch.tensor(
    [w / total_weight for w in weights], dtype=torch.float32, device=device
)
```

每个环境独立采样运动类型，使得 4096 个环境中各种运动的分布与权重成正比。

### 7.2 单运动 vs 多运动的代码分支

`_is_single_motion` 标志控制着关键行为分支（`ure:240-247`）：

```python
if self.num_motions == 1:
    self._is_single_motion = True
else:
    self._is_single_motion = False
```

在 `_update_command()` 中，单运动和多运动的帧推进逻辑不同：

- **单运动**：到达末帧后直接 `_resample_command`（重新采样新起始帧继续循环）
- **多运动**：根据当前运动的 `loop_mode` 决定行为——WRAP 则回绕并累加 `wrap_offset`，CLAMP 则触发 SUCC 终止

### 7.3 各运动独立维护失败计数

在多运动场景下，每个运动独立维护自己的失败计数数组（`ure:223-238`）：

```python
for m_idx in range(self.motion.num_motions):
    self._motion_bin_failed_count.append(torch.zeros(nb, ...))
    self._motion_current_bin_failed.append(torch.zeros(nb, ...))
```

这种设计确保各运动的采样分布互不影响——如果机器人难以执行"空中翻滚"，但容易执行"站立"，两个运动的采样分布各自调整，不会相互干扰。

运动级统计也独立维护（`ure:255-259`）：

```python
self._motion_success_count = torch.zeros(self.motion.num_motions, ...)
self._motion_fail_count = torch.zeros(self.motion.num_motions, ...)
```

### 7.4 部署时的多运动策略

多运动部署时导出独立的 ONNX 文件和 `deploy.yaml` 配置文件：

```yaml
policies:
  - name: "walk"
    onnx: "motion_0.onnx"
    loop_mode: "wrap"
  - name: "stand"
    onnx: "motion_1.onnx"
    loop_mode: "clamp"
  - name: "backflip"
    onnx: "motion_2.onnx"
    loop_mode: "wrap"
```

`motion_tracking_controller` 的 `MotionOnnxPolicy`（`mtc:include/motion_tracking_controller/MotionOnnxPolicy.h`）通过 ONNX 元数据和 `deploy.yaml` 选择对应的策略模型进行推理。

### 7.5 四仓库多运动支持对比

| 特性 | whole_body_tracking | motion_tracking_controller | Mini-Pi-Plus | unitree_rl_mjlab |
|------|:---:|:---:|:---:|:---:|
| 多运动训练 | ❌ | N/A | ✅（dataset YAML） | ✅ |
| 运动级独立计数 | N/A | N/A | ❌ | ✅ |
| 加权采样 | ❌ | N/A | ✅ | ✅ |
| 独立循环模式 | ❌ | N/A | ❌ | ✅ |
| 导出多 ONNX | ❌ | ❌（单 ONNX 内嵌） | N/A | ✅ |
| deploy.yaml | ❌ | ❌（YAML 配置路径） | N/A | ✅ |

---

## 八、与论文训练规模对比

### 8.1 论文训练数据规模

BeyondMimic 论文报告了以下训练数据统计：

> 论文训练了 **2.5 小时的多样化人类运动数据**，从中选出 **30 个代表性片段部署到真机**。

这 30 个片段覆盖了论文所展示的全部激进行为，包括：

- 步行、跑步、转身等基本步态
- 跳跃、单腿跳等动态运动
- **空中翻滚**：论文报告的最高难度动作
- 旋转踢腿等组合武术动作

### 8.2 空中翻滚的关键指标

论文在空中翻滚动作中报告了惊人的动力学指标：

> **"Peak acceleration 31m/s², pelvic angular velocity up to 20rad/s"**

- 31m/s² ≈ 3.16g 的加速度（超过了典型宇航员发射时的 3g 过载）
- 20rad/s ≈ 1145°/s 的骨盆角速度（每秒约 3.2 圈）

这些指标对 MotionCommand 的设计提出了极高的要求：

1. **FPS 一致性**：高动态运动需要精确的帧索引，FPS 感知机制确保训练和部署的帧率匹配
2. **RSI 的初始状态偏差**：空中翻滚的初始状态（起跳速度、角度）稍有偏差就会导致完全不同轨迹，RSI 必须精确建模
3. **自适应采样的困难时段**：空中翻滚的"腾空阶段"是策略最容易失败的地方，自适应采样会集中在这些时段

### 8.3 unitree 目前支持的运动

在 unitree_rl_mjlab 的训练配置中，运动数量和类型的扩展性完全取决于 NPZ 数据的提供。当前框架支持的运动类型理论上不受限制，只要有对应的 NPZ 文件和 YAML 配置即可。

---

## 九、Ghost 可视化机制

### 9.1 设计动机

Ghost 可视化是 MotionCommand 的调试功能，用于在训练和评估时**可视化参考运动**与**机器人当前状态**之间的差异。其核心价值在于让研究人员**立即看出**策略是否在正确跟踪运动，而非通过数值指标间接推断。

### 9.2 深拷贝 MuJoCo 模型渲染半透明 Ghost

Ghost 模式通过深拷贝 MuJoCo 模型来渲染参考运动的半透明模型（`ure:695-711`）：

```python
if self.cfg.viz.mode == "ghost":
    if self._ghost_model is None:
        self._ghost_model = copy.deepcopy(self._env.sim.mj_model)
        self._ghost_model.geom_rgba[:] = self._ghost_color
```

关键步骤：

1. **深拷贝**：`copy.deepcopy(self._env.sim.mj_model)` 创建 MuJoCo 模型的完整副本
2. **颜色覆盖**：`self._ghost_model.geom_rgba[:] = self._ghost_color` 将所有几何体的 RGBA 置为半透明绿色（默认 `(0.5, 0.7, 0.5, 0.5)`）
3. **QPos 设置**：从参考运动数据中解算关节位置，写入 ghost 模型的 qpos 数组
4. **可视化**：通过 `visualizer.add_ghost_mesh()` 渲染

ghost 模型的 qpos 组装：

```python
qpos = np.zeros(self._env.sim.mj_model.nq)
qpos[free_joint_q_adr[0:3]] = self.body_pos_w[batch, 0].cpu().numpy()    # 根位置
qpos[free_joint_q_adr[3:7]] = self.body_quat_w[batch, 0].cpu().numpy()   # 根姿态
qpos[joint_q_adr] = self.joint_pos[batch].cpu().numpy()                   # 关节位置
```

### 9.3 Frames 模式

Frames 模式在三维空间中显示参考和当前各 body 的坐标系框架（`ure:713-757`）：

- **参考框架**：粉色系（`_DESIRED_FRAME_COLORS`），较小（scale=0.08）
- **当前框架**：原色，较大（scale=0.12）
- **锚点参考框架**：粉色系，中等（scale=0.10）
- **锚点当前框架**：原色，最大（scale=0.15）

通过对比框架的**位置**和**朝向**，可以直观判断跟踪误差的大小和方向。

### 9.4 两种模式的调试价值

| 模式 | 适用场景 | 优势 | 局限 |
|------|---------|------|------|
| Ghost | 宏观运动对比 | 一眼看出全身姿势差异 | 无法精确量化各 body 误差 |
| Frames | 精细化分析 | 显示各 body 的 6-DoF 误差 | 多个 body 时视觉杂乱 |

实践中的典型用法是：先用 Ghost 模式快速检查整体运动是否合理，再切换到 Frames 模式分析具体身体部位的跟踪误差。

### 9.5 四仓库可视化对比

| 特性 | whole_body_tracking | motion_tracking_controller | Mini-Pi-Plus | unitree_rl_mjlab |
|------|:---:|:---:|:---:|:---:|
| Ghost 可视化 | ❌（仅 marker 可视化） | ❌（无） | ✅（Viser 仿真） | ✅ |
| Frames 模式 | ✅（marker 可视化） | ❌ | ❌ | ✅ |
| 半透明 Ghost | ❌ | ❌ | ❌ | ✅ |
| 坐标系框架 | ✅ IsaacLab marker | ❌ | ❌ | ✅ |

---

## 十、综合架构评述

### 10.1 MotionCommand 的数据流全景

```
┌─────────────────────────────────────────────────────────────────────┐
│                        MotionCommand 数据流                          │
├───────────────┬──────────────────┬──────────────────┬────────────────┤
│   加载阶段      │    训练阶段       │    评估阶段       │    部署阶段     │
│               │                  │                  │                │
│ NPZ/YAML      │ _resample_command│ start 模式       │ ONNX 复合模型  │
│   ↓           │   ↓              │   ↓              │   ↓            │
│ MotionLoader  │ RSI 扰动         │ 确定帧起点        │ 帧索引由        │
│   ↓           │   ↓              │   ↓              │ time_step 驱动 │
│ 拼接张量       │ 自适应采样        │ 固定轨迹播放       │   ↓            │
│ _length_starts │   ↓              │   ↓              │ C++ ONNX       │
│ _frames_per_step│ _update_command │ 无随机化          │ Runtime 推理    │
│               │   ↓              │                  │                │
│               │ 帧推进 + 相对位姿  │                  │                │
│               │ 更新 + EMA 更新   │                  │                │
└───────────────┴──────────────────┴──────────────────┴────────────────┘
```

### 10.2 论文主张的工程实现映射

| 论文主张 | 工程实现 | 对应代码 |
|---------|---------|---------|
| "Compact motion-tracking formulation" | 拼接张量设计 + FPS 感知索引 | `ure:124-141` |
| "Shared hyperparameters" | 自适应采样的统一参数（alpha=0.001, lambda=0.8, ratio=0.1） | `ure:770-772` |
| "Minimize deployment discrepancies" | 训练/部署使用相同帧索引公式 `frame_idx = time_step × step_dt × fps` | `ure:281-294` |
| "Domain randomization only to truly uncertain" | RSI 对初始状态建模 ≠ 域随机化对物理参数建模 | `ure:561-618` |
| "Observation history N=4" | 观测系统中的 obs_history_length=4 | tracking_env_cfg.py |
| "Prediction horizon H=1" | PPO 单步 TD 更新 | rl_cfg.py |

### 10.3 局限性与改进方向

1. **WRAP 模式的连续性假设**：如前所述，WRAP 模式隐含首末帧可拼接的假设。对于不满足此条件的运动（如翻滚、跳跃序列），WRAP 会导致状态跳变。可能的改进是添加 overlap 检测，自动计算最佳拼接点。

2. **自适应采样只有 EMA 没有动量**：当前的 EMA 更新是各向同性的（所有桶使用相同的 alpha），但不同运动的"困难时段"分布不同。引入自适应 alpha（根据运动类型自动调整）可能是改进方向。

3. **Ghost 模型的性能开销**：每次可视化都需要深拷贝 MuJoCo 模型并重新设置 qpos，在多环境场景下可能影响训练吞吐量。增加条件编译开关（如环境变量控制）是一种可行的工程优化。

4. **多运动导出 ONNX 的存储开销**：每个运动导出独立 ONNX 文件，N 个运动就有 N 倍的文件大小。可以考虑共享策略网络权重、仅替换运动 buffer 的压缩方案。

---

## 十一、总结

MotionCommand 与 MotionLoader 构成了 unitree_rl_mjlab 中 Motion Tracking 任务的**数据基础设施**。从多运动加载的 YAML 配置，到 FPS 感知的帧索引，从 RSI 扰动到自适应采样，再到 Ghost 可视化和多运动部署策略——整个系统设计体现了"紧凑且灵活"的哲学。

与 whole_body_tracking 相比，unitree_rl_mjlab 在数据管理层面更具工程完备性（多运动、YAML、FPS 感知）；与 motion_tracking_controller 相比，训练侧提供了更丰富的数据工具；与 Mini-Pi-Plus_BeyondMimic 相比，部署链路更适合宇树机器人生态。

论文 BeyondMimic 的主张——"Compact motion-tracking formulation enables mastering a wide range of radically agile behaviors with a single setup and shared hyperparameters"——在 MotionCommand 的实现中得到了充分印证：一套统一的自适应采样框架、一组共享的超参数、一个 FPS 感知的索引机制，支撑了从平稳步行到空中翻滚的广阔运动空间。

---

## 附录：关键源码路径汇总

| 组件 | 仓库 | 路径 |
|------|------|------|
| MotionLoader | unitree_rl_mjlab | `file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/commands.py#L45` |
| MotionCommand | unitree_rl_mjlab | `file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/commands.py#L183` |
| MotionCommandCfg | unitree_rl_mjlab | `file:///home/meme/Documents/unitree_h1/unitree_rl_mjlab/src/tasks/tracking/mdp/commands.py#L760` |
| MotionLoader | whole_body_tracking | `file:///home/meme/Documents/github_code/whole_body_tracking/source/whole_body_tracking/whole_body_tracking/tasks/tracking/mdp/commands.py#L30` |
| MotionCommand | whole_body_tracking | `file:///home/meme/Documents/github_code/whole_body_tracking/source/whole_body_tracking/whole_body_tracking/tasks/tracking/mdp/commands.py#L61` |
| ONNX exporter | whole_body_tracking | `file:///home/meme/Documents/github_code/whole_body_tracking/source/whole_body_tracking/whole_body_tracking/utils/exporter.py` |
| MotionCommand (C++) | motion_tracking_controller | `file:///home/meme/Documents/github_code/motion_tracking_controller/include/motion_tracking_controller/MotionCommand.h` |
| MotionOnnxPolicy (C++) | motion_tracking_controller | `file:///home/meme/Documents/github_code/motion_tracking_controller/include/motion_tracking_controller/MotionOnnxPolicy.h` |
| GMR→MimicKit 转换 | MimicKit (Mini-Pi-Plus) | `file:///home/meme/Documents/github_code/MimicKit/tools/gmr_to_mimickit/gmr_to_mimickit.py` |
| 训练环境配置 | whole_body_tracking | `file:///home/meme/Documents/github_code/whole_body_tracking/source/whole_body_tracking/whole_body_tracking/tasks/tracking/tracking_env_cfg.py` |
| G1 环境配置 | whole_body_tracking | `file:///home/meme/Documents/github_code/whole_body_tracking/source/whole_body_tracking/whole_body_tracking/tasks/tracking/config/g1/flat_env_cfg.py` |
| 运动数据 YAML 示例 | MimicKit | `file:///home/meme/Documents/github_code/MimicKit/data/datasets/dataset_humanoid_locomotion.yaml` |
| 部署控制器配置 | motion_tracking_controller | `file:///home/meme/Documents/github_code/motion_tracking_controller/config/g1/controllers.yaml` |
| CSV→NPZ 转换 | whole_body_tracking | `file:///home/meme/Documents/github_code/whole_body_tracking/scripts/csv_to_npz.py` |
| 论文页面 | BeyondMimic | https://beyondmimic.github.io/ |
| 论文原文 | arXiv | https://arxiv.org/abs/2508.08241 |

---

> **文档版本**：v1.0 · 2026-07-01
> **覆盖范围**：unitree_rl_mjlab `src/tasks/tracking/mdp/commands.py` 全文件深度分析 + 四仓库对比
> **引用论文**：BeyondMimic arXiv:2508.08241
