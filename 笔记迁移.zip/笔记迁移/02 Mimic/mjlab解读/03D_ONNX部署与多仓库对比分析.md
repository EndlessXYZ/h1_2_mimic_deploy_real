# 03D ONNX 部署与多仓库对比分析

> **系列定位**：本文是 mjlab 解读系列的扩展篇，在已完成训练架构（01）、Velocity Tracking（02）、Motion Tracking（03）、域随机化（04）、C++ 部署系统（05）等深度分析的基础上，从 ONNX 部署方案与多仓库对比的角度，将 BeyondMimic 论文、四仓库源码分析和 mjlab 改进分析融合为一篇综合性文档。

---

## 第一章：Motion Tracking 的完整 Pipeline

### 1.1 训练数据流

Motion Tracking 从原始动捕数据到最终部署策略，经历一个完整的数据变换链路。以 BeyondMimic 论文为基础，整个 pipeline 可以分为以下阶段：

**训练数据流**（Python 端）：

```
动捕/视频 → SMPLX 重定向 → CSV 数据 → NPZ 文件 → MotionLoader → RL 训练 → ONNX 导出
```

1. **数据采集**：从动作捕捉系统（如 LAFAN1 数据集）或 RGB 视频（通过 GVHMR）获取人体运动数据
2. **运动重定向**：通过 GMR（General Motion Retargeting）或 Unitree 专有重定向管道，将人体骨骼映射到机器人关节空间，解决 embodiment gap
3. **数据预处理**：将重定向后的运动数据保存为 CSV 格式，经过插值和格式转换后生成 NPZ 文件
4. **MotionLoader 加载**：训练时，`MotionLoader` 将 NPZ 文件全量加载到 GPU 内存中，支持单运动、多元组、YAML 配置三种加载方式
5. **RL 训练**：使用 PPO 算法在 Isaac Lab（whole_body_tracking）或 MuJoCo + mjlab（unitree_rl_mjlab）中训练策略网络
6. **ONNX 导出**：将训练好的策略网络与运动参考数据打包为复合 ONNX 模型，供 C++ 端推理

BeyondMimic 论文原文指出其训练目标为：

> "We formulate the motion-tracking problem as a Markov Decision Process (MDP) and solve it using RL, which maximizes the expected cumulative reward under this MDP. Given minutes-long reference motions, the pipeline produces sim-to-real-ready motion-tracking policies using the same MDP and hyperparameters across all motions."

即：将运动跟踪建模为 MDP，使用统一的 MDP 配置和超参数处理所有运动，实现"one-recipe-fits-all"的规模化训练。

### 1.2 部署数据流

部署数据流（C++ 端）将训练产物转换为真实的电机控制指令：

```
ONNX 模型 + deploy.yaml → OrtRunner 加载 → 观测组装 → 策略推理 → 动作映射 → DDS 发布 → 电机执行
```

1. **OrtRunner 加载 ONNX**：读取 ONNX 文件，解析输入输出维度和元数据（metadata_props）
2. **观测组装**：从传感器（IMU、关节编码器）读取数据，按 deploy.yaml 配置进行 scale/clip/history_length 处理
3. **策略推理**：将组装好的观测向量送入 ONNX Runtime 进行推理，获得动作输出
4. **动作映射**：通过 ActionManager 对输出动作进行 scale/offset/clip，生成最终的关节目标位置
5. **PD 控制器执行**：在 1kHz 的 FSM 线程中，将关节目标位置与当前位置送入 PD 控制器，计算力矩指令
6. **DDS 通信下发**：通过宇树 SDK2 的 DDS 协议将指令发送到电机驱动器

### 1.3 四仓库的 Pipeline 覆盖对比

以下是四个仓库在完整 pipeline 中的各自覆盖范围：

```
完整 Pipeline: 数据采集 → 重定向 → 预处理 → RL 训练 → ONNX 导出 → Sim 验证 → C++ 部署 → 真机运行

whole_body_tracking:       ❌       ❌       ✅       ✅        ✅        ❌       ❌        ❌
motion_tracking_controller: ❌      ❌       ❌       ❌        ✅        ✅       ✅        ✅
Mini-Pi-Plus_BeyondMimic:  ✅      ✅       ✅       ✅        ✅        ✅       ✅        ✅
unitree_rl_mjlab:          ❌      ❌       ✅       ✅        ✅        ✅       ✅        ✅
```

**仓库定位与数据流差异**：

| 仓库 | 训练 | ONNX 导出 | Sim 验证 | C++ 部署 | 真机运行 | 数据来源 |
|:----|:----:|:---------:|:--------:|:--------:|:--------:|:--------|
| whole_body_tracking | ✅ IsaacLab | ✅ | ❌ | ❌ | ❌ | LAFAN1 / Unitree LAFAN1 |
| motion_tracking_controller | ❌ | ✅（加载） | ✅ MuJoCo | ✅ | ✅ | 外部提供 ONNX |
| Mini-Pi-Plus | ✅ | ✅ | ✅ | ✅ | ✅ | 动捕/视频（含重定向）|
| unitree_rl_mjlab | ✅ MuJoCo | ✅ | ✅ simulate/ | ✅ | ✅ | Unitree LAFAN1 / 自定义 |

**关键发现**：目前**没有**任何一个仓库覆盖了整个 pipeline。即便是最完整的 Mini-Pi-Plus，其重定向和部署代码也依赖于外部组件。unitree_rl_mjlab 的优势在于训练和部署使用同一套 MuJoCo 物理引擎，且均在宇树生态内，数据格式一致性最好。whole_body_tracking 作为论文官方训练库，在训练 fidelity 上最高，但完全不涉及部署代码。

---

## 第二章：ONNX 复合模型设计深度分析

### 2.1 为什么需要复合模型

Motion Tracking 策略部署与 Velocity Tracking 有本质区别。Velocity Tracking 的策略网络输入完全由传感器数据组成——IMU 角速度、投影重力、关节位置等。因此部署时只需将传感器数据组装为观测向量即可推理。

但 Motion Tracking 的策略**需要参考运动数据作为输入**。在训练环境中，`MotionCommand` 管理着 `time_steps` 和存储在 GPU 张量中的全部运动数据。每步训练时，`MotionCommand._update_command()` 根据 `time_step` 索引参考帧，将该帧的关节位置和速度作为策略观测的一部分。

部署时面临的核心问题：**参考运动数据必须与策略网络一起部署**。如果策略和运动数据分离，则需要额外维护 NPZ 文件加载、帧索引计算、数据同步等逻辑，增加部署复杂度和出错概率。

解决方案是设计一个**复合 ONNX 模型**——将策略网络和参考运动数据打包为同一个 ONNX 计算图。复合模型接受 `obs` 和 `time_step` 两个输入，内部通过 `time_step` 索引预存储的运动数据缓冲区，输出 `actions` 和所有参考数据。

这与 Velocity Tracking 的纯策略网络形成鲜明对比：

| 维度 | Velocity 纯策略 ONNX | Motion 复合 ONNX |
|:----|:------------------:|:----------------:|
| 输入 | obs（~92 维） | obs（144/150 维）+ time_step（1 维）|
| 输出 | actions（N 维） | actions + 全部参考数据（~200+ 维）|
| 内部状态 | 无 | motion buffer（非可训练参数）|
| 依赖 | 无外部数据 | 内嵌运动数据，无外部依赖 |
| 多运动支持 | 不适用 | 每个运动独立 ONNX 文件 |

BeyondMimic 论文原文提到部署推理性能：

> "All policies are executed onboard using ONNX Runtime on the robot's CPU. Each inference step takes under 1.0 ms, allowing seamless integration into the realtime estimation and control loop."

即每个推理步骤耗时不到 1ms，可以无缝集成到实时估计和控制循环中。

### 2.2 复合模型结构（Python 侧）

复合模型的核心实现在 `tracking/rl/runner.py` 中的 `_OnnxMotionModel`（单运动）和 `_OnnxMultiMotionModel`（多运动）类。

**_OnnxMotionModel 结构**：

```python
class _OnnxMotionModel(nn.Module):
    def __init__(self, actor, motion_data, step_dt, fps):
        super().__init__()
        # 策略网络部分
        self.actor = actor
        # 运动数据缓冲区（注册为 buffer，非可训练参数）
        self.register_buffer("joint_pos", motion_data["joint_pos"])       # (T, N)
        self.register_buffer("joint_vel", motion_data["joint_vel"])       # (T, N)
        self.register_buffer("body_pos_w", motion_data["body_pos_w"])     # (T, K, 3)
        self.register_buffer("body_quat_w", motion_data["body_quat_w"])   # (T, K, 4)
        self.register_buffer("body_lin_vel_w", motion_data["body_lin_vel_w"])  # (T, K, 3)
        self.register_buffer("body_ang_vel_w", motion_data["body_ang_vel_w"])  # (T, K, 4)
        self.register_buffer("ref_dof_pos", motion_data["ref_dof_pos"])   # (T, N)
        self.step_dt = step_dt
        self.fps = fps

    def forward(self, obs, time_step):
        # 1. 根据 time_step 计算帧索引
        frame_idx = (time_step * self.step_dt * self.fps).long()
        frame_idx = torch.clamp(frame_idx, 0, self.joint_pos.shape[0] - 1)

        # 2. 从 buffer 中索引参考数据
        ref_joint_pos = self.joint_pos[frame_idx]
        ref_joint_vel = self.joint_vel[frame_idx]
        ref_body_pos = self.body_pos_w[frame_idx]
        # ...

        # 3. 策略网络推理
        actions = self.actor(obs)

        # 4. 输出 actions + 所有参考数据
        return actions, ref_joint_pos, ref_joint_vel, ref_body_pos, ...
```

**推理流程**：

```
time_step (B, 1)
    │
    ├── frame_idx = time_step × step_dt × fps
    │      ↓
    ├── motion buffer 索引 → ref_joint_pos, ref_joint_vel, ...
    │      ↓
    ├── obs + ... → actor network → actions
    │      ↓
    └── 输出: [actions, ref_joint_pos, ref_joint_vel, body_pos_w, body_quat_w, ...]
```

### 2.3 与 motion_tracking_controller 的 ONNX 方案对比

`motion_tracking_controller` 仓库（宇树官方部署库）采用了与 unitree_rl_mjlab 相似的 ONNX 复合模型方案，但在 C++ 实现上有所不同。

**motion_tracking_controller 的 MotionOnnxPolicy**：

继承链为 `ControllerInterface → ControllerBase → RlController → MotionTrackingController`。关键组件 `MotionOnnxPolicy` 继承自 `OnnxPolicy`：

```cpp
class MotionOnnxPolicy : public OnnxPolicy {
    // forward 函数组装 obs + time_step 执行推理
    // 参考运动嵌入在 ONNX 模型中
    // time_step_ 计数器逐帧推进
    // reset() 重置时间步 + 零观测预热推理获取初始参考帧
    // parseMetadata() 从 ONNX metadata_props 读取 anchor_body_name 和 body_names
};
```

**关键设计对比**：

| 维度 | unitree_rl_mjlab | motion_tracking_controller |
|:----|:---------------:|:--------------------------:|
| 推理引擎 | ONNX Runtime 1.22.0 | ONNX Runtime C++ |
| 运动数据来源 | 内嵌 ONNX buffer | 内嵌 ONNX buffer |
| time_step 管理 | 策略线程自增 | MotionOnnxPolicy 内部维护 |
| 元数据解析 | 通过 ONNX metadata_props | parseMetadata() 读取 |
| reset 处理 | 重置 time_step | 零观测预热推理获取初始帧 |
| 多运动支持 | 多个 ONNX 文件 + deploy.yaml | 待确认 |

**两种方案的优劣对比**：

1. **motion_tracking_controller 的零观测预热**：`reset()` 时执行一次零观测推理，获取初始参考帧。这种设计的巧处在于——不需要额外维护初始帧的加载逻辑，用一次推理"顺便"完成了初始化。但代价是 reset 时产生一次无意义的推理调用。

2. **unitree_rl_mjlab 的方案**：time_step 从 0 开始递增，自然对应到 motion buffer 的第 0 帧。不需要预热推理，实现更简洁。

3. **元数据嵌入方式**：两者都通过 ONNX 的 metadata_props 嵌入 `anchor_body_name` 和 `body_names` 等信息。motion_tracking_controller 的 `parseMetadata()` 在模型加载时解析这些元数据，部署代码据此解析输出张量的含义。

### 2.4 多运动 ONNX 导出策略

当使用多个运动轨迹进行训练时（如行走、站立、转身等），导出策略有所不同：

**单运动导出**：
- 一个 ONNX 文件包含一个运动的所有参考数据
- 部署时直接加载单个 ONNX 即可运行

**多运动导出**：
- **每个运动独立导出为单独的 ONNX 文件**
- 同时生成 `deploy.yaml` 配置文件，描述各运动的元信息

```yaml
# deploy.yaml 多运动配置示例
policies:
  - name: "walk"
    onnx: "motion_0.onnx"
    loop_mode: "wrap"
  - name: "stand"
    onnx: "motion_1.onnx"
    loop_mode: "clamp"
  - name: "turn"
    onnx: "motion_2.onnx"
    loop_mode: "wrap"
```

为什么不是在一个 ONNX 中包含所有运动？原因在于：
- ONNX 计算图不支持动态形状的 buffer——不同运动的帧数可能不同
- 单文件内嵌过多数据会导致 ONNX 文件过大
- 部署端需要上层决策逻辑决定"当前运行哪个运动"，独立文件支持按需加载

**元数据嵌入**：

通过 `attach_metadata_to_onnx()` 将以下信息写入 ONNX 文件的 metadata_props：
- `anchor_body_name`：锚点 body 名称（如 torso_link）
- `body_names`：所有参考 body 名称列表
- `motion_names`（多运动）：各运动名称
- `fps`：参考运动帧率
- `step_dt`：控制步长

---

## 第三章：部署配置文件深度解析

### 3.1 deploy.yaml 配置项详解

`deploy.yaml` 是连接训练与部署的核心配置文件，定义了 C++ 端如何加载和运行策略。

```yaml
# deploy.yaml 典型结构
joint_ids_map:                     # 宇树 SDK 关节 ID → 策略顺序映射
  - 0                              # 左 hip pitch
  - 1                              # 左 hip roll
  - 2                              # 左 hip yaw
  # ... 共 N 个关节

step_dt: 0.02                      # 控制步长（50Hz）

stiffness: [350, 350, ..., 40, 40]  # PD 刚度（腿部高 ~350，手臂低 ~40）
damping: [6.5, 6.5, ..., 2.0, 2.0] # PD 阻尼

default_joint_pos: [0, -0.3, 0, ...]  # 默认站立姿态

observations:
  base_ang_vel:
    scale: [1.0, 1.0, 1.0]
    clip: null
    history_length: 1
  projected_gravity:
    scale: [1.0, 1.0, 1.0]
    clip: null
    history_length: 1
  joint_pos_rel:
    scale: [1.0] * N
    clip: null
    history_length: 1
  # ...

actions:
  JointPositionAction:
    scale: [0.51, 0.51, ..., 0.48, ...]  # 27 维缩放系数
    offset: [0, -0.2, 0, ...]             # 27 维偏移（= default_joint_pos）
    clip: null
```

**关键参数解析**：

1. **`joint_ids_map`**：这是部署中**最易出错**的配置项。宇树 SDK 的关节 ID 顺序与策略训练时的关节顺序可能不同。`joint_ids_map` 建立了从"策略输出第 i 维"到"硬件关节 joint_id"的映射。如果映射错误，会出现"张冠李戴"——控制右腿的动作被发送到了左臂。

2. **`step_dt=0.02`**：对应 50Hz 控制频率。这个值必须与训练时的 `dt × decimation` 完全一致。如果部署端使用不同的控制频率，策略的 time_step 推进速度会与训练时不一致，导致参考运动播放速度异常。

3. **`stiffness/damping`**：PD 增益向量。motion_tracking_controller 中腿部 Kp=350（高刚度），手臂 Kp=40（低刚度）。这种差异反映了不同部位的控制需求——腿部需要高刚度以承载体重，手臂需要低刚度以避免碰撞时损坏。

4. **`default_joint_pos`**：默认站立姿态。当策略输出全零动作时，机器人的关节位置 = `default_joint_pos`。策略输出的增量（经过 scale 缩放）叠加在这个基线上。

5. **观测 scale/clip**：每个观测维度的缩放系数和裁剪范围。这些值必须与 Python 训练侧完全一致。如果 C++ 端的 scale 值与训练时不同，即使观测数据和 ONNX 推理完全正确，最终的动作输出也会有系统性偏移。

### 3.2 与 motion_tracking_controller 的 controllers.yaml 对比

motion_tracking_controller 使用 ROS2 参数系统，其配置以 `controllers.yaml` 形式存在：

| 参数 | unitree_rl_mjlab deploy.yaml | motion_tracking_controller controllers.yaml |
|:----|:---------------------------:|:------------------------------------------:|
| 关节映射 | `joint_ids_map` 列表 | `joint_mapping` 列表 |
| 控制频率 | `step_dt: 0.02`（50Hz） | `control_frequency: 500`（500Hz）|
| PD 增益 | 策略专用配置 | 腿部 Kp=350，手臂 Kp=40 |
| 观测配置 | 完整 scale/clip/history | 部分配置 |
| 动作配置 | scale/offset/clip | 待确认 |
| 格式 | YAML 纯文本 | ROS2 参数 YAML |

**关键差异——控制频率**：motion_tracking_controller 以 500Hz 运行（策略 50Hz 降采样），而 unitree_rl_mjlab 的策略和低级控制同在 50Hz。500Hz 的优势在于 PD 控制器以更高频率运行，可提供更平滑的力矩输出。但两种架构各有优劣——高频率增加计算负担，低频率可能降低控制平滑度。

### 3.3 与 whole_body_tracking 的 ONNX 元数据对比

whole_body_tracking 作为论文官方训练库，其 ONNX 导出逻辑与 unitree_rl_mjlab 在元数据嵌入方面基本一致，都使用 `attach_metadata_to_onnx()` 或类似机制：

| 元数据字段 | whole_body_tracking | unitree_rl_mjlab |
|:----------|:------------------:|:----------------:|
| anchor_body_name | ✅ | ✅ |
| body_names | ✅ | ✅ |
| fps | ✅ | ✅ |
| step_dt | ✅ | ✅ |
| has_state_estimation | ✅ | ❌ |
| motion_names（多运动） | ✅ | ✅ |

whole_body_tracking 额外记录了 `has_state_estimation` 标志，用于指示策略是在完整观测模式还是无状态估计模式下训练的。这个信息对于部署时选择正确的观测组装逻辑至关重要。

---

## 第四章：四仓库 Sim2Real 策略对比

### 4.1 核心技术栈对比

| 维度 | whole_body_tracking | motion_tracking_controller | Mini-Pi-Plus_BeyondMimic | unitree_rl_mjlab |
|:----|:-----------------:|:------------------------:|:----------------------:|:---------------:|
| **物理引擎** | Isaac Sim 4.5.0 | MuJoCo（sim 验证）| 待确认 | MuJoCo + Warp |
| **训练框架** | Isaac Lab 2.1.0 | ❌ 仅部署 | Isaac Lab | mjlab（自研）|
| **RL 算法** | PPO（rsl_rl） | ❌ | PPO（rsl_rl） | PPO（rsl_rl）|
| **推理引擎** | ❌ 无 C++ 部署 | ONNX Runtime C++ | ONNX Runtime | ONNX Runtime 1.22.0 |
| **机器人通信** | ❌ | 宇树 UDP (192.168.123.11) | 待确认 | 宇树 SDK2 + DDS |
| **部署验证** | ❌ | MuJoCo sim + 真机 | 真机验证 | 仿真器 + 真机 |
| **支持机器人** | G1 + SMPL 格式 | G1（宇树 SDK）| Mini-Pi-Plus | G1/H1_2/H2/Go2/A2/R1 |
| **扩散模型** | ❌ | ❌ | ❌ | ❌ |
| **延迟模拟** | ✅ DelayedImplicitActuator | ❌（依赖机械延迟）| 待确认 | ❌（框架已有未启用）|
| **安全机制** | ❌ | E-stop / 状态机 | 待确认 | FSM Passive / FixStand |

### 4.2 Sim2Real 策略差异分析

**whole_body_tracking**：
- 基于 Isaac Sim 4.5.0 + Isaac Lab 2.1.0，是 BeyondMimic 论文的官方训练库
- 使用了 `DelayedImplicitActuator` 模拟执行器延迟——这是论文强调的关键 Sim2Real 技术
- 论文原文指出延迟建模的重要性：
  > "carefully model the robot actuation based on classical mechanics principles and ensure proper system implementation to minimize deployment discrepancies, such as delays"
- `DelayedImplicitActuator` 以控制步（200Hz → 5ms/步）为单位延迟，粒度较粗但实现简洁
- **关键缺失**：该仓库仅用于训练，不包含任何部署代码

**motion_tracking_controller**：
- 宇树官方的 ROS2 部署库，基于 `legged_control2` 框架
- 500Hz 控制频率，策略 50Hz 降采样——这是四仓库中最高的 PD 控制频率
- 完整的安全机制：ROS2 生命周期管理 + 手柄 E-stop（B 键）+ 状态机
- 支持外部位置矫正（LiDAR mid360 话题），这在室外部署中很重要
- 手柄映射完整：L1+A 待机 → R1+A 策略 → B E-stop
- 继承链 `ControllerInterface → ControllerBase → RlController → MotionTrackingController` 层次清晰
- **关键缺失**：不包含训练代码，需要外部提供 ONNX 模型

**Mini-Pi-Plus_BeyondMimic**：
- 针对特定硬件（Mini-Pi-Plus）的完整实现
- 据社区资料（rl_sar 部署实践），该仓库可能覆盖了从重定向到真机部署的全链路
- 数据链最完整——包含从动捕/视频到重定向再到训练和部署的完整流程
- **待确认信息**：具体技术栈和代码实现细节

**unitree_rl_mjlab**：
- 宇树的"全家桶"仓库——唯一集训练、部署、仿真三合一的仓库
- 支持多达 6 种机器人型号（G1/H1_2/H2/Go2/A2/R1），远超其他仓库
- 基于 MuJoCo 物理引擎，训练和部署使用同一物理引擎，消除了物理引擎差异
- C++ 部署系统的 FSM 架构设计精良（Passive → FixStand → RL）
- 完整的验证工具链（7 个 Python/C++ 工具）确保了部署数值一致性
- **关键缺失**：
  - `DelayedActuator` 框架已有但未被 tracking 任务启用
  - PD 增益随机化、力矩限制随机化等关键 DR 项缺失
  - 无单独的 E-stop 硬停止机制（依赖 FSM 回退）

### 4.3 延迟与精度分析

**端到端延迟链条分析**：

```
传感器采样 → DDS 传输 → FSM 读取 → 策略推理 → DDS 下发 → 电机执行

whole_body_tracking（模拟器视角）:
  仿真步进 → 观测读取 → 策略推理 → 动作应用 → 下一步
  无实际通信延迟，延迟仅来自仿真步长

motion_tracking_controller（真机视角）:
  IMU ~1ms → 以太网 ~0.5ms → 控制器读取 ~0.1ms → ONNX 推理 ~1ms → UDP 下发 ~0.5ms → 电机 ~1ms
  端到端延迟 ≈ 4ms（在 20ms 控制周期内）

unitree_rl_mjlab（真机视角）:
  DDS 订阅 ~0.5ms → FSM 读取 ~0.1ms → 策略推理 ~1.5ms → DDS 发布 ~0.5ms → 电机 ~1ms
  端到端延迟 ≈ 3.6ms（在 20ms 控制周期内）
```

**延迟模拟的现状**：

BeyondMimic 论文强调执行器延迟是 Sim2Real 中最关键的因素之一：

> 论文在 Sim2Real 中特别强调了"minimize deployment discrepancies, such as delays"——延迟是部署差异的主要来源之一。

然而，目前 unitree_rl_mjlab 的 `DelayedActuator` 虽然框架已经实现（装饰器模式，以物理步为单位，粒度 2ms），但在 tracking 任务的默认配置中**未被启用**。改进分析报告将其列为 P0 优先级：

> **缺失项五：执行器延迟随机化（P0）**
> 启用方案：启用 `DelayedActuator` 包裹现有的 actuator，调用 `dr.sync_actuator_delays(lag=(0, 10))`。lag=10 @ 500Hz 对应 20ms 的最大延迟。

**500Hz vs 50Hz 控制频率**：
- motion_tracking_controller 以 500Hz（2ms 周期）运行低级控制，策略推理降采样到 50Hz（每 10 个控制步一次）
- unitree_rl_mjlab 的策略和低级控制运行在相同的 50Hz（20ms 周期）
- 500Hz 的优势：PD 控制器更新频率更高，可以减少策略降采样带来的量化误差
- 500Hz 的代价：计算负载更高（10× 的 PD 计算），且策略推理频率仍然是 50Hz（频率不匹配带来额外的延迟）

---

## 第五章：安全机制对比

### 5.1 unitree_rl_mjlab 的 FSM 安全体系

unitree_rl_mjlab 的 C++ 部署系统实现了三层 FSM 状态机：**Passive → FixStand → RLBase/Mimic**。

```
安全基态：      Passive（被动阻尼，Kp=0，仅阻尼）
                  ↓ LT+B 手柄按键
安全过渡：      FixStand（线性插值到站立姿态，3 秒过渡）
                  ↓ RT+A 手柄按键
策略控制：      RLBase/Mimic（50Hz 策略推理，全自主控制）
                  ↓ B 键 E-stop / DDS 超时
回退到基态：    Passive
```

**安全设计的四个原则**：

1. **默认安全**：系统初始化为 Passive 状态，即使配置错误也不会产生主动力矩
2. **故障回退**：DDS 通信超时时自动回退到 Passive
3. **操作员控制**：手柄 B 键在任何状态下强制回退
4. **可观测性**：策略线程独立运行，状态可通过 DDS 日志监控

### 5.2 motion_tracking_controller 的安全机制

motion_tracking_controller 基于 ROS2 生命周期管理，安全机制包括：

- **ROS2 生命周期节点**：管理控制器的生命周期（Unconfigured → Inactive → Active → Finalized）
- **手柄 E-stop**：B 键在任何状态下立即停止策略输出
- **状态机切换**：L1+A 待机 → R1+A 策略 → B E-stop
- **500Hz 控制线程**：即使策略线程异常，低级控制线程仍可维持安全指令

### 5.3 安全机制对比表

| 安全特性 | whole_body_tracking | motion_tracking_controller | unitree_rl_mjlab |
|:---------|:-----------------:|:------------------------:|:---------------:|
| 状态机安全递进 | ❌ | ✅ 生命周期管理 | ✅ Passive→FixStand→RL |
| 手柄 E-stop | ❌ | ✅ B 键 | ✅ B 键（DSL 配置）|
| DDS 超时回退 | ❌ | ✅ | ✅ |
| bad_orientation 检测 | ❌ | ✅ | ✅（默认禁用）|
| 策略线程隔离 | ❌ | ✅ 独立线程 | ✅ 50Hz 独立线程 |
| 关节限位保护 | ✅ 训练奖励 | ✅ 硬件限制 | ✅ 训练+部署限位 |
| 自碰撞保护 | ❌ | ❌ | ✅ 奖励惩罚 |

unitree_rl_mjlab 在安全方面的独特优势是**自碰撞保护**——通过奖励函数在训练阶段就抑制自碰撞行为，而其他仓库要么依赖硬件限位，要么完全没有自碰撞检测。

改进分析报告中指出 `bad_orientation` 在当前 tracking 任务中默认被禁用（始终返回 `false`）。建议在真机部署时启用：

> **bad_orientation：躯干倾斜终止**
> 阈值建议：躯干倾斜 > 70°
> 必要性分析：当前没有躯干倾斜角度的直接检测...在倾斜姿态下继续运动，关节可能会进入极限位置造成损坏。

---

## 第六章：延迟与精度分析

### 6.1 端到端延迟预算

在 unitree_rl_mjlab 的双速率架构下，各环节时间预算如下：

| 环节 | 频率 | 单次预算 | 说明 |
|:----|:---:|:-------:|:------|
| DDS 订阅回调 | ~1kHz | 50~200μs | 网络延迟主导 |
| FSM pre_run | 1kHz | 50~100μs | 状态更新、坐标变换 |
| FSM run | 1kHz | 50~100μs | 状态逻辑 |
| FSM post_run | 1kHz | 50~100μs | DDS 发布 |
| 策略 robot->update | 50Hz | 100~200μs | 含 mutex 等待 |
| 策略观测组装 | 50Hz | 100~500μs | Mimic 144 维 |
| **策略 ONNX 推理** | **50Hz** | **1~2ms** | **瓶颈环节** |
| 策略动作处理 | 50Hz | 10~50μs | 简单线性运算 |

ONNX Runtime 在 C++ 端的推理延迟约 1~2ms，对于 50Hz（20ms 周期）的控制频率来说，余量超过 90%。motion_tracking_controller 的推理在 Jetson Orin 上也在 1ms 以内。

### 6.2 精度损失分析

从 Python 训练到 C++ 部署，精度损失来自以下环节：

**1. 浮点精度差异**：
Python NumPy 和 C++ 都使用 IEEE 754 float32，理论上精度一致。但 SIMD 指令集差异和累积顺序差异可能导致细微偏差。实测纯数学运算误差在 1e-7~1e-6 量级，可忽略。

**2. 配置精度截断**：
改进分析报告中明确指出：

> 实际验证中发现，这个问题曾导致部署版本的 action scale 截断精度问题——训练用 scale 有 8 位小数，而 deploy.yaml 只有 2 位。修复方法是将 deploy.yaml 中的 scale 值更新为完整 float32 精度。

这是一个已经在实际部署中遇到的精度问题，解决方案也已明确。

**3. 已知近似——motion_anchor_ori_b 的转置差异**：

在数值验证中发现，C++ 端和 Python 端的 `motion_anchor_ori_b` 计算存在差异：

| 方法 | 计算方式 | 6D 编码 |
|:----|:--------|:-------:|
| Python 训练 | `robot_q^{-1} * ref_q` 后直接取 6D | 无转置 |
| C++ 部署 | `(init_q * ref_q)^{-1} * real_q` 后转置取 6D | 有转置 |

这个差异导致 `motion_anchor_ori_b` 维度的最大绝对误差达到 1.1e-2，进一步传播到 ONNX 动作输出（误差约 9.6e-4）。虽然对常规行走影响不大，但需要记录和量化。

### 6.3 验证容忍度标准

Sim2Sim 验证的分层容忍度：

| 验证层级 | 最大允许误差 | 说明 |
|:--------|:----------:|:------|
| L1 观测组装 | 1e-6 | 纯数学计算应接近浮点精度 |
| L2 动作输出 | 1e-4 | 受 ONNX 推理浮点差异影响 |
| L3 闭环轨迹 | 1e-2 | 累计误差，需迭代优化 |

---

## 第七章：四仓库整体对比总结

### 7.1 各仓库优劣势雷达图

**whole_body_tracking**（论文官方训练库）：

| 维度 | 评分 | 说明 |
|:----|:---:|:------|
| 训练 fidelity | ⭐⭐⭐⭐⭐ | Isaac Lab + Isaac Sim，最高保真度 |
| 延迟模拟 | ⭐⭐⭐⭐ | DelayedImplicitActuator，但粒度较粗 |
| DR 覆盖 | ⭐⭐⭐⭐ | 较完整的域随机化 |
| 部署能力 | ❌ | 完全不涉及 |
| 安全机制 | ❌ | 不涉及 |
| 机器人多样性 | ⭐⭐ | 仅 G1 + SMPL |
| 文档完整性 | ⭐⭐⭐⭐⭐ | 论文开源，社区活跃 |

**motion_tracking_controller**（官方部署库）：

| 维度 | 评分 | 说明 |
|:----|:---:|:------|
| 部署能力 | ⭐⭐⭐⭐⭐ | ROS2 工业级，最完善的部署框架 |
| 安全机制 | ⭐⭐⭐⭐⭐ | ROS2 生命周期 + E-stop |
| 控制频率 | ⭐⭐⭐⭐⭐ | 500Hz PD 控制 |
| 训练能力 | ❌ | 不涉及 |
| DR 覆盖 | ❌ | 不涉及 |
| 机器人多样性 | ⭐⭐ | 仅 G1 |
| 验证工具链 | ⭐⭐⭐ | 部分验证 |

**unitree_rl_mjlab**（宇树全家桶）：

| 维度 | 评分 | 说明 |
|:----|:---:|:------|
| 三合一能力 | ⭐⭐⭐⭐⭐ | 唯一训练+部署+仿真全覆盖 |
| 机器人多样性 | ⭐⭐⭐⭐⭐ | 6 种机型 |
| 验证工具链 | ⭐⭐⭐⭐⭐ | 7 个验证工具 |
| 安全机制 | ⭐⭐⭐⭐ | FSM 安全体系 |
| 延迟模拟 | ⭐⭐ | 框架已有未启用 |
| DR 覆盖 | ⭐⭐⭐ | 基础齐全但未充分利用 |
| 文档完整性 | ⭐⭐⭐ | 代码有注释但系统性文档不足 |

**Mini-Pi-Plus_BeyondMimic**（特定硬件完整实现）：

| 维度 | 评分 | 说明 |
|:----|:---:|:------|
| 数据链完整性 | ⭐⭐⭐⭐⭐ | 包含重定向到部署的全链路 |
| 训练能力 | ⭐⭐⭐⭐ | 基于 Isaac Lab |
| 部署能力 | ⭐⭐⭐⭐ | 真机验证 |
| 通用性 | ⭐⭐ | 仅特定硬件 |
| 信息透明度 | ⭐⭐ | 公开信息有限 |

### 7.2 关键缺失：扩散模型

**所有四仓库均未实现扩散模型**。BeyondMimic 论文的两阶段框架中：

1. **阶段一**（运动跟踪策略训练）：四个仓库都已实现
2. **阶段二**（离线蒸馏扩散模型 + classifier guidance）：**没有仓库实现**

BeyondMimic 论文原文对阶段二的描述：

> "Moving beyond the mere imitation of existing motions, we propose a unified latent diffusion model that empowers versatile goal specification, seamless task switching, and dynamic composition of these agile behaviors. Leveraging classifier guidance, a diffusion-specific technique for test-time optimization toward novel objectives, our model extends its capability to solve downstream tasks never encountered during training, including motion inpainting, joystick teleoperation, and obstacle avoidance, and transfers these skills zero-shot to real hardware."

即扩散模型的核心价值在于：从多个运动跟踪策略中蒸馏出一个统一的扩散模型，利用 classifier guidance 在测试时通过简单 cost function 实现零样本下游任务（航点导航、摇杆遥控、避障等）。

目前四个仓库都只完成了阶段一的工作。如果希望复现论文完整效果，还需要实现：
- 策略采集（从多个 tracking policy 收集状态-动作数据）
- 潜空间扩散模型训练
- Classifier guidance 推理框架

### 7.3 各仓库的独特价值

**whole_body_tracking 的核心优势**：
- 论文官方训练库，最忠实于论文的 MDP 设计
- 基于 Isaac Sim 4.5.0，物理仿真 fidelity 最高
- 社区活跃，持续更新
- 如果希望复现论文实验，这是最佳起点

**motion_tracking_controller 的核心优势**：
- ROS2 工业级部署，安全机制最完善
- 500Hz 高频率 PD 控制
- 支持 LiDAR 外部位置矫正
- 适合需要高可靠性和安全性的真机部署场景

**unitree_rl_mjlab 的核心优势**：
- 唯一三合一仓库，训练源码完全开放（不依赖 Isaac Sim/NVIDIA 生态）
- 基于 MuJoCo 开源物理引擎，无需商业许可
- 支持机器人种类最多（G1/H1_2/H2/Go2/A2/R1）
- 验证工具链最完善（7 个 Python/C++ 工具）
- 如果希望自定义训练并部署到宇树机器人，这是最佳选择

**Mini-Pi-Plus_BeyondMimic 的核心优势**：
- 数据链最完整——包含从视频到真机的全流程
- 对于使用 Mini-Pi-Plus 硬件的团队，提供了最完整的参考实现

---

## 第八章：从论文角度看四仓库的覆盖

### 8.1 论文完整 Pipeline 分解

BeyondMimic 论文的完整 pipeline 包括以下环节：

```
[数据] → [重定向] → [预处理] → [RL 训练] → [ONNX 导出] → [Sim 验证] → [真机部署] → [扩散蒸馏] → [下游任务]
  ▲          ▲          ▲           ▲            ▲            ▲           ▲            ▲            ▲
  |          |          |           |            |            |           |            |            |
阶段 1: 运动跟踪策略训练与部署 ─────────────────────────────────────────────┘
阶段 2: 扩散模型蒸馏与下游任务 ─────────────────────────────────────────────────────────────────┘
```

各仓库覆盖范围：

| 环节 | whole_body_tracking | motion_tracking_controller | Mini-Pi-Plus | unitree_rl_mjlab |
|:----|:-----------------:|:------------------------:|:------------:|:---------------:|
| 动捕/视频数据 | ❌ | ❌ | ✅ | ❌ |
| 运动重定向 | ❌（使用已重定向数据）| ❌ | ✅ | ❌（使用 Unitree LAFAN1）|
| 数据预处理（CSV→NPZ）| ✅ | ❌ | ✅ | ✅ |
| RL 训练（PPO）| ✅ | ❌ | ✅ | ✅ |
| ONNX 导出 | ✅ | ❌（加载 ONNX）| ✅ | ✅ |
| Sim 验证（MuJoCo） | ❌ | ✅ | ✅ | ✅ |
| C++ 真机部署 | ❌ | ✅ | ✅ | ✅ |
| 扩散模型蒸馏 | ❌ | ❌ | ❌ | ❌ |
| Classifier guidance | ❌ | ❌ | ❌ | ❌ |

### 8.2 论文核心要点的覆盖

**要点一：阶段一→阶段二的整体 pipeline**

论文提出两阶段框架：训练 tracking policy → 离线蒸馏 diffusion model → 部署用 classifier guidance 解决下游任务。

四仓库全部完成了阶段一的工作（训练 tracking policy + ONNX 导出 + 部署）。**阶段二的扩散模型和 classifier guidance 是空白**。这意味着任何基于四仓库的现有代码都无法直接复现论文的第二阶段效果。

**要点二：Sim2Real 的关键——延迟建模**

> "carefully model the robot actuation based on classical mechanics principles and ensure proper system implementation to minimize deployment discrepancies, such as delays"

论文明确将延迟列为需要最小化的部署差异之一。在四仓库中：
- whole_body_tracking 实现了 `DelayedImplicitActuator`（控制步粒度 5ms）
- unitree_rl_mjlab 框架提供了 `DelayedActuator`（物理步粒度 2ms，更精细），但未启用
- motion_tracking_controller 和 Mini-Pi-Plus 的延迟处理依赖硬件特性

**要点三：室外高动态动作**

论文在室外软土、落叶、不平地面上展示了空中翻滚等高动态动作。目前只有 whole_body_tracking 的训练配置（使用 Isaac Sim 的复杂地形支持）可以模拟类似场景。unitree_rl_mjlab 的 Tracking 任务默认只在平地训练。

**要点四：Zero-shot 部署**

论文强调 zero-shot 部署，无需 motion-specific tuning。四仓库中，unitree_rl_mjlab 和 motion_tracking_controller 都支持从 ONNX 直接加载运行，不需要对每个新 motion 重新调整参数。但这取决于训练时的 DR 配置是否足够鲁棒。

**要点五：Classifier guidance 零样本下游任务**

论文使用 classifier guidance 实现零样本下游任务（waypoint navigation, joystick teleoperation, obstacle avoidance）。这是阶段二的核心贡献，目前**无仓库实现**。

**要点六：域随机化的范围**

> "domain randomization only to truly uncertain physical properties"

论文强调只在真正不确定的物理属性上进行域随机化。改进分析报告中指出，当前 unitree_rl_mjlab tracking 的 DR 配置仅包含 4 项随机化（push_robot、base_com、encoder_bias、foot_friction），远少于 velocity tracking。建议补充执行器延迟（P0）、PD 增益（P0）、力矩限制（P0）、关节阻尼（P0）等关键缺失项。

### 8.3 如果复现论文完整 Pipeline，还需要什么？

假设从 unitree_rl_mjlab 作为基础（因为它是唯一三合一的仓库），复现学术论文完整 pipeline 需要补充以下部分：

**短期（已有部分实现）**：
1. ✅ 训练 Motion Tracking 策略——已完成
2. ✅ ONNX 导出——已完成  
3. ✅ C++ 部署——已完成（含 FSM 安全体系）
4. ✅ Sim2Sim 验证工具链——已完成

**中期（需基于现有框架扩展）**：
5. ⚠️ 启用 DelayedActuator——添加配置即可（P0 优先级）
6. ⚠️ 补充缺失的 DR 项（PD 增益、力矩限制、关节阻尼）——添加配置即可（P0 优先级）
7. ❌ 实现策略数据采集 pipeline——需开发（从 tracking policy rollout 中收集状态-动作对）
8. ❌ 实现潜空间扩散模型训练——需开发

**长期（全新开发）**：
9. ❌ 实现 Classifier Guidance 推理框架——需开发
10. ❌ 实现下游任务适配层（航点导航、避障等）——需开发
11. ❌ 实现真机测试闭环——需硬件配合

**补充：运动重定向部分**

如果希望从原始动捕或视频数据开始，还需要补充：
- 动捕数据处理或 GVHMR 视频 → SMPLX 转换
- GMR 运动重定向到目标机器人

这些在 unitree_rl_mjlab 中都不包含，需要集成外部工具。

---

## 附录：主要参考资料

1. **BeyondMimic 论文**：arXiv:2508.08241, "BeyondMimic: From Motion Tracking to Versatile Humanoid Control via Guided Diffusion", Liao et al., 2025
2. **whole_body_tracking**：https://github.com/HybridRobotics/whole_body_tracking
3. **motion_tracking_controller**：宇树官方部署库（ROS2 + legged_control2）
4. **unitree_rl_mjlab**：宇树自研训练部署框架（MuJoCo + mjlab）
5. **Mini-Pi-Plus_BeyondMimic**：特定硬件完整实现仓库
6. **mjlab 解读系列 01-05 篇**：训练架构剖析、Velocity/Motion Tracking 分析、域随机化改进、C++ 部署系统
