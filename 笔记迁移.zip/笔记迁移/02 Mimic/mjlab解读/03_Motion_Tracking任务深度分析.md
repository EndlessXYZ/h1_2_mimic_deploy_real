# Motion Tracking / Mimic 任务深度分析

## 一、引言

Motion Tracking（运动跟踪/运动模仿，亦称 Mimic）是机器人强化学习中的一个核心任务范式。其目标并非让机器人自主决策"去哪里、怎么走"，而是要求机器人**精确复现一段或多段参考运动轨迹**——从人类的行走、跑步，到挥手、转身等复杂全身运动。在 Unitree RL 框架（mjlab）中，Tracking 任务与 Velocity Tracking 并列，形成了两种互补的 locomotion 训练范式。

本文基于 `mjlab/src/tasks/tracking/` 目录下的全部源代码，对 Motion Tracking 任务进行**极其细致的深度分析**，涵盖运动数据加载与管理（MotionLoader）、参考指令生成（MotionCommand）、观测系统设计、奖励函数构造、终止条件、训练策略（自适应采样）、ONNX 部署模型设计、Ghost 可视化、多运动混合训练，以及与 Velocity Tracking 的全方位对比。

---

## 二、MotionCommand 核心机制深度分析

### 2.1 整体架构

`MotionCommand`（位于 `tracking/mdp/commands.py`）是 Motion Tracking 任务的**核心指令管理器**。它继承自 `CommandTerm`，承担以下职责：

1. 通过 `MotionLoader` 加载和管理参考运动数据
2. 在训练过程中逐帧推进参考运动的时间索引
3. 在每回合开始时（resample）采样起始帧
4. 将参考运动数据暴露给观测系统和奖励函数

其工作流程可概括为：**加载 → 索引 → 采样 → 推进 → 暴露**。

### 2.2 MotionLoader：多运动加载与管理

`MotionLoader` 是运动数据的统一加载器，支持三种输入形式：

- **单个 NPZ 文件**：直接加载单一运动轨迹
- **NPZ 元组（tuple）**：加载多个运动，权重均等，所有运动使用 WRAP（循环）模式
- **YAML 配置文件**：最灵活的方式，可为每个运动指定权重（weight）和循环模式（wrap/clamp）

YAML 的典型结构如下：

```yaml
motions:
  - file: "walk.npz"
    weight: 2.0
    loop_mode: "wrap"
    name: "walk"
  - file: "stand.npz"
    weight: 1.0
    loop_mode: "clamp"
    name: "stand"
```

`_load_from_yaml` 静态方法解析 YAML 后返回 `(file_list, weights, loop_modes, names)` 四元组，其中 `name` 字段在导出多运动 ONNX 模型时用于生成部署配置。

**关键数据结构**：`MotionLoader` 将所有运动数据拼接到连续的张量中（通过 `torch.cat`），同时维护 `_length_starts` 数组记录每个运动在拼接张量中的起始偏移量。这种"拼接而非分片"的设计使得帧索引可以通过统一的 `frame_idx` 完成，但在多运动场景下需要额外维护 `current_motion_idx` 来区分当前属于哪个运动。

**FPS 感知机制**：这是 MotionLoader 的一个关键设计。参考运动数据通常以 50Hz 或 100Hz 记录，而训练步长（step_dt）通常为 0.02s（50Hz 控制频率 × decimation=4 → 实际动作频率 12.5Hz）。`_frames_per_step = fps × step_dt` 建立了从"环境步"到"运动帧"的转换关系。例如，一个 50FPS 的运动在 step_dt=0.02 的环境下，每步推进 1 帧；若运动为 100FPS，则每步推进 2 帧。`_motion_steps = ceil(total_frames / frames_per_step)` 计算出每个运动对应的环境步数，用于循环和采样。

**循环模式**：
- **WRAP（循环模式）**：运动播放到末尾后回到第 0 帧，并累加 `_wrap_offset` 记录位置偏移（根位置末帧 - 首帧，仅 XY 方向，Z 方向归零）。这样每轮循环机器人在世界中持续前进。
- **CLAMP（钳位模式）**：运动播放到末尾后标记为 `TerminationType.SUCC`（成功终止），环境会触发重置。

`wrap_delta` 的计算非常精巧：取 root body（index 0）的首帧和末帧位置差，将 Z 分量置零。这意味着 WRAP 模式只补偿水平位移，而垂直方向的高度变化由奖励函数和终止条件共同约束。

### 2.3 RSI（Residual Stage-wise Imitation）扰动机制

RSI 是 Motion Tracking 中至关重要的**随机化技术**，位于 `_resample_command` 方法中。当每个环境在回合开始时重新采样运动帧，RSI 对参考运动的状态施加随机噪声：

1. **位姿扰动（pose_range）**：对根位置（x, y, z）和根朝向（roll, pitch, yaw）各施加均匀噪声。H1_2 的默认值为：平移 ±0.05m（xy）、±0.01m（z），旋转 ±0.1rad（roll/pitch）、±0.2rad（yaw）。

2. **速度扰动（velocity_range）**：对根线速度和角速度施加 ±0.5m/s（线速度 xy）、±0.2m/s（z）和 ±0.52rad/s（roll/pitch）、±0.78rad/s（yaw）的噪声。

3. **关节位置扰动（joint_position_range）**：对每个关节位置施加 ±0.1rad 的噪声，然后通过 `soft_joint_pos_limits` 裁剪到合法范围。

RSI 的物理意义在于：**防止策略过拟合到参考运动的精确初始状态**。如果没有 RSI，策略会学到"从第 X 帧开始、关节处于精确位置 Y"的捷径，一旦部署时初始条件稍有偏差就会失败。RSI 迫使策略学会从偏离参考的状态**纠正回参考轨迹**的能力——这是"跟踪"的核心能力。

值得注意的是，RSI 通过 `write_joint_state_to_sim` 和 `write_root_state_to_sim` 直接写入仿真状态，然后调用 `clear_state` 清空速度残差。这意味着 RSI 是在**物理 reset 之前**对仿真状态做的一次"初始化注入"，不违反物理约束（关节位置会被限位裁剪）。

### 2.4 三种采样模式深度分析

`MotionCommand` 支持三种采样模式，通过 `sampling_mode` 参数控制：

#### 2.4.1 Start 模式（play 模式）

始终从第 0 帧开始播放。这是**评估/部署模式**：每个回合从头开始播放运动，确保可重复性和确定性。在 H1_2 的 play 配置中，`sampling_mode="start"` 且 `pose_range` 和 `velocity_range` 被清空（禁用 RSI），`enable_corruption=False`（禁用观测噪声），`push_robot` 事件被移除——所有随机化被关闭，只保留纯粹的跟踪能力测试。

#### 2.4.2 Uniform 模式

从运动轨迹中**均匀随机**采样起始帧。这是最简单的训练采样策略，每个时间步被选中的概率相等。`_uniform_sampling` 方法直接调用 `torch.randint(0, ns, ...)` 生成起始帧。

#### 2.4.3 Adaptive 模式（默认训练模式）

这是最精妙的采样策略，其核心思想是：**策略在运动轨迹上各位置的性能不同，应该在策略表现差的位置更频繁地采样**，实现自适应的课程学习。

**数学原理**：

1. **分桶（Binning）**：将每个运动轨迹划分为 `nb` 个 bin（桶），每个 bin 覆盖连续的若干环境步。bin 的大小由 FPS 感知计算：`frames_per_bin = max(1, round(fps × step_dt))`，然后 `nb = nf / frames_per_bin + 1`。对于 50FPS、step_dt=0.02 的运动，每个 bin 对应 1 帧，nb 约等于总帧数。

2. **失败率追踪**：每个 bin 维护一个 EMA（指数移动平均）的失败计数值 `_motion_bin_failed_count`。每次回合结束时，检查哪些环境终止（`terminated=True`），找到这些环境的当前 bin 索引，通过 `torch.bincount` 统计每个 bin 的失败次数，存入 `_motion_current_bin_failed`。

3. **EMA 平滑**：每步更新时：
   ```
   bin_failed_count = alpha * current_bin_failed + (1 - alpha) * bin_failed_count
   ```
   其中 `adaptive_alpha = 0.001`。这意味着历史失败率以指数衰减的方式影响当前采样概率，近期失败对采样影响更大。

4. **核平滑（Kernel Smoothing）**：为防止相邻 bin 间的概率陡变，对采样概率应用 1D 卷积核进行平滑：
   ```
   kernel[i] = lambda^i  (i = 0, 1, ..., kernel_size-1)
   kernel = kernel / sum(kernel)
   ```
   其中 `adaptive_lambda = 0.8`，`adaptive_kernel_size` 默认为 1（即不平滑）。随着核大小的增加，相邻 bin 的概率分布更加平滑。

5. **均匀混合**：为保证探索，每个 bin 的最终采样概率加入均匀分布的混合：
   ```
   prob = bin_failed_count + adaptive_uniform_ratio / nb
   ```
   `adaptive_uniform_ratio = 0.1` 确保即使某个 bin 从未失败，仍有基础概率被采样到。

6. **加权采样**：通过 `torch.multinomial(probabilities, count, replacement=True)` 进行多项式采样，选择起始 bin。然后在 bin 内均匀采样具体的时间步。

7. **信息论指标**：对于单运动场景，还计算了采样分布的熵（归一化后，范围 [0,1]）和 Top-1 概率。熵接近 1 表示均匀采样（策略在所有位置表现接近），熵降低表示策略在某些位置持续失败、采样集中在这些区域。

自适应采样的优点在于：**训练效率显著提升**。策略不需要在已经擅长的时间段浪费样本，而是将计算资源集中在困难的时间段（如单脚支撑过渡期、手臂摆动极值点等）。

---

## 三、6D 旋转矩阵表示 vs 四元数/欧拉角优劣分析

在 Motion Tracking 的观测系统中，一个**非常重要的设计选择**是使用 6D 旋转矩阵表示（旋转矩阵的前两行，共 6 个数值）来表示朝向信息，而非直接使用四元数（4 个数值）或欧拉角（3 个数值）。

### 3.1 三种表示方式对比

| 表示方式 | 维度 | 连续性 | 奇异性 | 神经网络友好度 |
|:--------:|:----:|:------:|:------:|:--------------:|
| 欧拉角 | 3 | 不连续 | 有（万向锁） | 低 |
| 四元数 | 4 | 双覆盖（q 和 -q 等价） | 无 | 中 |
| 6D 表示 | 6 | 连续且唯一 | 无 | 高 |

### 3.2 6D 表示的优势

**1. 连续性（最重要的优势）**

神经网络本质上是连续函数的逼近器。欧拉角在接近 ±π 时存在角度跳变，四元数存在 q 和 -q 表示同一旋转的二义性，这两种不连续性都会让神经网络难以学习。6D 旋转矩阵表示（取 3×3 旋转矩阵的前两行，共 6 个元素）是整个 SO(3) 群上的**连续且唯一的表示**——旋转矩阵的每个元素都是旋转角度的光滑函数，没有跳变点。

引用 Zhou et al. (2019) 在 *"On the Continuity of Rotation Representations in Neural Networks"* 中的理论证明：**连续映射的旋转表示对于神经网络的稳定学习至关重要**。6D 表示是 SO(3) 上连续的最小维表示之一。

**2. 无奇异性**

欧拉角在 pitch = ±90° 时出现万向锁（两个轴的旋转自由度合并），导致数值不稳定。四元数虽然无奇异性但有双覆盖问题。6D 旋转矩阵表示完全没有这些问题。

**3. 便于误差计算**

在奖励函数中，朝向误差通过四元数误差幅度（`quat_error_magnitude`）计算，这是因为四元数的误差度量在数学上更直接（对应旋转角度）。但在观测输入中，6D 表示更适合作为神经网络的输入特征。

### 3.3 代码中的实现

在 `observations.py` 中，`motion_anchor_ori_b` 和 `robot_body_ori_b` 两个观测函数都使用了相同的模式：

```python
mat = matrix_from_quat(ori)  # quat → 3×3 旋转矩阵
return mat[..., :2].reshape(mat.shape[0], -1)  # 取前两行 → 6D
```

`motion_anchor_ori_b` 提供**参考运动锚点相对于机器人锚点的相对朝向**（6D），`robot_body_ori_b` 提供**机器人各 body 相对于机器人锚点的朝向**（每个 body 6D，共 K×6 维）。两者都使用 6D 表示。

### 3.4 为何奖励函数中仍使用四元数

尽管观测中使用 6D 表示，奖励函数中的朝向误差仍通过 `quat_error_magnitude` 计算。这是因为：

1. 四元数误差幅度有明确的物理含义：`error = arccos(|q1·q2|)`，结果即为旋转角度（弧度），单位明确。
2. 指数型奖励函数 `exp(-error²/std²)` 需要误差的物理意义清晰，便于设定 std 参数。
3. 四元数误差幅度对两个朝向的微小偏差具有平滑的梯度，适合梯度优化。

观测输入和奖励计算使用不同的旋转表示，这种"各取所长"的设计是工程实践中的最佳选择。

---

## 四、观测系统设计深度分析

### 4.1 Actor 观测（策略网络输入）

Actor 观测共 150 维（以 H1_2 为例，N=27 个自由度），每个观测项的设计意图如下：

#### 4.1.1 command（54 维）

由参考运动的关节位置（`joint_pos`，27 维）和关节速度（`joint_vel`，27 维）拼接而成。这是 "command" 的核心——策略通过 `command` 知道"参考运动希望我的关节在哪、以多快速度运动"，然后调整自己的动作去匹配。

#### 4.1.2 motion_anchor_pos_b（3 维）

参考锚点（anchor body，H1_2 为 `torso_link`）相对于机器人锚点的位置，**在机器人本体坐标系下表示**。这告诉策略"我的躯干应该相对于当前躯干往哪个方向移动"。

实现方式：
```python
pos, _ = subtract_frame_transforms(
    robot_anchor_pos_w, robot_anchor_quat_w,  # 源坐标系（机器人锚点）
    anchor_pos_w, anchor_quat_w,              # 目标点（参考锚点）
)
```
`subtract_frame_transforms` 本质上是将世界系下的参考锚点位置转换到机器人锚点坐标系下：`pos_b = R_robot_inv × (pos_ref_w - pos_robot_w)`。

#### 4.1.3 motion_anchor_ori_b（6 维）

参考锚点相对于机器人锚点的朝向，使用 6D 旋转矩阵表示。这告诉策略"我的躯干应该旋转到什么朝向"。

#### 4.1.4 base_lin_vel（3 维）和 base_ang_vel（3 维）

来自 IMU 传感器的线速度和角速度。在实际机器人上，线速度通常需要通过视觉或轮式里程计估计（或没有），角速度由陀螺仪直接测量。

#### 4.1.5 joint_pos（27 维）和 joint_vel（27 维）

当前关节位置（含 bias 噪声）和关节速度。`joint_pos` 使用 `biased=True` 模拟编码器偏置误差。

#### 4.1.6 actions（27 维）

上一步动作，用于建立动作的时间依赖性，类似于 PPO 中的 action buffer。

### 4.2 Critic 观测（特权信息）

Critic 观测包含 Actor 的全部 150 维（**无噪声**），再加上**特权信息**：

- **body_pos（81 维）**：3 维位置 × 27 个 body（H1_2 的 `body_names` 共 14 个，此处为 3×27 似乎有误，实际应为 3×14=42 维。但源材料中标注为 3×27=81，可能使用了更多的 body 数量，或 body_names 扩展到了 27 个）

- **body_ori（162 维）**：6 维朝向 × 27 个 body（同理）

这些特权信息告诉 Critic 所有身体部位在锚点坐标系下的精确位置和朝向——这些信息在真实机器人上无法直接测量，但 Critic 仅在训练时使用，辅助 PPO 的价值估计。

Critic 观测总维度：150 + 81 + 162 = 393 维。

### 4.3 观测系统中的"锚点"概念

锚点（anchor body）是 Motion Tracking 中**极其核心的概念**。锚点是参考运动与机器人之间的"对齐点"——通常选择躯干上的一个 body（H1_2 为 `torso_link`）。

锚点的作用：
1. **位置对齐**：所有身体部位的位置都相对于锚点表示（`body_pos_relative_w`），消除全局漂移的影响。策略只需要关注"我的身体部位相对于锚点的姿态是否正确"，而不需要关注"我在世界中的位置是否正确"。
2. **朝向对齐**：类似地，朝向也相对于锚点表示。
3. **终止条件**：锚点的位置和朝向偏差超过阈值时触发终止，防止策略"为了匹配身体姿态而扭曲了锚点"。

在 `_update_command` 中，`body_pos_relative_w` 和 `body_quat_relative_w` 的更新是每步的关键操作，包含**偏航对齐**处理：
```python
delta_ori_w = yaw_quat(quat_mul(robot_anchor_quat_w, quat_inv(anchor_quat_w)))
```
`yaw_quat` 提取旋转中的偏航分量，这意味着只有偏航方向的漂移被补偿，roll 和 pitch 的偏差仍然保留——因为 roll/pitch 偏差会影响机器人平衡，必须由策略纠正。

---

## 五、has_state_estimation 模式深度分析

这是 Motion Tracking 中最具实践意义的设计之一，控制策略的信息获取方式。

### 5.1 Estimate 模式（完整 150 维）

在 `has_state_estimation=True` 时，Actor 接收完整的 150 维观测，包括 `motion_anchor_pos_b`（3 维）和 `base_lin_vel`（3 维）。这意味着策略依赖"状态估计系统"提供：
- **参考锚点相对于机器人的位置**（需要知道机器人自身的位姿才能计算）
- **机器人本体线速度**（需要视觉或里程计估计）

这是传统设定：假设机器人有完善的 state estimation（如通过 SLAM、VIO、轮式里程计等），策略可以直接使用这些信息。

### 5.2 No-Estimate 模式（144 维）

当 `has_state_estimation=False` 时：
- 移除 `motion_anchor_pos_b`（3 维）
- 移除 `base_lin_vel`（3 维）
- Actor 观测缩减为 144 维

这种模式**模拟真实机器人上缺乏状态估计的情况**——例如足式机器人没有视觉、没有 GPS、没有轮式里程计，只有关节编码器和 IMU。

### 5.3 无状态估计时策略如何推断状态

这是 No-Estimate 模式最引人入胜的问题。移除 base_lin_vel 和 anchor_pos_b 后，策略如何知道自己的身体位置和速度？

策略必须**隐式推断状态**，利用以下信息：

1. **关节位置与速度（54 维，含噪声）**：通过关节角度和角速度，结合运动学模型，可以推断出姿态的大致信息。例如，膝关节弯曲角度可以暗示是否处于蹲姿。

2. **IMU 角速度（3 维）**：陀螺仪直接测量躯干角速度，结合时间积分可推断朝向变化。

3. **IMU 重力方向（隐式）**：虽然 `motion_anchor_ori_b`（6D）提供了参考朝向，但策略可以通过角速度积分和重力方向感知自身的朝向变化——重力方向不在显式观测中，但可以通过加速度计（在 base_lin_vel 的位置），然而在 No-Estimate 中 base_lin_vel 也被移除。实际上，IMU 的线速度观测量被移除了，但 mjlab 的 IMU 传感器可能仍然提供加速度信息（需要通过代码确认）。

4. **动作历史（actions，27 维）**：策略知道"我上一步做了什么动作"，结合关节响应的延迟，可以推断出当前状态。

5. **参考运动信息（command，54 维）**：策略知道"参考运动期望我处于什么状态"。

**本质上，策略通过时间序列信息的隐式积分来推断状态**。例如：
- 角速度积分 → 朝向变化
- 动作 + 关节位置 → 运动阶段推断
- 关节位置 vs 参考关节位置 → "滞后量"感知

为了补偿缺乏状态估计带来的困难，No-Estimate 模式在训练中做了以下调整：

**奖励函数调整**：
- 增加辅助奖励项如 `capture_point_balance`（捕获点平衡）、`root_stay_in_place`（防漂移）、`foot_slip`（足底滑动惩罚）、`body_orientation`（躯干姿态惩罚）
- 放宽部分跟踪奖励的 std（如 body_pos std 0.3→0.45，body_ori std 0.4→0.55），降低对精确姿态跟踪的要求，给策略更多自由度来维持平衡

**终止条件调整**：
- `anchor_pos` 阈值从 0.25m 收紧到 0.15m：没有全局定位信息时，限制机器人在小范围内活动，防止盲目游走
- `ee_body_pos` 阈值从 0.25m 放宽到 0.35m：允许末端执行器有更大的位置偏差

### 5.4 实际部署意义

No-Estimate 模式更加**接近真实部署**。实际足式机器人上，精确的全局定位（尤其是在室内无 GPS 环境）是困难的。策略如果能仅依靠 proprioceptive（本体感受）传感器——关节编码器和 IMU——完成运动跟踪，其部署成本、可靠性和通用性将大幅提升。

这也是 HuB（Humanoid Controller 风格）的核心思想：让策略学会"盲跟踪"，仅凭本体感受器感知世界。

---

## 六、奖励函数设计深度分析

Motion Tracking 的奖励系统包含 **9 项核心奖励**（6 项正向跟踪奖励 + 3 项惩罚），外加 No-Estimate 模式下的若干辅助奖励。

### 6.1 指数型奖励函数设计

所有跟踪奖励都使用**指数型**函数：
```
reward = exp(-error² / std²)
```

这种设计的特点：
- 误差为零时奖励为 1.0（最大值）
- 误差 = std 时奖励 ≈ 0.3679
- 误差 = 2×std 时奖励 ≈ 0.0183（几乎为 0）
- 误差越大，奖励下降越快

std 参数实际上控制了"可接受的误差范围"——std 越大，相同误差下的奖励越高，策略对误差的容忍度越大。

### 6.2 六项核心跟踪奖励

#### 6.2.1 motion_global_root_pos（权重 0.5，std 0.3）

全局锚点位置误差。计算世界系下参考锚点与机器人锚点的距离平方，取指数。权重仅 0.5，因为全局位置重要性相对较低——跟踪的核心是姿态而非位置。

#### 6.2.2 motion_global_root_ori（权重 0.5，std 0.4）

全局锚点朝向误差。使用四元数误差幅度计算。std 0.4 比位置略宽松，因为朝向控制允许一定偏差。

#### 6.2.3 motion_body_pos（权重 1.0，std 0.3）

**最重要的奖励项之一**。计算各身体部位在锚点相对系下的位置误差。权重为 1.0 说明姿态跟踪是核心目标。std 0.3 表示 0.3m 的 body 位置误差会得到约 0.37 的奖励——这是一个比较紧的约束。

#### 6.2.4 motion_body_ori（权重 1.0，std 0.4）

各身体部位朝向误差（相对锚点系）。std 0.4 比位置略宽松，因为身体朝向存在一定的可接受误差范围。

#### 6.2.5 motion_body_lin_vel（权重 1.0，std 1.0）

各身体部位线速度误差（世界系）。std 1.0 意味着速度误差容忍范围较大（1.0 m/s），符合运动速度范围较大的实际情况。速度误差 $error = \sum ||v_{ref} - v_{robot}||^2$ 是标量，物理单位 m/s。

#### 6.2.6 motion_body_ang_vel（权重 1.0，std 3.14）

**关于为什么 std=3.14（π）**：

这是奖励函数设计中最值得分析的一个参数。3.14 ≈ π rad/s ≈ 180°/s。这个值看起来非常大，但有其深层次原因：

1. **角速度的量级**：机器人身体各部位（尤其是四肢末端）在世界系下的角速度可以很大。例如，手臂快速摆动时，手腕的角速度可能达到 10+ rad/s。如果 std 设置过小（如 0.5），任何动态运动的角速度误差都会导致奖励迅速归零，使得策略无法学习快速运动。

2. **相对宽松的约束**：角速度跟踪在物理上比位置跟踪更难。位置和朝向可以通过"锁定"关节位置来精确控制，但角速度受到动力学约束（惯性、力矩等）。使用大 std 意味着奖励函数对角速度误差的惩罚比较温和，策略有更大的自由度。

3. **与线速度 std 的对比**：线速度 std=1.0（m/s），角速度 std=3.14（rad/s）。在典型运动场景下，身体各部位线速度范围约 0-5m/s，角速度范围约 0-15rad/s。两个 std 值都大约是最大量程的 20-30%，比例一致。

4. **数学解释**：角速度误差的平方和很可能远大于位置误差，因为角速度在全身累加。较大的 std 相当于对误差做了归一化，使奖励项的量级与其他项匹配。

### 6.3 惩罚项

#### 6.3.1 action_rate_l2（权重 -0.1）

动作变化率的 L2 惩罚，即 `sum((action_t - action_{t-1})²)`。权重 -0.1 较小，主要作用是平滑动作、减少抖动。

#### 6.3.2 joint_limit（权重 -10.0）

关节超限位惩罚。当关节位置超出软限位时施加的高额负奖励。权重 -10.0 非常大，说明关节保护是硬约束。

#### 6.3.3 self_collisions（权重 -10.0）

自碰撞惩罚。通过接触传感器检测身体各部位之间的碰撞力（force > 10N 算碰撞）。同样权重极高，因为自碰撞不仅会损坏机器人，还会导致仿真不稳定。

### 6.4 No-Estimate 模式辅助奖励

当 `has_state_estimation=False` 时激活的辅助奖励：

- **capture_point_balance（权重 0.2）**：基于 LIPM（线性倒立摆模型）的捕获点平衡奖励。计算捕获点（CP = COM + COM_vel / ω）与支撑中心之间的距离。ω = sqrt(g / h) 是倒立摆的固有频率。这本质上是奖励策略维持动态平衡。

- **root_stay_in_place（权重 0.45）**：锚点防漂移奖励。惩罚机器人在 XY 方向上的全局漂移——因为没有全局定位，漂移过多会导致危险。

- **foot_slip（权重 -2.0）**：足底滑动惩罚。检测支撑相（足底高度 < 4cm）时足底的世界系线速度。权重大说明滑动是不可接受的。

- **body_orientation（权重 -2.0）**：躯干倾斜惩罚。通过投影重力的 XY 分量大小衡量躯干是否水平。

- **body_ang_vel（权重 -0.1）**：躯干角速度惩罚，抑制躯干抖动。

- **contact_mode_match（权重 -0.5）**：接触模式匹配惩罚。比较参考运动和仿真中足底的接触状态（通过足底高度 < 4cm 推断接触）。不匹配时施加惩罚。这是来自 ProtoMotions 的经典设计。

- **contact_vel_matching（权重 -1.0）**：接触速度匹配惩罚。当参考运动表示足底应处于接触状态时，惩罚足底的滑动速度。

这些辅助奖励弥补了 No-Estimate 模式下缺乏状态估计带来的信息缺失。它们的共同特点是：
1. 使用**世界系**参考帧（如足底位置、滑动速度），不需要本体状态估计
2. 依赖**物理常识**（如 LIPM 模型、接触状态推断）
3. 通过**间接监督**帮助策略维持平衡

---

## 七、终止条件分析

| 终止条件 | 含义 | 阈值 | 物理意义 |
|:--------|:----|:----:|:--------:|
| time_out | 回合超时 | 10s | 防止无限循环 |
| anchor_pos | 锚点高度偏离参考 | >0.25m | 躯干高度失控 |
| anchor_ori | 锚点朝向偏离参考 | 重力投影差>0.8 | 躯干严重倾斜 |
| ee_body_pos | 末端执行器高度偏离 | >0.25m | 手脚位置失控 |

**anchor_ori** 的终止检测使用了一种精巧的设计：比较参考运动和机器人各自在锚点坐标系下投影的重力方向（`projected_gravity_b` 的 Z 分量差 > 0.8）。这本质上是检测"躯干相对于重力方向的倾斜程度"，与全局朝向无关——即使机器人在世界中的航向与参考不同，只要躯干直立，就不会触发终止。

**termination_type** 机制记录了终止原因（SUCC/FAIL/TIMEOUT/OTHER），在多运动训练中用于统计各运动的成功/失败次数，进而影响运动选择权重（间接影响，通过自适应采样）。

---

## 八、Motion Tracking 与 Velocity Tracking 的本质区别

这是理解整个 motion tracking 任务设计的关键对比。

### 8.1 任务目标

| 维度 | Velocity Tracking | Motion Tracking |
|:----|:-----------------|:---------------|
| 目标 | 跟踪速度指令（前进/后退/转向） | 跟踪完整运动轨迹（含全身姿势） |
| 输出 | 基频速度 | 全身关节位置 |
| 自由度 | 高层命令（"往前走"） | 底层命令（"每个关节在每时刻的位置"） |
| 复杂度 | 相对简单，单任务 | 极高，需跟踪完整运动 |

### 8.2 观测依赖

**Velocity Tracking** 的观测主要包括：
- 速度指令（x, y, yaw）
- IMU 数据（角速度、投影重力）
- 关节位置/速度
- 动作历史
- 地形扫描（可选）

其**观测不依赖于参考运动**——参考只是一个速度标量。

**Motion Tracking** 的观测核心是 **reference command（54 维）**——参考运动的关节位置和速度。策略每步都知道"参考运动希望我处于什么状态"，然后据此调整动作。

### 8.3 奖励函数

| 维度 | Velocity Tracking | Motion Tracking |
|:----|:-----------------|:---------------|
| 核心奖励 | 跟踪线速度/角速度 | 跟踪全身姿态+速度 |
| 姿态奖励 | 单一姿态奖励（pose） | 细分为 body_pos/body_ori/... |
| 支撑相 | 足底高度/滑动/空域 | 接触模式匹配 |
| 动作惩罚 | DOF-specific std 参数 | 统一 action_rate_l2 |

Velocity Tracking 的奖励函数往往是 DOF（自由度）级别的——不同的关节有不同的 std 参数（如膝关节 0.5、踝关节 0.1），反映了不同关节对运动质量的不同重要性。而 Motion Tracking 使用追迹误差，对所有 body 使用统一的 std 参数。

### 8.4 训练策略

| 维度 | Velocity Tracking | Motion Tracking |
|:----|:-----------------|:---------------|
| 参考生成 | 随机采样子空间 | 从参考运动数据中采样 |
| 任务难度 | 课程式（curriculum，地形/速度） | 自适应采样（按失败率） |
| 回合起点 | 随机初始状态 | 参考运动中的随机帧 |
| 最大迭代 | 10001 | 30001 |

Motion Tracking 需要更多的训练迭代（30001 vs 10001），因为任务更复杂——不仅需要学会运动，还需要精确跟踪每个时刻的状态。

### 8.5 部署模型

| 维度 | Velocity Tracking | Motion Tracking |
|:----|:-----------------|:---------------|
| 输入 | obs（~200 维） | obs（150/144 维）+ time_step |
| 输出 | actions（27 维） | actions + 全部 motion buffer 数据 |
| 模型结构 | 纯策略网络 | 策略网络 + motion buffer 复合模型 |

Velocity Tracking 部署时只需要神经网络推理，输入传感器观测、输出关节位置指令。Motion Tracking 必须将参考运动数据一起部署，通过 time_step 索引实时读取参考数据。

### 8.6 本质差异总结

**Velocity Tracking 解决的是"如何产生运动"，Motion Tracking 解决的是"如何复现运动"。**

前者需要策略**创造**出符合物理规律和速度指令的步态，后者需要策略**精确跟随**已给定的全身运动轨迹。Motion Tracking 的"上限"是参考运动的质量——如果参考运动有缺陷（如不连续、违反动力学），策略将无法良好跟踪。

---

## 九、ONNX 复合模型设计

### 9.1 为何需要复合模型

Motion Tracking 部署时面临一个特殊问题：**参考运动数据必须在推理时可用**。策略网络本身输出的只是关节位置指令（actions），但策略的状态输入需要参考运动的关节位置和速度（command 部分），而这部分数据来自外部 NPZ 文件。

在训练环境中，`MotionCommand` 管理着 `time_steps` 和运动数据张量，通过 GPU 张量索引高效获取参考帧。但在部署环境中（如 C++ 运行时），如果策略和运动数据分离，需要额外的数据传输和帧索引逻辑，增加延迟和复杂度。

解决方案是**将策略网络和运动数据打包成一个复合 ONNX 模型**。

### 9.2 复合模型结构

`_OnnxMotionModel`（单运动）和 `_OnnxMultiMotionModel`（多运动）是复合模型的核心实现：

```
输入: obs (1, obs_dim), time_step (1, 1)
输出: actions (1, N), joint_pos (1, N), joint_vel (1, N),
      body_pos_w (1, K, 3), body_quat_w (1, K, 4),
      body_lin_vel_w (1, K, 3), body_ang_vel_w (1, K, 4)
内部缓冲: 注册为 nn.Module 的 buffer（非可训练参数），包含完整运动张量
```

推理流程：
1. 接收 obs 和 time_step
2. 根据 time_step 计算 frame_idx：`frame_idx = (time_step × step_dt × fps).long()`
3. 从内部 buffer 中索引参考数据：`joint_pos[frame_idx]` 等
4. 将 obs 传入策略网络，得到 actions
5. 输出 actions + 所有参考数据

### 9.3 多运动导出策略

对于多运动训练，每个运动导出独立的 ONNX 文件，同时生成 `deploy.yaml` 配置文件：

```yaml
policies:
  - name: "walk"
    onnx: "motion_0.onnx"
    loop_mode: "wrap"
  - name: "stand"
    onnx: "motion_1.onnx"
    loop_mode: "clamp"
```

部署代码根据 `deploy.yaml` 加载对应运动的 ONNX 模型和元数据。

### 9.4 Metadata 元数据

通过 `attach_metadata_to_onnx` 将关键配置信息嵌入 ONNX 文件：
- `anchor_body_name`：锚点 body 名称
- `body_names`：所有参考 body 名称列表
- `motion_names`（多运动）：各运动名称

这些元数据在 C++ 部署端用于解析模型输出。

### 9.5 复合模型的设计价值

1. **最小化部署依赖**：只需要一个 ONNX 模型文件即可完成推理，不需要额外的 NPZ 加载逻辑
2. **零数据传输开销**：参考数据以 buffer 形式内嵌在模型中，CPU 推理时直接内存访问
3. **统一的帧索引逻辑**：训练和部署使用相同的帧索引公式（`frame_idx = time_step × step_dt × fps`），保证行为一致性
4. **C++ 友好**：C++ ONNX Runtime 可以直接加载和执行，输出完整的 8 个张量，无需额外处理

---

## 十、Ghost 可视化实现原理

### 10.1 可视化模式

`MotionCommand` 支持两种调试可视化模式（通过 `viz.mode` 参数控制）：

1. **ghost 模式**（默认）：显示参考运动的半透明模型
2. **frames 模式**：显示参考和当前各 body 的坐标系框架

### 10.2 Ghost 模式实现

```python
if self._ghost_model is None:
    self._ghost_model = copy.deepcopy(self._env.sim.mj_model)
    self._ghost_model.geom_rgba[:] = self._ghost_color  # (0.5, 0.7, 0.5, 0.5)
```

关键步骤：
1. **深拷贝 MuJoCo 模型**：复制当前仿真场景的 MjModel，用于渲染 ghost
2. **修改几何体颜色**：将所有几何体的 RGBA 设为半透明绿色
3. **构造 ghost 的 qpos**：
   - 前 3 个自由关节位置：参考运动的 root body 位置（`body_pos_w[batch, 0]`）
   - 3-7 自由关节朝向：参考运动的 root body 四元数（`body_quat_w[batch, 0]`）
   - 后续关节位置：参考运动的关节位置（`joint_pos[batch]`）
4. **调用 visualizer.add_ghost_mesh**：在指定位置渲染半透明模型

这种实现利用了 MuJoCo 的渲染能力——通过复制仿真模型并替换位置数据，可以在不实际创建物理体的前提下渲染参考姿态。

### 10.3 Frames 模式实现

Frames 模式在参考和当前机器人各 body 位置渲染坐标系框架：
- **参考帧**（粉色/绿色/蓝色，缩放 0.08）：参考运动的 body 位置和朝向
- **当前帧**（标准色，缩放 0.12）：机器人实际 body 的位置和朝向
- **锚点帧**：参考锚点（0.1）和当前锚点（0.15）的坐标系

Frames 模式对于调试非常有用——可以直观地看到"参考姿态 vs 当前姿态"的差异。

---

## 十一、多运动训练时的混合策略

### 11.1 运动选择权重

当 `MotionLoader` 加载多个运动时，每个运动在 YAML 中配置 `weight` 参数。权重经过归一化处理后作为多项式采样的概率分布：

```python
total_weight = sum(weights)
self._motion_weights = tensor([w / total_weight for w in weights])
```

在 `_resample_command` 中，每个环境通过 `torch.multinomial` 从权重分布中采样选择当前运动：
```python
selected_motions = torch.multinomial(
    self.motion._motion_weights, len(env_ids), replacement=True
)
```

这确保了不同运动被采样的频率与其权重成正比——权重更大的运动被训练得更多。

### 11.2 单运动 vs 多运动的代码分支

代码中有大量 `_is_single_motion` 分支，体现在：
- **时间步推进**：单运动达到末尾时直接 `resample`，多运动需要考虑 WRAP/CLAMP 循环模式
- **自适应采样**：单运动使用统一的 `bin_failed_count`，多运动为每个运动维护独立的 bin 失败计数
- **指标统计**：多运动追踪各运动的成功/失败次数（`_motion_success_count` / `_motion_fail_count`）
- **ONNX 导出**：单运动导出单一 ONNX 文件，多运动导出多个 `motion_i.onnx` + `deploy.yaml`

### 11.3 多运动训练的优势

1. **单一策略掌握多种技能**：一个神经网络可以学会行走、站立、转身等多种运动
2. **技能泛化**：多种运动数据增加了数据多样性，可能提升策略的泛化能力
3. **平滑过渡**：不同运动之间可以通过时间步自然过渡（虽然在当前设计中，每次 resample 重新采样是独立的）

### 11.4 多运动部署时的权衡

多运动 ONNX 模型在每个运动文件都是独立的 ONNX + 独立的 motion buffer。部署端需要根据当前运动类型切换到不同的 ONNX 模型执行推理。这引入了一个上层决策逻辑：**"当前应该运行哪个运动？"**。

在 `deploy.yaml` 中，每个运动都有 `loop_mode` 信息：WRAP 运动播放完毕后重新开始（无限循环），CLAMP 运动播放完毕后停留在最后一帧。这一元数据帮助部署代码决定何时切换到下一个运动。

---

## 十二、PPO 超参对比分析

### 12.1 核心超参对比

| 参数 | Velocity | Tracking | 差异分析 |
|:----|:--------:|:--------:|:---------|
| 熵系数 | 0.01 | 0.005 | Tracking 任务更精确，需要更低探索 |
| 最大迭代 | 10001 | 30001 | Tracking 更复杂，需要更多训练 |
| 保存间隔 | 100 | 500 | Tracking 训练更久，间隔更大 |
| 网络结构 | 512/256/128 (MLP) | 512/256/128 (MLP) 或 GRU | Tracking 支持 GRU 时序网络，可选 |
| 激活函数 | ELU | ELU | 相同 |
| 学习率 | 1e-3 adaptive | 1e-3 adaptive | 相同 |
| clip | 0.2 | 0.2 | 相同 |
| γ | 0.99 | 0.99 | 相同 |
| λ | 0.95 | 0.95 | 相同 |
| KL 目标 | 0.01 | 0.01 | 相同 |

### 12.2 熵系数差异深度分析

Velocity Tracking 的熵系数（0.01）是 Motion Tracking 的 2 倍。这意味着 Velocity 任务的策略在训练过程中保持更高的随机性（探索性），而 Motion Tracking 的策略更快趋于确定性。

原因：
1. **任务确定性**：Motion Tracking 的参考运动是确定性的——给定 time_step，参考状态完全确定。策略不需要探索"不同的走路方式"，只需要精确跟随参考。因此探索需求较低。
2. **输出精度要求**：跟踪任务要求精确的关节控制，高熵会导致动作抖动，不利于精确跟踪。
3. **任务难度**：Velocity Tracking 需要探索多种步态以应对不同地形，而 Motion Tracking 只需要跟随给定的轨迹。

### 12.3 迭代次数差异

Velocity 训练 10001 次迭代（约 1 亿步经验），Tracking 训练 30001 次迭代。这是因为：
1. Motion Tracking 需要学习的时间更长——不仅要学会"运动"，还要学会"跟踪每一个时刻的精确姿态"
2. 自适应采样策略虽然提升了样本效率，但任务本身的复杂度远高于 Velocity Tracking

### 12.4 GRU 时序网络支持

在 H1_2 的 Tracking 训练中，Actor 网络除了标准的 MLP（512/256/128）外，还引入了**GRU（Gated Recurrent Unit）时序网络**选项，通过 `rl_cfg.py` 中的 `use_gru` 参数控制。

#### 12.4.1 配置方式

```python
def unitree_h1_2_tracking_ppo_runner_cfg(
    use_gru: bool = False,
) -> RslRlOnPolicyRunnerCfg:
    actor_cfg = RslRlModelCfg(
        hidden_dims=(512, 256, 128),
        activation="elu",
        ...
    )

    if use_gru:
        actor_cfg.class_name = "RNNModel"
        actor_cfg.extra_kwargs = {
            "rnn_type": "gru",
            "rnn_hidden_dim": 128,
            "rnn_num_layers": 1,
        }
```

当 `use_gru=True` 时，网络结构变为：

```
obs (144/150维) → MLP 编码 → GRU (hidden_dim=128, 1层) → MLP 解码 → actions (27维)
```

#### 12.4.2 GRU 的优势

GRU 的引入主要解决了 No-Estimate 模式下的**时序状态推断**问题：

1. **隐式速度估计**：在没有 `base_lin_vel` 和 `motion_anchor_pos_b` 的情况下，策略需要通过关节位置/速度的历史序列推断自身状态。GRU 的隐藏状态天然适合这种时序信息累积。
2. **运动相位感知**：参考运动是确定性的时间序列，GRU 可以从历史帧中推断当前的运动相位（处于行走周期的哪个阶段），无需显式的相位计数器。
3. **噪声过滤**：观测噪声（关节编码器偏置、IMU 噪声）通过时序平滑可以有效抑制，GRU 的隐式状态比单帧 MLP 对噪声更鲁棒。

实验名称也会相应区分：`use_gru=True` 时使用 `h1_2_tracking_gru`，否则使用 `h1_2_tracking`。

#### 12.4.3 与 MLP 的对比

| 维度 | MLP (512/256/128) | GRU + MLP |
|:---|:-----------------|:----------|
| 时序建模能力 | 无（每帧独立） | 有（隐状态跨步传递） |
| 推理延迟 | ~1-2ms | ~2-4ms（含 GRU 循环） |
| 训练收敛 | 更快 | 稍慢但最终性能更优 |
| 对 No-Estimate 模式的适配 | 需辅助奖励补偿 | 更自然（时序推断补偿） |
| 部署复杂度 | 标准 ONNX | 需处理 GRU 隐状态（ONNX 自动管理） |

在 ONNX 导出时，GRU 隐状态会被自动展平并作为模型内部状态管理，部署端无需额外处理。

---

## 十三、代码架构总结

### 13.1 文件关系

```
tracking_env_cfg.py           ← 基础环境配置（观测、动作、奖励、终止、事件）
  ├── config/h1_2/env_cfgs.py  ← H1_2 机器人特化配置（body names、no-estimate、play）
  ├── config/h1_2/rl_cfg.py   ← PPO 超参配置
  └── config/h1_2/__init__.py  ← 任务注册

mdp/
  ├── commands.py     ← MotionLoader + MotionCommand（核心参考运动管理）
  ├── observations.py ← Actor/Critic 观测函数
  ├── rewards.py      ← 全部奖励函数（跟踪 + 惩罚 + 辅助）
  ├── terminations.py ← 终止条件
  ├── metrics.py      ← 评估指标（MPKPE、R-MPKPE 等）
  └── __init__.py     ← 导出 mdp 命名空间

rl/
  ├── runner.py       ← MotionTrackingOnPolicyRunner + ONNX 复合模型
  └── __init__.py
```

### 13.2 数据流

```
1. MotionLoader 加载 NPZ → 拼接张量（所有运动数据）
2. MotionCommand 维护 time_steps（每个环境当前时间）
3. _update_command 每步推进 time_steps → 处理 WRAP/CLAMP → 更新相对位姿
4. 观测系统读取 MotionCommand 的 property → 拼接观测向量
5. 奖励函数读取 MotionCommand 的 参考 + 机器人数据 → 计算误差
6. 终止条件监测锚点和末端执行器的偏差
7. 回合结束时 _resample_command 调用自适应/均匀/start 采样
8. ONNX 导出时创建复合模型，将运动 buffer 嵌入 ONNX
```

---

## 十四、总结与展望

Motion Tracking 是机器人全身运动控制中**最具挑战性**的任务之一。mjlab 的实现展示了几个关键设计思想：

1. **模仿学习的系统化**：从加载运动数据（NPZ）到参考帧管理（MotionLoader），再到观测/奖励/终止条件的设计，形成了一套完整的模仿学习框架。

2. **自适应的课程学习**：自适应采样策略通过追踪学习过程中的"困难时段"，实现样本的高效利用——这在长周期运动中尤其重要。

3. **部署优先的设计**：从复合 ONNX 模型到 FPS 感知的帧索引，再到多运动部署配置，代码始终将"训练好之后如何部署"作为重要考量。

4. **状态估计的灵活性**：`has_state_estimation` 开关使得策略可以适应不同的传感器配置，从完整状态估计到纯本体感受（proprioceptive）控制。

5. **鲁棒性的多重保障**：RSI 随机化、观测噪声、域随机化（摩擦力/质心偏置/编码器偏置）共同工作，使得策略在 sim-to-real 迁移中具有足够鲁棒性。

未来可能的扩展方向：
- **运动生成与跟踪的联合训练**：将 VAE/扩散模型与跟踪策略结合，实现从文本或语音指令直接生成运动
- **跨形态迁移**：同一套 Motion Tracking 框架在 H1_2、G1、G1_23dof 等不同机器人上的配置差异已经很小，未来可能实现单一策略跨机器人迁移
- **实时运动重定向**：从 human motion capture 到机器人运动的实时重定向与跟踪
- **更复杂的接触模式**：当前接触模式匹配基于高度阈值推断，未来可以引入力传感器直接检测接触状态
