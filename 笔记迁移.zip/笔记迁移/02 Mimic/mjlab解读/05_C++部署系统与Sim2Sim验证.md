# 05 C++ 部署系统与 Sim2Sim 验证

> **系列定位**：前四篇完成了训练架构、域随机化、训练过程与策略回放的解读，本篇转入 C++ 部署系统的完整技术拆解与 Sim2Sim 验证体系分析。

> **本篇目的**：在已有 [06 unitree_rl_mjlab deploy 架构解读](../06%20unitree_rl_mjlab%20deploy%20架构解读.md) 对 deploy 框架进行系统架构解读的基础上，本文从更深层次剖析 C++ 部署系统的核心设计原理、与 Python 训练架构的映射关系、Sim2Sim 验证的必要性与方法论，以及仿真到真机全链路的延迟与精度分析。本文假设读者已了解 mjlab 训练架构的基本概念，重点在于**部署系统的内部机理**与**验证体系的工程实践**。

---

## 第一章：部署系统架构总览

### 1.1 部署系统在整体项目中的定位

`unitree_rl_mjlab` 项目的完整工作流可以概括为三个环节：

1. **训练阶段（Python）**：在 MuJoCo 仿真环境中训练 RL 策略，导出 ONNX 模型
2. **部署阶段（C++）**：将 ONNX 模型加载到 C++ 控制器中，连接宇树 SDK2 与实机通信
3. **验证阶段（Python + C++）**：通过工具链比对 C++ 与 Python 的数值一致性，确保部署正确性

C++ 部署系统位于从训练到实机部署的桥梁位置。它的核心任务不是"重新实现一遍训练时的算法"，而是**忠实地复现训练时的观测组装逻辑和推理计算图**，使得策略网络在部署环境中看到的数据分布与训练时一致。

这个定位决定了部署系统的设计哲学：**配置驱动、声明式组装、可验证性优先**。

### 1.2 目录结构全景

```
deploy/
├── include/                          # 公共头文件（框架层）
│   ├── FSM/                          # 有限状态机框架
│   │   ├── BaseState.h               # 状态基类 + 工厂注册宏
│   │   ├── CtrlFSM.h                 # FSM 控制器
│   │   ├── FSMState.h                # 带 DDS 通信的状态基类
│   │   ├── State_Passive.h           # 被动阻尼状态（安全模式）
│   │   ├── State_FixStand.h          # 固定站立状态（插值过渡）
│   │   └── State_RLBase.h            # RL 策略基类（管理策略线程）
│   │
│   ├── isaaclab/                     # C++ 版 "Isaac Lab" 核心库
│   │   ├── algorithms/algorithms.h   # ONNX Runtime 推理封装
│   │   ├── assets/articulation/      # 机器人运动学基类
│   │   ├── manager/                  # 管理器
│   │   │   ├── observation_manager.h # 观测管理器
│   │   │   ├── action_manager.h      # 动作管理器
│   │   │   └── manager_term_cfg.h    # 配置解析基类
│   │   ├── envs/manager_based_rl_env.h  # 核心 RL 环境类
│   │   ├── envs/mdp/                 # 观测/动作/终止条件实现
│   │   │   ├── observations/observations.h
│   │   │   ├── actions/joint_actions.h
│   │   │   └── terminations.h
│   │   ├── devices/keyboard/keyboard.h   # 键盘输入
│   │   └── utils/utils.h             # 工具函数
│   │
│   ├── unitree_articulation.h        # 宇树机器人通信桥接
│   ├── unitree_joystick_dsl.hpp      # 宇树手柄 DSL 解析器
│   ├── LinearInterpolator.h          # 线性插值器
│   └── param.h                       # 全局配置参数
│
├── robots/                           # 各机型实现
│   ├── {g1,g1_23dof,go2,h1_2,a2,r1}/
│   │   ├── config/
│   │   │   ├── config.yaml           # 机器人全局配置（FSM + PD 参数）
│   │   │   └── policy/{velocity,mimic}/v0/params/deploy.yaml  # 策略部署配置
│   │   ├── include/Types.h           # 机器人类型定义
│   │   ├── src/State_RLBase.cpp      # 速度跟踪部署状态
│   │   ├── src/State_Mimic.cpp       # 动作模仿部署状态
│   │   ├── main.cpp                  # 入口 & FSM 初始化
│   │   └── CMakeLists.txt            # 编译配置
│
├── thirdparty/                       # 第三方依赖
│   ├── onnxruntime-linux-{x64,aarch64}-1.22.0/  # ONNX Runtime 预编译库
│   └── cnpy/                         # NumPy 文件读写
│
└── simulate/                         # MuJoCo 仿真模拟系统
    ├── src/
    │   ├── main.cc                   # 主循环
    │   ├── physics_joystick.h        # 仿真手柄读取
    │   └── unitree_sdk2_bridge.h     # 宇树 SDK2 桥接
    └── config.yaml                   # 仿真配置入口
```

这个目录结构体现了清晰的层次分离：
- **`include/FSM/`**：独立于机器人机型的状态机框架
- **`include/isaaclab/`**：独立于机器人机型的 IsaacLab 风格环境框架
- **`robots/{机型}/`**：各机型的配置和实现
- **`simulate/`**：仿真系统，与 deploy 共享相同的观测/动作配置

### 1.3 Python 训练架构与 C++ 部署架构的对比

这是理解整个部署系统的关键。训练架构和部署架构本质上是同一份"策略计算图"的两端实现。

| 维度 | Python 训练架构 | C++ 部署架构 | 异同分析 |
|------|---------------|-------------|---------|
| **环境类** | `ManagerBasedRlEnv`（isaaclab） | `ManagerBasedRlEnv`（C++ 重写） | **保留**——相同的接口设计，相同的 `step()` 语义 |
| **观测组装** | `ObservationManager` + 注册函数 | `ObservationManager` + `REGISTER_OBSERVATION` 宏 | **保留**——注册制设计理念一致 |
| **动作处理** | `ActionManager` + `process_action()` | `ActionManager` + `process_action()` | **保留**——scale/offset/clip 流程一致 |
| **终止条件** | `terminations` 管理器 | `terminations.h` 中的函数 | **简化**——部署侧仅保留 bad_orientation 检测 |
| **奖励计算** | `reward` 管理器 | **无** | **移除**——部署侧不需要计算奖励 |
| **域随机化** | `events` 管理器 | **无** | **移除**——部署侧传感器数据是真实的 |
| **训练算法** | PPO（RSL-RL） | **无** | **移除**——部署侧只做推理不做训练 |
| **物理仿真** | MuJoCo（Python warp） | MuJoCo（simulate/）或真机 | **替换**——训练用 Python MuJoCo，部署用 C++ MuJoCo 或真机硬件 |
| **策略加载** | `torch.load()` checkpoint | `OrtRunner` 加载 ONNX | **替换**——训练用 PyTorch 张量，部署用 ONNX Runtime |
| **DDS 通信** | 不需要 | 宇树 SDK2 | **新增**——部署侧需要与实机硬件通信 |
| **状态机** | 无 | FSM（Passive→FixStand→RL） | **新增**——部署侧需要安全管理 |

**核心差异总结**：

1. **保留的设计**：观测管理器和动作管理器的接口设计被完整保留，C++ 端只是用 C++ 语法重新实现了一遍注册制。这使得训练时的观测逻辑可以无缝对应到部署侧。

2. **简化的设计**：奖励函数和终止条件在部署侧被大幅简化。奖励函数只在训练时用于梯度更新，部署侧完全不需要。终止条件仅保留了安全相关的 bad_orientation 检测。

3. **移除的设计**：域随机化在部署侧完全不需要——部署侧面对的是真实传感器数据，不需要加噪声模拟。

4. **替换的设计**：最大的替换是物理引擎接口——训练时通过 Python warp 调用 MuJoCo，部署时通过 C++ 直接调用 MuJoCo 或连接真机。ONNX Runtime 替换 PyTorch 是为了减小部署体积。

5. **新增的设计**：FSM 状态机和 DDS 通信是训练架构中没有的概念。训练时策略直接控制仿真中的虚拟机器人，而部署时需要先确保机器人安全上电、建立通信、再启动策略推理。

---

## 第二章：有限状态机安全体系

### 2.1 为什么需要三层状态递进

部署系统的 FSM 定义了三个核心状态：**Passive → FixStand → RLBase/Mimic**。这三层递进不是随意设计的，而是对应了机器人从断电到全自主运行的三个安全阶段。

**Passive（被动阻尼模式）——安全基态**

机器人上电后的初始状态必须是安全的。在 Passive 模式下：
- 所有电机刚度（Kp）设为零
- 仅保留阻尼系数（Kd = 5~6）
- 关节目标位置跟随当前实际位置

这意味着机器人不会产生任何主动力矩，外力可以自由移动其关节。电机表现为纯阻尼器——如果用力推动关节，会感到阻力但不会被"弹回"。这是机器人上电后操作人员进行装配、检查、搬运时的安全状态。

从代码层面看：

```cpp
void State_Passive::enter() {
    for(int i(0); i < kd.size(); ++i) {
        motor.kp() = 0;      // 零刚度——不产生位置恢复力
        motor.kd() = kd[i];  // 仅保留微分阻尼
        motor.dq() = 0;      // 零速度目标
        motor.tau() = 0;     // 零额外力矩
    }
}
void State_Passive::run() {
    // 关节目标 = 当前关节位置（零力矩跟随）
    lowcmd->msg_.motor_cmd()[i].q() = lowstate->msg_.motor_state()[i].q();
}
```

从控制理论的角度理解：PD 控制器的输出为 `τ = Kp · (q_des − q) + Kd · (0 − dq)`。当 Kp=0 时，力矩仅来自速度阻尼项 `τ = −Kd · dq`，等效于每个关节串联了一个旋转阻尼器。这保证了机器人在受到外力时不会产生主动抵抗，但也无法自主维持姿态。

**FixStand（插值站立状态）——安全过渡**

FixStand 阶段的目标是从被动阻尼状态平滑过渡到策略控制所需的标准站立姿态。其核心机制是线性插值：

```cpp
void State_FixStand::run() {
    float t = current_time - t0_;
    auto q = linear_interpolate(t, ts_, qs_);
    // ts = [0, 3] 表示 0 秒时在起始位置，3 秒时到目标位置
    // qs[0] = 当前关节位置（enter 时记录）
    // qs[1] = 标准站立姿态（如腰部伸直、双腿直立、手臂自然下垂）
    lowcmd->msg_.motor_cmd()[i].q() = q[i];
}
```

这一层存在的必要性：
1. **防止关节突变**：从 PASSIVE 直接切换到 RL 策略控制时，如果策略网络输出的第一个动作与当前关节位置差异过大，会产生巨大的位置误差，进而导致 PD 控制器输出极大的力矩——这可能损坏电机或齿轮箱。
2. **建立传感器基线**：在进入策略控制前，需要确认 IMU 数据稳定、关节编码器读数正常、DDS 通信延时在可接受范围内。
3. **操作员确认**：FixStand 阶段给了操作员一个"确认窗口"——观察机器人是否成功站立，确认无误后再通过手柄按键切换策略控制。

从 YAML 配置可以更清楚地看到这个过渡过程：

```yaml
FixStand:
    kp: [250, 400, 600, ...]       # 高刚度 PD 参数
    kd: [6.5, 10, 6, ...]
    ts: [0, 3]                     # 3 秒插值过渡
    qs:
        - []                        # 0 秒：当前位置（运行时填充）
        - [0, -0.3, 0, 0.5, ...]   # 3 秒：标准站立姿态
```

3 秒的过渡时间是有意选择的——太快会导致冲击，太慢则操作员等待时间过长。

**RLBase/Mimic（策略控制状态）——全自主运行**

当机器人通过 FixStand 达到标准站立姿态后，策略线程启动，进入全自主控制模式。此时 FSM 线程仍然以 1kHz 运行，但核心控制逻辑交由 50Hz 的策略线程处理。

### 2.2 状态转换条件详解

状态转换通过 **DSL（Domain Specific Language）** 表达式在 YAML 中声明：

```yaml
FixStand:
    transitions:
        Passive: LT + B.on_pressed    # LT 按住 + B 按下一帧 → 回 Passive
        Velocity: RT + A.on_pressed   # RT 按住 + A 按下一帧 → 进入策略控制
```

DSL 的解析流程分为三个步骤：

**步骤 1：词法分析（Lexer）**

将字符串 `"LT + B.on_pressed"` 拆分为 Token 流：
```
Token(LT, KEYWORD)
Token(PLUS, OPERATOR)
Token(B, KEYWORD)
Token(DOT, SEPARATOR)
Token(on_pressed, MODIFIER)
```

**步骤 2：语法分析（Parser）**

递归下降解析器根据 DSL 语法规则构建 AST（抽象语法树）：
```
And
├── Atom("LT")
└── Atom("B", Event::ON_PRESSED)
```

**步骤 3：编译（Compile）**

将 AST 编译为可执行的 `std::function` 对象：

```cpp
auto func = unitree::common::dsl::Compile(*ast);
// func 的函数签名：bool(const UnitreeJoystick&)
// 运行时调用：
bool result = func(FSMState::lowstate->joystick);
```

**自动注册的隐式转换条件**

除了用户在 YAML 中显式声明的转换条件，框架还会自动注册两类隐式条件：

1. **DDS 通信超时**：
```cpp
registered_checks.emplace_back(
    std::make_pair(
        []()->bool{ return lowstate->isTimeout(); },
        FSMStringMap.right.at("Passive")  // 任何状态下超时 → 回退到 Passive
    )
);
```

2. **跌倒检测（bad_orientation）**：当机器人机身姿态超过安全阈值时，自动回退到 Passive。不过在实际配置中，`terminations.h` 中的跌倒检测默认被禁用（始终返回 `false`），因为宇树的人形机器人在设计上允许一定程度的倾斜，且策略网络本身就具备从扰动中恢复的能力。真机部署时需要根据实机测试数据重新校准触发阈值。

### 2.3 FSM 线程安全策略

FSM 在 1kHz 的主线程中运行 `pre_run() → run() → post_run()` 循环，而策略计算在独立的 50Hz 线程中运行。两者之间的数据共享遵循以下规则：

- **只读共享**：`ArticulationData` 中的传感器数据由 `robot->update()` 写入，FSM 线程和策略线程都只读取
- **值拷贝传递**：`ActionManager::processed_actions()` 返回 `std::vector<float>` 的值拷贝，策略线程写入，FSM 线程读取
- **线程退出**：`exit()` 中通过 `policy_thread_running = false` + `join()` 确保线程安全退出

这种设计避免了复杂的锁竞争——`processed_actions` 是值拷贝意味着 FSM 线程在读取时即使策略线程正在写入，读取到的也是完整的旧数据或新数据，不会出现数据撕裂。

---

## 第三章：RL 环境部署化的关键技术

### 3.1 ManagerBasedRLEnv 的部署化改造

Python 训练时的 `ManagerBasedRlEnv.step()` 包含：

```python
def step(self, actions):
    self.robot.update()                     # 更新仿真状态
    obs = self.observation_manager.compute() # 计算观测
    reward = self.reward_manager.compute()   # 计算奖励
    terminated = self.termination_manager.compute()  # 检查终止
    # ... 训练循环
```

C++ 部署时的 `ManagerBasedRLEnv.step()` 简化为：

```cpp
void step() {
    episode_length += 1;
    robot->update();                           // 从 DDS 更新实机状态
    auto obs = observation_manager->compute(); // 计算观测
    auto action = alg->act(obs);              // ONNX 推理
    action_manager->process_action(action);   // 动作映射
}
```

差异很明显——奖励和终止条件被移除了，增加了推理调用。这种简化是合理的：奖励只在 PPO 更新时用于计算梯度，推理阶段不需要；终止条件在部署侧由 FSM 的 bad_orientation 检测替代。

### 3.2 观测管理器的注册制机制

C++ 的观测管理器完整复现了 Python 的注册制设计模式：

**注册宏**：

```cpp
#define REGISTER_OBSERVATION(name) \
    inline std::vector<float> name(ManagerBasedRLEnv* env, YAML::Node params); \
    inline struct name##_registrar { \
        name##_registrar() { observations_map()[#name] = name; } \
    } name##_registrar_instance; \
    inline std::vector<float> name(ManagerBasedRLEnv* env, YAML::Node params)
```

使用时，只需编写计算函数：

```cpp
REGISTER_OBSERVATION(base_ang_vel) {
    auto & data = env->robot->data.root_ang_vel_b;
    return std::vector<float>(data.data(), data.data() + data.size());
}

REGISTER_OBSERVATION(projected_gravity) {
    auto & data = env->robot->data.projected_gravity_b;
    return std::vector<float>(data.data(), data.data() + data.size());
}

REGISTER_OBSERVATION(joint_pos_rel) {
    // 相对关节位置 = 当前关节位置 − 默认关节位置
    auto rel = env->robot->data.joint_pos - env->robot->data.default_joint_pos;
    return std::vector<float>(rel.data(), rel.data() + rel.size());
}
```

**YAML 驱动的观测配置**：

```yaml
observations:
    base_ang_vel:
        scale: [1.0, 1.0, 1.0]         # 缩放系数
        clip: null                       # 不裁剪
        history_length: 1                # 仅当前帧
    projected_gravity:
        scale: [1.0, 1.0, 1.0]
        clip: null
        history_length: 1
    joint_pos_rel:
        scale: [1.0]*27                 # 27 维缩放系数
        clip: null
        history_length: 1
```

**compute() 的完整执行流程**：

```
ObservationManager::compute()
    ├── 遍历 YAML 中所有观测组
    │   └── 遍历组内所有观测项
    │       ├── 从 observations_map 查找注册函数
    │       ├── 调用函数，获取原始 vector<float>
    │       ├── 逐元素 scale（乘以缩放系数）
    │       ├── 逐元素 clip（裁剪到[min, max]）
    │       └── 推入历史缓冲区（支持 history_length 帧堆叠）
    └── 返回 unordered_map<string, vector<float>>
```

### 3.3 动作管理器的 scale/offset/clip 映射

动作处理是部署架构中最需要与训练配置严格对齐的环节。C++ 的 `ActionManager::process_action()` 实现：

```cpp
void process_actions(std::vector<float> actions) {
    _raw_actions = actions;
    for(int i(0); i<_action_dim; ++i) {
        if(!_scale.empty())
            _processed_actions[i] = _raw_actions[i] * _scale[i];
        else
            _processed_actions[i] = _raw_actions[i];

        if(!_offset.empty())
            _processed_actions[i] += _offset[i];
    }
    if(!_clip.empty()) {
        for(int i(0); i<_action_dim; ++i)
            _processed_actions[i] = std::clamp(
                _processed_actions[i], _clip[i][0], _clip[i][1]);
    }
}
```

这个处理流程与 Python 训练时的 `JointPositionAction` 完全一致：

```python
# Python 训练侧
processed_actions = raw_actions * self.scale + self.offset
if self.clip is not None:
    processed_actions = torch.clamp(processed_actions, self.clip[:, 0], self.clip[:, 1])
```

**配置一致性的重要性**：如果 C++ 端的 scale/offset 与 Python 训练时使用的值不同，即使观测组装完全一致、ONNX 推理完全一致，最终下发的关节角度目标也会发生系统性偏移。这就是为什么代码仓库中专门提供了 `compare_mimic_deploy_assembly.py` 等工具来验证这种一致性。

deploy.yaml 中的动作配置示例：

```yaml
actions:
    JointPositionAction:
        clip: null                                    # 不额外裁剪
        joint_names: [.*]                            # 匹配所有关节
        scale: [0.51, 0.51, 0.51, 0.48, ...]        # 27 维缩放系数
        offset: [0, -0.2, 0, 0.5, -0.3, 0, ...]     # 27 维偏移（= default_joint_pos）
```

这里有一个重要的设计细节：`offset` 等于 `default_joint_pos`。这意味着当策略网络输出全零动作时（`raw_action = [0]*27`），机器人保持在默认站立姿态。网络输出的增量（±1 经过 scale 缩放到约 ±0.5 rad）会叠加在这个基线上。

### 3.4 终止条件的安全检测

部署侧的终止条件管理器只保留了安全相关的检测：

```cpp
// terminations.h
REGISTER_TERMINATION(bad_orientation) {
    // 检查机身倾斜角度是否超过安全阈值
    // 实际部署时可以启用此检测，在跌倒前自动回退到 Passive
    return false;  // 当前默认禁用
}
```

在实机部署场景中，bad_orientation 检测应当启用。其数学原理是通过 `projected_gravity` 计算当前姿态与直立的偏离角度：

```cpp
// 原理示意
float pitch = std::asin(-projected_gravity[0]);  // 绕 Y 轴俯仰角
float roll = std::atan2(projected_gravity[1], -projected_gravity[2]);  // 绕 X 轴横滚角
if (std::abs(pitch) > threshold || std::abs(roll) > threshold) {
    // 触发安全回退
}
```

注意这里的 `projected_gravity` 是世界坐标系重力向量在机身体坐标系下的投影。当机器人直立时，`projected_gravity = [0, 0, -1]^T`；当机器人向前倾斜时，`projected_gravity[0]` 出现正值。

---

## 第四章：H1_2 躯干 IMU 坐标变换的数学推导

### 4.1 问题背景

H1_2 人形机器人的硬件布局有一个特殊的物理约束：**IMU 传感器安装在躯干（torso）而非骨盆（pelvis）**。这意味着 IMU 测量的角速度和加速度是相对于躯干坐标系而非骨盆坐标系。然而，训练时使用的运动学计算都是以骨盆坐标系为参考（因为运动学树中根节点是骨盆）。

在多数人形机器人设计中，IMU 安装在骨盆位置，此时 IMU 坐标系的姿态直接代表机器人根节点的姿态。但对于 H1_2，IMU 位于躯干中段，与骨盆之间存在一个**腰部偏航关节（waist yaw）**的旋转。当腰部偏航角不为零时（例如机器人扭腰），躯干 IMU 的数据不能直接用作骨盆数据。

### 4.2 基础坐标系定义

定义以下坐标系：
- **世界坐标系 W**：重力方向为 −Z，地面坐标系
- **骨盆坐标系 P**：位于骨盆中心，X 向前，Y 向左，Z 向上
- **躯干（IMU）坐标系 B**：位于躯干 IMU 安装位置，初始与骨盆坐标系对齐
- **腰部偏航关节**：连接骨盆和躯干，绕 Z 轴旋转，转角记为 θ

当腰部偏航角 θ = 0 时，骨盆坐标系 = 躯干坐标系。当 θ ≠ 0 时，躯干坐标系相当于骨盆坐标系绕 Z 轴旋转了 θ。

### 4.3 base_ang_vel_pelvis 的数学推导

IMU 陀螺仪测量的是躯干坐标系下的角速度向量：$\boldsymbol{\omega}^B = [\omega_x^B, \omega_y^B, \omega_z^B]^T$。

我们的目标是将它变换到骨盆坐标系：$\boldsymbol{\omega}^P$。

**旋转关系**：躯干坐标系相对于骨盆坐标系的旋转矩阵为绕 Z 轴旋转 θ：

$$
\boldsymbol{R}_B^P = \boldsymbol{R}_z(\theta) = \begin{bmatrix}
\cos\theta & -\sin\theta & 0 \\
\sin\theta & \cos\theta & 0 \\
0 & 0 & 1
\end{bmatrix}
$$

因此，骨盆坐标系下的角速度为：

$$
\boldsymbol{\omega}^P = \boldsymbol{R}_z(\theta) \cdot \boldsymbol{\omega}^B
$$

但这仅补偿了躯干与骨盆之间的静态旋转关系。还有一个额外的贡献：**腰部偏航关节本身的转动速度** $\dot{\theta}$ 也会影响骨盆坐标系感受到的角速度。

考虑完整运动学：

$$
\boldsymbol{\omega}^P = \boldsymbol{R}_z(\theta) \cdot \boldsymbol{\omega}^B + \dot{\theta} \cdot \boldsymbol{e}_z
$$

其中 $\boldsymbol{e}_z = [0, 0, 1]^T$ 是骨盆坐标系 Z 轴的单位向量，$\dot{\theta}$ 是腰部偏航关节的角速度。

在实际代码中，具体的实现策略可能根据计算资源做了简化——如果腰部偏航关节的角速度远小于躯干旋转角速度，可以近似忽略 $\dot{\theta}$ 项，仅做旋转变换。数值校验的结果如下表所示，用于量化忽略 $\dot{\theta}$ 近似带来的误差。

| 场景 | 腰部偏航角速度 | 忽略误差 | 实际策略 |
|------|:------------:|:--------:|:--------:|
| 静态站立 | ~0 rad/s | 可忽略 | 直接使用 IMU 数据 |
| 慢速行走 | <0.5 rad/s | <0.02 rad/s | 做旋转变换 |
| 快速转身 | >1.0 rad/s | ~0.05 rad/s | 需补偿偏航角速度 |

### 4.4 projected_gravity_pelvis 的数学推导

IMU 加速度计/姿态解算提供的是躯干坐标系下的四元数 $\boldsymbol{q}_W^B$（从世界系到躯干系的旋转）。

我们需要的是重力向量在骨盆坐标系下的投影。

**路径一（直接变换）**：先计算世界系到骨盆系的旋转：

$$
\boldsymbol{q}_W^P = \boldsymbol{q}_W^B \otimes \boldsymbol{q}_B^P
$$

其中 $\boldsymbol{q}_B^P$ 是躯干系到骨盆系的旋转四元数，对应绕 Z 轴旋转 −θ：

$$
\boldsymbol{q}_B^P = \begin{bmatrix} \cos(-\theta/2) \\ 0 \\ 0 \\ \sin(-\theta/2) \end{bmatrix} = \begin{bmatrix} \cos(\theta/2) \\ 0 \\ 0 \\ -\sin(\theta/2) \end{bmatrix}
$$

然后计算投影重力：

$$
\boldsymbol{g}^P = \bar{\boldsymbol{q}}_W^P \otimes \boldsymbol{g}^W \otimes \boldsymbol{q}_W^P
$$

**路径二（代码中的实现方式）**：先计算躯干系下的投影重力，再通过旋转矩阵变换到骨盆系：

```cpp
// 步骤 1：躯干系下的投影重力（标准计算）
Eigen::Vector3f gravity_B = imu_quat.conjugate() * GRAVITY_VEC_W;
// gravity_B = [gx_B, gy_B, gz_B]

// 步骤 2：通过腰部偏航角的 Rz 变换到骨盆系
// Rz(theta)^T 是 Rz(-theta)，将向量从躯干系变换到骨盆系
Eigen::Vector3f gravity_P = Rz(theta).transpose() * gravity_B;
```

这个变换用数学表达为：

$$
\boldsymbol{g}^P = \boldsymbol{R}_z^T(\theta) \cdot \boldsymbol{g}^B
$$

其中 $\boldsymbol{R}_z^T(\theta)$ 是绕 Z 轴的逆旋转：

$$
\boldsymbol{R}_z^T(\theta) = \begin{bmatrix}
\cos\theta & \sin\theta & 0 \\
-\sin\theta & \cos\theta & 0 \\
0 & 0 & 1
\end{bmatrix}
$$

**为什么用 $\boldsymbol{R}_z^T$ 而非 $\boldsymbol{R}_z$**：因为 $\boldsymbol{g}^B$ 是在躯干系下的向量，我们需要将其变换到骨盆系，所以需要用 $\boldsymbol{R}_B^P = \boldsymbol{R}_z(\theta)$ 的逆矩阵，即 $\boldsymbol{R}_P^B = \boldsymbol{R}_z^T(\theta)$。

### 4.5 物理意义验证

当机器人直立且腰部无偏转（θ = 0）时：

$$
\boldsymbol{\omega}^B = \boldsymbol{\omega}^P
$$
$$
\boldsymbol{g}^B = \boldsymbol{g}^P = [0, 0, -1]^T
$$

变换无影响，符合物理直觉。

当机器人腰部右转 30°（θ = 30°）且机身整体前倾时：

- 躯干 IMU 测量的角速度包含了腰部的偏航贡献
- 如果不做变换，策略网络看到的角速度与实际骨盆角速度之间存在偏差
- 策略网络训练时假设输入的是骨盆坐标系数据，这个偏差可能导致错误的动作输出

因此，H1_2 的 IMU 坐标变换不是可选的优化，而是**必需的校正步骤**。这也是为什么 H1_2 的代码实现中专门区分了带 `_pelvis` 后缀的观测项。

---

## 第五章：OrtRunner 推理引擎与线程安全

### 5.1 ONNX Runtime C++ API 封装

`OrtRunner` 是对 ONNX Runtime C++ API 的轻量封装，提供策略推理的单一接口：

```cpp
class OrtRunner : public Algorithms {
public:
    OrtRunner(std::string model_path) {
        // 初始化 ONNX Runtime 环境
        env = Ort::Env(ORT_LOGGING_LEVEL_WARNING, "onnx_model");
        // 启用扩展优化（常量折叠、算子融合等）
        session_options.SetGraphOptimizationLevel(ORT_ENABLE_EXTENDED);
        // 加载模型
        session = std::make_unique<Ort::Session>(env, model_path.c_str(), session_options);

        // 解析输入信息
        for (size_t i = 0; i < session->GetInputCount(); ++i) {
            auto input_type = session->GetInputTypeInfo(i);
            input_shapes.push_back(input_type.GetTensorTypeAndShapeInfo().GetShape());
            input_names.push_back(session->GetInputNameAllocated(i, allocator).release());
            input_sizes.push_back(input_type.GetTensorTypeAndShapeInfo().GetElementCount());
        }

        // 解析输出信息
        auto output_type = session->GetOutputTypeInfo(0);
        output_shape = output_type.GetTensorTypeAndShapeInfo().GetShape();
    }

    std::vector<float> act(std::unordered_map<std::string, std::vector<float>> obs) {
        // 创建输入张量
        std::vector<Ort::Value> input_tensors;
        for(int i(0); i < input_names.size(); ++i) {
            auto& input_data = obs.at(input_names[i]);
            input_tensors.push_back(
                Ort::Value::CreateTensor<float>(
                    memory_info, input_data.data(), input_sizes[i],
                    input_shapes[i].data(), input_shapes[i].size()));
        }

        // 执行推理
        auto output_tensor = session->Run(
            Ort::RunOptions{nullptr},
            input_names.data(), input_tensors.data(), input_tensors.size(),
            output_names.data(), output_names.size());

        // 拷贝输出
        std::vector<float> action(output_shape[1]);
        float* floatarr = output_tensor[0].GetTensorMutableData<float>();
        std::memcpy(action.data(), floatarr, output_shape[1] * sizeof(float));
        return action;
    }

private:
    Ort::Env env;
    Ort::SessionOptions session_options;
    std::unique_ptr<Ort::Session> session;
    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(
        OrtArenaAllocator, OrtMemTypeDefault);

    std::vector<const char*> input_names;
    std::vector<std::vector<int64_t>> input_shapes;
    std::vector<size_t> input_sizes;
    std::vector<const char*> output_names;
    std::vector<int64_t> output_shape;
};
```

### 5.2 推理流程与线程安全边界

`OrtRunner::act()` 是多线程环境中的关键路径。在 FSM 架构中：

- **策略线程（50Hz）**：调用 `env->step()` → `ObservationManager::compute()` → `OrtRunner::act()`
- **FSM 主线程（1kHz）**：读取 `ActionManager::processed_actions()` 并发送到 DDS

推理本身发生在策略线程中，不需要锁保护——因为 `OrtRunner` 的所有成员只在策略线程中访问。但 `env->robot->data` 中的数据由基础关节体在 `robot->update()` 中更新，而 `update()` 内部会获取 DDS wrapper 的互斥锁：

```cpp
void update() override {
    std::lock_guard<std::mutex> lock(lowstate->mutex_);
    // 从 lowstate 中读取 IMU/关节数据，写入 data 结构体
    // ...
}
```

这意味着 `update()` 会短暂阻塞等待 DDS 数据就绪，但由于 DDS 订阅线程以远高于 50Hz 的频率写入数据，这个等待通常只需要几微秒。

**线程安全的关键边界**：

```
DDS 订阅线程（~1kHz 回调写入）
    ↓ mutex 保护
ArticulationData（robot->data）
    ↓ 只读访问
策略线程（50Hz）→ OrtRunner::act()
    ↓ 只读/值拷贝
FSM 主线程（1kHz）→ processed_actions 读取
```

OrtRunner 本身不需要 mutex 保护，因为 `act()` 仅在策略线程中被调用。但如果多个线程同时调用 `act()`，则需要外部加锁。在实际部署中，策略线程是唯一的调用者，因此不存在竞争。

### 5.3 ONNX Runtime 的优化能力

`ORT_ENABLE_EXTENDED` 优化级别启用了 ONNX Runtime 的所有图优化，包括：

1. **常量折叠**：将输入为常量的子图在模型加载时提前计算，减少运行时计算量
2. **算子融合**：将多个连续算子融合为单个更高效的实现（如 `BatchNormalization + Relu` 融合）
3. **布局优化**：根据目标 CPU/NPU 特性调整张量内存布局
4. **冗余消除**：删除无用节点（如恒等变换、重复的 cast 操作）

对于典型的策略网络（~3 层 MLP + 残差连接），这些优化可以减少 20~30% 的推理延迟。

### 5.4 与 LibTorch 的对比

旧版 CppSDK 使用 LibTorch（PyTorch 的 C++ 前端）进行推理：

| 特性 | LibTorch | ONNX Runtime | 对部署的影响 |
|------|---------|-------------|------------|
| 库体积 | ~200MB（CPU 版本） | ~30MB | ONNX 更适合嵌入式部署 |
| 模型格式 | `motion.pt`（JIT ScriptModule） | `policy.onnx` | ONNX 是开放标准 |
| 输入方式 | 单 Tensor（拼接全部观测） | 多命名 Tensor | ONNX 支持结构化输入 |
| 推理延迟 | ~3-5ms（CPU） | ~1-2ms（CPU） | ONNX 优化更好 |
| GPU 支持 | 原生支持 CUDA | 需单独安装 CUDA EP | 两者都支持，但 CPU 部署更常见 |
| 跨平台 | 需单独编译各平台版本 | 官方提供各平台预编译库 | ONNX 更易部署 |

在 50Hz（20ms 周期）的控制频率下，推理延迟差异（3ms vs 1.5ms）对整体系统的影响不大。但 LibTorch 的依赖体积巨大——200MB 的库文件对实机部署来说是一个显著的负担，特别是在空间有限的嵌入式系统中。

---

## 第六章：Sim2Sim 验证体系

### 6.1 什么是 Sim2Sim 验证

Sim2Sim（Simulation-to-Simulation）验证指的是：**在 C++ 部署环境中运行与 Python 训练环境中完全相同的观测组装逻辑，然后逐维度对比两者的数值输出**。

这里的关键是"Sim2Sim"而不是"Sim2Real"——我们用仿真环境同时驱动 Python 训练侧和 C++ 部署侧，确保两者的数学计算完全等价，然后再过渡到真机部署。这相当于在软件层面先发现和修复所有不一致，再将干净的代码部署到真机。

Sim2Sim 验证不是可选的——它是策略从训练环境到真机部署的必要中间步骤。没有 Sim2Sim 验证就直接上真机，一旦出现异常行为（如机器人抖动、摔倒），将无法区分是部署实现错误还是策略本身的局限性。

### 6.2 为什么需要独立的验证工具链

C++ 部署代码是人为编写的，它存在以下风险：

1. **公式翻译错误**：Python 训练侧的数学公式被翻译为 C++ 实现，过程中可能出现符号错误、坐标系理解偏差、索引错位等
2. **配置映射错误**：deploy.yaml 中的 scale/offset/clip 值与 Python 训练侧不一致
3. **四元数约定差异**：Python 使用 scalar-first（w,x,y,z）还是 scalar-last？C++ Eigen 默认是 scalar-first。如果有一侧混淆了约定，姿态计算会完全错误
4. **ONNX 输入顺序差异**：观测向量各分量的拼接顺序与训练时不匹配

这些错误在仿真中很容易暴露，因为仿真环境提供了"ground truth"（Python 训练侧的输出），可以直接与 C++ 输出逐元素对比。

### 6.3 验证工具链全景

在 `deploy/robots/h1_2/tools/` 下提供了完整的验证工具链：

#### 6.3.1 policy_replay_dump.cpp——C++ 侧数据采集

**使用场景**：在 C++ 控制器中植入 CSV dump 代码，运行策略回放时逐帧将 144 维观测、27 维原始动作、27 维处理后动作写入 CSV。

**工作原理**：

```cpp
// 在 State_Mimic 的策略循环中
FILE* fp = fopen("mimic_dump.csv", "w");
// 写入表头
fprintf(fp, "step,");
for(int i=0; i<144; i++) fprintf(fp, "obs_%d,", i);
for(int i=0; i<27; i++) fprintf(fp, "raw_action_%d,", i);
for(int i=0; i<27; i++) fprintf(fp, "proc_action_%d,", i);
fprintf(fp, "motor_q_%d,...\n", ...);

// 每步写入
while(policy_thread_running) {
    env->step();
    // 获取观测（dump 专用接口）
    auto obs = env->observation_manager->get_last_obs();
    auto raw = env->action_manager->raw_actions();
    auto proc = env->action_manager->processed_actions();
    // 写入 CSV
    fprintf(fp, "%d,", step);
    for(float v : obs) fprintf(fp, "%.8f,", v);
    for(float v : raw) fprintf(fp, "%.8f,", v);
    for(float v : proc) fprintf(fp, "%.8f,", v);
    // ...
}
```

关键设计要点：
- 写入 8 位小数的 float32 精度，确保对比时有足够的分辨率
- 同时输出观测和动作，支持端到端对比
- 文件写入在策略线程中同步执行，不影响仿真步进

#### 6.3.2 capture_tracking_rollout.py——Python 侧数据采集

**使用场景**：在 Python 训练/仿真环境中播放同一段 motion 数据，并 dump 观测组装结果。

**工作原理**：

```python
def capture_rollout():
    env = ManagerBasedRlEnv(cfg)
    env.load_motion("ref_motion.npz")
    obs_list = []
    action_list = []
    env.reset()
    for t in range(num_steps):
        # 执行策略推理
        actions = env.policy(obs)
        obs, reward, terminated, info = env.step(actions)
        # 记录观测和动作
        obs_list.append(obs.numpy())
        action_list.append(actions.numpy())
        # 也 dump 中间计算值
        env.observation_manager.dump_intermediates()
    # 保存为 NPZ
    np.savez("python_rollout.npz",
             obs=np.stack(obs_list),
             actions=np.stack(action_list))
```

这个脚本在 Python 训练侧录制 rollout 数据，生成一份"标准答案"供 C++ dump 对比。

#### 6.3.3 verify_deploy_obs_assembly.py——观测组装验证

**使用场景**：验证 C++ 端的观测组装逻辑是否与 Python 训练侧一致。

**工作原理**（对比逻辑）：

```python
def verify_observation_assembly():
    # 加载 C++ dump 数据
    cpp_data = np.loadtxt("cpp_dump.csv", delimiter=",", skiprows=1)
    # 加载 Python rollout 数据
    py_data = np.load("python_rollout.npz")

    # 逐维度对比
    for dim in range(144):
        cpp_obs = cpp_data[:, dim]      # 第 dim 维的时序数据
        py_obs = py_data["obs"][:, dim] # 对应维度的 Python 数据
        max_err = np.max(np.abs(cpp_obs - py_obs))
        print(f"Dim {dim:3d}: max_err = {max_err:.6e}")
        if max_err > 1e-5:
            print(f"  ⚠️  WARNING: dimension {dim} exceeds tolerance!")
```

#### 6.3.4 compare_mimic_deploy_assembly.py——模仿任务部署观测对比

**使用场景**：针对 Mimic（动作模仿）策略的部署验证，Mimic 策略的观测中包含 motion 参考数据，需要额外验证。

**特有验证项**：

1. **motion_ref_pos [0:27]**：从 NPZ 加载的参考关节位置序列，C++ 和 Python 应从同一文件加载，输出必须完全一致
2. **motion_ref_vel [27:54]**：参考关节速度，同理
3. **motion_anchor_ori_b [54:60]**：参考姿态锚点的 6D 旋转表示

#### 6.3.5 compare_mimic_full_assembly.py——端到端验证

**使用场景**：不仅验证观测组装，还验证 ONNX 推理输出。这是最全面的验证。

**工作流**：

```
C++ 端:
  motor_state (关节位置/速度) → observation_manager → obs → ONNX → actions_out
       ↓ dump                         ↓ dump                ↓ dump
  CSV 文件                            CSV 文件              CSV 文件

Python 端:
  同一段 motor_state（来自 CSV）→ observation_manager → obs → ONNX → actions_out
       ↓ 逐元素对比                   ↓ 逐元素对比           ↓ 逐元素对比
  差异分析报告
```

这种端到端验证可以捕获任何环节的不一致，包括：
- 观测组装公式错误
- 观测向量拼接顺序错误
- ONNX 模型加载问题
- 动作 scale/offset 配置错误

#### 6.3.6 analyze_mimic_cpp_dump.py——C++ dump 数据分析

**使用场景**：当 C++ dump 数据与 Python 预期不一致时，使用此工具进行深入分析。

**功能**：
- 统计各观测维度的均值、方差、最大绝对值
- 绘制观测时序图（帮助发现异常跳变）
- 计算与 Python 参考数据的 RMS 误差
- 输出异常维度列表

#### 6.3.7 test_obs_assembly.py——观测组装单元测试

**使用场景**：在修改观测逻辑后快速验证基本正确性。

**测试用例**：
```python
def test_projected_gravity():
    """验证投影重力向量计算"""
    env = create_test_env()
    env.reset()

    # 设置已知的 IMU 四元数（绕 X 轴旋转 30°）
    env.set_imu_quat([cos15°, sin15°, 0, 0])

    obs = env.observation_manager.compute()["projected_gravity"]
    # 预期结果：重力在体坐标系下为 [-sin30°, 0, -cos30°]
    expected = [-0.5, 0.0, -0.866]
    assert np.allclose(obs, expected, atol=1e-6)
```

### 6.4 验证流程与指标

在实际验证执行中，遵循分层验证策略：

**L1：公式等价性验证**——在理想条件下（机器人状态 = 运动参考状态），对比 C++ 和 Python 的观测公式输出。这个阶段不涉及 ONNX 推理，只验证观测组装。

**L2：开环推理验证**——C++ 端读取同一段 motion 数据，执行完整的观测组装 + ONNX 推理，输出 action，与 Python 端的 action 逐元素对比。

**L3：闭环仿真验证**——在 MuJoCo 仿真器中，C++ 和 Python 各自闭环运行（策略输出 → MuJoCo 步进 → 新观测 → 新输出），对比两个闭环系统的轨迹偏差。

数值校验的典型容忍度：

| 验证层级 | 最大允许误差 | 说明 |
|---------|:----------:|------|
| L1 观测组装 | 1e-6 | 纯数学计算应接近浮点精度 |
| L2 动作输出 | 1e-4 | 受 ONNX 推理浮点差异影响 |
| L3 闭环轨迹 | 1e-2 | 累计误差，需迭代优化 |

---

## 第七章：仿真模拟系统（simulate/）

### 7.1 基于 MuJoCo 3.3.6 的实时仿真器

`deploy/simulate/` 目录下提供了一个独立的 MuJoCo 实时仿真器，与 Python 训练时使用的 MuJoCo 实例共享完全相同的物理引擎：

```
simulate/
├── src/
│   ├── main.cc                     # 主循环
│   ├── physics_joystick.h          # 仿真手柄读取
│   └── unitree_sdk2_bridge.h       # 宇树 SDK2 桥接
└── config.yaml                     # 仿真配置
```

**核心主循环**（main.cc 简化版）：

```cpp
int main() {
    // 1. 初始化 MuJoCo
    mjModel* model = mj_loadXML("robot.xml", nullptr, error, 300);
    mjData* data = mj_makeData(model);

    // 2. 设置定时
    const double physics_dt = 0.001;   // 1ms 物理步进
    auto sleepTill = std::chrono::steady_clock::now();

    while (!exit_requested) {
        // 3. 读取手柄
        auto joy = read_joystick();

        // 4. 更新控制器（调用 FSM 的策略推理）
        controller.update(joy, data);

        // 5. 应用电机指令到 MuJoCo
        for (int i = 0; i < model->nu; i++) {
            data->ctrl[i] = controller.get_action(i);
        }

        // 6. 步进物理世界
        mj_step(model, data);

        // 7. 可选：通过 unitree_sdk2_bridge 转发到实机
        if (bridge.is_connected()) {
            bridge.send(data);  // 将仿真数据编码为宇树协议格式
        }

        // 8. 精确计时
        std::this_thread::sleep_until(sleepTill);
        sleepTill += std::chrono::duration<double>(physics_dt);
    }
}
```

### 7.2 MuJoCo 作为训练与部署统一物理引擎的优势

使用 MuJoCo 同时作为训练和部署的物理引擎有以下关键优势：

1. **零 Sim2Real Gap 中的 Sim2Sim 部分**：训练和部署使用完全相同的物理引擎，意味着观测模型中不存在"物理引擎差异"这一变量。所有数值校验只需关注代码实现的正确性，而非物理引擎的差异。

2. **确定性的物理仿真**：MuJoCo 在相同输入下产生完全确定的输出（无随机种子波动）。这使得逐帧对比成为可能——我们可以精确复现训练时的环境状态，验证 C++ 端的计算是否匹配。

3. **跨语言 API 兼容**：MuJoCo 提供了 Python（warp）和 C 两种接口，但底层是同一套计算引擎。Python 训练侧通过 `mujoco_warp` 访问 MuJoCo，C++ 部署侧直接通过 `mj_step()` 访问 MuJoCo，两者的物理计算结果完全一致。

4. **性能优势**：C++ 直接调用 MuJoCo C API 没有 Python 解释器的开销，在相同硬件上可以获得更高的仿真频率。这对于需要快速迭代的验证场景非常有用。

### 7.3 unitree_sdk2_bridge：仿真到真机的桥梁

`unitree_sdk2_bridge` 是一个可选组件，它将 MuJoCo 仿真数据编码为宇树 SDK2 协议格式，然后通过 DDS 发送到真机：

```cpp
class UnitreeSDK2Bridge {
public:
    bool connect(const std::string& network) {
        // 初始化 DDS 发布器
        publisher = std::make_unique<Publisher<LowCmd>>(network);
        subscriber = std::make_unique<Subscriber<LowState>>(network);
        return true;
    }

    void send(const mjData* sim_data) {
        // 将 MuJoCo 仿真数据映射到宇树协议格式
        LowCmd cmd;
        for (int i = 0; i < num_joints; i++) {
            cmd.motor_cmd[i].q() = sim_data->ctrl[i];          // 关节位置
            cmd.motor_cmd[i].dq() = 0;                         // 关节速度（可选）
            cmd.motor_cmd[i].kp() = stiffness[i];              // PD 刚度
            cmd.motor_cmd[i].kd() = damping[i];                // PD 阻尼
            cmd.motor_cmd[i].tau() = 0;                        // 前馈力矩
        }
        publisher->write(cmd);
    }

    LowState receive() {
        // 从真机接收状态回传
        return subscriber->read();
    }
};
```

这个桥接组件使得以下工作流成为可能：
1. 仅仿真（Sim-Only）：策略在 MuJoCo 中闭环运行，不与实机通信
2. 仿真驱动真机（Sim-to-Real Bridge）：策略在仿真中推理，控制指令通过桥接发送到实机
3. 仅真机（Real-Only）：直接连接实机，不经过仿真

模式 2 在初始部署测试时特别有用——可以在仿真环境中先行验证策略的安全性，再逐步过渡到真机。

### 7.4 仿真-真机数据流总览

将整个系统的数据流整合在一起，从用户输入到物理执行：

```
用户输入（手柄/键盘）
    │
    ▼
┌─────────────────────────────────────────────────────┐
│  FSM 控制线程（1kHz）                                │
│  1. pre_run(): lowstate->update()                   │
│     ├── DDS 订阅线程写入 LowState（带 mutex 保护）    │
│     ├── BaseArticulation::update()                  │
│     │   ├── IMU 陀螺仪 → root_ang_vel_b             │
│     │   ├── IMU 四元数 → projected_gravity_b         │
│     │   ├── 关节编码器 → joint_pos/joint_vel         │
│     │   └── (H1_2) 腰部偏航变换                     │
│     └── 手柄/键盘状态更新                            │
│                                                    │
│  2. run(): 执行当前状态逻辑                          │
│     ├── Passive: 零力矩跟随                         │
│     ├── FixStand: 线性插值                          │
│     └── RLBase: 读取 processed_actions → 写入 lowcmd │
│                                                    │
│  3. post_run(): lowcmd->unlockAndPublish()          │
│     ├── DDS 发布线程发送 LowCmd                     │
│     └── (仿真) unitree_sdk2_bridge 转发到 MuJoCo     │
└─────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────┐
│  策略推理线程（50Hz）                                 │
│  1. robot->update()（只读传感器数据）                 │
│  2. observation_manager->compute()                   │
│     ├── base_ang_vel:      IMU → 3维                │
│     ├── projected_gravity: IMU → 3维                │
│     ├── velocity_commands: 手柄 → 3维               │
│     ├── gait_phase:       计数器 → 2维               │
│     ├── joint_pos_rel:    编码器 − default → 27维    │
│     ├── joint_vel_rel:    编码器微分 → 27维           │
│     ├── last_action:      缓存 → 27维               │
│     └── (Mimic) motion_command: NPZ → 54维          │
│                                                    │
│  3. OrtRunner::act(obs) → raw_action (27维)         │
│  4. ActionManager::process_action(raw)              │
│     ├── scale + offset + clip                       │
│     └── → processed_actions (27维)                  │
└─────────────────────────────────────────────────────┘
    │
    ▼
执行层（物理引擎或实机）
    ├── MuJoCo 仿真: mj_step(model, data) @ 1kHz
    └── 实机: 通过宇树 SDK2 下发到电机 @ 1kHz
```

---

## 第八章：延迟与精度损失分析

### 8.1 延迟预算分析

系统运行在双速率架构下，各环节的时间预算如下：

| 环节 | 频率 | 单次预算 | 说明 |
|------|:---:|:-------:|------|
| DDS 订阅回调 | 取决于网卡 | 50~200μs | 纯数据拷贝，网络延迟主导 |
| FSM pre_run | 1kHz | 50~100μs | 状态更新、坐标变换 |
| FSM run | 1kHz | 50~100μs | 状态逻辑（Passive/FixStand 极轻，RLBase 仅赋值） |
| FSM post_run | 1kHz | 50~100μs | DDS 发布序列化 |
| **FSM 总周期** | **1kHz** | **200~400μs** | **远小于 1ms 预算** |
| 策略 robot->update | 50Hz | 100~200μs | 含 mutex 等待 |
| 策略观测组装 | 50Hz | 100~500μs | 维度越高耗时越大（Mimic 144 维 > Velocity 92 维） |
| 策略 ONNX 推理 | 50Hz | 1~2ms | 模型大小和优化决定 |
| 策略动作处理 | 50Hz | 10~50μs | 简单线性运算 |
| **策略总周期** | **50Hz** | **1.5~3ms** | **远小于 20ms 预算** |

从延迟角度分析，系统的瓶颈在 ONNX 推理（1~2ms），但即使如此，也远小于 20ms 的控制周期。这意味着在 x86_64 平台上，延迟不是问题——延迟预算的富余量超过 85%。

**延迟的传递链条**：

```
传感器采集时刻 → DDS 传输 → FSM 读取 → 策略推理 → DDS 下发 → 电机执行

各环节延迟：
├── 传感器采集：~1ms（IMU 内部采样 + 滤波）
├── DDS 传输：~0.5ms（基于 CycloneDDS 的实时性评估）
├── FSM 读取：<0.1ms（mutex 竞争最坏情况）
├── 策略推理：~1.5ms（ONNX Runtime 推理）
├── DDS 下发：~0.5ms
└── 电机执行：~1ms（电机驱动器内部处理）

端到端延迟：~4.5ms（在控制周期 20ms 内）
```

这个端到端延迟分布在人形机器人的控制中是可以接受的。50Hz 控制 + 1kHz 执行的双速率架构确保了：虽然策略知道有 20ms 的延迟，但电机仍以 1ms 的精度执行指令。

### 8.2 精度损失分析

从 Python 训练到 C++ 部署，数值精度损失来自以下环节：

**1. 浮点精度差异**

Python（NumPy）和 C++ 都使用 IEEE 754 float32，理论上精度一致。但在以下场景中可能出现细微差异：

- **SIMD 指令集差异**：不同的 CPU 或不同的编译优化（如 `-ffast-math`）可能导致浮点运算的中间精度不同
- **累积顺序差异**：向量点积等操作如果元素的求和顺序不同，累积误差也有差异

实际测量表明，纯数学运算的误差通常在 1e-7 到 1e-6 量级，可以忽略。

**2. 数据类型转换**

ONNX 模型输入要求 float32 张量。在 Python 端，torch.onnx.export 导出的模型在推理时使用 float32；在 C++ 端，OrtRunner 同样使用 float32。因此不存在类型转换损失。

但在旧版 LibTorch 部署方案中，存在 `double → float` 的截断。因为 LibTorch 的某些算子默认使用 double 精度，而 ONNX Runtime 全程使用 float32。这实际上意味着 ONNX Runtime 方案精度更一致。

**3. 配置精度**

deploy.yaml 中的 scale/offset 采用 YAML 文本格式存储，存在以下精度问题：

```yaml
# 示例：action scale
scale: [0.51, 0.51, ...]  # 只有 2 位小数！
```

如果 Python 训练时使用的 scale 是 `0.51234567`，但在 deploy.yaml 中被截断为 `0.51`，则每个动作维度会引入约 `0.0023 × action_value` 的误差。当 action_value 接近 1.0 时，误差可达 0.23%，这在电机控制中是显著的。

实际验证中发现，这个问题曾导致部署版本的 action scale 截断精度问题——训练用 scale 有 8 位小数，而 deploy.yaml 只有 2 位。修复方法是将 deploy.yaml 中的 scale 值更新为完整 float32 精度。

**4. 观测裁剪**

观测裁剪（clip）的一致性也需要严格对齐。如果 Python 侧对某个观测维度裁剪到 [-10, 10]，但 C++ 侧配置的裁剪范围是 [-5, 5]，则当观测值落在 [-10, -5) ∪ (5, 10] 区间时，两端的输入会不同，导致推理结果差异。

### 8.3 已知近似与误差容忍度

部署实现中存在一些有意或无意的近似，这些近似需要被识别、量化和记录：

**已知近似案例：motion_anchor_ori_b 的转置差异**

在数值验证中发现，C++ 端和 Python 端的 `motion_anchor_ori_b` 计算存在公式差异：

| 方法 | 计算方式 | 6D 编码 |
|------|---------|---------|
| Python 训练 | `robot_q^{-1} * ref_q` 后直接取 6D | 无转置 |
| C++ 部署 | `(init_q * ref_q)^{-1} * real_q` 后转置取 6D | 有转置 |

差异来源：C++ 侧为了做 yaw 对齐（消除初始偏航角差异），使用了 `init_q * ref_q` 复合参考四元数，并对结果做了转置。这种差异导致 `motion_anchor_ori_b` 维度的最大绝对误差达到 1.1e-2，并进一步传播到 ONNX 动作输出（误差约 9.6e-4）。

对于这个差异的处理策略：
1. 记录并量化——1.1e-2 的观测误差对常规行走影响不大
2. 如果后续发现某个动作在这种情况下表现异常，再考虑统一公式
3. 关键是要**知道这个差异存在**，而不是在真机出现异常时从头排查

这个案例说明了数值校验工具链的价值——它暴露了部署实现与训练实现之间的已知差异，使得工程师可以基于量化数据做出工程决策，而不是依赖直觉判断。

---

## 第九章：Mimic 策略部署的特殊性

### 9.1 Mimic 与 Velocity 策略的差异

动作模仿（Mimic）策略与速度跟踪（Velocity）策略在部署架构上有显著差异：

| 维度 | Velocity 策略 | Mimic 策略 |
|------|-------------|-----------|
| 控制目标 | 按手柄指令行走 | 跟踪参考动作序列 |
| 观测维度 | 92 维 | 144 维 |
| 动作维度 | 12 维（仅下肢） | 27 维（全身） |
| 观测含 motion 数据 | 否 | 是（54 维） |
| 需要加载 NPZ 文件 | 否 | 是 |
| 状态类 | `State_RLBase` | `State_Mimic` |

### 9.2 State_Mimic 与 State_RLBase 的差异

`State_Mimic` 继承自 `State_RLBase`，新增了 motion 数据管理：

```cpp
class State_Mimic : public State_RLBase {
public:
    void enter() override {
        State_RLBase::enter();  // 调用基类 enter()

        // 额外初始化：加载 motion 数据
        motion_loader = std::make_unique<MotionLoader>(
            param::config_dir / "policy/mimic/v0/params/ref_motion.npz");

        // 将 motion 数据注入观测系统
        env->observation_manager->set_motion_data(motion_loader->get_data());
    }

    void run() override {
        // 在策略推理前更新当前 motion 帧索引
        motion_loader->advance_frame(env->step_dt);
        State_RLBase::run();  // 调用基类 run()
    }

private:
    std::unique_ptr<MotionLoader> motion_loader;
};
```

关键的区别在于观测计算：Mimic 策略的观测中包含 `motion_command`（54 维 = 27 关节参考位置 + 27 关节参考速度），这些数据从 NPZ 文件加载，需要与训练时使用相同的采样频率和骨骼定义。

### 9.3 motion_anchor_ori_b 的坐标变换

Mimic 策略中有一个特殊的观测项 `motion_anchor_ori_b`，它编码了参考姿态与实际姿态之间的旋转差异：

```cpp
REGISTER_OBSERVATION(motion_anchor_ori_b) {
    // 从 motion 加载器获取当前帧的参考姿态四元数
    auto ref_quat = env->motion_loader->get_current_frame_quat();

    // 从 IMU 获取实际姿态四元数
    auto real_quat = env->robot->data.root_quat_w;

    // 计算初始补偿四元数
    auto init_quat = env->motion_loader->get_init_quat();

    // 计算相对旋转
    // (init_q * ref_q)^{-1} * real_q
    auto delta = (init_quat * ref_quat).conjugate() * real_quat;

    // 转换为 6D 旋转表示（取旋转矩阵的前两行）
    Eigen::Matrix3f rot_mat = delta.toRotationMatrix();
    std::vector<float> obs(6);
    // 第 0-2 维：旋转矩阵第一行
    obs[0] = rot_mat(0, 0); obs[1] = rot_mat(0, 1); obs[2] = rot_mat(0, 2);
    // 第 3-5 维：旋转矩阵第二行
    obs[3] = rot_mat(1, 0); obs[4] = rot_mat(1, 1); obs[5] = rot_mat(1, 2);

    return obs;
}
```

这个 6D 旋转表示比四元数更适合作为神经网络输入，因为它不存在四元数的双重覆盖问题（q 和 -q 表示相同旋转）和单位范数约束。

`(init_q * ref_q)` 中的 `init_q` 用于对齐初始姿态——在训练开始时，参考动作的起始姿态可能与机器人当前的实际姿态不同，`init_q` 消除了这个初始偏移。

---

## 第十章：从仿真到真机的工程实践

### 10.1 部署核查清单

基于 Sim2Sim 验证的经验，部署从仿真到真机可以总结为以下核查项目：

| 核查项 | 验证方法 | 严重性 |
|-------|---------|:-----:|
| ONNX 模型输入维度匹配 | 对比 ONNX 模型与 deploy.yaml 的观测维度 | 必须一致 |
| 观测 scale/clip 与训练一致 | 对比 train_cfg.py 与 deploy.yaml | 必须一致 |
| 动作 scale/offset/clip 与训练一致 | 对比 train_cfg.py 与 deploy.yaml | 必须一致 |
| 关节 ID 映射正确 | 逐关节验证顺序 | 必须正确 |
| PD 增益合理 | FixStand 下观察机器人是否平稳 | 影响性能 |
| bad_orientation 阈值 | 水平静置时不应误触发 | 影响安全 |
| DDS 通信时延 | 检查 lowstate->isTimeout() | 影响安全 |
| 手柄按键映射 | 验证所有 DSL 表达式 | 影响操作 |
| 策略线程启动/停止 | 检查 enter()/exit() 时序 | 影响安全 |

### 10.2 常见部署问题与修复

以下是部署过程中常见的问题及其解决方案：

**问题 1：观测维度不匹配**

现象：C++ 端组装出的观测向量维度与 ONNX 模型期望的输入维度不一致。

原因：deploy.yaml 中的观测项配置遗漏或多余，导致 C++ `ObservationManager::compute()` 产出的向量维度与 ONNX 模型不匹配。

修复：确认 Python 训练时的 `env_cfg.observations` 配置与 deploy.yaml 中的 `observations` 配置一一对应。

**问题 2：关节顺序不匹配**

现象：机器人动作异常，表现为"张冠李戴"——本应控制右腿的关节却在控制左臂。

原因：`joint_ids_map` 的定义顺序与策略网络输出的关节顺序不匹配。

修复：验证 `joint_ids_map` 中各元素对应的硬件关节与训练时的关节顺序一致。

**问题 3：尺度误差导致动作溢出**

现象：机器人启动策略后剧烈抖动。

原因：deploy.yaml 中的 action scale 值不正确，导致 ONNX 输出的归一化动作被错误放大。

修复：对比训练侧的 `action_scale` 参数，确认 deploy.yaml 中的 scale 值与之完全相同。

### 10.3 安全设计原则

部署系统在安全方面有四点关键设计：

1. **默认安全**：系统初始化为 Passive 状态，即使配置错误也不会产生主动力矩
2. **故障回退**：任何异常（通信超时、传感器异常）自动回退到 Passive
3. **操作员控制**：手柄保留最高优先级，任何状态下手柄按键可强制回退
4. **可观测性**：策略线程独立运行，其状态可通过 DDS 日志实时监控

---

## 总结

C++ 部署系统与 Sim2Sim 验证体系构成了策略从训练环境到真机部署的完整桥梁：

1. **架构保留**：C++ 部署框架完整保留了 Python 训练架构的 Manager-Observation-Action 三层设计，通过配置驱动和注册制实现声明式部署。

2. **安全递进**：Passive → FixStand → RLBase/Mimic 的三层状态机提供了从安全无动力到全自主控制的安全递进路径。

3. **坐标变换**：H1_2 的 IMU 躯干安装位置要求了必要的坐标变换，通过 `Rz(θ)` 旋转将躯干系下的传感器数据变换到骨盆系，确保策略看到的数据与训练时一致。

4. **推理轻量化**：ONNX Runtime 以约 30MB 的体积和 1~2ms 的推理延迟替代了约 200MB 的 LibTorch，更适合嵌入式部署。

5. **验证工具链**：完整的 Python↔C++ 数值对齐验证体系（从公式等价性到端到端动作输出）确保了部署实现的正确性。

6. **已知差异管理**：通过量化已知差异（如 motion_anchor_ori_b 的转置差异）并评估其影响，避免了部署实现差异导致的潜在问题。

部署系统的核心工程原则可以概括为一句话：**"在仿真中先做对，再到真机上做快"**。Sim2Sim 验证正是这一原则的具体体现——它确保了 C++ 实现与 Python 训练在数学上等价，然后才能将注意力集中在真机部署时特有的问题（通信延迟、硬件噪声、磨损等）上。
