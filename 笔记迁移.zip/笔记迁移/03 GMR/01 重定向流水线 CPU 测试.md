# 01 GMR / NMR 重定向流水线 CPU 验证记录

> **系列定位**：本篇为 GVHMR → GMR → BeyondMimic 全链路的 CPU 可行性验证记录。以 `/home/meme/Documents/unitree_h1/retgt/` 为工作目录，在无 GPU 环境下验证 GMR（通用运动重定向）和 MakeTrackingEasy（NMR 神经运动重定向）两个组件的推理流程。

**本篇目的**：
在 `retargeting_repos` 代码仓库中，仅使用 CPU 资源（GPU 暂不可用）跑通人体运动到机器人关节空间的转换流程。涵盖 conda 环境搭建、依赖安装、SMPL-X 体模型配置、测试数据准备、GMR 和 NMR 推理执行，以及输出验证。

---

## 1. 实验基本设计

本实验从 [retargeting_repos](file:///home/meme/Documents/github_repos/retargeting_repos)（后迁移至 [retgt](file:///home/meme/Documents/unitree_h1/retgt)）中选取两个关键组件进行 CPU 验证：

| 组件 | 功能 | 输入 | 输出 | CPU 可行性 |
|------|------|------|------|-----------|
| **GMR** | 通用运动重定向（优化式 IK） | SMPL-X 参数 (.npz) | 机器人关节轨迹 (.pkl) | ✅ 全 CPU 可运行 |
| **NMR (MakeTrackingEasy)** | 神经运动重定向（Transformer） | SMPL-X 参数 (.npz) | bmimic 格式 (.npz) | ✅ 全 CPU 可运行 |
| GVHMR | 单目视频人体运动恢复 | 视频 (.mp4) | SMPL-X 参数 (.pt) | ❌ 需 GPU（ViT/YOLO） |
| BeyondMimic | RL 跟踪策略训练 | 参考轨迹 (.npz) | 策略网络 (.pt) | ❌ 需 GPU |

---

## 2. 项目文件迁移

### 2.1 背景

原始代码位于 `/home/meme/Documents/github_repos/retargeting_repos/`，包含 GMR、GVHMR、MakeTrackingEasy、PHC、MimicKit、ProtoMotions 等十余个项目。

### 2.2 迁移操作

> [!WARNING]
> **初次操作失误**：首次迁移时误将 `retargeting_repos/` 下所有项目整体移动，后纠正为仅迁移流水线所需项目。以下是修正后的正确操作。

```bash
# 创建目标目录
mkdir -p /home/meme/Documents/unitree_h1/retgt

# 第一步：迁移 GMR（重定向核心）和 NMR（神经重定向）
mv /home/meme/Documents/github_repos/retargeting_repos/GMR             /home/meme/Documents/unitree_h1/retgt/
mv /home/meme/Documents/github_repos/retargeting_repos/MakeTrackingEasy /home/meme/Documents/unitree_h1/retgt/

# 将其他不需要的项目移回原处
# (GVHMR优化脚本-B站, holosoma, MimicKit, PHC, ProtoMotions, pyroki, robot_retargeter, soma-retargeter, spider_adam)

# 第二步（用户指示后）：补迁 GVHMR（流水线上游，GMR 的 gvhmr_to_robot.py 依赖）
mv /home/meme/Documents/github_repos/retargeting_repos/GVHMR           /home/meme/Documents/unitree_h1/retgt/
```

### 2.3 最终目录结构

```
/home/meme/Documents/unitree_h1/retgt/
├── CHANGELOG.md        ← 本记录文件
├── GMR/                ← 通用运动重定向（YanjieZe/GMR）
├── GVHMR/              ← 单目视频人体运动恢复（zju3dv/GVHMR）
└── MakeTrackingEasy/   ← 神经运动重定向 / NMR（RayZhao/NMR）
```

---

## 3. Conda 环境部署

两个组件需要独立的 conda 环境，可并行安装。

### 3.1 GMR 环境

```bash
# 创建环境
conda create -y -n gmr python=3.10

# 安装 PyTorch CPU 版
conda run -n gmr pip install torch --index-url https://download.pytorch.org/whl/cpu

# 代理配置（国内网络）
export http_proxy=http://localhost:7897
export https_proxy=http://localhost:7897

# 安装 GMR 及其依赖
cd /home/meme/Documents/unitree_h1/retgt/GMR
conda run -n gmr pip install -e .
```

**关键依赖版本（已验证）**：

| 依赖 | 版本 | 说明 |
|------|------|------|
| PyTorch | 2.12.1+cpu | CPU 版 |
| smplx | 0.1.28 | 人体参数化模型 |
| mujoco | 3.10.0 | 物理引擎（渲染需 xvfb） |
| numpy | 2.2.6 | GMR 无版本限制 |

### 3.2 NMR 环境

```bash
# 创建环境
conda create -y -n nmr python=3.10

# 安装 PyTorch CPU 版
conda run -n nmr pip install torch --index-url https://download.pytorch.org/whl/cpu

# 安装 NMR 依赖（注意 numpy<2 限制）
cd /home/meme/Documents/unitree_h1/retgt/MakeTrackingEasy
conda run -n nmr pip install -r requirements.txt
```

**关键依赖版本（已验证）**：

| 依赖 | 版本 | 说明 |
|------|------|------|
| PyTorch | 2.12.1+cpu | CPU 版 |
| mmengine | 0.10.7 | 模型注册与构建 |
| numpy | 1.26.4 | 满足 <2 限制 |
| huggingface_hub | - | 自动下载模型权重 |

---

## 4. SMPL-X 体模型配置

### 4.1 模型下载

SMPL-X 中性体模型（~108MB）从 HuggingFace Hub 自动下载：

```bash
# 使用代理下载
export http_proxy=http://localhost:7897
export https_proxy=http://localhost:7897
export HF_ENDPOINT=https://hf-mirror.com  # 国内镜像（备选）

conda run -n gmr python -c "
from huggingface_hub import hf_hub_download
hf_hub_download(repo_id='RayZhao/NMR',
  filename='assets/SMPLX_NEUTRAL.npz',
  local_dir='/home/meme/Documents/unitree_h1/retgt/GMR/assets/')
"
```

### 4.2 目录结构

```bash
mkdir -p /home/meme/Documents/unitree_h1/retgt/GMR/assets/body_models/smplx/
ln -s ../../SMPLX_NEUTRAL.npz /home/meme/Documents/unitree_h1/retgt/GMR/assets/body_models/smplx/SMPLX_NEUTRAL.npz
```

### 4.3 验证加载

```python
import smplx
model = smplx.create(
    '/home/meme/Documents/unitree_h1/retgt/GMR/assets/body_models',
    'smplx', gender='neutral', use_pca=False
)
print(f'SMPL-X loaded: {type(model).__name__}')
# 输出: SMPL-X loaded: SMPLX
```

---

## 5. 测试数据准备

### 5.1 数据来源

NMR 仓库的示例数据 `MakeTrackingEasy/examples/sample_motion.npz` 为 AMASS 格式，包含 90 帧运动数据。

```python
# 原始数据字段
keys: ['trans', 'root_orient', 'pose_body', 'mocap_frame_rate']
- trans:         (90, 3)     # 根位置
- root_orient:   (90, 3)     # 根朝向（axis-angle）
- pose_body:    (90, 63)     # 21个身体关节 × 3（axis-angle）
- mocap_frame_rate: 120      # 原始采集帧率
```

### 5.2 GMR 兼容格式转换

GMR 的 `load_smplx_file()` 额外要求 `gender` 和 `betas` 字段：

```python
import numpy as np

d = np.load('examples/sample_motion.npz')
np.savez('examples/sample_motion_gmr_compat.npz',
    trans=d['trans'],
    root_orient=d['root_orient'],
    pose_body=d['pose_body'],
    betas=np.zeros(10, dtype=np.float32),   # SMPL-X 用 10 维 shape 参数
    gender='neutral',                       # 必须为 str 类型
    mocap_frame_rate=d['mocap_frame_rate'])
```

> [!WARNING]
> **常见陷阱**：`gender` 字段如果用 `np.string_('neutral')` 保存，加载后为 `b'neutral'` 字节串，会被 smplx 格式化为错误文件名。必须保存为 Python 原生 `str`。

---

## 6. GMR 推理执行

### 6.1 命令

```bash
eval "$(/home/meme/miniconda3/bin/conda shell.bash hook)"
conda activate gmr

cd /home/meme/Documents/unitree_h1/retgt/GMR

export MUJOCO_GL=osmesa  # 无头渲染后端

xvfb-run --auto-servernum python3 scripts/smplx_to_robot.py \
  --smplx_file /home/meme/Documents/unitree_h1/retgt/MakeTrackingEasy/examples/sample_motion_gmr_compat.npz \
  --robot unitree_g1 \
  --save_path /home/meme/Documents/unitree_h1/retgt/GMR/output_g1.pkl
```

### 6.2 运行输出

成功加载 G1 机器人的 29 个自由度和 MuJoCo 模型：

```
[GMR] Robot Degrees of Freedom (DoF) names:
  DoF 0-5:    pelvis (free joint, 6D)
  DoF 6-11:   left_hip_pitch → left_ankle_roll (左腿 6 关节)
  DoF 12-17:  right_hip_pitch → right_ankle_roll (右腿 6 关节)
  DoF 18-20:  waist_yaw → waist_pitch (腰部 3 关节)
  DoF 21-27:  left_shoulder_pitch → left_wrist_yaw (左臂 7 关节)
  DoF 28-34:  right_shoulder_pitch → right_wrist_yaw (右臂 7 关节)

Saved to /home/meme/Documents/unitree_h1/retgt/GMR/output_g1.pkl
```

### 6.3 输出结构

```python
import pickle
with open('output_g1.pkl', 'rb') as f:
    data = pickle.load(f)

print(data.keys())
# ['fps', 'root_pos', 'root_rot', 'dof_pos', 'local_body_pos', 'link_body_list']

- fps:      30                              # 帧率
- root_pos: (89, 3)   float64              # 根位置 [m]
- root_rot: (89, 4)   float64              # 根四元数 (xyzw)
- dof_pos:  (89, 29)  float64              # 29 个关节角度 [rad]
```

> [!NOTE]
> 输入 90 帧 → 输出 89 帧。首帧作为初始状态被消耗，不产生输出。

---

## 7. NMR 推理执行

### 7.1 模型自动下载

首次运行自动从 HuggingFace Hub 下载：

| 文件 | 大小 | 说明 |
|------|------|------|
| `weights/epoch_30.pth` | ~542 MB | NMR Transformer 模型权重 |
| `assets/SMPLX_NEUTRAL.npz` | ~104 MB | SMPL-X 体模型（若不存在） |

### 7.2 命令

```bash
eval "$(/home/meme/miniconda3/bin/conda shell.bash hook)"
conda activate nmr

python3 /home/meme/Documents/unitree_h1/retgt/MakeTrackingEasy/inference.py \
  --src /home/meme/Documents/unitree_h1/retgt/MakeTrackingEasy/examples/sample_motion.npz \
  --output-dir /home/meme/Documents/unitree_h1/retgt/MakeTrackingEasy/output/
```

### 7.3 运行输出

```
Loading model...
Model loaded on cpu
[1/1] .../examples/sample_motion.npz
  90 frames @ 30 FPS → 149 frames @ 50 FPS → output/sample_motion.npz
  Total: 0.12s
```

> [!TIP]
> NMR 推理极快（90 帧仅 0.12s），因为 Transformer 是非自回归的 one-shot 映射。相比之下 GMR 的逐帧 IK 求解需数分钟。

### 7.4 输出结构

```python
import numpy as np
d = np.load('output/sample_motion.npz')

字段              形状              说明
───               ────              ────
fps              (1,)              50 Hz
joint_pos        (149, 29)         29 个关节角度 [rad]
joint_vel        (149, 29)         关节角速度 [rad/s]
body_pos_w       (149, 30, 3)      30 个 body 世界坐标位置 [m]
body_quat_w      (149, 30, 4)      body 朝向四元数 (wxyz)
body_lin_vel_w   (149, 30, 3)      body 线速度 [m/s]
body_ang_vel_w   (149, 30, 3)      body 角速度 [rad/s]
```

---

## 8. 性能对比

| 指标 | GMR (smplx_to_robot) | NMR (inference) |
|------|:--------------------:|:---------------:|
| 计算类型 | 优化式 IK（每帧 QP 求解） | 神经网络（Transformer） |
| CPU 耗时 | ~数分钟（89 帧） | 0.12s（90 帧 → 149 帧） |
| 输出帧率 | 30 FPS | 50 FPS（含上采样） |
| 输出格式 | pickle (.pkl) | bmimic npz (.npz) |
| 机器人支持 | 17+ 种 | 仅 Unitree G1 |
| 渲染依赖 | 需要 MuJoCo + xvfb | 不需要渲染 |

---

## 9. 源码修改记录

### 9.1 SMPL-X 兼容性修复

**文件**：`GMR/general_motion_retargeting/utils/smpl.py`  
**问题**：较新版本的 smplx 库（>=0.1.28）要求 forward 调用时传入 `expression` 参数，否则 batch size 不匹配：

```
RuntimeError: Sizes of tensors must match except in dimension 1.
Expected size 90 but got size 1 for tensor number 1 in the list.
```

**修改**：

```diff
- # expression=torch.zeros(num_frames, 10).float(),
+ expression=torch.zeros(num_frames, body_model.num_expression_coeffs).float(),
```

**说明**：使用 `body_model.num_expression_coeffs` 动态获取系数数量，避免硬编码 10。

### 9.2 测试数据修复

**文件**：`MakeTrackingEasy/examples/sample_motion_gmr_compat.npz`  
**问题**：原始 AMASS 格式缺少 `gender` 和 `betas` 字段，且 `betas` 需为 10 维（SMPL-X neutral 模型标准）

---

## 10. 限制与后续建议

### 当前限制

| 限制项 | 原因 | 影响 |
|--------|------|------|
| GVHMR 不可用 | 需 GPU（YOLO + ViTPose + ViT） | 无法从视频端到端跑通 |
| BeyondMimic 不可用 | RL 训练需 GPU | 无法训练跟踪策略 |
| GMR 无渲染可视化 | 仅命令行运行，无法看到实际效果 | 需 GPU 或远程桌面 |
| 测试数据单一 | 仅用了一条 90 帧的示例运动 | 未验证复杂运动重定向 |

### 后续步骤

1. 恢复 GPU 后，先跑通 GVHMR 端到端视频推理
2. 用 GVHMR 的输出作为 GMR 输入，完成全链路验证
3. 使用 GMR 输出的 `.pkl` 训练 BeyondMimic 跟踪策略
4. 在 MuJoCo 仿真中可视化重定向效果

---

## 附录：Conda 环境快照

```bash
# gmr 环境
conda list -n gmr | grep -E "torch|smplx|mujoco|numpy"
# torch             2.12.1+cpu
# smplx             0.1.28
# mujoco            3.10.0
# numpy             2.2.6

# nmr 环境
conda list -n nmr | grep -E "torch|mmengine|numpy"
# torch             2.12.1+cpu
# mmengine          0.10.7
# numpy             1.26.4
```
