# GMR（General Motion Retargeting）通用运动重定向系统原理与操作流程

本教程将结合 arXiv 论文与 GitHub 开源仓库，从源码到算法原理，剖析 GMR 运动重定向系统的工作机制、架构设计及完整操作流程。

> 参考文献：
> - arXiv: [2510.02252](https://arxiv.org/abs/2510.02252) *Retargeting Matters: General Motion Retargeting for Humanoid Motion Tracking*
> - GitHub: [github.com/YanjieZe/GMR](https://github.com/YanjieZe/GMR)

---

## 1. 背景：人形机器人运动重定向面临的挑战

### 1.1 具身鸿沟（Embodiment Gap）

人形机器人模仿学习面临一个本质问题：人类与机器人在骨骼长度、关节自由度拓扑、运动范围、质量分布及驱动机制上存在巨大差异。这种 **"具身鸿沟"（Embodiment Gap）** 使得直接从人类运动数据（如 AMASS、LAFAN1 等数据集）到机器人控制策略之间存在根本性的转换障碍。

当前主流范式采用 **"先重定向（Retargeting）、后跟踪（Tracking）"** 的解耦架构：

```text
人体运动数据（SMPLX/BVH/FBX）
    │
    ▼
┌─────────────────────────────────┐
│   运动重定向（Motion Retargeting）  │  ← GMR 的核心定位
│   人体 → 人形机器人                 │
└─────────────────────────────────┘
    │ 机器人关节轨迹（参考运动）
    ▼
┌─────────────────────────────────┐
│   RL 运动跟踪策略（Motion Tracking）│  ← BeyondMimic
└─────────────────────────────────┘
    │ 策略部署（Sim2Real）
    ▼
┌─────────────────────────────────┐
│   机器人真实关节控制               │
└─────────────────────────────────┘
```

### 1.2 现有重定向方法的缺陷

在 GMR 提出之前，主流的开源重定向方法存在以下问题：

| 方法 | 核心策略 | 主要缺陷 |
| :--- | :--- | :--- |
| **PHC 重定向** | SMPL 拟合机器人 → 梯度下降 IK | 耗时长（无法实时）；忽视接触状态；SMPL 无法覆盖非人形机器人拓扑 |
| **ProtoMotions** | 全局轴对齐缩放 + 差分 IK | 全局缩放过于刚性，无法处理身体各部位的不同尺度比例；优化不稳定 |
| **简单复制关节旋转** | 直接映射 SO(3) 关节旋转 | 拓扑不匹配导致严重穿透、足部滑动、浮空等伪影 |

GMR 的核心贡献在于提出了一套**非均匀局部缩放（Non-uniform Local Scaling）** + **两阶段 IK 优化（Two-stage IK Optimization）** 的通用框架，在保持实时性能（60-70 FPS）的前提下，显著提升了重定向质量和下游策略跟踪成功率。

---

## 2. GMR 系统核心架构

### 2.1 整体模块设计

GMR 的软件架构采用 **"主控代理（GeneralMotionRetargeting） + 子代理模块（IK求解器、运动学模型、数据加载器、可视化器）"** 的模块化设计：

```text
┌─────────────────────────────────────────────────────────┐
│              GeneralMotionRetargeting（主控代理）          │
│   - 协调所有子代理模块的工作流程                           │
│   - 管理状态：非均匀缩放 → 两阶段 IK → 后处理              │
└────────────┬────────────────────────┬───────────────────┘
             │                         │
    ┌────────▼────────┐      ┌────────▼────────┐
    │   KinematicsModel  │      │   Data Loader    │
    │   (运动学模型子代理) │      │   (数据加载子代理)  │
    │   - FK 正向运动学   │      │   - SMPLX 解析    │
    │   - IK 逆向运动学   │      │   - BVH 解析      │
    │   - 雅可比矩阵      │      │   - FBX 解析      │
    └───────────────────┘      └───────────────────┘
                    │                         │
    ┌────────▼────────┐      ┌────────▼────────┐
    │   IK Solver      │      │ RobotMotionViewer│
    │   (IK求解子代理)   │      │   (可视化子代理)   │
    │   - DAQP 求解器   │      │   - MuJoCo 渲染  │
    │   - 任务空间控制   │      │   - 视频录制      │
    └───────────────────┘      └───────────────────┘
```

#### 各模块职责

1. **`GeneralMotionRetargeting`（主控类）**：
   - 位于 [motion_retarget.py](file:///home/meme/Documents/gmr/general_motion_retargeting/motion_retarget.py)
   - 编排完整的重定向流水线：加载人体运动 → 坐标系转换 → 非均匀缩放 → 两阶段 IK → 速度限制 → 输出机器人运动
   - 内部维护 `_config` 字典（IK 权重配置、偏移量、阻尼参数）

2. **`KinematicsModel`（运动学模型子代理）**：
   - 位于 [kinematics_model.py](file:///home/meme/Documents/gmr/general_motion_retargeting/kinematics_model.py)
   - 从 MuJoCo XML 自动构建运动学树
   - 提供 FK（正向运动学）和 IK（逆向运动学）接口
   - 支持 1-DOF 旋转关节和 3-DOF 球关节

3. **IK 求解器（任务空间控制子代理）**：
   - 基于 `mink` 库和 DAQP（Default Affine QP Solver）求解器
   - 使用 `FrameTask` 定义控制目标：位置代价权重 + 方向代价权重 + Levenberg-Marquardt 阻尼

4. **数据加载器**：
   - 支持多种人体运动格式（SMPLX、BVH、FBX、PICO 等），每种格式有对应的解析子代理
   - 统一输出为 `{body_name: (3D_position, quaternion_rotation)}` 格式

5. **可视化器**：
   - 基于 MuJoCo 的实时渲染窗口
   - 支持视频录制（`--record_video`）

### 2.2 "子代理"模式的协作原理

GMR 中的各个模块在逻辑上具有清晰的**职责分离**，每个模块只负责自身领域内的事务，通过主控类进行协调：

```python
# motion_retarget.py 中的核心流程（简化示意）
class GeneralMotionRetargeting:
    def retarget(self, human_motion_data):
        # 阶段1：数据预处理（数据加载子代理）
        scaled_data = self._scale_human_motion(human_motion_data)
        
        # 阶段2：坐标系转换（运动学子代理）
        robot_frames = self._transform_to_robot_frame(scaled_data)
        
        # 阶段3：两阶段 IK 求解（IK 求解子代理）
        #   第1阶段：躯干 + 腿部
        joint_positions_stage1 = self._ik_solve_stage1(robot_frames)
        #   第2阶段：手臂（基于第1阶段结果）
        joint_positions_stage2 = self._ik_solve_stage2(robot_frames, joint_positions_stage1)
        
        # 阶段4：速度限制后处理（安全子代理）
        final_motion = self._apply_velocity_limits(joint_positions_stage2)
        
        return final_motion
```

---

## 3. GMR 核心技术原理

### 3.1 非均匀局部缩放（Non-uniform Local Scaling）

GMR 最核心的创新是对人体运动数据进行**局部、非均匀的缩放**，使缩放后的人体骨架与目标机器人的骨骼尺寸匹配。

#### 问题背景

人体与机器人在各个身体部分的长度比例完全不同。例如，某人的上肢可能比机器人的上肢长，但下肢却比机器人短。如果采用全局统一缩放因子，必然导致某个部位匹配不上。

#### 解决方案

GMR 将身体划分为多个局部区域，每个区域独立计算缩放因子：

```text
身体局部区域划分：
┌─────────────────────────────────────────────────┐
│  区域1: 躯干（Torso）                            │
│    包含: pelvis, spine, chest                    │
│    缩放策略: 根据实际身高与机器人躯干高度比例       │
├─────────────────────────────────────────────────┤
│  区域2: 左腿（Left Leg）                         │
│    包含: left_hip, left_knee, left_ankle        │
│    缩放策略: 根据大腿长度比例 + 小腿长度比例       │
├─────────────────────────────────────────────────┤
│  区域3: 右腿（Right Leg）                        │
│    包含: right_hip, right_knee, right_ankle     │
├─────────────────────────────────────────────────┤
│  区域4: 左臂（Left Arm）                         │
│    包含: left_shoulder, left_elbow, left_wrist  │
├─────────────────────────────────────────────────┤
│  区域5: 右臂（Right Arm）                        │
└─────────────────────────────────────────────────┘
```

数学上，对于每个局部区域 $i$，缩放因子 $s_i$ 的计算方式为：

$$s_i = \frac{L_i^{\text{robot}}}{L_i^{\text{human}}}$$

其中 $L_i^{\text{robot}}$ 是机器人对应区域在参考姿态下的长度，$L_i^{\text{human}}$ 是人体对应区域在当前帧的长度。

缩放后的关节位置为：

$$\mathbf{p}_{j,\text{scaled}} = \mathbf{c}_i + s_i \cdot (\mathbf{p}_{j,\text{orig}} - \mathbf{c}_i)$$

其中 $\mathbf{c}_i$ 是区域 $i$ 的局部坐标系原点（通常是该区域根关节的 3D 位置）。

#### 消除足部滑动的数学原理

GMR 的非均匀局部缩放之所以能从根本上消除足部滑动，有其严谨的数学保证。

设人类源骨架的实际身高为 $h$，系统配置的参考人类身高为 $h_{ref}$，全局身高比例系数为：

$$\gamma = \frac{h}{h_{ref}}$$

对于每个关键身体部位 $b$，定义局部缩放因子 $s_b$。设 $t$ 时刻人类源关节位置为 $p_{source}^j(t)$，根节点位置为 $p_{source}^{root}(t)$，则该关节相对于根节点的局部相对位移为：

$$\Delta p_{source}^j(t) = p_{source}^j(t) - p_{source}^{root}(t)$$

映射到机器人上的目标笛卡尔位置为：

$$p_{target}^b(t) = \gamma \cdot s_b \left( p_{source}^j(t) - p_{source}^{root}(t) \right) + \gamma \cdot s_{root} \cdot p_{source}^{root}(t)$$

将脚部（$b = foot$）的世界坐标展开并重新整理：

$$p_{target}^{foot}(t) = \gamma \cdot s_{foot} \cdot p_{source}^{foot}(t) + \gamma (s_{root} - s_{foot}) \cdot p_{source}^{root}(t)$$

观察该公式可以发现：**只有当根节点的缩放因子与脚部的缩放因子完全一致时（即 $s_{root} = s_{foot}$），右边含有时变变量 $p_{source}^{root}(t)$ 的那一项系数才为零。**

当 $s_{root} = s_{foot}$ 时，公式退化为：

$$p_{target}^{foot}(t) = \gamma \cdot s_{foot} \cdot p_{source}^{foot}(t)$$

在走路动作的支撑期，人类脚部在世界坐标系中的位置 $p_{source}^{foot}(t)$ 是常数，因此映射后的 $p_{target}^{foot}(t)$ 也必然是常数。**这就从数学上保证了：只要人类的脚不滑动，重定向到机器人上的脚也绝对不会发生滑动。**

### 3.2 两阶段 IK 优化（Two-stage IK Optimization）

由于人体与机器人在关节自由度拓扑上存在本质差异（人体髋关节/肩关节为 3-DOF 球关节，机器人通常由 1-DOF 旋转关节组合实现），直接求解全身体 IK 会面临高维非凸优化问题，容易陷入局部最优。

GMR 将 IK 求解拆分为两个阶段：

#### 第1阶段：躯干 + 腿部 IK

```text
目标: 匹配 pelvis（骨盆）、feet（双脚）的位置和朝向
关键 body: pelvis, left_foot, right_foot
权重配置: 位置权重高（~100），朝向权重低（~10）
```

在第1阶段，求解器固定核心躯干和下肢的关节角度，使得机器人的根部位姿、双脚落地位置与缩放后的人体运动尽可能一致。这一阶段的输出为后续手臂 IK 提供了一个稳定的基础参考系。

#### 第2阶段：手臂 IK

```text
目标: 匹配 hands（双手）的位置和朝向
关键 body: left_hand, right_hand
前提: 躯干和腿部的关节角度已在第1阶段确定
权重配置: 位置权重中等（~50），朝向权重高（~20）
```

在第2阶段，求解器在**保持第1阶段结果不变**的前提下，优化双臂的关节角度，使双手末端的位置和朝向与缩放后的人体运动匹配。

#### 两阶段 IK 的数学表述

GMR 采用双阶段优化策略来克服传统单阶段 IK 容易陷入局部极小值的问题。

**第一阶段：骨架姿态粗对齐**

核心目标是建立机器人整体骨架的朝向，并确保手脚末端（End-effectors）到达正确位置。此阶段不强制限制中间肢体（手肘、膝盖）的绝对空间位置：

$$\min_{q} \sum_{(i,j) \in \mathcal{M}} (w_1)_R^{i,j} \left\| R_h^i \ominus R_j(q) \right\|_2^2 + \sum_{(i,j) \in \mathcal{M}_{ee}} (w_1)_p^{i,j} \left\| p_{target}^i - p_j(q) \right\|_2^2$$

$$\text{subject to} \quad q^- \leq q \leq q^+$$

其中：
- $q$ 为优化变量，包含六自由度基座位姿与所有主动关节角度
- $\mathcal{M}_{ee}$ 仅包含手脚四个末端执行器
- $\ominus$ 算子定义旋转群 $SO(3)$ 上的测地线距离：$R_1 \ominus R_2 := \log(R_1^{-1} R_2)$
- 关节限位约束 $q^- \leq q \leq q^+$ 保证运动学可行性

关于初始化技巧：GMR 将机器人根节点位置初始化为 $p_{target}^{root}$，且仅将人类根节点的偏航角（Yaw）赋给机器人基座旋转，忽略俯仰角（Pitch）和横滚角（Roll）。这是因为人类骨盆的晃动非常剧烈，直接复制会导致机器人躯干倾斜，难以站立。

**第二阶段：全身多约束精调**

第二阶段以第一阶段的最优解 $q^*_{\text{stage1}}$ 为初始猜测，引入所有匹配身体部位的位置约束进行精细化微调：

$$\min_{q} \sum_{(i,j) \in \mathcal{M}} (w_2)_R^{i,j} \left\| R_h^i \ominus R_j(q) \right\|_2^2 + \sum_{(i,j) \in \mathcal{M}} (w_2)_p^{i,j} \left\| p_{target}^i - p_j(q) \right\|_2^2$$

$$\text{subject to} \quad q^- \leq q \leq q^+$$

关键区别在于：位置误差的求和项从 $\mathcal{M}_{ee}$（仅末端）扩大到了 $\mathcal{M}$（所有关键身体部位），且权重系数更新为精调权重。由于初始猜测已接近全局最优，第二阶段优化器可平滑微调关节角度而不会发生关节跳变。

#### IK 求解器参数

| 参数 | 值 | 说明 |
| :--- | :--- | :--- |
| 求解器类型 | DAQP | Default Affine QP Solver |
| 阻尼系数 | 5e-1 | Levenberg-Marquardt 阻尼，提高数值稳定性 |
| 最大迭代次数 | 10 | 每帧最大优化步数 |
| 关节速度限制 | 3π rad/s（默认） | 可通过 `use_velocity_limit=True` 启用 |

### 3.3 微分逆运动学求解器

GMR 将逆运动学求解转化为**微分逆运动学（Differential IK）**，并利用高效的二次规划（Quadratic Programming, QP）求解器在每个控制周期进行迭代。其底层求解器建立在 Mink（基于 MuJoCo）机器人运动学库之上。

设机器人的前向运动学方程 $\mathbf{x} = \mathbf{f}(q)$，对其求时间导数可得关节速度与任务空间速度的线性关系：

$$\dot{\mathbf{x}} = J(q)\dot{q}$$

其中 $J(q) = \frac{\partial \mathbf{f}(q)}{\partial q}$ 为任务空间雅可比矩阵。

在离散时间步 $\Delta t$ 下，根据比例控制思想，期望的任务空间速度为：

$$\mathbf{v}^* = K_p \left( \mathbf{x}_{target} - \mathbf{x}(q_{t-1}) \right)$$

其中 $K_p$ 为反馈增益。目标是使得 $J(q)\Delta q \approx \mathbf{v}^* \Delta t$。

将上述跟踪任务构建为带约束的二次规划问题：

$$\min_{\Delta q} \frac{1}{2} \Delta q^T W_q \Delta q + \frac{1}{2} \left\| J(q)\Delta q - \mathbf{v}^* \Delta t \right\|_W^2$$

$$\text{subject to} \quad q^- - q_{t-1} \leq \Delta q \leq q^+ - q_{t-1}$$

$$\dot{q}^- \Delta t \leq \Delta q \leq \dot{q}^+ \Delta t$$

其中：
- $W_q$ 为正则化权重矩阵，对关节速度进行惩罚，防止冗余自由度下的剧烈晃动
- $W$ 为任务空间误差权重矩阵
- $\dot{q}^-$ 和 $\dot{q}^+$ 为关节速度物理极限

展开目标函数并合并同类项，可得标准 QP 形式 $\min_{\Delta q} \frac{1}{2} \Delta q^T H \Delta q + \mathbf{g}^T \Delta q$，其中 $H = W_q + J(q)^T W J(q)$，$\mathbf{g} = - \Delta t \cdot J(q)^T W \mathbf{v}^*$。

GMR 底层采用 DAQP 求解器，在普通 CPU 上仅需 2–4 次迭代即可收敛，计算频率高达 60–70 FPS，完全满足实时遥操作的需求。

### 3.4 后处理与高度修正

尽管经过非均匀缩放和带约束 IK 能够生成高质量的关节运动，但由于人体动捕数据的噪声，机器人整体仍可能出现轻微的"漂浮"或"轻微穿模"现象。GMR 在最后加入了一个轻量化的时序后处理步骤：

1. **计算最低点**：遍历每个时间步 $t$，计算机器人所有刚体中距离地面最近的顶点的 Z 轴坐标：

   $$z_{min}(t) = \min_{b \in \mathcal{B}_{robot}} \text{Vertex}_z(b, t)$$

2. **全局对齐地面**：找到整段轨迹中最低的那一帧，计算与真实地面的偏差：

   $$\Delta z = \min_{t} z_{min}(t) - z_{ground}$$

   将整个运动序列中机器人的根节点 Z 轴平移统一减去该偏差：

   $$p_{robot}^{root, z}(t) \leftarrow p_{robot}^{root, z}(t) - \Delta z$$

通过这一简单的时序平移，机器人的脚部最低点将完美地与地面共面，既消除了"穿模"，也避免了"悬空漫步"。

### 3.5 IK 配置（IK Config）

GMR 使用 JSON 配置文件定义每个 body 的跟踪目标和权重，参见 [DOC.md](file:///home/meme/Documents/gmr/DOC.md)：

```json
{
    "ik_match_table1": {
        "pelvis": [
            "pelvis",       // 对应的人体部位名称
            100,            // 位置跟踪权重 (xyz)
            10,             // 旋转跟踪权重
            [0.0, 0.0, 0.0], // 位置偏移量 (x, y, z)
            [0.5, -0.5, -0.5, -0.5]  // 旋转偏移量 (wxyz 四元数)
        ],
        "left_foot": [ ... ],
        "right_foot": [ ... ]
    },
    "ik_match_table2": {
        "left_hand": [ ... ],
        "right_hand": [ ... ]
    }
}
```

不同身体部位的权重配置策略：
- **骨盆（pelvis）**：位置权重 100，旋转权重 10 — 刚性跟踪，确保整体位姿一致
- **脚部（feet）**：位置权重 100，旋转权重 30 — 严格跟踪，避免足部滑动和地面穿透
- **手部（hands）**：位置权重 50，旋转权重 20 — 适度跟踪，允许轻微偏差以换取手臂运动的平滑性

### 3.6 重定向质量对下游强化学习的影响

GMR 论文的核心论点之一是：重定向质量会直接决定下游强化学习（RL）算法的成败。

**低质量重定向如何拖累 RL 策略**：若使用带有足部滑动、自穿模等伪影的轨迹进行模仿学习，RL 策略会陷入两难——强行模仿物理不可行的动作会导致机器人频繁失去平衡；而放弃模仿则迫使工程师进行大量的奖励函数调优。这导致了所谓的**过度奖励工程（Excessive Reward Engineering）**问题。

**GMR 的实证优势**：在论文对比实验中，使用相同 RL 框架 BeyondMimic，GMR 生成的干净轨迹使人形机器人能够轻松学会武术、舞蹈、单脚跳等高难度动态动作，而传统方法（如 PHC）处理的数据在复杂动作上易导致策略失败。这充分证明了**在源头解决数据问题**的重要意义。

---

## 4. 多格式人体数据支持的子代理架构

GMR 支持多种人体运动数据格式，每种格式通过独立的"数据加载子代理"进行解析，统一转换为内部标准格式后再进行重定向。这种架构设计体现了**并发子代理**的思想：

```text
┌──────────────────────────────────────────────────────────┐
│                统一内部表示（标准格式）                       │
│  {body_name: (3D_position, quaternion_rotation)} per frame│
└──────────┬──────────┬──────────┬──────────┬───────────────┘
           │          │          │          │
┌──────────▼──┐ ┌─────▼─────┐ ┌─▼────────┐ ┌▼──────────────┐
│ SMPLX Loader│ │BVH Loader │ │FBX Loader│ │PICO Loader    │
│ (smplx)     │ │(lafan1)   │ │(OptiTrack)│ │(XRoboToolkit) │
└─────────────┘ └───────────┘ └──────────┘ └───────────────┘
```

当前支持的数据格式和对应脚本：

| 数据来源 | 入口脚本 | 加载器子代理 |
| :--- | :--- | :--- |
| SMPLX（AMASS/OMOMO） | `scripts/smplx_to_robot.py` | `smplx_data_loader` |
| BVH（LAFAN1） | `scripts/bvh_to_robot.py` | `bvh_data_loader` |
| FBX（OptiTrack） | `scripts/fbx_offline_to_robot.py` | `fbx_data_loader` |
| GVHMR（单目视频） | `scripts/gvhmr_to_robot.py` | `gvhmr_data_loader` |
| Xsens BVH | `scripts/xsens_bvh_to_robot.py` | `xsens_data_loader` |
| PICO VR （TWIST2） | `scripts/xsens_live_streaming.py` | `pico_streaming_agent` |

### 4.1 GVHMR → GMR → BeyondMimic 多代理流水线

在实际应用中，GMR 通常与 GVHMR（人体姿态提取）和 BeyondMimic（RL 策略训练）配合使用，形成完整的"视频 → 运动 → 控制"代理链：

```text
RGB 视频
   │
   ▼
GVHMR（人体姿态提取代理） ← 详见《GVHMR 世界坐标系人体运动恢复系统原理与操作流程》
   │ 输出 SMPLX 格式 .pt 文件
   ▼
GMR（运动重定向代理）
   │ 运行 gvhmr_to_robot.py → 非均匀缩放 + 两阶段 IK
   │ 输出 .pkl 机器人运动文件
   ▼
   │ 运行 batch_gmr_pkl_to_csv.py
   ▼
BeyondMimic（RL 策略训练代理）
   │ 运行 csv_to_npz.py → train.py → PPO 策略训练 (rsl_rl)
   ▼
机器人部署
```

> GVHMR 的详细原理与操作流程请参见同目录下的 [《GVHMR 世界坐标系人体运动恢复系统原理与操作流程》](file:///home/meme/Documents/笔记/03%20GMR/GVHMR%20世界坐标系人体运动恢复系统原理与操作流程.md)。

---

## 5. 操作流程：从安装到使用

### 5.1 环境安装

```bash
# 1. 创建 conda 环境
conda create -n gmr python=3.10 -y
conda activate gmr

# 2. 安装 GMR 包
cd ~/Documents/gmr
pip install -e .

# 3. 下载 SMPL-X 人体模型
# 从 https://smpl-x.is.tue.mpg.de/ 下载后放置到 assets/body_models/ 目录
# 目录结构:
#   assets/body_models/smplx/
#   ├── SMPLX_NEUTRAL.pkl
#   ├── SMPLX_FEMALE.pkl
#   └── SMPLX_MALE.pkl

# 4. 注意：修改 smplx/body_models.py 中的 ext 从 npz 为 pkl
```

### 5.2 运行重定向

#### 从 SMPLX（AMASS）重定向到机器人

```bash
# 单条运动
python scripts/smplx_to_robot.py \
    --smplx_file <path_to_smplx_data> \
    --robot unitree_g1 \
    --save_path motions/G1/G1.pkl \
    --rate_limit

# 批量数据集
python scripts/smplx_to_robot_dataset.py \
    --data_root <path_to_amass_data> \
    --robot unitree_g1 \
    --save_root motions/G1_dataset/
```

#### 从 GVHMR（单目视频）重定向

> GVHMR 的安装配置与详细用法请参见 [《GVHMR 世界坐标系人体运动恢复系统原理与操作流程》](file:///home/meme/Documents/笔记/03%20GMR/GVHMR%20世界坐标系人体运动恢复系统原理与操作流程.md)。

```bash
# Step 1: GVHMR 提取人体姿态（详见 GVHMR 文档）
cd ~/Documents/GVHMR
python tools/demo/demo.py --video=path/to/video.mp4 -s

# Step 2: GMR 重定向到机器人
cd ~/Documents/gmr
python scripts/gvhmr_to_robot.py \
    --gvhmr_pred_file <path_to_gvhmr_output.pt> \
    --robot unitree_g1 \
    --record_video \
    --save_path motions/G1/G1.pkl

# Step 3: 转换为 CSV（供 BeyondMimic 使用）
python3 scripts/batch_gmr_pkl_to_csv.py --folder motions/G1/
```

#### 从 LAFAN1（BVH）重定向

```bash
python scripts/bvh_to_robot.py \
    --bvh_file <path_to_lafan1_bvh> \
    --robot unitree_g1 \
    --rate_limit
```

### 5.3 可视化

```bash
# 可视化单条机器人运动
python scripts/vis_robot_motion.py \
    --motion_file motions/G1/G1.pkl

# 可视化 URDF 模型
python scripts/vis_robot_urdf.py \
    --robot unitree_g1
```

---

## 6. 支持的人形机器人平台

GMR 目前支持 17+ 种人形机器人（数据截止 2026-01）：

| ID | 机器人 | DoF | 状态 |
| :--- | :--- | :--- | :--- |
| 0 | Unitree G1 | 29 | ✅ 完整支持 |
| 1 | Unitree G1 with Hands | 43 | ✅ |
| 2 | Unitree H1 | 19 | ✅ |
| 3 | Unitree H1-2 | 27 | ✅ |
| 4-5 | Booster T1 (23/29dof) | 23/29 | ✅ |
| 6 | Booster K1 | 22 | ✅ |
| 7 | Stanford ToddlerBot | - | ✅ |
| 8 | Fourier N1 | - | ✅ |
| 9 | ENGINEAI PM01 | - | ✅ |
| 10 | HighTorque Hi | 25 | ✅ |
| 11 | Galaxea R1 Pro | 24 | ✅（轮式） |
| 12 | Kuavo S45 | 28 | ✅ |
| 15 | Tienkung | 20 | ✅ |
| 16 | PAL Robotics Talos | 30 | ✅ |
| 17 | Fourier GR3 | 31 | ✅ |

切换机器人只需更改 `--robot` 参数即可，其余流程完全相同。这体现了 GMR 的**通用性设计**——IK 配置（关节映射表、偏移量、权重）由各机器人的 JSON 配置文件管理，核心算法与具体机器人型号解耦。

---

## 7. 仓库代码结构

```text
~/Documents/gmr/
├── general_motion_retargeting/     # GMR 核心 Python 包（主控 + 子代理模块）
│   ├── __init__.py                 # 包初始化，导出 GeneralMotionRetargeting 等
│   ├── motion_retarget.py          # ★ 核心主控类，编排重定向流水线
│   ├── kinematics_model.py         # 运动学模型子代理（FK/IK/雅可比）
│   ├── params.py                   # 参数管理子代理
│   ├── data_loader.py              # 数据加载统一接口子代理
│   ├── neck_retarget.py            # 颈部重定向子代理
│   ├── robot_motion_viewer.py      # 可视化子代理（MuJoCo 交互窗口）
│   ├── rot_utils.py                # 旋转工具函数（四元数/轴角转换）
│   ├── torch_utils.py              # PyTorch 工具函数
│   ├── xrobot_utils.py             # PICO VR/XRoboToolkit 工具函数
│   ├── ik_configs/                 # ★ 各机器人的 IK 配置（JSON）
│   │   ├── smplx_to_g1.json
│   │   ├── smplx_to_h1.json
│   │   └── ...                     # 17+ 种机器人的配置文件
│   ├── utils/                      # 其他工具模块
│   └── optitrack_vendor/           # OptiTrack 第三方库
│
├── scripts/                        # ★ 入口脚本（各数据格式的转换入口）
│   ├── smplx_to_robot.py           # SMPLX → 机器人
│   ├── bvh_to_robot.py             # BVH → 机器人
│   ├── gvhmr_to_robot.py           # GVHMR → 机器人
│   ├── fb_offline_to_robot.py      # FBX(OptiTrack) → 机器人
│   ├── xsens_bvh_to_robot.py       # Xsens BVH → 机器人
│   ├── optitrack_to_robot.py       # OptiTrack → 机器人
│   ├── batch_gmr_pkl_to_csv.py     # 批量 pkl → CSV
│   ├── vis_robot_motion.py         # 可视化机器人运动
│   └── ...
│
├── assets/                         # 资源文件（模型、纹理、视频等）
│   └── body_models/                # SMPL-X 人体模型
│       └── smplx/
│
├── third_party/                    # 第三方依赖
├── setup.py                        # Python 包安装脚本
├── README.md                       # 官方文档
├── DOC.md                          # IK 配置说明
├── CLAUDE.md                       # Claude AI 辅助开发提示
└── TEST_MOTIONS.md                 # 测试动作列表
```

---

## 8. 常见问题与排查

### 8.1 重定向结果出现足部滑步

**原因**：IK 配置中足部的旋转跟踪权重不足，或缩放参数不准确。
**解决方案**：增大 `ik_match_table1` 中 `left_foot` 和 `right_foot` 的旋转权重（如从 10 调整为 30）。

### 8.2 手臂重定向后出现自穿透

**原因**：手臂 IK 的解空间过大，或初始过渡姿态不合理。
**解决方案**：在 `init_pos` 中为肩滚转关节添加外展偏置（如 `±0.3 rad`），拉开手臂与躯干的距离。

### 8.3 重定向帧率低（< 30 FPS）

**原因**：单帧 IK 求解迭代次数过多，或启用了过于严格的速度限制。
**解决方案**：减小 `max_iterations`（默认 10 可降至 5），或关闭 `use_velocity_limit`。

### 8.4 SMPLX 加载报错

**原因**：`smplx` 库的 `body_models.py` 中 `ext` 参数为 `npz` 但实际文件是 `pkl`。
**解决方案**：修改 `smplx/body_models.py`，将 `ext` 从 `npz` 改为 `pkl`。
