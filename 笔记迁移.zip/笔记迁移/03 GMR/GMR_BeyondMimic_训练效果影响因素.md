# 全链路架构大纲：从 GMR 重定向到 BeyondMimic 扩散控制与 Sim-to-Real 部署的 32 个核心瓶颈

在人形机器人运动控制的全链路上，构建一个能够自适应各种复杂任务、鲁棒迁移到物理真机的高性能控制系统，必须攻克从数据源、离线优化、强化学习跟踪策略、生成式扩散策略到真实硬件物理部署等多个维度的技术难题。

以下是贯穿 **GMR（通用运动重定向）$\to$ BeyondMimic 跟踪与扩散 $\to$ Sim-to-Real 部署** 完整链路的 32 个核心技术瓶颈及其系统级解决方案大纲。本报告将围绕该大纲展开深度剖析。

---

## GMR 上游数据与重定向阶段的几何与运动学瓶颈

*   **非均匀缩放中的拓扑比例失调与关节越界（Morphological Mismatch & Joint Limit Violation）**
*   **单帧微分逆运动学（IK）求解在奇异点处的数值振荡（Kinematic Singularity & Sudden Joint Jumps）**
*   **接触盲区导致的支撑相脚部滑动（Foot Skating due to Lacking Contact Physics）**
*   **忽略地形特征引起的地面穿模与空中漂浮（Ground Penetration & Floating on Unflat Terrains）**
*   **极端动态动作中的肢体自碰撞与穿插（Self-Collision & Self-Penetration）**
*   **几何与动力学解耦导致的轨迹不物理平衡（Dynamic Infeasibility & CoM Deviation）**
*   **动捕源数据与机器人模型的局部坐标系轴向对齐偏差（Local Coordinate Axis Alignment Mismatch）**
*   **交互任务中末端执行器空间约束丢失（Spatial Constraint Loss in Loco-Manipulation）**

---

## BeyondMimic 第一阶段：强化学习动作跟踪策略训练瓶颈

*   **均匀时间采样在困难动作区间引发的“探索饥饿”（Uniform Sampling Starvation on High-Difficulty Motions）**
*   **模仿跟踪奖励与物理平衡惩罚之间的梯度冲突（Tracking Reward vs. Balancing Regularization Gradient Conflict）**
*   **高频指令输出（PD Target Position）引发的电机震颤与能源虚耗（High-Frequency Joint Jitter & Power Waste）**
*   **确定性参考轨迹对仿真环境动力学分布的过拟合（Overfitting to Deterministic Reference Trajectories）**
*   **观察空间中本体感觉状态反馈的时延响应不匹配（Proprioceptive Feedback Time Lag Mismatch）**
*   **长序列、非周期性动作下价值函数估计的方差爆炸（Value Function Divergence in Long-Horizon Motions）**
*   **困难动作微调中的通用运动技能灾难性遗忘（Catastrophic Forgetting of Base Locomotion Skills）**
*   **抵抗外部物理冲撞时刚性跟踪引发的失稳（Instability from Rigid Tracking under Physical Disturbances）**

---

## BeyondMimic 第二阶段：状态-动作协同扩散与测试时引导瓶颈

*   **多步去噪循环（Denoising Loops）的极高推理时延与控制实时性瓶颈（High Inference Latency & Real-Time Control Bottleneck）**
*   **隐含状态-动作空间（Latent Space）对细微运动特征的物理保真度丢失（Latent VAE Information Loss）**
*   **测试时引导（Test-Time Guidance）计算出的梯度超出分布边界（Classifier Guidance OOD Cost Gradient Collapse）**
*   **引导代价函数（Guidance Cost Function）在障碍物避障中的局部极小值锁死（SDF Local Minima Entrapment）**
*   **协同扩散（Co-Diffusion）过程中状态预测与物理引擎动力学退耦（State-Action De-alignment / Planning-Control Gap）**
*   **极长轨迹生成中的去噪漂移累积与关节崩溃（Compounding Denoising Drift in Long-Horizon Generation）**
*   **技能拼接（Motion Inpainting）边界处的速度跳变与物理不连续（Inpainting Boundary Discontinuities）**
*   **面对多模态任务目标时的生成模式坍塌（Mode Collapse under Multi-Modal Downstream Commands）**

---

## 最后一公里：Sim-to-Real 迁移与物理硬件部署瓶颈

*   **真实电机的非线性特性（静摩擦、粘性阻尼、死区、背隙）未建模（Unmodeled Actuator Dynamics & Joint Deadband）**
*   **接触力学模型的简化失真（MuJoCo/Isaac 弹簧模型 vs. 真实柔性地面与硬底脚掌）（Contact Mechanics Simplification Gap）**
*   **状态估计器（VIO/IMU）的漂移与累计误差导致策略失真（State Estimator Drift & Proprioceptive Noise）**
*   **领域随机化（Domain Randomization）过度泛化导致控制策略过于保守（Conservative Policy from Over-Randomization）**
*   **真实机器人重心（CoM）偏置及质量矩阵偏差（Mass Matrix & Inertia Tensor Misidentification）**
*   **嵌入式算力平台的功耗墙、热节流与线程时序抖动（Thermal Throttling & Thread Jitter on Edge Computing Platforms）**
*   **高动态运动下的结构柔性与连杆形变误差（Structural Compliance & Link Elasticity）**
*   **电源电压跌落与峰值电流饱和下的扭矩输出受限（Voltage Sag & Torque Saturation under Peak Discharge）**

---

# 全链路实战深度剖析：32 个核心问题的物理、数学诊断与全栈解决方案

---

## GMR 上游数据与重定向阶段的几何与运动学瓶颈

### 非均匀缩放中的拓扑比例失调与关节越界

*   **物理与数学机理诊断：**  
    GMR 在处理源人体骨骼向人形机器人躯干和四肢映射时，通常在关键刚体匹配阶段使用分区域的局部缩放因子 $s_b$：
    $$p_{target}^b = \frac{h}{h_{ref}} s_b (p_{source}^j - p_{source}^{root}) + \frac{h}{h_{ref}} s_{root} p_{source}^{root}$$
    然而，人类的关节极限（ROM, Range of Motion）与其骨骼长度之间呈现高度非线性的拓扑关联。直接对连杆进行基于相对比例的局部缩放，无法将关节极限的几何边界（由机器人关节硬限位 $q^{-} \leq q \leq q^{+}$ 决定）等比映射。当源动作包含人类极端的弯曲、伸展（如深蹲、大跨步）时，缩放后的目标笛卡尔坐标 $p_{target}^b$ 极易落在机器人的物理工作空间之外，迫使第一阶段微分逆运动学（IK）求解器向关节边界逼近。当优化计算被关节硬限位阻断，求解器的雅可比矩阵（Jacobian）发生秩亏（Rank Deficiency），将导致机器人关节"卡死"在硬限位边界，动作变形。

*   **实际案例：G1 与 H1 的非均匀缩放策略对比**  

    GMR 的 `scale_human_data()` 实现中，缩放仅影响位置，旋转数据（四元数）保持不变——旋转的精确匹配由后续两阶段 IK 求解器处理。以 Unitree G1（29 DoF）和 H1（19 DoF）的实际配置为例：

    | 身体部位 | G1 缩放比例 | H1 缩放比例 | 差异分析 |
    |:---------|:-----------:|:-----------:|:---------|
    | pelvis（骨盆） | 0.9 | 1.1 | G1 比 H1 小，需要更多缩小 |
    | spine3（躯干） | 0.9 | 1.1 | 同上 |
    | left_hip（左髋） | 0.9 | 1.1 | 同上 |
    | left_knee（左膝） | 0.9 | 1.1 | 同上 |
    | left_foot（左脚） | 0.9 | 1.1 | 同上 |
    | left_shoulder（左肩） | 0.8 | 1.1 | 手臂缩放更明显 |
    | left_elbow（左肘） | 0.8 | 1.1 | 同上 |
    | left_wrist（左手腕） | 0.8 | 不适用 | H1 无手腕自由度 |

    G1 的手臂缩放比例（0.8）比腿部（0.9）更小，体现了非均匀缩放的实际效用——如果不对手臂进行额外缩小，重定向后的手臂运动可能超出 G1 的运动范围。

*   **对下游训练/部署的级联影响：**  
    下游的强化学习（RL）策略在跟踪这种包含限位妥协的轨迹时，会试图通过产生巨大的关节瞬态扭矩来强行弥合空间误差。这不仅极大降低了跟踪阶段的奖励值，还会导致关节在物理引擎中反复碰撞其物理软限位，引发电机过热并导致 Sim-to-Real 部署时电机的热保护停机。

*   **全栈解决方案：**  
    引入**形状自适应逆运动学（Shape-adaptive IK, 如 PhySINK 框架）**。在重定向初始阶段，不再使用静态的局部缩放乘数，而是构建一个包含人体 SMPL-X 形状参数 $\beta$ 和机器人关节限位约束的联合几何优化目标：
    $$\min_{\beta', q} \sum_{k \in \mathcal{M}} w_k \| p_{robot}^k(q) - p_{human}^k(\beta') \|_2^2 + \lambda \mathcal{R}(q)$$
    其中 $\mathcal{R}(q)$ 为关节限位屏障罚函数（Barrier Function，如对数屏障函数 $-\ln(q - q^{-}) - \ln(q^{+} - q)$），确保在形状匹配与坐标映射的初始阶段，优化点就主动退避关节极限，留出 $5^{\circ}$ 到 $10^{\circ}$ 的安全冗余空间。

---

### 单帧微分逆运动学（IK）求解在奇异点处的数值振荡

*   **物理与数学机理诊断：**  
    GMR 采用基于一阶微分的 IK 求解器（如 Mink 求解器），其核心更新公式依赖于雅可比矩阵的伪逆（Moore-Penrose Pseudoinverse）：
    $$\Delta q = J^{\dagger} \Delta x = J^T (J J^T)^{-1} \Delta x$$
    在机器人手臂或腿部完全伸直、或多关节轴线共线的奇异位姿（Singular Configurations）下，雅可比矩阵的最小奇异值 $\sigma_{min}$ 趋近于零，导致 $\lim_{\sigma_{min} \to 0} J^{\dagger}$ 趋向无穷大。单帧独立求解（Frame-by-frame Optimization）缺乏时延平滑机制，当动捕轨迹微弱抖动时，数值求逆会将此噪声放大数百倍，导致相邻帧之间计算出的关节角速度 $\dot{q}$ 瞬时突破物理电机的极限值（如 $> 30\text{ rad/s}$），呈现尖锐的脉冲突变。

*   **对下游训练/部署的级联影响：**  
    这些数值突变在强化学习中表现为非连续性的状态跃迁。RL 的策略梯度算法（如 PPO）很难拟合具有无限高阶导数的运动轨迹，导致价值网络估计失真，跟踪策略无法收敛。若强行部署，物理电机将产生剧烈共振，造成减速器齿轮打齿。

*   **全栈解决方案：**  
    1. 在微分 IK 求解器中引入**阻尼最小二乘法（Damped Least Squares, Levenberg-Marquardt 形式）**，将求逆公式修正为：
       $$\Delta q = J^T (J J^T + \lambda^2 I)^{-1} \Delta x$$
       其中阻尼因子 $\lambda$ 会根据雅可比矩阵的条件数（Condition Number）动态自适应调节。
    2. 使用**双向滑窗优化（Sliding Window Spatiotemporal Optimization）**。在重定向后处理阶段，对相邻 5 帧的关节轨迹进行二次 B 样条插值（B-Spline Interpolation）或 Savitzky-Golay 滤波，强制约束关节角加速度 $\ddot{q}$ 的上限。

*   **深入分析：GMR 两阶段 IK 的设计逻辑与权重配置**  

    GMR 采用两阶段 IK 而非直接全身求解，源于三个核心问题：  
    - **高维非凸性**：人形机器人通常有 20-40 个自由度，直接在全关节空间优化容易陷入局部最优  
    - **任务优先级冲突**：同时匹配骨盆、双脚、双手的位置/朝向会导致任务空间内的竞争  
    - **数值稳定性**：高维雅可比矩阵的条件数较差，导致求解不稳定  

    两阶段将问题分解为：**阶段 1（躯干+腿部）** 固定核心稳定性和支撑面匹配；**阶段 2（手臂）** 在稳定的基础参考系上优化上肢运动。不同身体部位的 IK 权重配置如下：

    | 身体部位 | 阶段 | 位置权重 | 旋转权重 | 策略含义 |
    |:---------|:----:|:--------:|:--------:|:---------|
    | pelvis（骨盆） | 1 | 100 | 10 | 刚性跟踪整体位姿 |
    | left/right_foot（脚） | 1 | 100 | 10-30 | 严格避免足部滑动 |
    | torso_link（躯干） | 1 | 0 | 10 | 仅匹配朝向 |
    | left/right_shoulder（肩） | 1 | 0 | 10 | 仅匹配朝向，位置留给阶段2 |
    | left/right_hand（手） | 2 | 50 | 20 | 适度跟踪，允许轻微偏差 |

    在 ik_match_table1 中肩部和肘部的位置权重被设为 0——阶段 1 不关心手臂末端的位置，只匹配朝向。手臂末端位置的精确匹配被推迟到阶段 2 处理。两阶段拆分配合差异化权重，使得 IK 求解器在高维关节空间中仍能稳定收敛。

---

### 接触盲区导致的支撑相脚部滑动

*   **物理与数学机理诊断：**  
    在双足支撑期内，人类脚掌与地面理论上存在非滑移的完全物理接触（无相对运动 $\dot{p}_{foot} = 0$）。然而，由于重定向模型不包含重力和摩擦锥物理约束，仅通过几何末端位置逼近。当人体质心高度投影发生微调时，IK 求解器为了满足根节点（Root）的高度路径，会对脚部末端产生一个毫米级的切向微扰 $\Delta p_{xy}$。这个在几何求解中看似可以忽略的微扰，在物理动力学中意味着静摩擦力无法建立，脚掌呈现为在冰面上持续滑行（Foot Skating）。

*   **对下游训练/部署的级联影响：**  
    在强化学习物理仿真器（如 Isaac Gym）中，脚掌打滑会导致机器人质心产生持续的漂移，控制器无法通过地面的法向反作用力维持侧向平衡，直接导致 RL 智能体频繁滑倒，阻碍策略探索。

*   **全栈解决方案：**  
    在 GMR 阶段显式增加**零速接触约束（Zero-velocity Contact Constraint）**：
    首先利用足底力传感器阈值或视觉接触检测网络（如 TRAM）识别源轨迹中的足部支撑期（Stance Phase）。在属于支撑期的帧区间 $[t_s, t_e]$ 内，将对应足部末端刚体的笛卡尔坐标强行锁定为常量：
    $$p_{foot}(t) = p_{foot}(t_s), \quad \forall t \in [t_s, t_e]$$
    并通过在微分 IK 中将足部的位置雅可比矩阵 $J_{foot}$ 作为等式硬约束（Equality Constraint）来进行二次规划（QP）求解：
    $$\begin{aligned} \min_{\Delta q} \quad & \frac{1}{2} \|\Delta q\|_2^2 \\ \text{s.t.} \quad & J_{foot} \Delta q = 0 \\ & q^{-} \leq q + \Delta q \leq q^{+} \end{aligned}$$

*   **实际调参与工程检查清单**  
    - **IK 权重调整**：在 `ik_match_table1` 中将 `left_foot` 和 `right_foot` 的旋转权重从 10 提高到 30，增强足部朝向的跟踪刚性  
    - **地面高度参数**：检查 `ground_height` 参数是否正确，使用 `--offset_to_ground` 自动对齐地面  
    - **可视化验证**：逐帧播放重定向结果，检查足部是否与地面有毫米级穿透或离地间隙

---

### 忽略地形特征引起的地面穿模与空中漂浮

*   **物理与数学机理诊断：**  
    在非结构化地形（如楼梯、缓坡、乱石）上运动时，源动捕通常在一个平坦的刚性平面上采集，忽略了地形高程起伏。GMR 仅对根节点相对人体初始平面的高度进行线性补偿。当机器人步入起伏的地形时，其脚部刚体边界会与网格碰撞体产生几何重叠（Ground Penetration），或在应该踩实台阶时，脚部悬空（Floating）。

*   **对下游训练/部署的级联影响：**  
    穿模在物理仿真中会触发穿透深度惩罚（Penetration Penalty），导致物理引擎瞬时产生极大且非真实的接触弹簧力，直接将机器人“弹飞”发生数值崩塌（NaN）；而悬空则会导致机器人单腿无法支撑，重心失稳。

*   **全栈解决方案：**  
    1. 在重定向数据转换阶段引入**实时的射线投射高度对齐（Raycasting Terrain Alignment）**。从机器人的每个足端质心向上和向下发射虚拟射线，检测当前仿真地形的高程图 $z_{terrain}(x,y)$。
    2. 基于实际接触点高度动态修正 GMR 产生的轨迹：
       $$z_{target}^{foot} = \max(z_{retarget}^{foot}, z_{terrain}(x_{foot}, y_{foot}) + \epsilon)$$
       其中 $\epsilon$ 为防止接触力突变设立的微小安全阈值（通常为 $1\text{mm}$）。

---

### 极端动态动作中的肢体自碰撞与穿插

*   **物理与数学机理诊断：**  
    人类骨骼在表层覆盖有柔性的肌肉和皮肤，而人形机器人肢体是由刚性的铝合金或碳纤维连杆（如 Unitree G1 较大的大腿侧护板）构成。GMR 的关键刚体映射仅将人类骨骼简化为无体积的线段进行轴向逼近。当人体进行交叉步、抱胸、盘腿或高难度侧手翻动作时，机器人刚体连杆的碰撞凸包（Collision Convex Hulls）会发生大面积的重叠（Intersection）。

*   **对下游训练/部署的级联影响：**  
    在 Isaac Gym 或 MuJoCo 仿真中，自碰撞默认会触发接触阻断力（Contact Exclusion Forces）。机器人的左腿和右腿一旦穿模碰撞，两腿会相互纠缠，产生极大的摩擦阻矩，使得关节卡死或产生剧烈的方向反转，导致 RL 跟踪动作完全变形。

*   **全栈解决方案：**  
    在 GMR 阶段集成**带自碰撞避障的二次规划求解器（QP with Self-Collision Avoidance）**：
    为机器人关键刚体对（如左肘与左侧躯干，左膝与右膝）配置简化的包围球（Bounding Spheres）或圆柱体，实时计算两两刚体之间的最短距离 $d_{ij}(q)$。引入控制屏障函数（Control Barrier Function, CBF）约束：
    $$\dot{d}_{ij}(q) = \frac{\partial d_{ij}}{\partial q} \dot{q} \geq -\gamma (d_{ij}(q) - d_{min})$$
    当距离接近安全阈值 $d_{min}$ 时，迫使 $\dot{q}$ 产生远离方向的运动，从而在重定向源头上避免任何肢体穿插。

*   **实际工程解决方案**  
    当无法修改 GMR 内核时，可通过以下参数调整缓解自碰撞：  
    - **肩关节偏置**：在 `init_pos` 中调整肩关节偏置（如 `±0.3 rad`），拉开手臂与躯干距离  
    - **旋转偏移量校正**：检查肩部 `rot_offsets` 四元数是否正确，错误的旋转偏移会导致手臂朝向错误  
    - **手臂缩放比例**：在 `human_scale_table` 中收窄手臂缩放比例（如从 0.85 降至 0.75），缩短手臂连杆长度以避开躯干碰撞凸包  

---

### 几何与动力学解耦导致的轨迹不物理平衡

*   **物理与数学机理诊断：**  
    重定向是一种典型的“运动学（Kinematic）”过程，而机器人在物理世界中的运动必须遵循牛顿-欧拉动力学方程（Newton-Euler Equations）：
    $$\left[\begin{matrix} M(q) & H(q) \\ H(q)^T & I_{CoM}(q) \end{matrix}\right] \left[\begin{matrix} \dot{v} \\ \dot{\omega} \end{matrix}\right] + C(q, \dot{q}) = \left[\begin{matrix} f_{ext} \\ \tau_{ext} \end{matrix}\right]$$
    由于 GMR 忽略了质量分布、关节扭矩上限以及惯性张量，其生成的机器人质心（CoM）轨迹在快速侧身、急转弯等高动态场景下，完全偏离了支撑多边形（Support Polygon）。质心处的合外力矩无法通过摩擦力锥（Friction Cone）内的地面反作用力抵消，导致参考运动轨迹在重力场中天然是不稳定的。

*   **对下游训练/部署的级联影响：**  
    RL 跟踪策略被要求去执行一个物理上注定会摔倒的动作。智能体为了不摔倒，被迫采取极其保守的“半蹲防御步”来代偿，甚至完全放弃高动态部分的跟踪，导致训练出的动作与原人动作相去甚远（失真度极高）。

*   **全栈解决方案：**  
    采用**基于动力学优化的后处理滤波器（Dynamics-based Trajectory Optimization, 如 KDMR 算法）**。在 GMR 生成的几何轨迹后，增加一个基于单质点动力学（Centroidal Dynamics）的滑窗优化阶段：
    $$\begin{aligned} \min_{x_{CoM}, f_c} \quad & \sum_{t} \|x_{CoM}(t) - x_{retarget}^{CoM}(t)\|_2^2 \\ \text{s.t.} \quad & \dot{L}(t) = \sum_{i} (p_i(t) - x_{CoM}(t)) \times f_i(t) + m g \\ & f_i(t) \in \mathcal{FC} \quad (\text{摩擦力锥约束}) \end{aligned}$$
    这保证了优化后的质心运动轨迹在物理上可以通过真实的地面反作用力来实现平衡。

---

### 动捕源数据与机器人模型的局部坐标系轴向对齐偏差

*   **物理与数学机理诊断：**  
    常用的动捕文件（如 BVH 或来自 SMPL-X 的 PKL）采用世界坐标系（通常为 Y 轴向上）以及定义在各关节局部旋转中心的相对坐标轴。而人形机器人模型（MJCF 或 URDF）通常遵循工业机器人标准（Z 轴向上，X 轴向前）。如果旋转对齐矩阵 $R_{align}$ 定义错误，即使只是微小的欧拉角偏差，在长链分支（如双臂、双腿）的累积下，会造成末端执行器位置发生巨大的空间漂移。

*   **对下游训练/部署的级联影响：**  
    直接导致第一帧初始化时，机器人关节呈现“骨折式”的极端扭曲。物理引擎会在启动瞬间由于关节角度越界而强行重置（Reset），引发 RL 阶段的训练环境崩溃，甚至输出非数的梯度。

*   **全栈解决方案：**  
    在数据处理管线中设立**标准化的 T-Pose/Zero-Pose 轴对齐检验块**。重定向算法首先强制让人类动捕和机器人模型同时进入标准 T-Pose（双臂外展 $90^{\circ}$，双足平行向前），利用主成分分析（PCA）自动提取两者的主轴方向，构建精确的解析转换矩阵：
    $$T_{robot}^{link} = (T_{robot}^{world})^{-1} R_{align} T_{human}^{world} T_{human}^{link}$$
    并在训练环境初始化前，对所有变换矩阵进行可视化图形学自检，确保几何方向的一致性。

*   **GMR 中的偏移量实现细节**  
    GMR 通过 `offset_human_data()` 为每个 body 配置位置偏移和旋转偏移：
    - **位置偏移**在局部坐标系中应用（随 body 姿态旋转），如 G1 的 `left_toe_link` 配置了 `[0.0, 0.02, 0.0]` 的偏移，用于微调脚尖接触位置  
    - **旋转偏移**以四元数（wxyz 格式）表示，用于对齐人体和机器人的 body 坐标系。例如 `pelvis` 的旋转偏移为 `[0.5, -0.5, -0.5, -0.5]`，对应 180° 旋转，将 SMPL-X 的骨盆坐标系映射到机器人骨盆坐标系  
    - **四元数约定**：GMR 内部使用 wxyz 格式（MuJoCo 标准），而 BeyondMimic 管道中需要转换为 xyzw 格式。在 `gvhmr_to_robot.py` 中通过 `root_rot = np.array([qpos[3:7][[1,2,3,0]] for qpos in qpos_list])` 完成转换。转换缺失会导致机器人朝向错误

---

### 交互任务中末端执行器空间约束丢失

*   **物理与数学机理诊断：**  
    在涉及 Loco-manipulation（如推车、搬运箱子、开门）的任务中，人类末端执行器（手掌）与交互物体之间存在临界约束，如封闭的环路运动学（Closed-loop Kinematics）。GMR 在独立重定向双臂和底盘时，由于各个分支是解耦求解的，无法保证两手之间的相对距离 $d_{hands}$ 恒定。这会导致原本在动捕中紧抱箱子的人类动作，映射到机器人上时双臂发生向外滑移或相对挤压。

*   **对下游训练/部署的级联影响：**  
    由于相对距离改变，机器人在物理仿真中无法对箱子施加等效的夹持正压力，导致搬运的箱子在 Episode 启动后的前几帧就滑落，任务无法正常收敛。

*   **全栈解决方案：**  
    采用**解耦分支关联优化（Decoupled Linkage Association, 如 OmniRetarget 方法）**。在重定向优化阶段，为存在协作关系的关节末端建立虚拟距离传感器轴线约束：
    $$\| p_{left\_hand}(q) - p_{right\_hand}(q) \|_2 = d_{box}$$
    将此约束作为二次规划求解器的等式硬约束，从而在运动学层面确保双臂对箱子的几何锁死。

---

## BeyondMimic 第一阶段：强化学习动作跟踪策略训练瓶颈

---

### 均匀时间采样在困难动作区间引发的“探索饥饿”

*   **物理与数学机理诊断：**  
    在长达数分钟的复杂运动流（如 LAFAN1 数据集，包含步行、奔跑、倒地爬起、空翻）中，大部分帧数被低难度的稳态步行（占 80%）占据。若 RL 训练采用传统的均匀随机采样（Uniform RSI, Reference State Initialization）初始化策略，智能体在每个 Episode 开始时，有极大概率被初始化在“走路”阶段。而难度极高、时长仅有 1-2 秒的“空翻”阶段被采样的概率极低。策略由于无法获得足够的样本来探索困难动作的临界发力曲线，导致在此区间的时变状态转移矩阵发生断裂。

*   **对下游训练/部署的级联影响：**  
    跟踪策略表现出严重的偏科：在简单直行上表现尚可，但一旦过渡到动态爆发性动作（如跳跃或旋风踢），由于前期对该区间的 Q 估计极度欠拟合，策略网络输出错误的目标 PD 值，导致机器人瞬间失衡摔倒。

*   **全栈解决方案：**  
    实施**自适应经验成功率采样（Adaptive Sampling via Failure Density Estimation）**：
    将整条运动轨迹切分为长度为 $L$（如 1 秒）的独立时间仓（Bins）。在 RL 训练过程中，实时维护一个失败概率密度函数：
    $$P_{fail}(i) = \frac{N_{fail}(i)}{N_{sample}(i) + \epsilon}$$
    其中 $N_{fail}(i)$ 为智能体在第 $i$ 个时间仓内失稳重置的次数。在采样重置点（RSI）时，采用加权多项式分布采样：
    $$i_{init} \sim \text{Multinomial}\left( \frac{e^{\beta P_{fail}(i)}}{\sum_{j} e^{\beta P_{fail}(j)}} \right)$$
    强制将算力倾斜给物理探索最困难、最易摔倒的动作片段，直到所有片段的成功率均超过设定阈值。

---

### 模仿跟踪奖励与物理平衡惩罚之间的梯度冲突

*   **物理与数学机理诊断：**  
    BeyondMimic 的 RL 奖励函数结构在面临非自洽的重定向输入时，跟踪目标 $\nabla_{\theta} J_{\text{track}}$ 与自平衡正则化 $\nabla_{\theta} J_{\text{balance}}$ 会产生方向截然相反的梯度更新：
    $$\nabla_{\theta} J_{\text{total}} = w_1 \nabla_{\theta} J_{\text{track}} + w_2 \nabla_{\theta} J_{\text{balance}}$$
    例如：跟踪奖励要求左腿前伸贴合参考姿态（提供向前拉的控制力矩），而平衡奖励为了抑制由于重定向质心前倾导致的即将失衡摔倒，要求左腿向后踩踏以维持支撑多边形（提供向后支撑的力矩）。当这两股梯度在反向传播中直接叠加，会导致策略网络的隐藏层权重频繁在两个方向剧烈振荡，策略更新效率低下（Policy Oscillation）。

*   **对下游训练/部署的级联影响：**  
    策略无法稳定收敛到高精度区间。训练曲线上表现为 Episode 平均回报长期处于中等偏低水平，机器人在仿真中呈现出双腿高频颤抖、行动拖沓的病态控制行为。

*   **全栈解决方案：**  
    1. 引入**梯度投影与修正机制（Grad-Surgery, 如 PCGrad 投影算法）**。在计算策略梯度时，若检测到跟踪奖励梯度 $g_{\text{track}}$ 与平衡梯度 $g_{\text{balance}}$ 的余弦相似度为负：
       $$g_{\text{track}} \cdot g_{\text{balance}} < 0$$
       则将 $g_{\text{track}}$ 投影到 $g_{\text{balance}}$ 的正交超平面上：
       $$g_{\text{track}}^{corrected} = g_{\text{track}} - \frac{g_{\text{track}} \cdot g_{\text{balance}}}{\|g_{\text{balance}}\|^2} g_{\text{balance}}$$
       以此消除梯度冲突，保证物理自平衡优先级最高。
    2. 采用**非对称解耦奖励时间调度（Asymmetric Reward Scheduling）**：在训练的前 $30\%$ 阶段，将跟踪奖励设为较低权重，主攻"活下去"（即平衡正则化）；中后期再逐步线性增加精确跟踪的比重。

*   **BeyondMimic 实际奖励函数结构与参数**  

    BeyondMimic 论文提出的"3+1"公式（3个正则化惩罚 + 1个统一跟踪奖励）在 `unitree_rl_mjlab` 实现中被展开为 6 项核心跟踪奖励：

    | 奖励项 | 权重 | std | 物理含义 |
    |:------|:----:|:---:|:---------|
    | `motion_global_anchor_pos` | 0.5 | 0.3 | 全局锚点位置跟踪（偏航不变性） |
    | `motion_global_anchor_ori` | 0.5 | 0.4 | 全局锚点朝向跟踪 |
    | `motion_body_pos` | 1.0 | 0.3 | 全身姿态位置跟踪（核心） |
    | `motion_body_ori` | 1.0 | 0.4 | 全身朝向跟踪（核心） |
    | `motion_body_lin_vel` | 1.0 | 1.0 | 全身线速度跟踪 |
    | `motion_body_ang_vel` | 1.0 | 3.14 | 全身角速度跟踪 |

    **std 参数的影响**：较小的 std（如 0.3）意味着误差容忍度低、跟踪更严格，但奖励函数梯度更大、训练更不稳定；较大的 std（如 3.14）意味着误差容忍度高、跟踪更宽松，但可能导致策略对参考运动的"敷衍"行为。

    **调参经验**：
    - **动态运动（武打、跳跃）**：`std_pos=0.5, std_ori=0.6`（更宽松，防止梯度爆炸）  
    - **精细运动（舞蹈、上肢动作）**：`std_pos=0.2, std_ori=0.3`（更严格，改善末端精度）  
    - 正则化惩罚（joint limit = -10.0, self-collision = -10.0, action rate = -0.1）通常保持不变。若参考运动本身包含轻限位超限（重定向误差），可适当降低惩罚权重

    **3 个正则化惩罚项**：
    - 关节限位惩罚（Joint Limit Penalty）：权重 -10.0
    - 自碰撞惩罚（Self-Collision Penalty）：权重 -10.0
    - 动作平滑惩罚（Action Rate Penalty）：权重 -0.1

    > **实践要点**：相比在所有实验中使用相同的优化权重，部分运动可能需要进一步调整权重以达到最优结果。建议先以默认参数跑出一条基线，再根据运动特性（动态 vs 精细）针对性调整 std 参数和跟踪权重。

---

### 高频指令输出引发的电机震颤与能源虚耗

*   **物理与数学机理诊断：**  
    BeyondMimic 的行动空间通常是关节层面的 PD 目标位置（Target Joint Angles） $q_{\text{target}}$。策略网络在每一个控制步（如 $50\text{Hz}$）直接输出这组目标位置，随后由底层硬件的高刚度 PD 控制器计算输出扭矩：
    $$\tau = K_p (q_{\text{target}} - q) + K_d (\dot{q}_{\text{target}} - \dot{q})$$
    由于 RL 策略在探索过程中没有内在的时序连续性约束，相邻控制步输出的 $q_{\text{target}}$ 可能会产生无序跳变（高频噪声）。这种瞬态跳变在被高 $K_p$ 放大后，会导致输出扭矩 $\tau$ 在短时间内在正负最大扭矩限制之间做方波式的切换。

*   **对下游训练/部署的级联影响：**  
    机器人全身关节呈现肉眼可见的、伴有刺耳声响的高频微幅震颤（Jitter）。这会直接导致谐波减速器和电机绕组在数分钟内迅速升温到 $80^{\circ}\text{C}$ 以上，电量消耗速率上升 3-5 倍，且极易导致真机驱动器触发过流保护。

*   **全栈解决方案：**  
    1. 在奖励函数中引入**严厉的动作二阶导数惩罚（Action Rate & Acceleration Regularization）**：
       $$\mathcal{L}_{smooth} = - w_{\text{rate}} \| u_t - u_{t-1} \|_2^2 - w_{\text{acc}} \| u_t - 2u_{t-1} + u_{t-2} \|_2^2$$
    2. 将动作空间从“直接位置指令”升级为“**关节加速度指令（Joint Acceleration Control）**”，通过在策略网络外挂接一个积分滤波器（First-Order Low-Pass Filter），将策略输出限制在平滑的低频带内。
    3. 在 Sim-to-Real 部署时，在控制回路中加入截止频率为 $15\text{Hz}$ 的巴特沃斯低通滤波器（Butterworth Filter）。

---

### 确定性参考轨迹对仿真环境动力学分布的过拟合

*   **物理与数学机理诊断：**  
    如果将某一特定的 GMR 重定向轨迹（如特定人类在特定地面上走出的 10 秒 PKL 文件）作为唯一的跟踪参照，RL 智能体会将所有的策略权重用于适配当前仿真环境中的特定动力学参数（如固定的地面摩擦系数 $\mu = 1.0$、默认的连杆质量分量）。由于缺乏泛化性探索，智能体在状态空间中形成了一条极窄的“平衡管道”，对环境的扰动没有任何鲁棒边界。

*   **对下游训练/部署的级联影响：**  
    一旦仿真环境与真实物理硬件发生轻微偏移（如真机脚掌在光滑瓷砖上 $\mu = 0.45$），或者机器人的电池电量下降导致输出力矩上限发生改变，策略会在第 1 秒瞬间失稳倒地，Sim-to-Real 的鲁棒性归零。

*   **全栈解决方案：**  
    1. 引入**轨迹时空扰动增强（Reference Trajectory Augmentation）**。在每一个训练 Epoch 中，对参考轨迹的根节点线性速度 $v_{root}$、旋转 $\omega_{root}$ 注入随时间缓慢变化的微小高斯漂移，模拟机器人在不同推力环境下的偏差。
    2. 配合**自适应领域随机化（Active Domain Randomization, ADR）**，根据策略目前的平均跟踪误差，动态调整摩擦力、重力、关节阻尼等参数的采样边界，确保策略在多种极端动力学配置下都能完成闭环。

*   **实际域随机化参数范围参考**  

    基于 GMR 论文实验和 BeyondMimic 实践，推荐的域随机化范围：

    | 参数 | 范围 | 说明 |
    |:-----|:----:|:-----|
    | 摩擦系数 | [0.5, 1.5] | ±50%，防止策略过度依赖特定地面条件 |
    | 质量偏移 | [0.8, 1.2] | ±20%，提高对模型误差的鲁棒性 |
    | 质心偏移 | [-0.05, 0.05]m | ±5cm |
    | 关节噪声 | 0.01 rad | 模拟真实传感器读取误差 |
    | 外部推力 | 0.5 m/s | 每 10 秒随机推一次，提高抗干扰能力 |

    注意：若随机化范围过大（如摩擦系数 $\mu \in [0.1, 8.0]$、重力 $g \in [8.5, 11.0]$），策略会变得极度保守僵硬，丧失敏捷性。

---

### 观察空间中本体感觉状态反馈的时延响应不匹配

*   **物理与数学机理诊断：**  
    在 Isaac Gym 仿真中，策略网络获取机器人的本体感觉状态（Joint Positions, Velocities, Orientation）是实时且无任何滞后的（物理仿真步推进后，状态立刻完全可见）。而在物理真机中，从传感器（光电编码器、IMU）采集信号、经过 CAN 总线传输、进入嵌入式控制器进行状态估计（State Estimation），再到策略前向计算输出，整个链路存在至少 $15\text{ms}$ 至 $35\text{ms}$ 的系统时延（Latency）。如果策略在零时延假设下训练，它会在平衡控制时使用过高的瞬时反馈，造成相位滞后（Phase Lag）。

*   **对下游训练/部署的级联影响：**  
    在真机上部署时，策略会引发严重的低频振荡（一般为 $2\text{Hz}$ 到 $5\text{Hz}$，俗称“画圈”或“钟摆振荡”），机器人会由于控制输出与实际状态之间存在时间差而发生自激振荡，在行走数步后摔倒。

*   **全栈解决方案：**  
    1. 在训练环境的 Observation Pipeline 中显式引入**历史帧延迟缓存（Delayed Observation Buffer）**。
    2. 在每个 Episode 开始时，随机对当前的观察状态 $s_t$ 进行 $N$ 帧的时滞采样（如 $N \in [1, 3]$，在 $100\text{Hz}$ 环境下等效于 $10-30\text{ms}$ 延迟），迫使策略学习利用历史状态轨迹 $[s_{t-N}, ..., s_t]$ 来预测当前真实物理状态并做出预测性控制。

*   **BeyondMimic 标准 150 维观测空间**  

    Actor 网络的观测空间设计直接决定了策略能获取的信息量：

    | 观测项 | 维度 | 说明 |
    |:-------|:----:|:-----|
    | motion_ref_pos | 27 | 参考运动关节位置 |
    | motion_ref_vel | 27 | 参考运动关节速度 |
    | motion_anchor_pos_b | 3 | 锚点位置（机体系） |
    | motion_anchor_ori_b | 6 | 锚点朝向 6D 旋转 |
    | base_lin_vel | 3 | 机体线速度 |
    | base_ang_vel | 3 | 机体角速度 |
    | projected_gravity | 3 | 投影重力向量 |
    | joint_pos_rel | 27 | 关节相对位置 |
    | joint_vel_rel | 27 | 关节速度 |
    | last_action | 27 | 上一步动作 |
    | **总计** | **150** | |

    **参考运动 FPS 的影响**：观测中的 `motion_ref_pos` 和 `motion_ref_vel` 取自参考运动。GMR 输出默认降采样到 30 FPS，若原始运动包含高频成分（快速挥臂、跳跃），降采样会导致 aliasing 和信息丢失。关节速度通过相邻帧位置差分计算，低 FPS 会使速度估算不准确。30 FPS 是标准选择，但快速运动可能需要 60 FPS。

---

### 长序列、非周期性动作下价值函数估计的方差爆炸

*   **物理与数学机理诊断：**  
    对于长达 2 分钟、包含多阶段非周期行为（如：正常行走 $\to$ 跨栏 $\to$ 倒地 $\to$ 翻滚爬起）的超长参考轨迹，其贝尔曼方程（Bellman Equation）中的状态价值 $V(s)$ 存在巨大的空间跨度。在非周期动作中，早期的行走状态与后期的翻滚状态不满足马尔可夫决策过程（MDP）的平稳分布特性。在计算广义优势估计（GAE, Generalized Advantage Estimation）时：
    $$\hat{A}_t = \sum_{l=0}^{\infty} (\gamma \lambda)^l \delta_{t+l}^{V}$$
    由于时序过长且状态极度不稳定，差分误差（TD Error） $\delta_t^V = r_t + \gamma V(s_{t+1}) - V(s_t)$ 会在长序列反向传播中产生累积，导致价值网络估计的方差呈指数级放大。

*   **对下游训练/部署的级联影响：**  
    价值网络预测失准，导致策略梯度的方差爆炸。策略网络在训练后期往往会陷入退化状态，原本在第 10 秒已经学会的完美跨栏动作，会在优化第 100 秒的起立动作时发生梯度崩溃，导致前期的成果被完全摧毁。

*   **全栈解决方案：**  
    1. 使用**基于阶段的时间相位标签（Phase-conditioned Representation）**。在 Observation 中额外增加一个一维的一致性时间步标签（Time Phase Variable） $\phi = t/T_{\text{max}} \in [0, 1]$，打破时间维度的非马尔可夫性，帮助价值网络更好解耦不同时间段的状态特征。
    2. 采用**价值网络集成与正则化（Value Network Ensemble & PopArt Scaling）**。使用多个独立初始化的价值网络并行估计，并使用 PopArt 算法对价值目标的平均值和方差进行实时自适应缩放（Normalization），限制反向梯度的幅值上限。

*   **BeyondMimic PPO 超参数与网络架构**  

    BeyondMimic 使用 rsl_rl 库的 PPO 算法，关键超参数：

    | 参数 | 典型值 | 说明 |
    |:-----|:------:|:-----|
    | value_loss_coef | 1.0 | 价值函数损失系数 |
    | entropy_coef | 0.0 | 熵正则化系数（通常为 0） |
    | learning_rate | 1e-4 ~ 5e-4 | 学习率 |
    | num_learning_epochs | 5 | 每次更新迭代次数 |
    | num_mini_batches | 4 | mini-batch 数量 |
    | horizon | 32 | 时间步长（horizon） |

    **网络架构**：Actor-Critic 隐藏层为 512 → 256 → 128，激活函数 ELU，动作分布为高斯分布（GaussianDistribution），初始标准差 1.0。网络容量需与运动复杂度匹配——复杂的全身协调动作需要更大的网络容量。

    **长序列训练建议**：对于超长序列（> 30 秒），可增加 PPO horizon 长度、在 `MotionCommand` 中增加对序列后期的采样权重，或将长序列切分为短片段分别训练。

---

### 困难动作微调中的通用运动技能灾难性遗忘

*   **物理与数学机理诊断：**  
    当研究人员试图训练一个具备广泛运动技能（Locomotion Skills）的人形机器人时，通常会先训练好一个通用的“行走/奔跑跟踪器”，随后在这一策略权重上继续微调（Fine-tuning）更困难的动作（如“空翻”）。然而，人工神经网络在没有特殊约束的情况下进行微调，会导致新任务的强梯度大幅冲刷并覆盖网络隐藏层中原有的特征提取流形。这就是连接主义经典的**灾难性遗忘（Catastrophic Forgetting）**现象。

*   **对下游训练/部署的级联影响：**  
    微调完成后的策略网络确实掌握了高难度的空翻动作，但原先极其稳健的平地走、慢跑等基础导航技能却完全退化退化，导致机器人甚至无法完成基本的指令行走。

*   **全栈解决方案：**  
    1. 采用**弹性权重固化算法（EWC, Elastic Weight Consolidation）**。在微调阶段，引入基于原有任务 Fisher 信息矩阵 $F_i$ 的正则化惩罚，保护对基础行走技能最关键的网络权重：
       $$\mathcal{L}(\theta) = \mathcal{L}_{new\_motion}(\theta) + \sum_{i} \frac{\lambda}{2} F_i (\theta_i - \theta_{i, old})^2$$
    2. 基于**知识蒸馏（Knowledge Distillation）的多技能融合**。在多任务强化学习中，维持一个冻结参数的基础行走专家网络，在训练新动作时，将行走专家的输出概率分布 $a_{\text{base}}$ 作为一个 Kullback-Leibler (KL) 散度惩罚项约束新策略的更新：
       $$\mathcal{L}_{distill} = \beta D_{KL}(\pi_{base}(a|s) \parallel \pi_{\theta}(a|s))$$

---

### 抵抗外部物理冲撞时刚性跟踪引发的失稳

*   **物理与数学机理诊断：**  
    在传统的 BeyondMimic 模仿学习设置中，跟踪权重（Tracking Weights）通常是恒定不变的。当真机机器人在行走时受到外界的意外强力物理撞击（如被人横向猛推），机器人的躯干会瞬间偏离原有的几何轨迹。由于模仿策略极其渴望拿满“关节姿态跟踪奖励”，其控制决策会输出极其僵硬的矫正力矩，试图将腿部强行恢复到原定的人体姿态上，忽略了此时由于质心漂移应该顺势迈出“缓步”来重塑支撑面的物理现实。

*   **对下游训练/部署的级联影响：**  
    由于控制策略过于生硬僵化，机器人在面对任何轻微的外界机械碰撞时表现极差，几乎没有自适应恢复平衡的能力，无法在真实的动态人机共存环境（如办公室、工厂）中部署。

*   **全栈解决方案：**  
    构建**基于柔顺阻抗控制的动态奖励机制（Dynamic Impedance Reward Formulation）**。在 RL 训练中，引入一个动态衰减因子 $\alpha = f(\text{External Force})$：
    $$\mathcal{R}_{\text{tracking}} = \alpha \mathcal{R}_{\text{mocap\_track}} + (1-\alpha) \mathcal{R}_{\text{balance\_recovery}}$$
    当外部足端力或质心加速度计检测到异常物理冲击时，自动调低姿态模仿的约束比重，极大增加对全身质心平衡和足底反作用力平滑度的奖励。这使得机器人展现出类似人类的柔顺特征——受推搡后顺势踉跄跨步，稳定后再自然过渡回参考轨迹。

---

## BeyondMimic 第二阶段：状态-动作协同扩散与测试时引导瓶颈

---

### 多步去噪循环（Denoising Loops）的极高推理时延与控制实时性瓶颈

*   **物理与数学机理诊断：**  
    BeyondMimic 的通用控制器将 RL 专家的成功轨迹提炼并压缩进一个去噪扩散策略（Diffusion Policy）中。传统的扩散模型在推理时，需要从纯高斯噪声 $z_K \sim \mathcal{N}(0, I)$ 出发，经过多步（如 $K = 20$）逆向去噪迭代才能生成一组平滑的状态-动作轨迹：
    $$z_{k-1} = \frac{1}{\sqrt{\alpha_k}} \left( z_k - \frac{1-\alpha_k}{\sqrt{1-\bar{\alpha}_k}} \epsilon_{\theta}(z_k, c, k) \right) + \sigma_k \mathbf{z}$$
    即使使用极为紧凑的 Transformer 架构，每一次去噪都需要进行一次前向传播。对于 $100\text{Hz}$ 的高频控制要求，单次控制决策的计算窗口期仅有 $10\text{ms}$。在嵌入式端（如 NVIDIA Jetson Orin），连续进行 20 次网络前向计算的时延通常在 $100\text{ms}$ 以上，根本无法满足实时控制的闭环要求。

*   **对下游训练/部署的级联影响：**  
    由于控制延迟比物理动态慢了一个数量级，系统发生严重的相位延迟，造成执行器指令严重滞后于机器人当前的物理倾斜，机器人在启动去噪的瞬间就会直接向侧面摔倒。

*   **全栈解决方案：**  
    1. 采用**一致性蒸馏算法（Consistency Distillation / Consistency Models）**。将训练好的多步扩散策略蒸馏到一个单步一致性网络（Consistency Network）中。该网络能够实现从任意噪声步长直接预测终点状态，将推理去噪步骤从 20 步强行压缩至 **1 到 2 步**。
    2. 采用**时序滑动窗口与热启动机制（Warm-start Denoising in Temporal Sliding Window）**：
       由于相邻控制步之间的轨迹具有高度的时间相关性，在 $t$ 时刻，不再从纯噪声开始去噪，而是将 $t-1$ 时刻生成的轨迹向后平移一帧，加入极其微弱的噪声作为初始猜测值，仅进行 **2 至 3 步的精细去噪（Refinement Steps）**，从而将前向推理次数压缩 90%，控制频率轻松突破 $100\text{Hz}$。

---

### 隐含状态-动作空间（Latent Space）对细微运动特征的物理保真度丢失

*   **物理与数学机理诊断：**  
    BeyondMimic 采用变分自编码器（VAE）将高维的机器人状态 $s$ 和动作 $a$ 压缩为一个低维平滑的隐空间 $z = \text{Encoder}(s, a)$。为了保证隐空间的平滑度和生成能力，VAE 的损失函数中包含了一个强烈的 KL 散度约束：
    $$\mathcal{L}_{VAE} = \mathcal{L}_{recon}(s, a) + \beta D_{KL}(q(z|s,a) \parallel \mathcal{N}(0, I))$$
    当权重 $\beta$ 设得过大时，VAE 会过度平滑（Oversmoothing），将动作空间中的高频精细特征（如：脚底板与地面即将接触瞬间的脚踝微调、手指的灵巧捏握）作为不重要的噪声抹去（信息瓶颈丢失）。

*   **对下游训练/部署的级联影响：**  
    解码器（Decoder）重构出的关节指令往往偏向过于平缓和肉感，导致机器人在真实世界中无法执行敏捷跑跳中的点地接触（Touchdown）或高频调整，脚踝经常因为刚度不足而发生偏斜和失稳。

*   **全栈解决方案：**  
    1. 引入**多尺度金字塔 VAE 架构（Multi-scale Pyramid VAE）**，将隐空间划分为“全局粗粒度轨迹（慢速隐特征 $z_{slow}$）”和“局部高频精细动作（快速隐特征 $z_{fast}$）”双通道，其中 $z_{fast}$ 拥有更小的 KL 约束权重。
    2. 引入**物理约束重建损耗（Physics-informed Reconstruction Loss）**：在 VAE 训练中，除了传统的均方误差（MSE），额外加入重建后关节速度、加速度以及末端执行器接触状态的判定 Loss。

---

### 测试时引导计算出的梯度超出分布边界

*   **物理与数学机理诊断：**  
    BeyondMimic 使用测试时引导（Test-Time Classifier Guidance）来实现零样本泛化。其核心原理是，在逆向去噪步中，向隐向量 $z_k$ 注入人为设计的代价函数（Cost Function）的负梯度：
    $$z_{k-1} = z_{k-1} - \eta \nabla_{z_k} \mathcal{C}(z_k)$$
    由于代价函数 $\mathcal{C}$（例如：偏离期望速度的惩罚）通常是人工定义的，其梯度 $\nabla_z \mathcal{C}$ 在隐空间中并没有物理分布限制。当引导增益（Guidance Scale） $\eta$ 设得过大时，梯度的暴力推挤会将隐向量 $z_k$ 强行推出 VAE 训练时的核心分布边界 $\mathcal{N}(0, I)$，进入所谓的“超分布外（OOD）盲区”。

*   **对下游训练/部署的级联影响：**  
    一旦进入 OOD 隐空间，VAE 解码器（Decoder）的重构输出将彻底失真，重构出的关节角度会呈现病态的数值越界（如：膝关节反向折弯 $180^{\circ}$），导致机器人瞬时触发软硬件极限保护，瘫痪摔倒。

*   **全栈解决方案：**  
    1. 对引导梯度进行**流形投影与截断（Manifold Projection & Gradient Clipping）**。在将引导梯度叠加到 $z_k$ 之前，使用主成分分析（PCA）或对数概率密度评估网络评估当前 $z^{next}$ 的似然度。若 $\log p(z^{next}) < \text{Threshold}$，则对梯度步长进行指数衰减：
       $$\eta_{\text{adaptive}} = \eta \cdot \exp\left( \gamma \min(0, \log p(z^{next}) - T) \right)$$
    2. 引入**拉格朗日乘子约束优化（Lagrangian Dual Guidance）**，将无约束梯度注入转化为受边界限制的条件优化，确保隐向量严格位于 VAE 隐表征流形的高概率区域。

---

### 引导代价函数在障碍物避障中的局部极小值锁死

*   **物理与数学机理诊断：**  
    在敏捷避障任务中，BeyondMimic 通常在代价函数中引入符号距离场（SDF, Signed Distance Field）：
    $$\mathcal{C}_{obs}(z) = \max(0, R_{safe} - \text{SDF}(x_{robot}(z)))$$
    当机器人在运动方向上，正前方出现一堵宽大的刚性障碍物墙体时，SDF 梯度 $\nabla_z \mathcal{C}_{obs}$ 会在中心点形成一个向后的排斥力场，与导航代价 $\mathcal{C}_{nav}$（推挤机器人向前）完全相反。在隐空间去噪中，这两个梯度直接对冲，使得总梯度 $\nabla_z \mathcal{C}_{total} \to 0$。模型陷入了非凸优化中经典的**对称性局部极小值（Local Minima/Saddle Point Trap）**。

*   **对下游训练/部署的级联影响：**  
    机器人表现出严重的“认知瘫痪”：在距离障碍物 1 米处突然原地僵死、高频踱步、或开始非受控地剧烈颤抖，无法做出合理的主动绕行决策。

*   **全栈解决方案：**  
    1. 在避障代价函数中增加**旋涡流场梯度（Vortex Field Guidance / Gyroscopic Forces）**。当机器人质心靠近障碍物一定范围时，向梯度场中人工注入一个正交切向的“螺旋力”：
       $$F_{vortex} = \mathbf{n} \times \nabla \text{SDF}$$
       其中 $\mathbf{n}$ 为地表法向量，以此主动打破对称性，诱导扩散去噪过程向障碍物左侧或右侧偏转，实现优雅绕行。
    2. 在扩散模型去噪的初始前几步中引入**随机采样抖动（Noisy Perturbation Exploration）**，通过主动注入小幅度噪声帮助轨迹摆脱局部鞍点。

---

### 协同扩散过程中状态预测与物理引擎动力学退耦

*   **物理与数学机理诊断：**  
    BeyondMimic 的扩散模型不仅预测未来的控制动作 $a_{t:t+H}$，还协同预测机器人未来的物理状态 $s_{t:t+H}$（称为 Co-diffusion）。这种设计本意是提供“前瞻性控制”，但去噪网络所学习的状态预测本质上是对历史训练数据（物理引擎表现）的“静态拟合”。在真实部署中，由于不可预测的外界碰撞、摩擦力的微弱不连续，物理真机的状态演化完全服从最严苛的牛顿定律，而不服从扩散网络的拟合。因此，扩散预测的未来状态 $\hat{s}_{t+1}$ 与真实传感器反馈的状态 $s_{t+1}$ 之间会迅速发生退耦（Divergence）。

*   **对下游训练/部署的级联影响：**  
    网络会基于自我预测的虚假完美状态继续输出后续动作，形成“掩耳盗铃式”的控制。当退耦误差在几步内累积过大时，底层 PD 控制器将因为接收到非当前物理状态所需的力矩指令而发生瞬时失控。

*   **全栈解决方案：**  
    1. 引入**闭环反馈自适应重校准机制（Receded Horizon Model Predictive Control, MPC）**。
       在每一个决策步，虽然扩散模型输出了一组长达 16 步的未来动作和状态序列，但底层硬件**仅执行当前的第一步动作 $a_t$**。在下一个控制回路中，立刻使用真实传感器采集的最新的 $s_{t+1}$ 覆盖掉扩散模型预测的状态，并以此为新的起点重新去噪。
    2. 引入**状态重校正自回归网络（Autoregressive Calibration Model）**，对去噪后的动作进行实时残差补偿。

---

### 极长轨迹生成中的去噪漂移累积与关节崩溃

*   **物理与数学机理诊断：**  
    在需要人形机器人执行数十分钟的超长长途导航时，自回归（Autoregressive）的扩散轨迹生成会由于单步预测中的微弱高斯误差，产生数值上的**随机游走漂移（Drift Accumulation）**。这主要是因为去噪变换器（Denoiser Transformer）在生成轨迹时，对历史观测条件 $c_t = [s_{t-N}, ..., s_t]$ 的自注意权重存在长周期衰减。随着步数累计，状态向量中的累积误差会逐渐偏离 VAE 的标准流形。

*   **对下游训练/部署的级联影响：**  
    机器人往往在前 3 分钟走得非常完美，但在 5 分钟之后，某个关节的角度会开始不可逆地发生小幅度向一侧偏斜，最终导致整机关节畸变崩溃。

*   **全栈解决方案：**  
    1. 引入**基于周期性隐流形锚定的重投影算法（Latent Anchor Reprojection）**。每隔固定步数（如 100 步），强制对生成的隐向量 $z$ 进行流形截断，将其重投影回最近的、物理上完全自洽的“专家静息态分布（Rest Pose Distribution）”。
    2. 采用**时序反馈纠偏网络（Closed-Loop De-drift MLP）**，实时检测当前轨迹与离线动作数据库在拓扑空间中的马氏距离（Mahalanobis Distance），对偏离度超标的维度施加负反馈纠偏控制。

---

### 技能拼接（Motion Inpainting）边界处的速度跳变与物理不连续

*   **物理与数学机理诊断：**  
    BeyondMimic 支持通过时间切片修补（Inpainting）来实现动作的平滑拼接（如：快速奔跑 $\to$ 侧手翻）。其操作原理是在拼接点 $t_{\text{joint}}$ 强制将未来的局部关键帧（Keyframe）设定为侧手翻的初始态。然而，奔跑的末速度 $v_{\text{run}}$ 与空翻的初始速度 $v_{\text{flip}}$ 在相空间（Phase Space）中相隔甚远，且两者的关节加速度高阶导数不连续。扩散模型在修补中间几帧过渡动作时，仅仅在隐空间进行数学上的插值，无法保证边界处的动力学相容性（Dynamic Compatibility）。

*   **对下游训练/部署的级联影响：**  
    拼接处的过渡帧会重构出极为突兀的超常关节角速度（如关节角度在 1 帧内发生 $30^{\circ}$ 畸变），在真实硬件上会瞬间触发过载断电。

*   **全栈解决方案：**  
    1. 在 Inpainting 优化过程中，将**边界动量守恒定理（Conservation of Momentum）**作为硬约束引入：
       $$\lim_{\epsilon \to 0} P(t_{\text{joint}} - \epsilon) = P(t_{\text{joint}} + \epsilon)$$
       其中 $P$ 为系统总质心动量（Centroidal Momentum）。
    2. 采用**软边界掩膜过渡（Soft Masking Overlap）**：在 Inpainting 去噪过程中，不采用硬性的时间切片边界，而是使用一个随时间正弦变化的混合权重掩膜（Soft Blend Mask），让两个动作的隐表征在 10 帧的重叠区间（Overlap Region）内渐进式融合去噪，从而消灭速度突变点。

---

### 面对多模态任务目标时的生成模式坍塌

*   **物理与数学机理诊断：**  
    在面临如“前方有一面墙，左侧和右侧均可绕行”的多模态（Multi-modal）路径决策时，扩散策略所拟合的隐状态得分匹配函数（Score Matching Function） $\nabla_z \log p(z|c)$ 在数学上是一个双峰分布（Bimodal Distribution）。如果系统采用普通的确定性均值求取或扩散采样步长 $\eta$ 设置不当，扩散模型在进行得分梯度推挤时，会使得不同注意力头（Attention Heads）之间的输出发生冲突，将原本属于两端的高概率模式直接平均化，陷入中间零概率的死区。

*   **对下游训练/部署的级联影响：**  
    控制器在面临抉择时，无法坚定选择左侧或右侧绕行，而是采取一种折中的、在物理上完全不合逻辑的行为——笔直撞墙。

*   **全栈解决方案：**  
    1. 在测试时采样算法中引入**粒子过滤与多路径推演（Particle Filter Diffusion Sampling / Multiverse Rollouts）**。
       在推理去噪时，并行维护 8 组独立的噪声粒子（Particles），赋予它们不同的高斯扰动。在第 5 步去噪后，对粒子进行聚类检测，自动划分出两组高似然度路径（绕左与绕右），丢弃处于中间死区的粒子，并在后期仅保留一条最优路径粒子进行动作生成，从而保证多模态生成动作的极强目的性。

---

## 最后一公里：Sim-to-Real 迁移与物理硬件部署瓶颈

---

### 真实电机的非线性特性（静摩擦、粘性阻尼、死区、背隙）未建模

*   **物理与数学机理诊断：**  
    物理仿真器中对电机的驱动模型通常是极度理想化的常数 PD 控制。然而，物理真机中的无刷伺服电机（如 Unitree G1 的关节电机）搭配高减速比的谐波减速器时，会呈现极强的非线性物理特性：
    $$\tau_{motor} = f_{actuator}(V_{cmd}) - \tau_{static} \operatorname{sgn}(\dot{q}) - b \dot{q} - \tau_{hysteresis}$$
    其中包含阻碍启动的静摩擦力（Static Friction）、粘性阻尼项 $b \dot{q}$、由于齿轮啮合间隙造成的背隙（Backlash）以及由于电磁死区（Deadband）引起的极小电压下的非零响应。如果 BeyondMimic 输出的微小角度偏差无法克服静摩擦，机器人关节就会在零点附近发生严重的迟滞，无法执行微调平衡。

*   **对下游训练/部署的级联影响：**  
    在仿真中表现得极其轻盈、像猫一样灵活的机器人，在真机部署时会表现得极其僵硬和笨拙。细微平衡姿态由于静摩擦无法响应，导致系统最终无法保持静态站立平衡。

*   **全栈解决方案：**  
    1. 引入**深度自适应执行器网络（Actuator Network with Hysteresis Modeling, 如 GapONet / ASAP 框架）**。
       采集真实电机在各种动、静态力矩指令下的转角、转速和真实电流数据。使用一个一维时序卷积网络（1D-Temporal Convolutional Network）或 LSTM 网络来训练一个黑盒执行器模型（Actuator Net）：
       $$\tau_{actual} = \operatorname{ActNet}(q_{desired}, q_{actual}, \dot{q}_{actual}, I_{motor})$$
       在 BeyondMimic 训练时，将该训练好的执行器网络无缝嵌入到物理仿真器的推力控制回路中，代替理想 PD 计算，让策略在仿真阶段就必须学会“如何发力来克服静摩擦与背隙”。

---

### 接触力学模型的简化失真

*   **物理与数学机理诊断：**  
    Isaac Gym 或 MuJoCo 仿真中采用经典的弹簧-阻尼接触力学模型（Spring-Damper Contact Models）或非穿透凸锥互补约束来近似计算接触力。它们假设地面是绝对刚性的（弹性系数 $k \to \infty$），且摩擦锥表面完全符合库伦摩擦定律。而在真实物理环境中，机器人的橡胶脚掌具有超弹性变性（Hyperelastic Deformation），地面（如短毛地毯、沥青、泥地）具有独特的微观凹凸不平和柔性吸收特性。当机器人跳跃着地时，这种微观接触动力学的阻尼失配会造成反弹系数不一致。

*   **对下游训练/部署的级联影响：**  
    在仿真中被设计得刚刚好能够吸收落地冲击的力矩控制，在真机上由于地面质地偏软、反弹延迟，导致机器人的脚踝承受了极高的局部冲击阻抗，引发关节过载甚至在着地瞬间发生侧倾摔倒。

*   **全栈解决方案：**  
    1. 在仿真中对脚掌接触点引入**柔性软接触（Soft-Contact Modeling）**。
       在 MuJoCo 配置文件中配置 `solimp` 和 `solref` 参数，将刚性接触修正为柔性粘弹性接触模型，并对接触阻尼和弹簧系数进行大边界随机化采样（如将硬地与柔性软地毯的接触刚度进行 $50\%$ 至 $200\%$ 范围内的 ADR 随机采样）。
    2. 对机器人脚底板加装多孔橡胶缓冲垫，并在真机控制器底层增加基于接触阻抗控制（Impedance Control）的紧急过载缓冲算法。

---

### 状态估计器（VIO/IMU）的漂移与累计误差导致策略失真

*   **物理与数学机理诊断：**  
    BeyondMimic 的决策策略依赖于机器人高精度的当前线速度 $v$、角速度 $\omega$ 以及骨盆倾角 $\mathbf{q}_{ori}$。真机上的状态估计器（State Estimator）通常是通过将高频的六轴 IMU（惯性测量单元）数据与足端动力学接触（Contact Odometry）进行卡尔曼滤波融合（Error-State Kalman Filter, ESKF），或者通过 VIO（视觉惯性里程计）融合。当机器人产生高频高载荷冲击（如快速奔跑或双足跳跃）时，IMU 的白噪声积分偏置（Bias Drift）会呈二次方累积发散，导致估计的根节点倾角和线速度出现严重偏差。

*   **对下游训练/部署的级联影响：**  
    状态估计器给策略网络输入了一个“机器人正在向右倾斜”的错误信号，而机器人实际上处于垂直状态。策略网络接收到此错误信号，输出矫正动作，反而强行将原本平衡的机器人直接推到。

*   **全栈解决方案：**  
    1. 在仿真训练阶段，对观察空间的线速度和倾角输入**注入基于随机游走过程的逼真状态估计噪声（State Estimation Drift Emulation）**：
       $$x_{obs} = x_{true} + b_t + \eta_{white}, \quad b_t = b_{t-1} + \eta_{drift}$$
       其中 $b_t$ 模拟 IMU 的偏置漂移。这会逼迫策略网络不要过分信任绝对本体反馈，而是多利用一段时间窗内的时序历史状态来做自我纠偏。
    2. 在真机底层部署**双重容错卡尔曼滤波器**，当足底力传感器检测到打滑等异常接触事件时，自动降低接触里程计的融合权重，转而提高惯性阻尼估计比重。

---

### 领域随机化过度泛化导致控制策略过于保守

*   **物理与数学机理诊断：**  
    为了弥合 Sim-to-Real 的鸿沟，最常用的方法是领域随机化（Domain Randomization, DR）。在训练 BeyondMimic 时，如果简单地将地面摩擦系数 $\mu \in [0.1, 8.0]$、关节阻尼 $D \in [0.1, 5.0]$、重力加速度 $g \in [8.5, 11.0]$ 等参数进行无边界的剧烈随机化采样，虽然能够提升系统的鲁棒边界，但在数学上，这相当于在强化学习的目标函数上增加了一个超高熵的平滑滤波器。策略为了在这种极端不确定性的“多重物理宇宙”中存活，其解空间会发生退化。

*   **对下游训练/部署的级联影响：**  
    学习到的控制策略变得极度保守、僵硬。机器人在真机部署时会呈现极不自然、极其消耗电量的“半蹲碎步”防摔步态，彻底丧失了 GMR 数据中原本优雅、敏捷的人类动作质感。

*   **全栈解决方案：**  
    实施**基于主动辨识的残差反馈动力学对齐（Aligning Simulation and Real Physics, 如 ASAP 框架）**。
    在第一阶段，仅使用窄幅度的温和随机化训练 BeyondMimic 策略。在真机部署时，实时收集机器人的状态-动作序列；构建一个离线的参数识别网络（System Identification Network）或训练一个在线的**残差动作动力学补偿模型（Delta Action Model）**。该残差模型在仿真与真机之间学习力矩层面的不一致映射：
    $$\tau_{real} = \tau_{sim} + \Delta \tau_{residual}(s, a)$$
    随后将训练好的 $\Delta \tau_{residual}$ 注入回仿真器中进行微调（Fine-tuning）。这种“Simulation-to-Real-to-Simulation (S2R2S)”的闭环链路避免了盲目的过度随机化，既保留了极高的敏捷度，又优雅地跨越了动力学鸿沟。

---

### 真实机器人重心（CoM）偏置及质量矩阵偏差

*   **物理与数学机理诊断：**  
    仿真中使用的 MJCF/URDF 文件中，每个连杆的物理质量（Mass）和转动惯量（Inertia Tensor）通常是 CAD 建模软件输出的理论计算值。然而，在真实生产中，由于多层硬质碳纤维外壳的厚度偏差、内部布线束的不规则堆叠、以及后期加装的深度相机、LiDAR、应急电池等外设，会导致机器人的真实质心（CoM）偏离几何几何对称轴（如在中轴线方向偏前偏右数厘米），同时真实质量分布产生非对称偏移（$\Delta m_{CoM}$）。

*   **对下游训练/部署的级联影响：**  
    策略网络基于零偏置的质心估计输出平衡力矩。在真机启动瞬间，由于重力分配不均，机器人的某条单侧支撑腿会承担超常的压力，导致骨盆瞬间向重心偏置的一侧歪斜倾倒，无法起步。

*   **全栈解决方案：**  
    1. 采用**在线非对称重心辨识与补偿网络（Online CoM Identification Network）**。在策略观测空间中，增设一个三维的隐式偏置变量（Bias Latent Vector） $\mathbf{z}_{bias}$。
    2. 在训练中，ADR 对每个连杆的重心偏置 $(x_{off}, y_{off}, z_{off})$ 进行随机采样，并通过递归神经网络（RNN/Transformer）或自适应滤波，在控制前向传播中自动推断出当前的隐式偏置：
       $$\hat{\mathbf{z}}_{bias} = \operatorname{BiasEstimator}(s_{t-H:t})$$
       这使得真机策略能够在上电 2 秒内，通过重力分布反馈自动感知重心偏差并调整其零点力矩平衡偏置。

---

### 嵌入式算力平台的功耗墙、热节流与线程时序抖动

*   **物理与数学机理诊断：**  
    物理人形机器人的机载算力（通常为 NVIDIA Jetson Orin Nano / AGX 或 Intel 嵌入式 CPU）不仅需要运行 BeyondMimic 深度扩散推理，还需要同时运行视觉点云处理（Voxel Grid Filtering）、卡尔曼滤波状态估计、底盘安全看门狗（Watchdog）和底层 CAN 驱动。当机器人运行在高载荷动作（如空翻）时，算力平台的功耗和发热量急剧增加。一旦芯片温度触发硬件热阈值（通常在 $85^{\circ}\text{C}$ 到 $95^{\circ}\text{C}$），机载系统会瞬间启动**热节流（Thermal Throttling）降频机制**，迫使 CPU/GPU 频率腰斩。

*   **对下游训练/部署的级联影响：**  
    突如其来的频率降低会导致时序发生不可预测的“时序抖动（Thread Jitter）”。一个在常温下稳定耗时 $4\text{ms}$ 的控制周期，会突然由于降频或线程调度冲突而暴增至 $40\text{ms}$（导致通信丢包或超周期）。这会导致底层驱动器接收不到新指令而发生瞬时停机，机器人瞬间失控跌落。

*   **全栈解决方案：**  
    1. 采用**严格的硬实时系统内核配置（RT-Preempt Linux Kernel）**。
       将控制线程和去噪扩散推理线程赋予极高的进程优先级（FIFO Real-time Scheduler, Priority 99），锁定独立的核心（CPU Core Affinity Isolation），并使用多线程锁（pthread_mutex）和共享内存技术彻底解耦非实时的视觉计算与实时的物理控制。
    2. 将 VAE 解码器和 Transformer 推理网络导出为半精度（FP16）甚至整型（INT8）的 TensorRT 推理引擎，大幅降低 GPU 计算单元的瞬时发热量。
    3. 在嵌入式系统底层监控 CPU 温度，一旦接近热阈值，立刻自适应降低扩散去噪的去噪步数（如从 3 步精细去噪降至 1 步快速生成），牺牲局部精度以绝对确保时序的一致性。

---

### 高动态运动下的结构柔性与连杆形变误差

*   **物理与数学机理诊断：**  
    多物理引擎（如 MuJoCo）默认采用完全刚性体假设（Rigid Body Assumption）。但在真实的人形机器人中，虽然连杆由高刚性材料制造，其内部多处关节减速箱的输入输出端具有不可忽略的结构柔性（Joint Compliance, 扭转刚度有限）。当机器人执行跳跃着地、急刹狂奔等极度高载荷冲击动作时，关节扭转变形和连杆微观形变会导致足端实际坐标与基于理论刚性正向运动学（FK）计算的足端坐标发生厘米级的偏差。

*   **对下游训练/部署的级联影响：**  
    结构柔性在物理上相当于一个未经建模的扭转弹簧，会产生严重的非线性弹性迟滞和能量储存。策略网络无法感知这种柔性，会导致执行着地缓冲时控制力矩过载，发生严重的动作超调（Overshoot）或引起全身性的高频结构共振（Structural Resonance）。

*   **全栈解决方案：**  
    1. 在仿真中对关键连杆引入**虚拟柔性扭转关节（Flexible Joint Emulation）**。
       在机器人的髋关节、膝关节等关键位置，串联一个带有大阻尼、高弹性的虚拟一维无驱动关节，并对其刚度进行大幅度参数随机化（如 $k_{spring} \in [1000, 5000]\text{ Nm/rad}$），模拟硬件扭转刚度。
    2. 真机部署时，底层伺服驱动器开启**扰动观测器（DOB, Disturbance Observer）**，将由柔性形变引起的扭矩误差作为外部扰动并在几十毫秒内快速闭环补偿消退。

---

### 电源电压跌落与峰值电流饱和下的扭矩输出受限

*   **物理与数学机理诊断：**  
    仿真环境中，机器人的电源被默认为是具有无限能量、恒定电压输出的理想电压源。而在物理真机中，人形机器人（如 Unitree G1）通常搭载的是高倍率锂电池包（如 24V - 48V）。在高爆发动作（如从高台跳跃着地并快速站立）中，十几颗大功率高刚性伺服电机在几百毫秒内会同时爆发出接近极限的力矩输出。大电流的快速抽取会引发锂电池内部内阻的瞬时分压，造成**电源电压跌落（Voltage Sag）**；同时驱动器的板载 MOSFET 具有峰值电流限制（Current Saturation Limits）。

*   **对下游训练/部署的级联影响：**  
    由于供电电压跌落和电流饱和，机器人实际输出的最大力矩 $\tau_{max}^{real}$ 会瞬间打折到理论最大扭矩的 $50\%$ 至 $70\%$。在跳跃着地的关键失衡瞬间，机器人需要输出 $100\text{Nm}$ 的大扭矩来支撑，而驱动器由于限流只能输出 $60\text{Nm}$，导致机器人由于支撑力矩不足，发生极其尴尬的“瘫软跪地”故障。

*   **全栈解决方案：**  
    1. 在 BeyondMimic 训练环境中构建**基于电压跌落曲线的动态关节扭矩限幅器（Dynamic Torque Limiter）**。
       根据锂电池的放电化学特性模型，实时计算系统的瞬时总输出力矩 $\sum |\tau(t)|$。当总扭矩和电流接近极限时，自适应收窄策略网络在该帧的最大 Torque 裁切边界：
       $$\tau_{max}(t) = \tau_{max\_theoretic} \cdot g(V_{battery\_current})$$
       迫使策略学会通过“借力打力”、预留缓冲空间、或者利用肢体动量分配（Momentum Redistribution）来软化着地冲击，而不是依赖硬性大电流硬撑。
    2. 部署时，加入整机功耗智能限制管理模块（Power Management Module），防止电机群在同一毫秒内产生超宽的高频电流脉冲叠置。

---

## 附录：实验数据对比与各机器人配置参考

### 重定向方法对下游策略成功率的定量影响

GMR 论文通过 BeyondMimic 作为标准化评估框架，对比了四种重定向方法的策略训练成功率（21 个 LAFAN1 运动序列，不进行奖励调优）：

| 重定向方法 | 策略成功率 | 与 Unitree 基准的差距 |
|:-----------|:----------:|:--------------------:|
| Unitree（闭源高质量基准） | ≈90% | 基准 |
| GMR | ≈85% | ~5% |
| PHC | ≈70% | ~20% |
| ProtoMotions | ≈65% | ~25% |

关键结论：当重定向误差（关节位置 RMSE）超过某个阈值时，策略成功率呈非线性下降。差距在**动态运动**和**长序列**上尤为明显。

### 机器人自由度拓扑与重定向难度对比

| 机器人 | 总 DoF | 手臂 DoF | 腿部 DoF | 重定向难度 |
|:-------|:------:|:--------:|:--------:|:----------:|
| Unitree G1 | 29 | 7×2 | 6×2 | 中等 |
| Unitree H1 | 19 | 4×2 | 6×2 | 低（自由度少） |
| Booster T1 | 23 | 5×2 | 6×2 | 中等 |
| Fourier GR3 | 31 | 7×2 | 6×2 | 高 |

自由度少的机器人（如 H1 的 19 DoF）反而更容易训练，因动作空间更低维；自由度多的机器人（如 GR3 的 31 DoF）需要更多训练数据覆盖全部动作空间。

### 各机器人配置要点

| 机器人 | 注意事项 | 推荐参数 |
|:-------|:---------|:---------|
| Unitree G1 (29 DoF) | 手臂缩放 0.8，注意初始手臂位置避免自碰撞 | damping=5e-1, max_iter=10 |
| Unitree H1 (19 DoF) | 无手腕自由度，手臂 IK 更简单 | damping=5e-1, max_iter=8 |
| Booster T1 (23 DoF) | 注意 Waist 坐标系转换 | 检查 rotation offsets |
| Fourier N1 | 较小的机器人，检查缩放比例 | 可能需要调小 scale_table |
| Galaxea R1 Pro | 轮式底座，注意地面接触模型 | ground_height 需要精确 |

# 参考文献与前沿方向

本报告所涉及的算法诊断、物理分析和全栈解决方案，深度参考并提炼自以下前沿人形机器人和具身智能领域的重大研究成果：

*   **GMR (General Motion Retargeting)**: João Pedro Araújo, Yanjie Ze, et al., *Retargeting Matters: General Motion Retargeting for Humanoid Motion Tracking*. 深入剖析了非均匀缩放对减少滑移、穿地等物理伪影对下游强化学习跟踪的奠基性作用。
*   **BeyondMimic**: Hybrid Robotics, *BeyondMimic: From Motion Tracking to Versatile Humanoid Control via Guided Diffusion*. 实现了通过状态-动作协同扩散（State-Action Co-diffusion）结合测试时引导（Classifier Guidance），使模仿策略具备了零样本避障、导航和多技能修补合成的强力泛化能力。
*   **ASAP**: Carnegie Mellon University RI, *Aligning Simulation and Real-World Physics for Learning Agile Humanoid Whole-Body Skills*. 提出了利用 Sim-to-Real-to-Simulation 闭环链路中的残差动作（Delta Action）模型来拟合真实电机的背隙与摩擦力，实现了超高敏捷度的真机部署。
*   **PhySINK & NMR**: Academic efforts on Physics-informed Neural Retargeting, 采用包含关节屏障限位和接地、防滑三大物理损耗的形状自适应优化，彻底净化了重定向源头的数据。
*   **OmniRetarget**: Laplacian Interaction Mesh techniques for Loco-manipulation and closed-loop contact preservation. 解决了多接触复杂任务下双臂协作及地面贴合问题。