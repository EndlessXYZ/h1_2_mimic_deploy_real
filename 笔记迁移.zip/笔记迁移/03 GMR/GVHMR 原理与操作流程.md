# GVHMR（Gravity-View Human Motion Recovery）世界坐标系人体运动恢复系统原理与操作流程

本教程将从 arXiv 论文与 GitHub 开源仓库出发，剖析 GVHMR 如何从单目 RGB 视频中恢复重力对齐的世界坐标系人体运动（SMPL-X 格式），覆盖核心原理、网络架构、安装配置及完整操作流程。

> 参考文献：
> - arXiv: [2409.06662](https://arxiv.org/abs/2409.06662) *World-Grounded Human Motion Recovery via Gravity-View Coordinates*
> - GitHub: [github.com/zju3dv/GVHMR](https://github.com/zju3dv/GVHMR)
> - 项目主页: [zju3dv.github.io/gvhmr](https://zju3dv.github.io/gvhmr/)
> - 会议: SIGGRAPH Asia 2024 (Conference Track)

---

## 1. 背景：从单目视频恢复世界坐标系人体运动

### 1.1 问题定义

**World-Grounded Human Motion Recovery（世界坐标系人体运动恢复）** 的目标是从单目 RGB 视频中重建出连续、重力对齐的 3D 人体运动序列。与传统的**相机空间人体运动恢复**（如 HMR、PARE 等）不同，世界坐标系运动需要同时估计：

- **人体姿态与形状**：局部 body pose $\theta^{t} \in \mathbb{R}^{21 \times 3}$ 和 shape $\beta \in \mathbb{R}^{10}$（SMPL-X 参数）
- **相机空间轨迹**：人体相对于相机的朝向 $\Gamma_{c}^{t} \in \mathbb{R}^{3}$ 和平移 $\tau_{c}^{t} \in \mathbb{R}^{3}$
- **世界空间轨迹**：人体在重力感知世界坐标系中的朝向 $\Gamma_{w}^{t} \in \mathbb{R}^{3}$ 和平移 $\tau_{w}^{t} \in \mathbb{R}^{3}$

世界坐标系运动是更高级应用的**基础数据源**，如文本到运动生成（text-to-motion）、人形机器人模仿学习（通过 GMR 重定向）等。

### 1.2 现有方法的缺陷

| 方法 | 策略 | 主要问题 |
| :--- | :--- | :--- |
| **SLAM + 相机空间 HMR** | 用相机位姿将相机空间结果转换到世界空间 | 不保证重力对齐；平移和旋转误差随时间累积 |
| **WHAM** | 自回归 RNN 预测相对全局位姿 | 需要良好初始化；长序列误差累积；重力方向不一致 |
| **SLAHMR / PACE** | 结合 SLAM 和运动先验的优化框架 | 优化耗时；长视频收敛困难；不保证重力对齐 |

### 1.3 GVHMR 的核心思路

GVHMR 的核心洞察是：**人类可以凭直觉判断单张图片中人的重力对齐姿态**，而对连续两帧之间只需要估计**绕重力方向的 1-DoF 旋转**（比全 3-DoF 更容易）。

```text
现有方案（WHAM）：
  逐帧自回归预测 → 误差随帧数累积 → 长序列质量下降

GVHMR 方案：
  每帧独立估计 GV 坐标系姿态 → 利用相机旋转对齐全局轨迹 → 无累积误差
```

---

## 2. 核心技术原理：Gravity-View (GV) 坐标系

### 2.1 坐标系定义

GV 坐标系是 GVHMR 的核心创新。对每一帧图像，定义唯一的 GV 坐标系：

```text
GV 坐标系构建过程：
                   相机空间
    ┌──────────────────────────────────────┐
    │  已知：人体朝向 Γ_c、重力方向 g、       │
    │        相机视线方向 view=[0,0,1]^T     │
    └──────────────────┬───────────────────┘
                       │
                       ▼
    ┌──────────────────────────────────────┐
    │  Step 1: y 轴 = 重力方向 g            │
    │  Step 2: x 轴 = y × view（叉积）      │
    │  Step 3: z 轴 = x × y（右手定则）      │
    │  Step 4: Γ_GV = R_c2GV · Γ_c         │
    │         R_c2GV = [x, y, z]^T          │
    └──────────────────────────────────────┘
```

数学上，重力方向向量 $\vec{g}$ 和相机视线方向 $\overrightarrow{view} = [0,0,1]^T$ 定义了 GV 坐标系的三个轴：

$$\vec{y} = \vec{g}$$
$$\vec{x} = \vec{y} \times \overrightarrow{view}$$
$$\vec{z} = \vec{x} \times \vec{y}$$

人体在 GV 坐标系中的朝向为：$\Gamma_{GV} = R_{c2GV} \cdot \Gamma_{c} = [\vec{x}, \vec{y}, \vec{z}]^T \cdot \Gamma_{c}$

#### 实现细节与边界处理

对应代码位于 `hmr4d/utils/geo/hmr_global.py` 的 `get_R_c2gv()` 函数。核心实现步骤：

```python
# 1. 重力方向默认在世界坐标系中为 [0, 0, -1]（即 Z 轴负方向指向地心）
axis_gravity_in_w = [0, 0, -1]

# 2. 将重力方向从世界坐标系转换到相机坐标系
axis_y_of_gv = R_w2c @ axis_gravity_in_w  # (*, 3)

# 3. 计算 GV x 轴（重力方向与视线方向的叉积）
axis_x_of_gv = axis_y_of_gv × axis_z_in_c  # cross product

# 4. 归一化，处理边界情况
#    当重力方向与视线方向平行时（norm < 1e-5），
#    直接使用相机 x 轴 [1, 0, 0] 作为 GV x 轴
if norm < 1e-5:
    axis_x_of_gv = [1.0, 0.0, 0.0]

# 5. 计算 GV z 轴（右手定则）
axis_z_of_gv = axis_x_of_gv × axis_y_of_gv

# 6. 构建旋转矩阵 R_gv2c = [x|y|z]，转置得 R_c2gv
R_gv2c = stack([axis_x_of_gv, axis_y_of_gv, axis_z_of_gv], axis=-1)
R_c2gv = R_gv2c.transpose()
```

关键边界情况：
- **重力方向与视线方向平行**（如相机正对地面或正对天空）：此时 `axis_y_of_gv × view` 的结果趋近于零向量，代码回退使用相机 x 轴作为 GV x 轴，确保了数值稳定性
- **SMPL-X 输出的朝向格式**：网络输出 $\Gamma_{GV}^{t}$ 为 axis-angle 格式 `(L, 3)`，经过 `axis_angle_to_matrix` 转换为旋转矩阵后参与后续坐标变换

### 2.2 GV 坐标系的优势

1. **自然重力对齐**：y 轴与重力方向一致，人体姿态天然与重力方向对齐，物理合理
2. **每帧唯一确定**：同一帧图像有且只有一个 GV 坐标系，消除了世界坐标系的旋转歧义
3. **降低学习难度**：网络只需要学习从图像到 GV 坐标系的映射，而非从图像到任意世界坐标系的映射
4. **并行处理**：每帧独立估计，无需自回归，可利用 Transformer 并行处理整个序列

### 2.3 全局轨迹恢复算法

由于每帧有独立的 $GV_{t}$ 坐标系，需要将所有帧统一到一致的世界坐标系中。对应代码位于 `hmr4d/model/gvhmr/pipeline/gvhmr_pipeline.py` 的 `get_smpl_params_w_Rt_v2()` 函数。

#### 全局朝向恢复（核心 1-DoF 旋转）

关键洞察：相邻帧之间 GV 坐标系的相对旋转 $R_{\Delta GV}$ 仅绕重力方向（y 轴）发生，这是一个 **1-DoF 问题**，比全 3-DoF 旋转估计更加稳健。

完整算法流程：

```text
输入：
  - Γ_GV^t: 每帧在 GV 坐标系中的人体朝向 (B, L, 3)
  - Γ_c^t: 每帧在相机坐标系中的人体朝向 (B, L, 3)
  - cam_angvel: 相邻帧间相机相对旋转的 6D 表示 (B, L, 6)

Step 1: 从 cam_angvel 恢复相机相邻帧间旋转 R_t_to_tp1
  R_t_to_tp1 = rotation_6d_to_matrix(cam_angvel)  # (B, L, 3, 3)

Step 2: 计算 GV 坐标系中的相机视线方向
  R_c2gv = R_gv @ R_c^T            # (B, L, 3, 3)
  view_axis_gv = R_c2gv[:, :, :, 2] # 取第 3 列，即视线方向在 GV 中的表示

Step 3: 利用相机相对旋转预测下一帧的视线方向
  R_cnext2gv = R_c2gv @ R_t_to_tp1^T
  view_axis_gv_next = R_cnext2gv[..., 2]

Step 4: 去除重力分量（y 轴），仅保留 xz 平面 → 1-DoF 旋转
  vec1 = view_axis_gv, 设 y=0
  vec2 = view_axis_gv_next, 设 y=0
  计算 vec1→vec2 的旋转角度 → 得到 1-DoF 的 R_tp1_to_t

Step 5: 高斯平滑 → 减少 VO 噪声
  aa_tp1_to_t = gaussian_smooth(aa_tp1_to_t, dim=-2)

Step 6: 逐帧累积，得到每帧到第 0 帧的旋转
  R_t_to_0[t] = R_t_to_0[t-1] @ R_tp1_to_t[t]

Step 7: 将 GV 朝向变换到统一世界坐标
  global_orient = R_t_to_0 @ R_gv

Step 8: 坐标系转换（any→ay）：将任意朝向的 y 轴对齐到标准重力方向
  global_orient, transl, _ = get_tgtcoord_rootparam(tsf="any->ay")
```

关键设计：
- **1-DoF 约束**通过去除视线方向向量的 y 分量实现，大大简化了旋转估计问题
- **高斯平滑**减少 SimpleVO 的噪声影响
- **"any→ay" 转换**统一所有轨迹到标准世界坐标系（y 轴向上）

#### 全局平移恢复

全局平移通过预测 SMPL 坐标系中的根速度（root velocity）并逐帧累加得到：

```text
Step 1: 网络预测本地根速度 v_root^t（SMPL 坐标系）

Step 2: 将本地速度转换到世界坐标系
  v_global^t = R_t @ v_root^t

Step 3: 累积积分得到全局平移
  τ_w^t = Σ_{i=0}^{t} v_global^i  (从 τ_w^0 = 0 开始)

Step 4: 通过帧间旋转将 y 轴重对齐到标准重力方向
```

对应实现：`hmr4d/utils/geo/hmr_global.py` 中的 `rollout_local_transl_vel()` 函数：
- `local_transl_vel` 定义在 SMPL 局部坐标系中
- 通过 `global_orient_R @ local_transl_vel` 转换到世界坐标系
- 使用 `torch.cumsum()` 进行累积积分

---

## 3. 系统架构与网络设计

### 3.1 整体流水线

```text
┌─────────────────────────────────────────────────────────────────────┐
│                        输入：单目 RGB 视频                            │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│  预处理阶段（Preprocessing）                                          │
│                                                                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────────┐   │
│  │  YOLO    │  │ ViTPose  │  │ ViT(HMR2)│  │ SimpleVO/DPVO    │   │
│  │ 人体检测  │  │ 2D关键点  │  │ 图像特征  │  │ 视觉里程计       │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────────┘   │
│      │              │              │                 │              │
│      ▼              ▼              ▼                 ▼              │
│  边界框 bbx    2D 关键点 kp2d    ViT 特征      相机旋转 R_w2c      │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│  GVHMR 网络推理                                                     │
│                                                                     │
│  逐帧 Token（融合 bbx + kp2d + ViT 特征 + 相机角速度）                │
│         │                                                           │
│         ▼                                                           │
│  Transformer Encoder（RoPE 位置编码，因果注意力掩码）                  │
│         │                                                           │
│         ▼                                                           │
│  多任务 MLP Head                                                    │
│   ├── GV 朝向 Γ_GV^t    ← 核心输出                                  │
│   ├── 根速度 v_root^t   ← 全局平移恢复用                             │
│   ├── 静止概率 p_stat^t ← 手脚静止检测，减少足部滑动                   │
│   └── 相机空间 SMPL-X   ← 兼容现有评估基准                            │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│  后处理：全局轨迹恢复                                                 │
│                                                                     │
│  ① 每帧 Γ_GV^t 通过 R_Δ^t → 对齐到统一世界坐标系 → Γ_w^t            │
│  ② 根速度 v_root^t → 积分 → 全局平移 τ_w^t                          │
│  ③ 静止概率 p_stat^t → 约束足部/手部位置 → 减少滑动伪影               │
│                                                                     │
│  输出：SMPL-X 参数 + 世界坐标系轨迹 (.pt 文件)                        │
└─────────────────────────────────────────────────────────────────────┘
```

### 3.2 预处理模块详解

预处理阶段由四个独立子模块组成，从原始视频中提取 GVHMR 网络所需的输入特征：

| 模块 | 功能 | 输出 |
| :--- | :--- | :--- |
| **Tracker (YOLO)** | 人体目标跟踪，获取每帧的边界框 | `bbx_xyxy` (L, 4), `bbx_xys` (L, 3) |
| **ViTPose** | 2D 人体关键点检测（COCO17 骨架） | `kp2d` (L, 17, 3) |
| **Extractor (ViT/HMR2)** | 基于裁剪人体区域的图像特征提取 | `vit_features` (L, 1024) 或 (L, 512, 64) |
| **SimpleVO / DPVO** | 视觉里程计，估计相机相对旋转 | `R_w2c` (L, 3, 3) |

#### 视觉里程计选项

GVHMR 提供了两种 VO 方案：

- **SimpleVO（默认）**：基于 SIFT 特征匹配 + 对极几何，轻量高效，兼容性好
- **DPVO（可选）**：基于深度学习的 VO，精度更高但需要额外的 CUDA 编译和模型权重

对于**固定摄像头**场景，可使用 `-s`（静态相机）参数跳过 VO 阶段（`R_w2c` 设置为单位矩阵）。

#### SimpleVO 实现细节

代码位于 `hmr4d/utils/preproc/relpose/simple_vo.py`，核心流程：

```text
① 将视频降采样到原始分辨率的 50%（scale=0.5）
② 以 step=8 的间隔采样关键帧
③ 对每对相邻关键帧：
   └─ 使用 SIFT 提取特征点
   └─ 特征匹配（Matcher）
   └─ 基于 pycolmap 求解对极几何 → 本征矩阵 → 相对位姿 T_delta
④ 累乘相对位姿：T_w2c[t+1] = T_delta[t] @ T_w2c[t]
⑤ 插值缺失帧，恢复完整帧率的位姿

相机参数：
  - 默认焦距：24mm（全画幅等效），可通过 --f_mm 调整
  - iPhone 15p 不同镜头典型值：[13mm, 24mm, 48mm, 77mm]

并行加速：
  - 支持多线程并行（num_workers 参数）
  - 每个线程独立持有 Matcher/Solver 实例

### 3.3 网络架构

GVHMR 的网络核心是一个 **Transformer Encoder**，配备 Rotary Positional Embedding (RoPE)。输入输出 pipeline 的实现位于 `hmr4d/model/gvhmr/pipeline/gvhmr_pipeline.py`（`Pipeline` 类），核心网络架构位于 `hmr4d/network/gvhmr/relative_transformer.py`（`NetworkEncoderRoPE` 类）。

#### 输入 Token 的详细构成

每帧构建一个 token，融合多种模态的特征：

```text
Token_t 构成（对应 relative_transformer.py 的 forward 方法）：
┌────────────────────────────────────────────────────────────────┐
│  ① f_obs: 2D 关键点 (B, L, 17, 3)                              │
│     └─ visible_mask 过滤低置信度关键点                             │
│     └─ learned_pos_linear: 2→32，每个关键点独立编码                │
│     └─ learned_pos_params: 17×32 的可学习参数（用于遮挡时替换）      │
│     └─ embed_noisyobs: 17×32=544 → MLP → 512-dim 主 token       │
│                                                                 │
│  ② f_cliffcam: CLIFF-Cam 参数 (B, L, 3)                         │
│     └─ bbx 信息编码（bbox center + scale 在完整图像中的归一化坐标）   │
│     └─ Linear(3→512) + SiLU + zero-initialized Linear → 注入    │
│                                                                 │
│  ③ f_cam_angvel: 相机角速度 (B, L, 6)                           │
│     └─ 相邻帧间相机旋转的 6D 表示（rotation_6d）                   │
│     └─ Linear(6→512) + SiLU + zero-initialized Linear → 注入    │
│                                                                 │
│  ④ f_imgseq: ViT 图像特征 (B, L, 1024)                          │
│     └─ 来自 HMR2.0 的 ViT 特征提取器                              │
│     └─ LayerNorm(1024) + zero-initialized Linear(1024→512) → 注入│
│                                                                 │
│  最终 Token_t = 主 token + 各 condition 嵌入（逐元素相加）          │
└────────────────────────────────────────────────────────────────┘
```

关键设计要点：

- **Zero-initialized 跳跃连接**：所有 condition embedding 的最后一层线性层均使用 `zero_module`（初始化为零），这意味着训练开始时网络仅依赖 2D 关键点信息，条件信息通过梯度逐步引入。这种设计避免了训练初期条件信息的噪声干扰。
- **遮挡处理**：当 2D 关键点的置信度低于 0.5 时，使用可学习的 `learned_pos_params` 替代预测值，增强了网络对遮挡的鲁棒性。

#### Transformer Encoder 与 RoPE

**网络结构参数：**
- 12 层 Transformer Encoder Block
- 隐层维度 512，8 个注意力头（每头 64 维）
- MLP 扩展比 4.0（512→2048→512）
- Dropout 0.1

**RoPE 位置编码**（`hmr4d/network/base_arch/embeddings/rotary_embedding.py`）：

RoPE 的核心思想是在注意力计算之前，对 query 和 key 向量施加与位置相关的旋转变换：

```
RoPE 数学形式：
  对于位置 i 处的 query 向量 q_i，应用旋转：
  RoPE(q_i, i) = q_i · cos(iθ) + rotate_half(q_i) · sin(iθ)
  
  其中 θ_k = 10000^{-2k/d}，d 为每头维度（64）
  预缓存最大 4096 个位置的旋转变换
```

RoPE 的优势：
- **相对位置感知**：注意力分数 $q_i^T k_j$ 天然包含 $(i-j)$ 的相对位置信息
- **长序列友好**：预缓存编码可达 4096 帧，超出时可动态扩展
- **与因果注意力掩码兼容**：支持无限长序列的并行推理

#### 推理时的因果注意力掩码

对应 `relative_transformer.py` 中 `forward()` 方法的实现：

```text
最大感受野限制（max_len = 120 帧）：
  
  场景 A — 序列长度 ≤ 120：
    使用全连接注意力（无掩码）
  
  场景 B — 序列长度 > 120：
    每帧 i 的注意力范围：[max(0, i-60), min(L, i+60)]
    即每帧只能看到前后各 60 帧（共 120 帧感受野）
```

```python
# 伪代码实现
if L > max_len:  # L > 120
    attnmask = 全 True 掩码
    for i in range(L):
        min_ind = max(0, i - max_len//2)   # 左边界
        max_ind = min(L, i + max_len//2)   # 右边界
        attnmask[i, min_ind:max_ind] = False  # 允许关注的范围设为 False
```

这种设计避免了复杂的滑动窗口策略，同时实现了无限长序列的并行推理。

### 3.4 网络输出

| 输出 | 维度 | 用途 |
| :--- | :--- | :--- |
| GV 朝向 $\Gamma_{GV}^{t}$ | (L, 3) | 核心输出，用于恢复全局朝向 |
| 根速度 $v_{root}^{t}$ | (L, 3) | 在 SMPL 坐标系中，用于恢复全局平移 |
| 静止概率 $p_{stat}^{t}$ | (L, 6) | 左脚踝、左脚、右脚踝、右脚、左手腕、右手腕静止 logits，用于后处理优化 |
| 相机空间 SMPL-X | 21×3 pose + 10 shape | 兼容现有评估基准和可视化 |
| 世界空间 SMPL-X | 21×3 pose + 10 shape | 最终重力对齐输出 |

### 3.5 后处理：足部滑动优化与 IK 细化

后处理代码位于 `hmr4d/model/gvhmr/utils/postprocess.py`，包含三个阶段：

#### 阶段一：静止关节约束（`pp_static_joint`）

GVHMR 网络预测每帧 6 个关键点的静止 logits：
- joint_ids = [7, 10, 8, 11, 20, 21]（左脚踝、左脚、右脚踝、右脚、左手腕、右手腕）

```text
训练时：
  通过真实关节速度计算静止标签（velocity < 0.25 m/s 即为静止）
  → 二分类 BCE 损失监督
  
推理时：
  ① 对静止 logits 取 sigmoid，阈值 > 0 判定为静止
  ② 计算静止关节的位移 pred_disp（这些位移本应为零）
  ③ 从全局平移中减去 pred_disp → 消除足部滑动
  
  特殊处理：
  - 静态相机模式（pp_static_joint_cam）：
    额外利用"第一帧的 T_c2w 对所有帧有效"的先验
    将相机空间结果转换到世界空间作为校正参考
```

#### 阶段二：地面对齐

```text
① 计算所有关节点在 y 方向的最小值 ground_y
② 平移全局轨迹，使最低点贴地（y=0）
   post_w_transl[..., 1] -= ground_y
```

#### 阶段三：CCD IK 细化（`process_ik`）

使用 Cyclic Coordinate Descent (CCD) Inverse Kinematics 进一步优化：

```text
输入：全局 FK 后的关节位置 + 静止概率

① 利用静止概率融合位移（sebastian-style rollout merge）：
   〃静止关节保持上一帧位置〃
   post_target_j3d[i] = prev * static_conf + this * (1 - static_conf)

② 对四肢分别进行 IK 求解（max_iter=2）：
   - 左腿链：[0, 1, 4, 7, 10] → 目标：左脚踝、左脚
   - 右腿链：[0, 2, 5, 8, 11] → 目标：右脚踝、右脚
   - 左手链：[9, 13, 16, 18, 20] → 目标：左手腕
   - 右手链：[9, 14, 17, 19, 21] → 目标：右手腕

③ 将 IK 后的旋转矩阵转回 axis-angle，更新 body_pose
```

这个过程显著提升了全局运动轨迹的真实感，特别是在足部接触地面时消除滑动伪影。

### 3.6 训练损失函数

训练损失位于 `hmr4d/model/gvhmr/pipeline/gvhmr_pipeline.py` 的 `compute_extra_incam_loss()` 和 `compute_extra_global_loss()` 函数。总体损失由以下部分组成：

#### 主损失（Simple Loss）

直接对 endecoder 编码后的特征向量计算 MSE：

```text
L_simple = MSE(pred_x, target_x)
pred_x ∈ ℝ¹⁵¹：端到端预测的编码特征
target_x：ground truth 编码特征，包含：
  - body_pose_r6d (0:126)     → 身体姿态
  - betas (126:136)           → 体型
  - global_orient_r6d (136:142) → 相机空间全局朝向
  - global_orient_gv_r6d (142:148) → GV 坐标系全局朝向
  - local_transl_vel (148:151) → 本地根速度
```

#### 相机空间损失

| 损失项 | 权重 | 说明 |
| :--- | :--- | :--- |
| **cr_j3d_loss** | MSE | 根对齐的关节位置误差（Root-aligned MPJPE） |
| **transl_c_loss** | MSE | 相机空间平移的弱透视相机参数损失 |
| **j2d_loss** | MSE | 2D 重投影损失（仅在 BEDLAM/H36M 训练，3DPW 数据跳过） |
| **cr_verts_loss** | MSE | 根对齐的 SMPL 顶点误差（437 个顶点） |
| **verts2d_loss** | MSE | 顶点重投影损失 |

#### 世界空间损失

| 损失项 | 权重 | 说明 |
| :--- | :--- | :--- |
| **transl_w_loss** | L1 | 全局平移的 rollout 轨迹损失（仅在 BEDLAM/H36M 数据上计算，3DPW 跳过） |
| **static_conf_bce** | BCE | 手脚静止概率的二分类损失（velocity threshold = 0.15m/s） |

#### 训练数据

| 数据集 | 用途 | 特点 |
| :--- | :--- | :--- |
| **AMASS** | 纯运动数据 | 仅提供 body pose + betas，提供相机空间监督 |
| **BEDLAM** | 含图像 + GT | 提供完整的相机/世界空间监督，含重投影损失 |
| **H36M** | 含图像 + GT | 提供完整的相机/世界空间监督 |
| **3DPW** | 测试集/部分训练 | 训练时仅监督相机空间（spv_incam_only=True），世界空间损失跳过 |

---

### 3.7 编码解码器（EnDecoder）

`hmr4d/model/gvhmr/utils/endecoder.py` 中的 `EnDecoder` 类负责特征编码与解码：

```text
编码（encode）：
  GT SMPL 参数 → axis-angle → rotation_6d → 拼接 → 归一化 → (B, L, 151)

解码（decode）：
  网络输出 (B, L, 151) → 反归一化 → 拆分为各分量 → rotation_6d → axis-angle

统计数据：
  基于训练集统计的 mean 和 std 用于归一化
  支持多种统计模式（DEFAULT_01, MM_V1, MM_V2 等）
```

前向运动学（FK）通过 `fk_v2()` 实现：
- 将 body_pose + global_orient 的 axis-angle 转换为旋转矩阵
- 结合 skeleton 和 betas 构建局部变换矩阵
- 通过 `forward_kinematics` 链式相乘得到全局关节位置

---

## 4. 性能与对比

### 4.1 推理速度

| 硬件 | 视频长度 | 网络推理时间 | 等效实时性 |
| :--- | :--- | :--- | :--- |
| RTX 4090 | 1430 帧 (~45s) | **280 ms** | ~160x 实时 |

注：不包括预处理（YOLO + ViTPose + ViT + VO）的时间。预处理通常也需要数百毫秒到数秒。

### 4.2 与主流方法对比

| 指标 | GVHMR | WHAM | TRAM |
| :--- | :--- | :--- | :--- |
| 重力对齐 | ✅ 天然对齐 | ❌ 不一致 | ❌ 无保证 |
| 误差累积 | ✅ 无（逐帧估计） | ❌ 有（自回归） | ⚠️ 部分（依赖 SLAM） |
| 额外精炼网络 | ❌ 不需要 | ❌ 不需要 | ✅ 需要 |
| 长序列处理 | ✅ 强（RoPE） | ❌ 弱（RNN 衰减） | ⚠️ 中等 |
| 并行推理 | ✅ 全序列并行 | ❌ 逐帧串行 | ⚠️ 部分 |
| 相机运动支持 | ✅ SimpleVO/DPVO | ❌ 假设静态/简单 | ✅ SLAM |

---

## 5. 安装与配置

### 5.1 环境安装

```bash
# 1. 克隆仓库
git clone https://github.com/zju3dv/GVHMR.git
cd GVHMR

# 2. 创建 conda 环境
conda create -y -n gvhmr python=3.10
conda activate gvhmr

# 3. 安装依赖
pip install -r requirements.txt
pip install -e .          # 可安装模式，其他项目可通过 extraPaths 引用

# 4. 创建输入/输出目录
mkdir inputs outputs
mkdir -p inputs/checkpoints
```

### 5.2 模型权重下载

需要下载以下预训练模型和人体模型：

```text
inputs/checkpoints/
├── body_models/
│   ├── smplx/SMPLX_{GENDER}.npz      # SMPL-X 人体模型（需从 smpl-x.is.tue.mpg.de 注册下载）
│   └── smpl/SMPL_{GENDER}.pkl        # SMPL 模型（渲染和评估用，需从 smpl.is.tue.mpg.de 下载）
├── gvhmr/
│   └── gvhmr_siga24_release.ckpt     # GVHMR 主模型权重（Google Drive）
├── hmr2/
│   └── epoch=10-step=25000.ckpt      # HMR2 特征提取权重（Google Drive）
├── vitpose/
│   └── vitpose-h-multi-coco.pth      # ViTPose 模型权重（Google Drive）
├── yolo/
│   └── yolov8x.pt                    # YOLOv8x 检测模型（Google Drive）
└── dpvo/
    └── dpvo.pth                      # DPVO 模型权重（可选，Google Drive）
```

> 预训练模型下载地址（Google Drive）：https://drive.google.com/drive/folders/1eebJ13FUEXrKBawHpJroW0sNSxLjh9xD

### 5.3 可选：DPVO 安装

SimpleVO 为默认选项，无需额外安装。如需使用 DPVO（更高精度但更慢）：

```bash
cd third-party/DPVO
wget https://gitlab.com/libeigen/eigen/-/archive/3.4.0/eigen-3.4.0.zip
unzip eigen-3.4.0.zip -d thirdparty && rm -rf eigen-3.4.0.zip
pip install torch-scatter -f "https://data.pyg.org/whl/torch-2.3.0+cu121.html"
pip install numba pypose
export CUDA_HOME=/usr/local/cuda-12.1/
export PATH=$PATH:/usr/local/cuda-12.1/bin/
pip install -e .
```

### 5.4 训练/评估数据准备（可选）

如需复现论文结果，需下载预处理数据集（Google Drive）：

```bash
cd inputs
# 训练集
tar -xzvf AMASS_hmr4d_support.tar.gz
tar -xzvf BEDLAM_hmr4d_support.tar.gz
tar -xzvf H36M_hmr4d_support.tar.gz
# 测试集
tar -xzvf 3DPW_hmr4d_support.tar.gz
tar -xzvf EMDB_hmr4d_support.tar.gz
tar -xzvf RICH_hmr4d_support.tar.gz
```

---

## 6. 操作流程

### 6.1 单视频推理（最常用）

```bash
# 基本用法（静态摄像头，自动跳过 VO）
python tools/demo/demo.py --video=path/to/video.mp4 -s

# 如果相机有运动（使用 SimpleVO，默认）
python tools/demo/demo.py --video=path/to/video.mp4

# 指定焦距（毫米，针对不同镜头）
# iPhone 15p: [0.5x→13mm, 1x→24mm, 2x→48mm, 3x→77mm]
python tools/demo/demo.py --video=path/to/video.mp4 -s --f_mm=24

# 使用 DPVO（更高精度）
python tools/demo/demo.py --video=path/to/video.mp4 --use_dpvo

# 显示中间结果（边界框、2D 骨架等）
python tools/demo/demo.py --video=path/to/video.mp4 -s --verbose

# 指定输出目录
python tools/demo/demo.py --video=path/to/video.mp4 -s --output_root=outputs/my_result
```

### 6.2 批量处理

```bash
python tools/demo/demo_folder.py \
    -f inputs/demo/folder_in \
    -d outputs/demo/folder_out \
    -s    # 静态相机
```

### 6.3 推理流程说明

执行 `demo.py` 时，系统自动完成以下步骤：

```text
Step 1: 参数解析与配置加载
  ├── 读取视频基本信息（长度、宽、高）
  └── 创建输出目录

Step 2: 预处理（run_preprocess）
  ├── YOLO 人体检测与跟踪 → 保存 bbx（bbx_xyxy + bbx_xys）
  ├── ViTPose 2D 关键点检测 → 保存 vitpose（kp2d: L, 17, 3）
  ├── ViT 图像特征提取 → 保存 vit_features（f_imgseq: L, 1024）
  └── SimpleVO/DPVO 相机位姿估计 → 保存 slam（R_w2c: L, 3, 3）
       ├── 静态相机：R_w2c = 单位矩阵 × L
       ├── SimpleVO：SIFT + 对极几何 → numpy (L, 4, 4)
       └── DPVO：深度学习 VO → quaternion (L, 7)

Step 3: 数据加载与模型推理（load_data_dict）
  ├── 根据是否静态相机加载 R_w2c
  ├── 根据 --f_mm 或图像尺寸估算 K 矩阵（内参）
  ├── 计算 cam_angvel = rotation_6d(R_w2c[t+1] @ R_w2c[t]^T)
  ├── 组装 data dict（含 kp2d, bbx_xys, K_fullimg, cam_angvel, f_imgseq）
  ├── 加载 GVHMR 模型权重
  ├── model.predict(data) → 生成预测结果
  └── 保存 .pt 结果文件

Step 4: 可视化渲染（自动）
  ├── render_incam: 相机空间 3D 渲染视频
  ├── render_global: 世界坐标系 3D 渲染视频
  └── merge_videos_horizontal: 左右对比合并视频
```

### 6.4 复现论文结果

```bash
# 测试（3DPW + RICH + EMDB 联合测试）
python tools/train.py \
    global/task=gvhmr/test_3dpw_emdb_rich \
    exp=gvhmr/mixed/mixed \
    ckpt_path=inputs/checkpoints/gvhmr/gvhmr_siga24_release.ckpt

# 训练（从头训练）
# 注意：不同 GPU 配置可能导致结果略有差异
python tools/train.py exp=gvhmr/mixed/mixed
```

### 6.5 输出文件说明

执行成功后，输出目录包含以下文件：

```text
outputs/demo/{video_name}/
├── preprocess/                    # 预处理中间结果
│   ├── bbx.pt                    # 边界框
│   ├── vitpose.pt                # 2D 关键点
│   ├── vit_features.pt           # ViT 特征
│   └── slam.pt                   # 相机位姿（非静态相机时）
├── hmr4d_results.pt              # ★ 核心输出：SMPL-X 参数 + 轨迹
├── incam_video.mp4               # 相机空间渲染视频
├── global_video.mp4              # 世界坐标系渲染视频
└── incam_global_horiz.mp4        # 左右对比合并视频
```

### 6.6 与 GMR 的集成

GVHMR 输出的 `.pt` 文件可直接被 GMR 的 `gvhmr_to_robot.py` 脚本使用，实现 `RGB 视频 → GVHMR → GMR → BeyondMimic` 的完整流水线：

```bash
# Step 1: GVHMR 从视频提取人体运动
python tools/demo/demo.py --video=path/to/video.mp4 -s

# Step 2: GMR 重定向到机器人
cd ~/Documents/gmr
python scripts/gvhmr_to_robot.py \
    --gvhmr_pred_file <path_to_hmr4d_results.pt> \
    --robot unitree_g1 \
    --record_video \
    --save_path motions/G1/G1.pkl

# Step 3: 转 CSV（供 BeyondMimic 使用）
python3 scripts/batch_gmr_pkl_to_csv.py --folder motions/G1/
```

---

## 7. 仓库代码结构

```text
GVHMR/
├── hmr4d/                              # 核心 Python 包
│   ├── __init__.py                     # 包初始化，定义 PROJ_ROOT
│   ├── build_gvhmr.py                  # 模型构建器（demo 用）
│   │
│   ├── configs/                        # Hydra 配置
│   │   ├── demo.yaml                   # Demo 配置
│   │   └── ...                         # 训练/测试配置
│   │
│   ├── model/                          # 模型实现
│   │   ├── common_utils/               # 通用工具
│   │   └── gvhmr/                      # GVHMR 模型
│   │       ├── gvhmr_pl_demo.py        # ★ Demo PL 模块（推理入口）
│   │       ├── gvhmr_pl.py             # 训练 PL 模块
│   │       └── gvhmr.py                # 核心模型定义
│   │
│   ├── network/                        # 网络架构
│   │   ├── base_arch/                  # 基础 Transformer 架构
│   │   │   ├── attention.py            # 注意力层
│   │   │   ├── transformer.py          # Transformer Encoder
│   │   │   └── positional_embedding.py # RoPE 位置编码
│   │   ├── gvhmr/                      # GVHMR 特有网络组件
│   │   │   └── gvhmr_net.py            # 多任务 MLP heads
│   │   └── hmr2/                       # HMR2 特征提取网络
│   │
│   ├── dataset/                        # 数据集（AMASS, 3DPW, EMDB 等）
│   ├── datamodule/                     # Lightning DataModule
│   │
│   └── utils/                          # 工具函数
│       ├── preproc/                    # ★ 预处理模块
│       │   ├── tracker.py              # YOLO 人体检测跟踪
│       │   ├── extractor.py            # ViT 特征提取
│       │   ├── vitpose_extractor.py    # ViTPose 2D 关键点
│       │   ├── simple_vo.py            # ★ SimpleVO（默认 VO）
│       │   └── slam.py                 # DPVO 接口（可选）
│       ├── geo/                        # 几何工具（坐标变换、相机模型）
│       │   ├── hmr_cam.py              # 相机参数估计
│       │   └── geo_transform.py        # 坐标变换函数
│       ├── vis/                        # 可视化（Renderer）
│       │   └── renderer.py             # PyTorch3D 渲染器
│       ├── body_model/                 # SMPL-X / SMPL 模型接口
│       ├── smplx_utils.py              # SMPL-X 工具函数
│       ├── video_io_utils.py           # 视频读写工具
│       ├── net_utils.py                # 网络工具
│       └── pylogger.py                 # 日志
│
├── tools/                              # 入口脚本
│   ├── demo/
│   │   ├── demo.py                     # ★ 单视频推理主入口
│   │   └── demo_folder.py              # 批量推理
│   ├── train.py                        # 训练入口
│   ├── bench/                          # 性能基准测试
│   ├── video/                          # 视频处理工具
│   └── unitest/                        # 单元测试
│
├── docs/
│   └── INSTALL.md                      # 安装指南
│
├── third-party/                        # DPVO 子模块
├── requirements.txt                    # Python 依赖
├── setup.py                            # 安装脚本
└── pyproject.toml                      # 项目元数据
```

---

## 8. 常见问题与排查

### 8.1 推理速度慢

**原因**：预处理阶段（YOLO + ViTPose + ViT）较慢，特别是 CPU 环境。

**解决方案**：
- 确保所有预处理模块在 GPU 上运行（默认自动检测 CUDA）
- 使用 `-s`（静态相机）跳过 VO 阶段
- 减少视频分辨率和帧率

### 8.2 渲染视频中人体抖动/不自然

**原因**：
- VO 估计的相机旋转有噪声
- SimpleVO 在纹理不足的场景下精度下降

**解决方案**：
- 尝试 `--use_dpvo` 启用 DPVO（更高精度 VO）
- 视频中避免过快或剧烈相机运动
- 增加场景纹理（避免白墙等无纹理区域）

### 8.3 输出结果出现足部滑步

**原因**：静止概率预测不准，或后处理约束不够强。

**解决方案**：
- 确保视频中人体的脚部接触地面的帧包含在镜头内
- 避免遮挡严重的镜头

### 8.4 SMPL-X 模型加载失败

**原因**：未正确下载 SMPL-X 模型文件，或文件路径不匹配。

**解决方案**：
- 确认 `inputs/checkpoints/body_models/smplx/` 目录下存在 `SMPLX_NEUTRAL.npz` 等文件
- 从 https://smpl-x.is.tue.mpg.de/ 注册下载
- 确认文件后缀为 `.npz`（而非 `.pkl`）

### 8.5 CUDA 内存不足

**原因**：视频分辨率太高或帧数太多。

**解决方案**：
- 降低视频分辨率（如 720p → 480p）
- 隔帧采样（降低 FPS 到 15 或 10）
- 减小 batch size（注意 demo.py 默认自动处理长序列）

### 8.6 Google Drive 下载慢

**原因**：国内网络环境限制。

**解决方案**：
- 使用代理下载（参考系统代理设置）
- 使用 Colab / HuggingFace 在线 Demo 先体验功能
  - Colab: https://colab.research.google.com/drive/1N9WSchizHv2bfQqkE9Wuiegw_OT7mtGj
  - HuggingFace: https://huggingface.co/spaces/LittleFrog/GVHMR

---

## 附录：与相关方法的技术对比

```text
┌───────────────┬────────────────────┬───────────────────┬──────────────────┐
│   技术维度     │       GVHMR         │       WHAM        │       TRAM       │
├───────────────┼────────────────────┼───────────────────┼──────────────────┤
│ 坐标系设计     │ Gravity-View (GV)  │  世界坐标系直接    │  从相机空间转换   │
│ 时序建模       │ Transformer + RoPE │  双向 RNN         │  SLAM + 精炼网络 │
│ 全局轨迹恢复   │ GV → 世界（1-DoF）  │  自回归逐帧预测    │  SLAM 变换 + 精炼 │
│ 重力对齐       │ ✅ 天然重力对齐     │  ⚠️ 需要初始化好  │  ❌ 无保证        │
│ 长序列         │ ✅ 强（因果掩码）    │  ❌ 弱（RNN 衰减） │  ⚠️ 中等          │
│ 推理速度       │ ⭐ 最快             │  中等              │  较慢（优化）     │
│ 足部优化       │ ✅ 静止概率 MLP     │  ✅ 类似策略       │  ⚠️ 有限          │
│ 额外依赖       │ SimpleVO（轻量）    │  无                │  DroidSLAM       │
└───────────────┴────────────────────┴───────────────────┴──────────────────┘
```
