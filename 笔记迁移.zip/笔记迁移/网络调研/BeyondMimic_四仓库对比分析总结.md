# BeyondMimic 论文功能 vs 四个仓库实现对照总表

## 论文核心贡献总览

BeyondMimic 论文的两大核心贡献：

1. **阶段一 - Scalable Motion Tracking**：通过简洁的 RL 公式（统一奖励、物理启发式建模、最小域随机化）实现大规模、高质量的动作追踪
2. **阶段二 - Versatile Guided Diffusion**：基于潜在扩散模型 + 分类器引导实现零样本任务适配（遥操作、避障、运动补全等）

---

## 功能实现对照总表

| 编号 | BeyondMimic 论文功能 | whole_body_tracking (HybridRobotics) | motion_tracking_controller (HybridRobotics) | Mini-Pi-Plus_BeyondMimic (HighTorque) | unitree_rl_mjlab (Unitree) |
|---|---|---|---|---|---|
| **P1** | **阶段一核心：动作追踪训练** | | | | |
| 1.1 | DeepMimic风格跟踪奖励 | ✅ 完整实现 | ❌ (仅推理) | ✅ 完整实现 | ✅ 完整实现 (mjlab版) |
| 1.2 | 统一奖励函数(无需调参) | ✅ 单配置跨运动 | ✅ (从ONNX读取) | ✅ 单配置跨运动 | ✅ 单配置跨运动 |
| 1.3 | 自适应采样课程 | ✅ 完整实现 | ❌ | ✅ | ✅ (FPS感知增强版) |
| 1.4 | 域随机化(最小化) | ✅ 4项DR | ❌ | ✅ | ✅ 多运动+多DR |
| 1.5 | 多运动联合训练 | ❌ (单NPZ) | ✅ (ONNX含参考) | ✅ | ✅ 多NPZ+YAML配置 |
| 1.6 | 无状态估计模式 | ✅ G1FlatWoStateEstimation | ❌ | ✅ | ✅ (含辅助奖励) |
| 1.7 | 物理启发式执行器建模 | ✅ DelayedImplicitActuator | ❌ | ✅ | ❌ |
| 1.8 | 延迟模拟 | ✅ 随机延迟缓冲 | ❌ | ❌ | ❌ |
| **P2** | **训练辅助/基建** | | | | |
| 2.1 | ONNX模型导出+元数据 | ✅ (含motion+meta) | ✅ (加载ONNX) | ✅ | ✅ (含deploy.yaml) |
| 2.2 | WandB注册表管理 | ✅ 运动自动注册/加载 | ✅ W&B自动下载 | ❌ | ❌ (本地文件) |
| 2.3 | 运动数据预处理 | ⚠️ 仅CSV→NPZ | ❌ | ✅ BVH→CSV→NPZ | ✅ CSV→NPZ |
| 2.4 | 运动重定向(Retargeting) | ❌ | ❌ | ✅ GMR→BVH | ❌ |
| 2.5 | 多物理引擎支持 | ❌ (仅IsaacSim) | ❌ (仅MuJoCo) | ⚠️ (待确认) | ✅ (MuJoCo+Warp) |
| **P3** | **真机部署** | | | | |
| 3.1 | Sim-to-Sim评估 | ❌ | ✅ MuJoCo | ✅ | ✅ MuJoCo仿真器 |
| 3.2 | Sim-to-Real部署 | ❌ | ✅ 宇树以太网 | ✅ 特定硬件 | ✅ 宇树SDK2+DDS |
| 3.3 | C++ ONNX Runtime推理 | ❌ | ✅ 核心实现 | ❌ | ✅ 核心实现 |
| 3.4 | 手柄控制(启停) | ❌ | ✅ L1+A/R1+A/B | ❌ | ✅ 手柄映射 |
| 3.5 | 安全急停(E-stop) | ❌ | ✅ 手柄B键 | ❌ | ✅ 状态机切换 |
| **P4** | **阶段二：扩散模型** | | | | |
| 4.1 | 潜在扩散模型(LDM) | ❌ | ❌ | ❌ | ❌ |
| 4.2 | 分类器引导(Classifier Guidance) | ❌ | ❌ | ❌ | ❌ |
| 4.3 | 测试时优化 | ❌ | ❌ | ❌ | ❌ |
| 4.4 | 动作合成/规划 | ❌ | ❌ | ❌ | ❌ |
| 4.5 | 零样本任务适配 | ❌ | ❌ | ❌ | ❌ |
| 4.6 | 遥操作/避障等下游任务 | ❌ | ❌ | ❌ | ❌ |
| **P5** | **机器人支持** | | | | |
| 5.1 | Unitree G1 | ✅ | ✅ (29关节) | ❌ | ✅ (G1+G1_23dof) |
| 5.2 | Unitree H1_2/H2 | ❌ | ❌ | ❌ | ✅ (H1_2+H2) |
| 5.3 | Unitree Go2/A2/A2/R1 | ❌ | ❌ | ❌ | ✅ (四足+轮式) |
| 5.4 | SMPL人体模型 | ✅ | ❌ | ❌ | ❌ |
| 5.5 | Mini-Pi-Plus | ❌ | ❌ | ✅ (专属) | ❌ |

> ✅ 完整实现  ⚠️ 部分实现  ❌ 未实现

---

## 各仓库架构总结

### 1. whole_body_tracking（官方核心训练库）

**定位**：BeyondMimic 论文阶段一的**训练端**实现。

**技术栈**：IsaacLab 2.1.0 + IsaacSim 4.5.0 + rsl_rl PPO

**架构亮点**：
- 采用 IsaacLab 的 Manager 架构（Observations/Rewards/Commands/Terminations 管理器）
- 通过 `MotionCommand` 统一管理参考运动的加载、推进、坐标变换
- 独特的 `DelayedImplicitActuator` 模拟通信延迟
- 自适应采样基于运动片段的失败率统计
- ONNX导出含完整元数据供部署使用

**实现论文哪些功能**：P1全部(P1.1-P1.7)，P2部分(2.1-2.3)，不包含P3和P4

**缺失**：真机部署、扩散模型、运动重定向

---

### 2. motion_tracking_controller（官方真机部署库）

**定位**：BeyondMimic 论文阶段一的**部署端**实现。

**技术栈**：ROS 2 Jazzy + legged_control2 (闭源SDK) + ONNX Runtime C++ + pinocchio + MuJoCo (sim)

**代码已读分析**（完整C++源码已获取）：

**架构亮点**：
- **继承链**：`controller_interface::ControllerInterface` → `ControllerBase` → `RlController` (legged_control2) → `MotionTrackingController`
- **MotionTrackingController**：主控制器，通过 `on_init()` 声明 `motion.start_step` 参数，`on_configure()` 加载 ONNX 模型并解析元数据（anchor_body_name, body_names）
  - `parserCommand("motion")` 注册 `MotionCommandTerm`
  - `parserObservation()` 注册4类观测项：`motion_ref_pos_b/motion_anchor_pos_b`、`motion_ref_ori_b/motion_anchor_ori_b`、`robot_body_pos`、`robot_body_ori`
- **MotionOnnxPolicy** (继承 OnnxPolicy)：
  - `forward(obs)`：组装 `obs` + `time_step` 张量，执行推理
  - **参考运动嵌入 ONNX 模型**：推理输出包含 `joint_pos`、`joint_vel`、`body_pos_w`、`body_quat_w`，通过 `time_step_` 计数器逐帧推进
  - `reset()`：重置时间步 + 用零观测预热推理（获取初始参考帧）
  - `parseMetadata()`：从 ONNX metadata_props 读取 `anchor_body_name` 和 `body_names`
- **MotionCommandTerm** (继承 CommandTerm)：
  - `getValue()`：返回 `[joint_pos, joint_vel]` 拼接向量
  - `reset()`：通过 pinocchio 查找 `anchorRobotIndex_` 和 `anchorMotionIndex_`，计算 `worldToInit_` 变换（仅偏航+平移对齐）
  - `getAnchorPositionLocal()` / `getAnchorOrientationLocal()`：将参考运动帧的 anchor body 变换到机器人局部坐标系（`anchorPoseReal.actInv(worldToInit_.act(anchorPos))`）
  - `getRobotBodyPositionLocal()` / `getRobotBodyOrientationLocal()`：所有 body 位姿在 anchor body 局部系下表达，朝向使用旋转矩阵前两列（6D表示）
- **MotionObservation** 子类：4个观测项（MotionAnchorPosition 3D, MotionAnchorOrientation 6D, RobotBodyPosition 3N, RobotBodyOrientation 6N）
- **控制器配置** (config/g1/controllers.yaml)：G1 29关节配置，腿部 Kp=350（高刚度），手臂 Kp=40（低刚度），state_estimator 配置双脚接触

**支持的功能特性**：
- ✅ 支持 WandB 自动下载模型（`download_wandb_onnx()`）
- ✅ 支持本地 ONNX 文件加载
- ✅ 外部位置矫正（LiDAR mid360 话题）
- ✅ 手柄映射：L1+A 待机 → R1+A 策略 → B E-stop
- ✅ MuJoCo 仿真启动（mujoco.launch.py）
- ✅ 真机部署（real.launch.py + 静态IP 192.168.123.11）
- ✅ 500Hz 控制频率（策略 50Hz 降采样）

**实现论文哪些功能**：P3全部(P3.1-P3.5)，P2部分(2.1-2.2)

**缺失**：训练能力、扩散模型

---

### 3. Mini-Pi-Plus_BeyondMimic（特定硬件完整实现）

**定位**：面向 Mini-Pi-Plus 机器人的**端到端完整实现**。

**独特贡献**：
- 包含超集功能：运动重定向(GMR→BVH→CSV→NPZ)
- 数据预处理链条最完整
- 专属硬件资产配置和参数优化
- 覆盖从数据采集到仿真验证全流程

**实现论文哪些功能**：P1全部，P2最完整(含重定向)，P3部分

**缺失**：扩散模型、官方宇树硬件支持

---

### 4. unitree_rl_mjlab（宇树科技官方训练+部署框架）

**定位**：宇树科技官方 RL 框架，**同时包含训练和部署**。

**技术栈**：MuJoCo 3.3.6 + mjlab(IsaacLab风格API) + rsl_rl + ONNX Runtime 1.22.0

**架构亮点**：
- 三合一：Python训练 + C++部署 + MuJoCo仿真
- Training端：完全复现 BeyondMimic tracking，融合 mjlab 轻量级API
- Deploy端：C++实现ManagerBasedRLEnv完整复现训练观测，ONNX Runtime推理
- 支持7款宇树机器人(G1/Go2/H1_2/H2/A2/A2/R1)
- FPS感知的多运动加载、Ghost可视化、H1_2躯干IMU变换
- No-Estimate模式含7项辅助奖励

**实现论文哪些功能**：P1全部(扩展版)，P3全部(最完整部署栈)，P2部分(含CSV→NPZ)

**缺失**：扩散模型、W&B集成(本地文件)、运动重定向

---

## 论文完整Pipeline与各仓库覆盖范围

```
数据采集 → 重定向 → 预处理 → RL训练 → 模型导出 → Sim验证 → 真机部署
  ❌        ❌      ⚠️WBT    ✅WBT      ✅WBT      ❌       ❌      ← whole_body_tracking
  ❌        ❌      ❌       ❌         ✅MTC     ✅MTC    ✅MTC   ← motion_tracking_controller
  ❌        ✅MPP   ✅MPP    ✅MPP       ✅MPP      ✅MPP    ⚠️MPP   ← Mini-Pi-Plus_BeyondMimic
  ❌        ❌     ✅UMJ     ✅UMJ       ✅UMJ      ✅UMJ   ✅UMJ   ← unitree_rl_mjlab

扩散模型 → 分类器引导 → 动作合成 → 零样本适配 → 遥操作/避障
  ❌        ❌          ❌         ❌          ❌      ← 所有仓库均未实现
```

> WBT=whole_body_tracking, MTC=motion_tracking_controller, MPP=Mini-Pi-Plus, UMJ=unitree_rl_mjlab

---

## 关键发现

1. **阶段二(扩散模型)全网缺失**：所有四个仓库均**未实现** BeyondMimic 论文的 Latent Diffusion Model + Classifier Guidance 部分，这是论文最核心的创新点之一。该部分可能尚未开源或存放在私有仓库中。

2. **unitree_rl_mjlab 覆盖度最广**：唯一同时覆盖训练+部署的仓库，支持机器人种类最多，且在 tracking 实现上对原版有增强（多运动、No-Estimate辅助奖励、Ghost可视化）。

3. **whole_body_tracking 精度最高**：作为官方训练库，对论文原版实现最忠实（延迟模拟、物理启发式参数等），但仅覆盖训练端。

4. **motion_tracking_controller 部署最专业**：基于ROS 2工业级框架，安全机制（E-stop/状态机）最完善，但硬件绑定最深。

5. **Mini-Pi-Plus 数据链条最完整**：唯一包含运动重定向的仓库，但硬件特异性最强。

6. **开源程度不均**：阶段一训练代码全部开源，扩散模型部分完全未公开，限制了论文的完全复现。

---

## 各仓库报告文件

- [whole_body_tracking 详细报告](file:///home/meme/Documents/whole_body_tracking_analysis_report.md)
- [unitree_rl_mjlab 详细报告](file:///home/meme/Documents/unitree_rl_mjlab_分析报告.md)
- motion_tracking_controller 报告 → 见上述分析
- Mini-Pi-Plus_BeyondMimic 报告 → 见上述分析

---

*报告生成日期: 2026-07-01*
*分析范围: BeyondMimic(arXiv:2508.08241v4) 论文对照*
