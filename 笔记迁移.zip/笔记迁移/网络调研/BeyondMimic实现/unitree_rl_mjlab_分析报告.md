# Unitree RL Mjlab 代码仓库分析报告

> 仓库路径：`/home/meme/Documents/unitree_h1/unitree_rl_mjlab`

---

## 一、仓库概述

**Unitree RL Mjlab** 是宇树科技（Unitree Robotics）基于 [mjlab](https://github.com/mujocolab/mjlab.git) 框架构建的强化学习训练与部署平台。它使用 MuJoCo 作为物理仿真后端，结合 Isaac Lab 风格的高层 API，实现了从仿真训练到真实机器人部署的完整流水线。

### 技术栈

| 层级 | 技术 |
|------|------|
| 物理引擎 | MuJoCo 3.3.6（通过 mjlab 封装） |
| 训练框架 | mjlab（Isaac Lab 风格 API）+ rsl_rl（PPO） |
| 推理引擎 | ONNX Runtime 1.22.0（CPU） |
| 通信协议 | 宇树 SDK2 |
| 仿真模拟 | 自研 unitree_mujoco 模拟器 |
| 部署语言 | C++17 / Python 3.10+ |

### 支持的机器人

- G1（29 DOF，含腰部自由度）
- G1_23dof（23 DOF，无腰部自由度）
- Go2（四足机器人）
- H1_2（大型双足，含灵巧手）
- H2（大型双足）
- A2（四足机器人）
- AS2（四足机器人）
- R1（双足机器人）

---

## 二、项目架构（三部分）

### 2.1 Python 训练代码 — `src/`

```
src/
├── tasks/
│   ├── velocity/              # 速度跟踪训练任务
│   │   ├── velocity_env_cfg.py     # 基础环境配置工厂函数
│   │   ├── mdp/
│   │   │   ├── velocity_command.py # 速度指令生成
│   │   │   ├── observations.py     # 观测项（角速度/投影重力/关节位置等）
│   │   │   ├── rewards.py          # 速度跟踪奖励函数
│   │   │   ├── terminations.py     # 终止条件
│   │   │   └── curriculums.py      # 课程学习
│   │   ├── rl/runner.py            # PPO 训练启动器
│   │   └── config/{g1,g1_23dof,go2,h1_2,h2,a2,as2,r1}/
│   │       ├── env_cfgs.py         # 各机器人的环境配置
│   │       └── rl_cfg.py           # 各机器人的RL超参数
│   │
│   └── tracking/              # 动作模仿训练任务（BeyondMimic 复现）
│       ├── tracking_env_cfg.py     # 基础模仿环境配置
│       ├── mdp/
│       │   ├── commands.py         # MotionLoader（多运动加载）+ MotionCommand
│       │   ├── rewards.py          # 6项跟踪奖励 + 6项No-Estimate辅助奖励
│       │   ├── observations.py     # 运动锚点观测/机器人本体观测
│       │   ├── terminations.py     # 模仿任务终止条件
│       │   ├── metrics.py          # 训练指标
│       │   └── rl/runner.py
│       └── config/{g1,g1_23dof,h1_2}/
│           └── env_cfgs.py         # 含 No-State-Estimation 模式
│
├── assets/
│   ├── robots/                # 各机器人 MuJoCo XML 模型 & STL 文件
│   │   ├── unitree_{g1,g1_23dof,go2,h1_2,h2,a2,as2,r1}/
│   │   │   ├── xmls/          # scene_*.xml（场景）/ *.xml（机器人）
│   │   │   └── *constants.py  # 运动学/动力学常量
│   └── motions/               # 运动数据（NPZ 格式）
│
├── scripts/
│   ├── train.py               # 统一训练入口
│   ├── play.py                # 模型回放验证
│   ├── csv_to_npz.py          # 运动数据预处理（CSV → NPZ）
│   ├── list_envs.py           # 列出可用环境
│   └── visualize_terrain.py   # 地形可视化
```

**安装依赖**（`setup.py` 定义）：
- `mjlab==1.2.0` — 核心训练框架
- `mujoco-warp==3.5.0` — MuJoCo Warp 加速

### 2.2 C++ 部署代码 — `deploy/`

```
deploy/
├── include/
│   ├── FSM/                   # 状态机框架
│   │   ├── BaseState.h / FSMState.h / CtrlFSM.h    # 基类
│   │   ├── State_Passive.h     # 被动（安全）模式
│   │   ├── State_FixStand.h    # 固定站立模式
│   │   └── State_RLBase.h      # RL 策略基类（管理策略线程）
│   │
│   ├── isaaclab/               # C++ 版"Isaac Lab" 核心库
│   │   ├── envs/manager_based_rl_env.h     # 核心 RL 环境类
│   │   ├── envs/mdp/
│   │   │   ├── observations/observations.h # 观测注册实现
│   │   │   ├── actions/joint_actions.h     # 动作处理（JointPosition/Velocity）
│   │   │   └── terminations.h              # 终止条件（如 bad_orientation）
│   │   ├── manager/
│   │   │   ├── observation_manager.h       # 观测管理器（注册/组/计算/缓冲）
│   │   │   ├── action_manager.h            # 动作管理器
│   │   │   └── manager_term_cfg.h          # 配置解析基类
│   │   ├── assets/articulation/articulation.h  # 机器人运动学基类
│   │   ├── algorithms/algorithms.h          # ONNX Runtime 推理封装
│   │   ├── devices/keyboard/keyboard.h      # 键盘输入
│   │   └── utils/utils.h                   # 工具函数
│   │
│   ├── unitree_articulation.h    # 宇树机器人通信桥接（IMU/电机状态读取）
│   ├── unitree_joystick_dsl.hpp  # 宇树手柄驱动
│   ├── LinearInterpolator.h      # 线性插值器
│   └── param.h                   # 全局配置参数
│
├── robots/{g1,g1_23dof,go2,h1_2,a2,r1}/
│   ├── config/
│   │   ├── config.yaml           # 机器人全局配置
│   │   └── policy/{velocity,mimic}/v0/params/deploy.yaml  # 策略部署配置
│   ├── include/Types.h           # 机器人类型定义
│   ├── src/State_RLBase.cpp      # 速度跟踪部署状态
│   ├── src/State_Mimic.cpp       # 动作模仿部署状态（含运动加载器和额外观测）
│   ├── main.cpp                  # 入口 & FSM 初始化
│   └── CMakeLists.txt            # 编译配置
│
└── thirdparty/
    ├── onnxruntime-linux-{x64,aarch64}-1.22.0/  # ONNX Runtime 推理引擎
    └── cnpy/                     # NumPy 文件读写（用于策略数据导出/验证）
```

### 2.3 仿真模拟 — `simulate/`

基于 MuJoCo 3.3.6 的自研仿真器（`unitree_mujoco`），提供：

- **物理仿真**：加载机器人场景 XML 进行实时物理模拟
- **手柄控制**：支持 Xbox/Switch 手柄（通过 `joystick.cc`）
- **宇树 SDK2 桥接**：`unitree_sdk2_bridge.h` 实现仿真 ↔ 实机指令转发
- **弹性带模式**：`ElasticBand` 类用于悬吊辅助（如 H1 的吊装训练）

---

## 三、训练系统详解

### 3.1 速度跟踪任务（Velocity Tracking）

**入口**：`python scripts/train.py Unitree-G1-Flat --env.scene.num-envs=4096`

#### 观测空间（Actor Policy）
```
- base_ang_vel (3)        # IMU 角速度
- projected_gravity (3)   # 投影重力向量
- command (3)             # 速度指令 (vx, vy, wz)
- phase (sin, cos) (2)    # 运动相位编码
- joint_pos_rel (N)       # 关节相对位置（相对于默认姿态）
- joint_vel_rel (N)       # 关节速度
- last_action (N)         # 上一步动作
```
> Critic 额外包含 `height_scan`（地形扫描）和 `base_lin_vel`（线速度）等项。

#### 奖励函数
- 速度跟踪误差惩罚
- 角速度惩罚
- 关节限位惩罚
- 动作平滑惩罚
- 能量消耗惩罚
- 足端滑动惩罚
- 足端接触力惩罚

#### 关键特性
- 域随机化（摩擦系数、质心偏移、延迟等）
- 关节偏置噪声模拟真实传感器
- 课程学习（`curriculums.py`）
- 多 GPU 训练支持（`--gpu-ids 0 1`）

### 3.2 动作模仿任务（Motion Tracking）

**入口**：`python scripts/train.py Unitree-G1-Tracking-No-State-Estimation --motion_file=...`

#### MotionLoader（`commands.py`）

核心的运动数据加载模块，支持：

- **多运动文件加载**：支持单个 NPZ 文件、NPZ 文件元组、YAML 配置文件（含权重/循环模式）
- **三种采样模式**：
  - `adaptive`（自适应采样）：根据每个运动的采样频率自动分配，含独立 bin 计数
  - `uniform`（均匀采样）
  - `start`（从头采样）
- **两种循环模式**：
  - `WRAP`（循环）：播放到末尾后回到开头
  - `CLAMP`（夹断）：播放到末尾后保持最后一帧
- **FPS 感知**：自动将运动数据帧率转换为训练步长
- **Ghost 可视化**：在仿真器中显示参考运动姿态

#### 观测空间（Actor Policy，No-State-Estimation 模式）
```
- command (N*2)                    # 运动指令（关节位置+速度）
- motion_anchor_ori_b (6)          # 运动锚点方向（旋转矩阵前两列）
- base_ang_vel (3)                 # IMU 角速度
- joint_pos_rel (N)                # 关节相对位置
- joint_vel_rel (N)                # 关节速度
- last_action (N)                  # 上一步动作
```
> 无状态估计模式下，`motion_anchor_pos_b` 和 `base_lin_vel` 被移除（仅依赖 IMU 和关节编码器）。

#### 奖励函数

**6 项核心跟踪奖励**（与 whole_body_tracking 一致）：
1. `motion_global_anchor_position_error_exp` — 全局锚点位置误差
2. `motion_global_anchor_orientation_error_exp` — 全局锚点方向误差
3. `motion_relative_body_position_error_exp` — 相对身体位置误差
4. `motion_relative_body_orientation_error_exp` — 相对身体方向误差
5. `motion_global_body_linear_velocity_error_exp` — 全局身体线速度误差
6. `motion_global_body_angular_velocity_error_exp` — 全局身体角速度误差

**6 项 No-Estimate 辅助奖励**（权重默认为 0，可根据需要开启）：
1. `capture_point_balance_reward` — 捕获点平衡奖励
2. `root_stay_in_place_reward` — 防止漂移
3. `foot_slip_penalty` — 滑足惩罚
4. `body_orientation_penalty` — 身体姿态惩罚
5. `body_ang_vel_penalty` — 角速度惩罚
6. `contact_mode_match_reward` — 接触模式匹配
7. `contact_vel_matching_reward` — 接触速度匹配

---

## 四、C++ 部署系统详解

### 4.1 状态机框架

```
Passive（安全模式） → FixStand（固定站立） → RLBase/Mimic（策略运行）
```

- **State_Passive**：电机处于阻尼模式，安全无动力
- **State_FixStand**：使用 PD 控制器维持站立姿态
- **State_RLBase**：执行速度跟踪策略
- **State_Mimic**：执行动作模仿策略

状态转换由注册条件自动触发，例如 `bad_orientation`（摔倒检测）触发回到 Passive 状态。

### 4.2 ManagerBasedRLEnv（核心环境类）

C++ 部署框架完整复现了 Python 训练时的观测组装逻辑：

```
序列化流程：
1. ObservationManager 遍历所有注册项
2. 每项调用注册函数 → 返回 vector<float>
3. 合并到政策观测向量 → 调用 OrtRunner::act()
4. ActionManager::process_action() → scale/offset/clamp → 下发到电机
```

#### 关键观测实现

| 观测项 | C++ 实现 | 备注 |
|--------|---------|------|
| `base_ang_vel` | 从 IMU 陀螺仪读取 | H1_2 有特殊 pelvis 变换 |
| `projected_gravity` | IMU 四元数共轭 × (0,0,-1) | H1_2 有特殊 pelvis 变换 |
| `joint_pos_rel` | 当前关节位置 − 默认关节位置 | 与 Python 训练一致 |
| `joint_vel_rel` | 当前关节速度 − 默认关节速度 | 匹配 Python 端 |
| `last_action` | 从 ActionManager 缓存读取 | |
| `velocity_commands` | 手柄输入 clamped to ranges | 支持键盘替代 |
| `gait_phase` | 步态相位编码 (sin, cos) | 基于固定周期 |
| `motion_command` | 从 MotionLoader 获取参考轨迹 | 模仿任务专用 |
| `motion_anchor_ori_b` | 含骨盆→躯干坐标变换 | 模仿任务专用 |

#### H1_2 特殊处理

由于 H1_2 的 IMU 安装在躯干（torso）而非骨盆（pelvis），需要坐标变换：
- `base_ang_vel_pelvis`：IMU 角速度通过腰部偏航角变换到骨盆坐标系，并补偿腰部转动角速度
- `projected_gravity_pelvis`：IMU 四元数通过 `Rz(waist_yaw)^T` 变换到骨盆坐标系

#### 定时控制

策略运行在独立线程中，使用 `sleep_until` 实现精确的固定步长（`step_dt = 0.02s`）控制：

```cpp
policy_thread = std::thread([this]{
    while (policy_thread_running) {
        env->step();
        std::this_thread::sleep_until(sleepTill);
        sleepTill += dt;
    }
});
```

### 4.3 ONNX 推理部署

- **OrtRunner** 封装 ONNX Runtime C++ API
- 支持多输入 tensor 的动态处理
- 线程安全的 `get_action()`（带 mutex）
- 支持 x64 和 aarch64 两种架构

### 4.4 部署配置文件（deploy.yaml）

以 `g1/velocity/v0/params/deploy.yaml` 为例：

```yaml
joint_ids_map: [0,1,...,28]    # 关节 ID 映射（宇树 SDK → 策略顺序）
step_dt: 0.02                  # 控制步长（50Hz）
stiffness/damping: [...]       # PD 增益（29维向量）
default_joint_pos: [...]       # 默认站立姿态
commands:
  base_velocity:
    ranges: {lin_vel_x: [-0.5,1.0], lin_vel_y: [-0.5,0.5], ang_vel_z: [-1.0,1.0]}
actions:
  JointPositionAction:
    scale/offset: [...]         # 动作缩放和偏移（对应 Python 训练）
observations:                   # 观测项及其 scale/clip/history_length
  - base_ang_vel / projected_gravity / velocity_commands / gait_phase
  - joint_pos_rel / joint_vel_rel / last_action
```

### 4.5 部署验证工具

在 `deploy/robots/h1_2/tools/` 下提供了完整的数值对齐验证工具链：

| 工具 | 功能 |
|------|------|
| `policy_replay_dump.cpp` | C++ 端策略回放并 dump 中间数据 |
| `verify_deploy_obs_assembly.py` | 验证 C++ 端观测组装是否与 Python 一致 |
| `compare_mimic_deploy_assembly.py` | 验证模仿任务部署观测 |
| `compare_mimic_full_assembly.py` | 端到端模仿任务对比 |
| `capture_tracking_rollout.py` | 录制 Python 端 rollout 数据用于对比 |
| `analyze_mimic_cpp_dump.py` | 分析 C++ dump 数据 |
| `test_obs_assembly.py` | 观测组装单元测试 |

---

## 五、仿真模拟系统

### 5.1 simulate/ 架构

基于 MuJoCo 3.3.6 的实时仿真器，主要组件：

- **main.cc**：主循环（物理步进 + 电机指令下发 + UI 渲染）
- **physics_joystick.h**：手柄读取
- **unitree_sdk2_bridge.h**：宇树 SDK2 桥接（仿真 ↔ 实机）
- **config.yaml**：配置入口（选择机器人模型/手柄类型/SDK2 网络接口等）

**仿真流**：
```
手柄输入 → 策略推理 → 电机指令 → MuJoCo 步进 → 传感器数据 → 循环
                              ↓
                      unitree_sdk2_bridge（可选：转发到实机）
```

---

## 六、数据流总览

### 训练数据流
```
运动数据（CSV） → csv_to_npz.py → NPZ 文件 → MotionLoader → 训练环境
                    ↓
              域随机化 → 观测组装 → PPO 训练 → ONNX 导出
```

### 部署数据流
```
ONNX 模型 + deploy.yaml → C++ OrtRunner → 观测组装 → 策略推理 → 电机指令
                                 ↓
宇树 SDK2 ← 手柄/键盘 → IMU/编码器反馈
```

---

## 七、论文功能对照

### 已实现

| 功能 | 状态 | 说明 |
|------|------|------|
| 动作追踪训练 | ✅ | 基于 BeyondMimic / whole_body_tracking |
| 速度跟踪训练 | ✅ | 标准 velocity tracking 任务 |
| 统一奖励函数 | ✅ | 6项核心跟踪 + 6项辅助奖励 |
| 多机器人支持 | ✅ | G1/Go2/H1_2/H2/A2/AS2/R1（7 款） |
| Sim-to-Real 导出 | ✅ | ONNX + deploy.yaml 部署 |
| 域随机化 | ✅ | 摩擦/质心/延迟/偏置噪声等 |
| 自适应采样 | ✅ | MotionLoader 三种采样模式 |
| 无状态估计模式 | ✅ | 仅依赖 IMU + 关节编码器 |
| 真机部署 | ✅ | C++ ONNX Runtime + 宇树 SDK2 |
| 运动预处理 | ✅ | CSV → NPZ 转换（FPS 适配） |
| 多运动训练 | ✅ | 多 NPZ 文件 / YAML 配置 |
| Ghost 可视化 | ✅ | 仿真中显示参考运动姿态 |
| 多 GPU 训练 | ✅ | --gpu-ids 参数 |
| 课程学习 | ✅ | 速度跟踪任务 |

### 未实现

| 功能 | 状态 | 说明 |
|------|------|------|
| 扩散模型 | ❌ | Latent Diffusion Model 未集成 |
| 分类器引导 | ❌ | Classifier Guidance 未实现 |
| 动作合成/规划 | ❌ | 仅做动作跟踪，无规划模块 |
| 动作重定向 | ❌ | Retargeting 未实现 |

---

## 八、依赖关系总览

```
                    unitree_rl_mjlab
                   /        |        \
           Python训练    C++部署    仿真模拟
              |            |           |
             mjlab     ONNX Runtime  MuJoCo 3.3.6
              |            |           |
         MuJoCo Warp   宇树 SDK2   宇树 SDK2
         rsl_rl (PPO)   Eigen3     手柄驱动
         PyTorch        yaml-cpp
```

---

## 九、关键设计亮点

1. **模块化观测管理**：Python 端和 C++ 端都采用注册制管理观测项，通过统一的配置文件（`deploy.yaml`）保证训练与部署的观测一致性。

2. **状态机安全机制**：`bad_orientation` 检测自动回退到 Passive 模式，确保机器人在摔倒时安全停机。

3. **平衡的模仿与辅助奖励**：核心跟踪奖励保持运动质量，可选辅助奖励（捕获点、防滑足等）可在无状态估计时补偿缺失的传感器信息。

4. **H1_2 躯干 IMU 补偿**：由于 H1_2 的 IMU 安装在躯干而非骨盆，专门实现了骨盆坐标系的角速度和重力投影变换，确保与训练时一致。

5. **精度验证工具链**：提供了完整的 Python↔C++ 数值对齐验证工具，确保部署输出与训练输出一致。
