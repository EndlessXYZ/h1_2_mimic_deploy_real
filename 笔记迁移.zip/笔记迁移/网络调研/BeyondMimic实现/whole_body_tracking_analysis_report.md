# whole_body_tracking 仓库分析报告

> 仓库：HybridRobotics/whole_body_tracking  
> 分析日期：2026-07-01  
> 基础框架：Isaac Lab v2.1.0 + Isaac Sim 4.5.0 + rsl_rl  
> 论文对应：BeyondMimic — Motion Tracking Training

---

## 一、架构概述

### 1.1 仓库定位

本仓库是 **BeyondMimic** 论文的官方核心训练库，实现了 motion tracking 的策略训练（Policy Training）部分。基于 Isaac Lab 的 Manager-Based RL 框架构建，使用 rsl_rl 作为强化学习算法库。

仓库**不包含**扩散模型、分类器引导、动作合成等高层模块，聚焦于"给定参考运动序列，训练机器人模仿该运动"这一核心任务。

### 1.2 整体架构

```
┌─────────────────────────────────────────────────────────┐
│                    训练入口 (train.py)                    │
│  通过 wandb Artifact 加载运动数据 → 构建 env → 启动 PPO   │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│              TrackingEnvCfg (环境配置)                    │
│  Scene ─── 地形 + 机器人 + 灯光 + 接触传感器              │
│  MDP ───── Commands / Observations / Rewards / Events   │
│  Actions ─ PD目标位置输出                                 │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│                   MDP 模块 (tasks/tracking/mdp/)          │
│                                                          │
│  commands.py ─── MotionCommand + MotionLoader           │
│  observations.py ─ 策略/特权观测函数                      │
│  rewards.py ───── 6个跟踪奖励 + 3个正则惩罚               │
│  events.py ────── 域随机化 (摩擦力/CoM/关节偏置/推力)     │
│  terminations.py ─ 终止条件 (anchor/body位置/朝向超限)    │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│                 机器人配置 (robots/)                      │
│  g1.py ─── G1人形机器人 URDF + 电机参数 + 动作缩放       │
│  smpl.py ── SMPL人体模型配置                             │
│  actuator.py ── DelayedImplicitActuator (通信延迟模拟)    │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│                 工具模块 (utils/)                         │
│  exporter.py ────────── ONNX导出 + 元数据附加            │
│  my_on_policy_runner.py ─ 自定义保存 (ONNX → wandb)     │
└─────────────────────────────────────────────────────────┘
```

### 1.3 训练流程

1. **数据加载**：训练入口 `train.py` 从 wandb Registry 下载 `.npz` 运动文件
2. **环境构建**：`gym.make()` 创建基于 `TrackingEnvCfg` 的 Isaac Lab 环境
3. **PPO 训练**：rsl_rl 的 `OnPolicyRunner` 进行 PPO 训练，由 `MotionOnPolicyRunner` 封装保存逻辑
4. **模型导出**：每个 checkpoint 保存时自动导出 ONNX 文件并附加元数据，上传至 wandb
5. **评估**：`play.py` 支持从本地 checkpoint 或 wandb 运行加载模型推理

---

## 二、模块详细分析

### 2.1 环境配置（TrackingEnvCfg）

**文件**: `tasks/tracking/tracking_env_cfg.py`

| 配置项 | 值 | 说明 |
|--------|-----|------|
| `num_envs` | 4096 | 并行环境数 |
| `env_spacing` | 2.5m | 环境间距 |
| `decimation` | 4 | 动作下采样（每4个物理步执行1次控制） |
| `episode_length_s` | 10.0s | 回合长度 |
| `sim.dt` | 0.005s | 物理步长（200Hz） |
| 控制频率 | 50Hz | 200Hz ÷ 4 = 50Hz |

场景配置（`MySceneCfg`）包含：
- **地形**: 平面地形，摩擦力组合模式为 multiply
- **机器人**: 由子类配置（G1/SMPL）
- **传感器**: 全身接触传感器，`history_length=3`，`force_threshold=10.0N`，追踪空气时间
- **光照**: DistantLight + DomeLight

#### 子类配置

| 配置类 | 说明 |
|--------|------|
| `G1FlatEnvCfg` | G1人形机器人 + 全观测（含 motion_anchor_pos_b 和 base_lin_vel） |
| `G1FlatWoStateEstimationEnvCfg` | 移除 motion_anchor_pos_b 和 base_lin_vel（无状态估计模式） |
| `G1FlatLowFreqEnvCfg` | 降频模式（decimation / 0.5，控制频率降为25Hz） |

---

### 2.2 运动命令模块（commands.py）

**核心类**: `MotionCommand`（继承 `CommandTerm`）

#### MotionLoader — 运动数据加载器

- **输入格式**: `.npz` 文件
- **数据域**: `fps`, `joint_pos`, `joint_vel`, `body_pos_w`, `body_quat_w`, `body_lin_vel_w`, `body_ang_vel_w`
- **body 索引过滤**: 通过 `body_indexes` 选择关心的 body，`body_pos_w` 等属性自动过滤

#### MotionCommand — 运动命令执行

**关键功能**:

1. **自适应采样（Adaptive Sampling）**:
   - 将运动序列划分为 `bin_count` 个时间窗口
   - 记录每个窗口的失败次数（`bin_failed_count`）
   - 使用指数加权核（`adaptive_lambda`）平滑失败率
   - 根据失败率计算采样概率分布，实现课程学习
   - 维护 8 个度量指标：位置/旋转/速度误差等

2. **时间步推进**:
   - `advance()`: 每步推进 `time_steps`，推进幅度含 ±1 步的随机扰动
   - 支持多运动文件间的随机切换

3. **RSI（Reset-set Initialization）**:
   - **位姿随机化**: `pose_range`（平移 ±0.05m，旋转 ±0.2rad）
   - **速度随机化**: `velocity_range`（线速度 ±0.5m/s，角速度 ±0.78rad/s）
   - **关节位置随机化**: `joint_position_range`（±0.1rad）

4. **坐标变换**:
   - 参考运动的数据存储在全局坐标系（world frame）
   - `_update_body_relative()`: 将参考 body 位置/朝向转换到以 anchor body 为原点的相对坐标系

**配置参数（`MotionCommandCfg`）**:

| 参数 | 值 | 说明 |
|------|-----|------|
| `resampling_time_range` | (1e9, 1e9) | 极长，防止运动切换 |
| `adaptive_lambda` | 0.9 | 自适应采样衰减因子 |
| `adaptive_kernel_size` | 16 | 指数核窗口大小 |
| `target_entropy` | -ln(0.25) | 目标熵值（用于自适应采样率调整） |

---

### 2.3 观测空间（observations.py）

#### 策略观测（Policy Observation）— 共 8 项

| 观测项 | 维度 | 噪声 | 说明 |
|--------|------|------|------|
| `command` | 2×关节数 | 无 | 参考运动关节 pos + vel |
| `motion_anchor_pos_b` | 3 | ±0.25 | 参考 anchor 位置（body frame） |
| `motion_anchor_ori_b` | 4 | ±0.05 | 参考 anchor 朝向（9D：旋转矩阵前2列） |
| `base_lin_vel` | 3 | ±0.5 | 机器人基座线速度 |
| `base_ang_vel` | 3 | ±0.2 | 机器人基座角速度 |
| `joint_pos` | N关节 | ±0.01 | 关节位置（相对默认位置） |
| `joint_vel` | N关节 | ±0.5 | 关节速度 |
| `actions` | N关节 | 无 | 上一时刻动作 |

所有观测项拼接为一维向量输入策略网络。

**注意**: 朝向观测使用旋转矩阵的前两列（共6个值），而非原始四元数，避免四元数的双覆盖问题。

#### 特权观测（Critic/Privileged Observation）— 共 9 项

策略观测的基础上额外包含：
- `body_pos`: 14 个 body 在 anchor frame 中的位置（body frame）
- `body_ori`: 14 个 body 在 anchor frame 中的朝向（body frame）

Critic 可获得完整的机器人运动状态信息。

---

### 2.4 奖励函数（rewards.py）

**设计哲学**: 统一指数型奖励 `reward = exp(-error/σ²)`，无需繁琐调参。共 6 个跟踪奖励 + 3 个正则惩罚。

#### 跟踪奖励

| 奖励项 | 权重 | 标准差 σ | 误差计算 | 说明 |
|--------|------|----------|----------|------|
| `motion_global_anchor_pos` | 0.5 | 0.3 | anchor 位置 L2 误差 | 全局坐标系 |
| `motion_global_anchor_ori` | 0.5 | 0.4 | anchor 朝向四元数误差 | 关注躯干朝向 |
| `motion_body_pos` | 1.0 | 0.3 | 各 body 位置 L2 误差（均值） | 相对坐标系 |
| `motion_body_ori` | 1.0 | 0.4 | 各 body 朝向误差（均值） | 相对坐标系 |
| `motion_body_lin_vel` | 1.0 | 1.0 | 各 body 线速度 L2 误差（均值） | 全局坐标系 |
| `motion_body_ang_vel` | 1.0 | 3.14 | 各 body 角速度 L2 误差（均值） | 全局坐标系 |

**身体（body）奖励使用均值（`.mean(-1)`），而非求和**，确保不同 body 数量不影响奖励量级。

#### 正则惩罚

| 惩罚项 | 权重 | 说明 |
|--------|------|------|
| `action_rate_l2` | -0.1 | 动作变化率 L2 惩罚，鼓励平滑控制 |
| `joint_limit` | -10.0 | 关节位置超出软限制的惩罚 |
| `undesired_contacts` | -0.1 | 非期望接触（除双脚和双手外的部位） |

**脚部接触奖励**: `feet_contact_time()` 奖励脚掌在触地阈值内的接触时间，辅助步态学习。

---

### 2.5 终止条件（terminations.py）

| 条件 | 阈值 | 检测对象 |
|------|------|----------|
| `bad_anchor_pos_z_only` | 0.25m | anchor body Z 轴偏差 |
| `bad_anchor_ori` | 0.8 | 重力方向投影偏差 |
| `bad_motion_body_pos_z_only` | 0.25m | 手脚末端 Z 轴偏差 |
| `time_out` | 10.0s | 时间超限 |

---

### 2.6 域随机化（events.py）

| 随机化项 | 模式 | 参数 | 说明 |
|----------|------|------|------|
| `physics_material` | startup | 静摩擦 0.3~1.6, 动摩擦 0.3~1.2, 回弹 0~0.5 | 64 buckets |
| `add_joint_default_pos` | startup | ±0.01rad | 关节默认位置偏移 |
| `base_com` | startup | torso CoM 偏移 ±(0.025, 0.05, 0.05)m | 模拟负载不均 |
| `push_robot` | interval(1~3s) | 速度范围见 VELOCITY_RANGE | 推力扰动 |

---

### 2.7 机器人配置（robots/）

#### G1 人形机器人（g1.py）

**URDF**: `unitree_description/urdf/g1/main.urdf`（Cylinder 替换为 Capsule）

**初始化位姿**: (0, 0, 0.76)m，初始关节角度为半蹲姿态

**电机分组**: 5 组，基于电机型号 5020/7520/4010

| 分组 | 关节 | 刚度 (N·m/rad) | 阻尼 (N·m·s/rad) | 力矩限制 |
|------|------|----------------|------------------|----------|
| legs | 髋关节 + 膝关节 | 7520_14: ~4.55, 7520_22: ~11.22 | 7520_14: ~1.45, 7520_22: ~3.57 | 88~139Nm |
| feet | 踝关节 | 2×5020: ~2.85 | 2×5020: ~0.91 | 50Nm |
| waist | 腰 roll/pitch | 2×5020 | 2×5020 | 50Nm |
| waist_yaw | 腰 yaw | 7520_14 | 7520_14 | 88Nm |
| arms | 手臂+手腕 | 5020 / 4010 | 5020 / 4010 | 5~25Nm |

**动作缩放** (`G1_ACTION_SCALE`): `0.25 × effort_limit / stiffness`，将动作从 [-1, 1] 映射到实际力矩范围的 25%

**电机参数计算**: 基于 `stiffness = armature × (10×2π)²`，`damping = 2 × damping_ratio × armature × 10×2π`

#### 延迟执行器（actuator.py）

`DelayedImplicitActuator` 继承自 `ImplicitActuator`，增加命令延迟缓冲：
- 使用 `DelayBuffer` 循环缓冲区存储位置/速度/力指令
- `min_delay` / `max_delay` 配置延迟步数范围
- 每次 `reset()` 随机采样延迟步数，模拟通信延迟

---

### 2.8 模型导出（exporter.py）

#### ONNX 导出

`_OnnxMotionPolicyExporter` 继承 Isaac Lab 的 `_OnnxPolicyExporter`，**增强**了导出内容：

**输入**: `obs` (观测向量), `time_step` (时间步)
**输出** (共7个):
1. `actions` — 策略输出的动作
2. `joint_pos` — 当前时间步参考关节位置
3. `joint_vel` — 当前时间步参考关节速度
4. `body_pos_w` — 当前时间步参考 body 位置
5. `body_quat_w` — 当前时间步参考 body 朝向
6. `body_lin_vel_w` — 当前时间步参考 body 线速度
7. `body_ang_vel_w` — 当前时间步参考 body 角速度

这使得 ONNX 模型可直接在真机上同时输出控制指令和参考运动数据，无需额外加载运动文件。

#### 元数据附加

`attach_onnx_metadata()` 将以下信息以 StringStringEntryProto 附加到 ONNX 文件：
- `run_path` — wandb 运行路径
- `joint_names` — 关节名称列表
- `joint_stiffness/damping` — 电机 PD 参数
- `default_joint_pos` — 默认关节位置
- `observation_names` / `observation_history_lengths` — 观测项及历史长度
- `action_scale` — 动作缩放因子
- `anchor_body_name` / `body_names` — body 名称配置

---

### 2.9 PPO 超参数

| 参数 | 值 | 说明 |
|------|-----|------|
| `num_steps_per_env` | 24 | 每环境步数（= 4.8s 轨迹） |
| `max_iterations` | 30,000 | 最大迭代次数 |
| `save_interval` | 500 | 模型保存间隔 |
| `actor_hidden_dims` | [512, 256, 128] | Actor 网络结构 |
| `critic_hidden_dims` | [512, 256, 128] | Critic 网络结构 |
| `activation` | ELU | 激活函数 |
| `init_noise_std` | 1.0 | 初始动作噪声标准差 |
| `learning_rate` | 1.0e-3 | 学习率（adaptive 调度） |
| `num_learning_epochs` | 5 | 每轮训练 epoch 数 |
| `num_mini_batches` | 4 | mini-batch 数量 |
| `clip_param` | 0.2 | PPO clip 参数 |
| `entropy_coef` | 0.005 | 熵系数 |
| `gamma` | 0.99 | 折扣因子 |
| `lam` | 0.95 | GAE λ |
| `desired_kl` | 0.01 | 目标 KL 散度 |

---

### 2.10 脚本入口

| 脚本 | 功能 | 关键参数 |
|------|------|----------|
| `train.py` | PPO 训练 | `--registry_name`（wandb 注册表）、`--num_envs`、`--max_iterations` |
| `play.py` | 模型评估/推理 | `--wandb_path`、`--motion_file`、`--task` |
| `csv_to_npz.py` | CSV→NPZ 预处理 + 前向运动学计算 | — |
| `replay_npz.py` | 运动数据回放可视化 | — |
| `upload_npz.py` | 上传 NPZ 到 wandb | — |

---

## 三、论文功能实现对照表

### 3.1 已实现功能

| 论文功能 | 对应代码 | 状态/详情 |
|----------|----------|-----------|
| **动作追踪训练** | 全部 `tasks/tracking/` | ✅ 核心功能，完整的 PPO-based 训练流程 |
| **统一奖励函数** | `rewards.py` — 6个指数型跟踪奖励 | ✅ 无需调参，基于 exp(-error/σ²) |
| **多机器人支持** | `robots/g1.py` + `robots/smpl.py` | ✅ 已实现 G1 和 SMPL 配置框架 |
| **自适应采样课程** | `commands.py` — `MotionCommand` 中的 bin_failed_count | ✅ 基于失败率的指数核平滑+采样 |
| **Sim-to-Real 导出** | `exporter.py` — ONNX + 元数据 | ✅ 导出策略+运动参考+完整配置元数据 |
| **域随机化** | `events.py` — 4种随机化项 | ✅ 摩擦力/CoM/关节偏置/推力 |
| **无状态估计模式** | `G1FlatWoStateEstimationEnvCfg` | ✅ 移除 anchor_pos_b 和 base_lin_vel 观测 |
| **LAFAN1 数据集** | `csv_to_npz.py` | ✅ CSV→NPZ 转换全流程 |
| **低控制频率模式** | `G1FlatLowFreqEnvCfg` + `G1FlatLowFreqPPORunnerCfg` | ✅ 25Hz 控制，调整 gamma/lam 补偿 |
| **通信延迟模拟** | `actuator.py` — `DelayedImplicitActuator` | ✅ 随机延迟缓冲 |

### 3.2 部分实现/框架性功能

| 功能 | 对应代码 | 状态/说明 |
|------|----------|-----------|
| **接触奖励** | `rewards.py` — `feet_contact_time()` | ⚠️ 已定义但未在 RewardsCfg 中使用（weight=0） |
| **多运动文件切换** | `commands.py` — `_resample_motion()` 中的运动列表遍历 | ⚠️ 实现基础遍历，但切换逻辑简单（按顺序切换） |

---

## 四、缺失功能分析

### 4.1 论文未实现功能

| 功能 | 说明 | 缺失影响 |
|------|------|----------|
| **❌ 扩散模型（Latent Diffusion Model）** | BeyondMimic 论文的"生成"部分，用于动作合成 | 本仓库仅做 tracking 训练，扩散模型需配合训练 |
| **❌ 分类器引导（Classifier Guidance）** | 扩散模型的引导采样 | 同上 |
| **❌ 动作合成/规划（Motion Synthesis）** | 基于扩散模型生成连续运动序列 | 同上 |
| **❌ 真机部署代码** | 将 ONNX 模型部署到真机（G1 等）的实时代码 | 本仓库仅负责训练，部署需单独开发 |
| **❌ 动作重定向（Retargeting）** | 不同机器人/人体之间的运动重映射 | 训练数据需预先处理，非本仓库职责 |
| **❌ BVH 格式支持** | 仅支持 CSV→NPZ，无 BVH 解析器 | LAFAN1 数据已由论文方预处理 |

### 4.2 代码层面缺失/可改进点

| 缺失项 | 说明 |
|--------|------|
| **课程学习未激活** | `CurriculumCfg` 定义为 `pass`，无实际内容 |
| **接触奖励未启用** | `feet_contact_time` 定义但 weight 为 0，未在 RewardsCfg 中出现 |
| **无单元测试** | 项目中无 test 目录或测试文件 |
| **无 CI/CD 配置** | 无 GitHub Actions 或其他 CI 配置 |
| **SMPL 配置缺乏测试** | `smpl.py` 存在但未见完整环境配置验证 |

---

## 五、总体评估

### 5.1 代码质量

| 维度 | 评价 |
|------|------|
| **架构设计** | ★★★★★ — 基于 Isaac Lab Manager-Based 框架，模块化清晰，各 MDP 组件职责分明 |
| **可扩展性** | ★★★★☆ — 新增机器人只需添加 robot config + env config，奖励函数可通过参数调整 |
| **文档注释** | ★★★☆☆ — 核心文件有版权头，但函数级 docstring 较少，部分 magic number 缺少注释 |
| **类型注解** | ★★★☆☆ — 部分函数有 TYPE_CHECKING 类型提示，但多数缺少完整类型签名 |
| **代码复用** | ★★★★★ — 善用 Isaac Lab 框架的配置类继承和组合模式，避免重复 |
| **工程化** | ★★★☆☆ — wandb 集成完善，但缺少测试、CI、linting 等工程化配置 |

### 5.2 优点

1. **MDP 架构清晰**：命令/观测/奖励/事件/终止各模块独立，通过配置类组装，非常便于调试和定制
2. **指数型奖励设计简洁有效**：统一的 `exp(-error/σ²)` 形式，σ 作为唯一的"调参旋钮"
3. **自适应采样机制巧妙**：基于失败率的时间窗口采样课程，自动聚焦困难运动片段
4. **Sim-to-Real 导出完整**：ONNX 不仅包含策略，还嵌入了运动参考数据和完整配置元数据，真机部署无需额外的配置文件
5. **无状态估计模式设计**：提供 `G1FlatWoStateEstimationEnvCfg` 适配不同传感器配置的硬件

### 5.3 局限性/建议

1. **缺少自动化测试**：关键数学逻辑（坐标变换、奖励计算）建议添加单元测试
2. **多机器人支持不完整**：SMPL 配置存在但无实际训练验证
3. **课程学习未充分利用**：`CurriculumCfg` 为空，未实现课程学习逻辑
4. **运动数据预处理职责边界模糊**：`csv_to_npz.py` 的前向运动学计算与主要训练代码在同一仓库中，建议分离为独立工具
5. **可复现性**：域随机化种子管理等缺少显式控制

### 5.4 总结

`whole_body_tracking` 是一个专业且高质量的 motion tracking 训练库，专注于 BeyondMimic 论文的策略训练环节。代码结构遵循 Isaac Lab 的最佳实践，MDP 组件划分清晰，奖励函数设计简洁有效。ONNX 导出机制考虑了真机部署的完整需求，体现了良好的工程前瞻性。

仓库范围明确聚焦于训练阶段，缺失的扩散模型、分类器引导等功能属于论文其他模块的范畴。对于希望复现 BeyondMimic tracking 训练的团队，本仓库提供了完整且可直接运行的代码基础。
