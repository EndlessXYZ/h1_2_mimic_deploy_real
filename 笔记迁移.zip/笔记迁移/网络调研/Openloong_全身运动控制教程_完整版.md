# OpenLoong 全身运动控制教程

> **基于 Openloong-dyn-control 开源框架的全身运动控制完整教程**

---

本教程系统性地介绍了基于 MPC（模型预测控制）与 WBC（全身控制）的
双足人形机器人运动控制理论与工程实践。教程以 OpenLoong 开源框架为依托，
从基础数学工具出发，逐步深入到步态规划、全身控制、状态估计等核心算法，
并提供了完整的仿真部署与调试指导。

| 项目 | 内容 |
|------|------|
| 机器人平台 | 青龙（AzureLoong）全尺寸人形机器人 |
| 控制框架 | MPC + WBC 分层控制 |
| 仿真环境 | MuJoCo 物理引擎 |
| 开源仓库 | [Openloong-dyn-control](https://github.com/loongOpen/Openloong-dyn-control) |
| 教程涵盖 | 第1章 ~ 第16章 |

---

# 目录


## 第一部分：绪论与基础

- **第1章：人形机器人运动控制概述**

  - 1.1 人形机器人的发展历史与现状

  - 1.2 运动控制的核心挑战

  - 1.3 Openloong-dyn-control 项目背景

  - 1.4 青龙硬件参数

  - 1.5 控制框架整体架构

  - 1.6 章节导航与学习路径

- **第2章：准备工作与环境搭建**

  - 2.1 系统要求

  - 2.2 克隆与编译

  - 2.3 运行第一个仿真

  - 2.4 代码组织结构

  - 2.5 开发工具推荐


## 第二部分：数学基础

- **第3章 线性代数与数值优化基础**

  - 3.1 向量与矩阵的基本运算

  - 3.2 特征值分解与奇异值分解（SVD）

  - 3.3 伪逆（Pseudoinverse）

  - 3.4 二次规划（QP）问题

  - 3.5 qpOASES 求解器原理

  - 3.6 代码实践：Eigen 3 使用示例

- **第4章 刚体运动学与动力学**

  - 4.1 旋转的数学表达

  - 4.2 齐次变换矩阵与正向运动学

  - 4.3 雅可比矩阵

  - 4.4 牛顿-欧拉递推（RNEA）与逆动力学

  - 4.5 质量矩阵与非线性项

  - 4.6 质心动量矩阵 Ag

  - 4.7 Pinocchio 库原理与核心接口

  - 4.8 代码实践：利用 Pinocchio 计算动力学量

- **第5章 状态估计基础**

  - 5.1 卡尔曼滤波的直观理解

  - 5.2 扩展卡尔曼滤波（EKF）

  - 5.3 IMU 测量模型

  - 5.4 运动学约束

  - 5.5 代码实践：状态估计完整流程


## 第三部分：步态规划与模型预测控制

- **第6章：步态规划与落脚点控制**

  - 6.1 步态周期、相位与双足步行的基本概念

  - 6.2 有限状态机步态调度器实现（gait_scheduler.cpp）

  - 6.3 触地检测与状态切换逻辑

  - 6.4 Raibert 落脚点启发式 —— 原理与数学推导

  - 6.5 摆动腿三维轨迹生成：贝塞尔曲线

  - 6.6 缓动轨迹（Ramp Trajectory）与平滑过渡

  - 6.7 完整流程图与代码逐行解析

  - 6.8 参数影响分析与调优实验

- **第7章：模型预测控制（MPC）**

  - 7.1 MPC 基本原理 —— 滚动优化与反馈

  - 7.2 单刚体模型（SRBM）的完整推导（重点！）

  - 7.3 离散化与预测模型构建

  - 7.4 MPC 代价函数设计

  - 7.5 摩擦锥约束与线性化

  - 7.6 QP 问题组装与 qpOASES 求解

  - 7.7 200Hz 控制律：多速率协调

  - 7.8 完整代码逐行解析（mpc.cpp）

  - 7.9 权重参数对运动的影响与调优策略


## 第四部分：全身控制与状态估计实现

- **第8章 全身控制（Whole-Body Control, WBC）**

  - 8.1 为什么需要 WBC？

  - 8.2 任务空间与关节空间

  - 8.3 分层优先级控制的基本思想

  - 8.4 零空间投影法——数学原理

  - 8.5 行走模式的任务定义与优先级排序

  - 8.6 QP 问题构建

  - 8.7 从期望加速度到关节力矩的完整计算链

  - 8.8 完整代码逐行解析

  - 8.9 WBC vs MPC：角色分工与协同

- **第9章 状态估计实现**

  - 9.1 EKF 状态向量与观测向量设计

  - 9.2 过程模型与观测模型推导

  - 9.3 卡尔曼增益与协方差更新

  - 9.4 欧拉角/角速度滤波（Eul_W_filter）

  - 9.5 代码逐行解析（StateEst.cpp）

  - 9.6 状态估计对控制性能的影响


## 第五部分：系统集成

- **第10章 控制循环与数据流**

  - 10.1 主循环整体架构（1kHz 仿真步长）

  - 10.2 DataBus 数据总线设计原理

  - 10.3 读取-计算-写入（Read-Calc-Write）模式

  - 10.4 多速率控制

  - 10.5 walk_mpc_wbc 完整控制流解析

  - 10.6 模块化设计的优点与扩展性

- **第11章 MuJoCo 仿真接口**

  - 11.1 MuJoCo 仿真引擎简介

  - 11.2 传感器数据读取

  - 11.3 执行器指令下发

  - 11.4 仿真场景配置

  - 11.5 URDF vs MuJoCo XML

  - 11.6 可视化与交互

- **第12章 关节控制层**

  - 12.1 扭矩控制模式与 PVT 控制

  - 12.2 PD 控制与前馈

  - 12.3 关节指令合成流程

  - 12.4 关节限位与安全保护


## 第六部分：应用实践与展望

- **第13章 运动示例详解**

  - 13.1 纯 WBC 行走（walk_wbc）—— 最小可行示例

  - 13.2 MPC+WBC 行走与盲踩障碍（walk_mpc_wbc）

  - 13.3 MPC 跳跃（jump_mpc）

  - 13.4 摇杆交互控制

  - 13.5 楼梯行走（walk_wbc_staircase）

  - 13.6 浮动基座控制（float_control）

  - 13.7 各示例的完整控制流对比表

- **第14章 调试、分析与优化**

  - 14.1 数据记录器（DataLogger）使用

  - 14.2 Matlab 数据分析与可视化

  - 14.3 参数调优方法论

  - 14.4 常见问题排查

- **第15章 自定义机器人适配**

  - 15.1 模型文件准备

  - 15.2 参数调整指南

  - 15.3 Tutorial.md 模型替换实战

- **第16章 展望与进阶方向**

  - 16.1 强化学习与 MPC 的融合

  - 16.2 Sim-to-Real 迁移

  - 16.3 全身控制的前沿研究方向

  - 16.4 推荐学习资源


---

# 第一部分：绪论与基础

---

## 第1章：人形机器人运动控制概述

### 1.1 人形机器人的发展历史与现状

#### 1.1.1 从零到一：人形机器人的起源

人形机器人（Humanoid Robot）的研究可以追溯到上世纪70年代。1973年，日本早稻田大学的加藤一郎教授团队研制出了 **WABOT-1**（Waseda Robot），这是世界上第一个全尺寸的人形机器人。它拥有两只手臂、两条腿和一个视觉系统，虽然行走速度极慢（每步约45秒），但它的诞生标志着人类正式开启了"造一个自己"的征程。

此后几十年，人形机器人的发展大致经历了三个阶段：

- **1970s-1990s：萌芽探索期**。以静态步行为主，机器人需要时刻保持重心投影在支撑多边形内，行走姿态僵硬、速度慢。
- **2000s-2010s：动态行走期**。以本田 **ASIMO**（2000年）和波士顿动力 **Atlas**（2013年）为代表，实现了动态双足行走，机器人可以在行走中"自然摔倒"，通过不断迈步保持平衡。
- **2020s至今：商业化爆发期**。特斯拉 **Optimus**、Figure AI 的 **Figure 02**、宇树 **H1**、以及本教程使用的 **青龙（AzureLoong）** 等纷纷亮相，人形机器人开始从实验室走向工厂和家庭。

#### 1.1.2 为什么要做人形机器人？

一个自然而然的问题是：**为什么非要做成"人"的形状？** 轮式机器人不是更稳定、更容易控制吗？

答案是两个字：**适配**。人类世界的一切基础设施——楼梯、门把手、工具、操作台——都是为人形身材设计的。一台人形机器人理论上可以用人类的方式开门、爬楼梯、使用螺丝刀，而无需改造环境。此外，人形形态在人类社会中具有天然的亲和力，更适合服务、陪伴等场景。

当然，代价也不小——双足行走本质上是一个**不稳定控制问题**，这恰恰是本教程要攻克的核心。

---

### 1.2 运动控制的核心挑战

让一个31自由度的机器人稳定行走，究竟难在哪里？我们逐一拆解。

#### 1.2.1 高维：维数灾难

青龙机器人有 **31 个关节自由度**（详见1.4节），状态空间维度超过60维。在高维空间中，传统查表或简单的 PID 控制完全失效——你不可能手动调出31个关节的协调运动。控制算法必须能自动处理多关节的协调耦合。

#### 1.2.2 非线性：动力学耦合

机器人是一个**多刚体系统**，相邻连杆之间存在复杂的动力学耦合。举个直观的例子：

- 当左腿向前摆动时，由于动量守恒，躯干会不自觉地向右后方转动；
- 当手臂快速上抬时，质心（CoM）位置会改变，进而影响脚底受力。

这些耦合关系用数学描述就是高度非线性的二阶微分方程组：

$$M(q)\ddot{q} + C(q,\dot{q})\dot{q} + G(q) = S\tau + J_c^T F_c$$

其中 $M(q)$ 是质量矩阵，$C(q,\dot{q})$ 是科氏力和离心力项，$G(q)$ 是重力项。这些项都不是常数，而是随构型 $q$ 实时变化的。

#### 1.2.3 欠驱动：浮动基座

与工业机器人不同，人形机器人没有固定在地面上——它的"基座"是**漂浮在空中的**。数学上，这意味着基座的 6 个自由度（3个位置 + 3个姿态）没有直接对应的驱动关节，它们只能通过与地面的接触力间接控制。

在控制理论中，我们称这种系统为**欠驱动系统**（Underactuated System）。基座的状态不是"指令"出来的，而是"算出来"的——你需要通过规划足底反力来间接控制躯干的姿态和位置。

#### 1.2.4 不稳定性：本质上的倒立摆

双足行走本质上等效于一个**倒立摆**（Inverted Pendulum）。支撑腿相当于摆杆支点，躯干相当于摆杆顶部的质量。倒立摆的一个基本性质是：**静止时是不稳定的**——任何微小的扰动都会让它加速倾倒。

更严格地说，双足行走是一个**极限环**（Limit Cycle）：系统在稳定行走时不存在一个平衡点，而是沿着一条周期轨道循环。控制器的任务不是让系统停留在某个点，而是让它**跟着这条轨道周期性地走下去**。

这四条挑战（高维、非线性、欠驱动、不稳定）叠加在一起，使得人形机器人的运动控制成为机器人领域最具挑战性的问题之一。

---

### 1.3 Openloong-dyn-control 项目背景

#### 1.3.1 青龙机器人

**青龙（AzureLoong）** 是由国家地方共建人形机器人创新中心研发的国产开源人形机器人。其名字取自中国传统神话中的神兽青龙，象征着东方智慧与力量。

**Openloong** 开源项目由人形机器人（上海）有限公司、国家地方共建人形机器人创新中心与开放原子开源基金会共同运营。本仓库 `Openloong-dyn-control` 提供了基于 **MPC（模型预测控制）** 与 **WBC（全身控制）** 的仿人机器人控制框架，可在 MuJoCo 仿真平台上部署。

在实物样机上，该框架已实现了稳定的**行走**和**盲踩障碍物**两种运动；在仿真平台上还额外实现了**跳跃**运动。

#### 1.3.2 技术路线概览

本框架采用 **MPC + WBC** 的分层控制路线：

- **上层（MPC）**：使用**单刚体模型**（Single Rigid Body Model, SRBM）近似整个机器人，忽略腿部的质量细节，将机器人简化为一个有质心和足端力点的刚体。MPC 以 200 Hz 的频率运行，根据当前状态和期望速度，规划未来 10 步（每步 5ms）的最优足端接触力。
- **下层（WBC）**：使用**全动力学模型**（Full Dynamics），考虑所有 31 个关节和连杆的质量。WBC 以 1 kHz 的频率运行，将 MPC 规划的足端力跟踪为任务，同时满足摆动腿轨迹跟踪、躯干姿态保持、关节限位等多个优先级任务，最终求解出各关节的力矩指令。

这种分层设计的核心思想是：**高层做简化规划，低层做精细化跟踪**。MPC 用简化的模型快速算出"大致该怎么做"，WBC 用精确的模型算出"具体该怎么实现"。

---

### 1.4 青龙硬件参数

青龙机器人是一个全尺寸的人形机器人，主要参数如下：

| 参数 | 数值 |
|------|------|
| 总质量 | **77.35 kg** |
| 自由度总数 | **31** |
| 身高 | 约 1.7 m（仿真模型全高，含头部） |
| 躯干（base_link）质量 | 22.447 kg |

**自由度分布（31个自由度）：**

- **头部（2 DOF）**：偏航（J_head_yaw）、俯仰（J_head_pitch）
- **腰部（3 DOF）**：俯仰（J_waist_pitch）、滚转（J_waist_roll）、偏航（J_waist_yaw）
- **左臂（7 DOF）**：肩关节 x3 + 肘关节 x1 + 腕关节 x3（J_arm_l_01~07）
- **右臂（7 DOF）**：J_arm_r_01~07（对称）
- **左腿（6 DOF）**：髋关节滚转/偏航/俯仰 + 膝关节俯仰 + 踝关节俯仰/滚转
- **右腿（6 DOF）**：对称

关节命名规律可在源码中找到（对应文件名 `pino_kin_dyn.h` 第29-35行）：

```cpp
// pino_kin_dyn.h, 第29-35行
const std::vector<std::string> motorName = {
    "J_arm_l_01", ..., "J_arm_l_07",      // 左臂 7 个
    "J_arm_r_01", ..., "J_arm_r_07",      // 右臂 7 个
    "J_head_yaw", "J_head_pitch",         // 头部 2 个
    "J_waist_pitch", "J_waist_roll", "J_waist_yaw", // 腰部 3 个
    "J_hip_l_roll", "J_hip_l_yaw", "J_hip_l_pitch",  // 左腿 6 个
    "J_knee_l_pitch", "J_ankle_l_pitch", "J_ankle_l_roll",
    "J_hip_r_roll", "J_hip_r_yaw", "J_hip_r_pitch",  // 右腿 6 个
    "J_knee_r_pitch", "J_ankle_r_pitch", "J_ankle_r_roll"
};
```

注意：这 31 个自由度不包括浮动基座的 6 个自由度。在广义坐标向量 $q$ 中，前 6~7 个元素是基座的位姿（位置 + 四元数），第 7 个及以后才是关节位置。

**关键尺寸：**
- 大腿长度（髋-膝）：约 0.4 m
- 小腿长度（膝-踝）：约 0.387 m
- 髋关节间距（左右）：约 0.229 m（`width_hips`，见 `walk_wbc.cpp` 第51行）
- 足部尺寸：约 0.245 m × 0.08 m

---

### 1.5 控制框架整体架构

#### 1.5.1 分层控制：MPC → WBC

整个控制系统的架构可以看作是一个**三层流水线**：

```
┌───────────────────────────────────────────────────┐
│              第1层：感知与状态估计                    │
│   IMU + 关节传感器 → 状态估计器 → q, dq, 接触力   │
└──────────────────────┬────────────────────────────┘
                       ↓
┌───────────────────────────────────────────────────┐
│   第2层：MPC 高层规划 (200 Hz，使用单刚体模型)     │
│   ┌─────────┐  ┌──────────┐  ┌────────────────┐   │
│   │步态调度器 │→ │落脚点规划器│→ │MPC 优化求解   │   │
│   └─────────┘  └──────────┘  └────────┬───────┘   │
└──────────────────────────────────────────┼─────────┘
                                           ↓ 足端力规划
┌───────────────────────────────────────────────────┐
│  第3层：WBC 底层跟踪 (1 kHz，使用全动力学模型)    │
│   ┌──────────────┐  ┌─────────────────────────┐   │
│   │分层优先级 QP  │→ │逆动力学 → 关节力矩      │   │
│   └──────────────┘  └───────────┬─────────────┘   │
└──────────────────────────────────┼─────────────────┘
                                   ↓  τ_joint
                           MuJoCo 仿真 / 实物执行
```

三个层级以不同的频率异步运行：

| 层级 | 频率 | 模型复杂度 | 求解内容 |
|------|------|-----------|---------|
| 状态估计 | 1 kHz | 轻量 | 滤波、积分 |
| MPC | 200 Hz | 单刚体（12维状态） | 最优足端力 |
| WBC | 1 kHz | 全动力学（31 DOF） | 关节力矩 |

#### 1.5.2 数据流与控制流

各模块之间的数据通过 **DataBus**（参见 `common/data_bus.h`）进行交换。DataBus 是一个全局结构体，所有模块都遵循"读取-计算-写入"的简单逻辑：

```cpp
// walk_wbc.cpp 中的主循环（简化示意）
while (仿真运行) {
    // 1. 传感器更新
    mj_interface.updateSensorValues();
    mj_interface.dataBusWrite(RobotState);
    
    // 2. 状态估计
    StateModule.update();    // 状态估计
    StateModule.get(RobotState);
    
    // 3. 运动学/动力学计算
    kinDynSolver.computeJ_dJ();
    kinDynSolver.computeDyn();
    kinDynSolver.dataBusWrite(RobotState);
    
    // 4. 步态调度 & 落脚点规划
    gaitScheduler.step();
    footPlacement.getSwingPos();
    
    // 5. MPC（按 200Hz 频率调用）
    MPC_solv.cal();
    
    // 6. WBC 求解
    WBC_solv.computeDdq(kinDynSolver);
    WBC_solv.computeTau();
    
    // 7. PD/PVT 关节控制，发送力矩
    pvtCtr.calMotorsPVT();
    mj_interface.setMotorsTorque(RobotState.motors_tor_out);
}
```

#### 1.5.3 各核心模块职责

| 模块 | 文件位置 | 职责 |
|------|---------|------|
| `MJ_Interface` | `sim_interface/MJ_interface.*` | 封装 MuJoCo 传感器读取与力矩写入 |
| `StateEst` | `algorithm/StateEst.*` | 基座位置/速度估计，足端接触力估计 |
| `Pin_KinDyn` | `algorithm/pino_kin_dyn.*` | 基于 Pinocchio 的正运动学、雅可比、动力学计算 |
| `GaitScheduler` | `algorithm/gait_scheduler.*` | 步态相位管理（支撑相/摆动相切换） |
| `FootPlacement` | `algorithm/foot_placement.*` | 落脚点规划（含轨迹插值） |
| `MPC` | `algorithm/mpc.*` | 模型预测控制，单刚体模型 QP 求解 |
| `WBC_priority` | `algorithm/wbc_priority.*` | 全身控制，分层优先级 QP 求解 |
| `PriorityTasks` | `algorithm/priority_tasks.*` | WBC 任务优先级管理 |
| `PVT_Ctr` | `common/PVT_ctrl.*` | 位置-速度-力矩混合关节控制（PD 跟踪） |
| `DataBus` | `common/data_bus.h` | 全局数据总线，模块间数据交互 |
| `DataLogger` | `common/data_logger.*` | 数据记录与日志 |

---

### 1.6 章节导航与学习路径

本书面向有一定机器人学基础，但初次接触全身控制（WBC）和模型预测控制（MPC）的读者。建议的学习路径：

1. **第一部分（第1-2章）**：概览全文，搭建环境，运行第一个仿真。**你正在这里。**
2. **第二部分（第3-4章）**：深入 MPC 的数学原理。从单刚体模型（SRBM）建模开始，推导离散化公式，再到 QP 问题构建与求解。同时讲解步态调度与落脚点规划。
3. **第三部分（第5-6章）**：深入 WBC 的核心原理。从分层优先级控制的理论开始，分析每个任务（躯干姿态、摆动腿、支撑腿、手臂等）的数学表达，再到 QP 求解与逆动力学力矩计算。
4. **第四部分（第7-8章）**：进阶与实战。包括状态估计（滤波与数据融合）、仿真与实物的差异处理、调参与性能优化。

每一章都会紧密联系 `Openloong-dyn-control` 仓库中的实际代码，逐行解析核心算法。

---

## 第2章：准备工作与环境搭建

### 2.1 系统要求

在开始编译和运行代码之前，请确保你的系统满足以下要求：

- **操作系统**：Ubuntu 20.04 LTS 或 22.04 LTS（推荐 22.04）
- **编译器**：g++ 11.4.0 或更高版本（需支持 C++17 标准）
- **CMake**：3.10 或更高版本
- **OpenGL 支持**：MuJoCo 的仿真界面需要 OpenGL 支持
- **硬件**：建议至少 8 GB 内存，支持 OpenGL 3.3+ 的显卡

检查 g++ 和 CMake 版本：

```bash
g++ --version
cmake --version
```

如果版本过低，请升级（以 Ubuntu 22.04 为例）：

```bash
sudo apt update
sudo apt install git cmake gcc-11 g++-11
```

必须安装 OpenGL 相关依赖库：

```bash
sudo apt install libglu1-mesa-dev freeglut3-dev
```

> **注意**：以上是唯一需要 `apt` 安装的系统库。其余所有依赖（MuJoCo、Pinocchio、Eigen3、qpOASES、GLFW、JsonCpp、Quill 等）均已包含在仓库的 `third_party/` 目录中，**无需额外安装**。这大大简化了部署流程。

---

### 2.2 克隆与编译

#### 2.2.1 克隆代码仓库

首先，将代码仓库克隆到本地（本教程假设仓库已位于本地路径）：

```bash
# 如果从远程克隆（需联网且有访问权限）：
git clone https://github.com/loongOpen/Openloong-dyn-control.git

# 或者使用已有本地副本
cd ~/Documents/github_repos/wbc_repos/Openloong-dyn-control
```

#### 2.2.2 编译

仓库使用 CMake 构建系统。编译步骤如下：

```bash
cd ~/Documents/github_repos/wbc_repos/Openloong-dyn-control
mkdir build && cd build
cmake ..
make
```

编译过程会将所有源文件（`algorithm/`、`common/`、`math/`、`sim_interface/`）编译为 `core` 库，然后将各 demo 程序链接到该库。

从 `CMakeLists.txt`（第43-45行）可以看到文件组织方式：

```cmake
# CMakeLists.txt, 第43-45行
file(GLOB C_SOURCES *.c)
file(GLOB CPP_SOURCES *.cpp algorithm/*.cpp common/*.cpp math/*.cpp sim_interface/*.cpp)
file(GLOB HEADER_FILES *.h algorithm/*.h common/*.h math/*.h sim_interface/*.h)
```

#### 2.2.3 自包含依赖说明

`third_party/` 目录包含了所有运行时依赖，结构如下：

```
third_party/
├── boost/           # Boost 库（部分 Pinocchio 头文件依赖）
├── eigen3/          # Eigen 3 线性代数库
├── glfw/            # GLFW 图形窗口库（含预编译静态库）
├── jsoncpp/         # JSON 解析库
├── mujoco/          # MuJoCo 仿真引擎（含预编译动态库）
├── pinocchio/       # Pinocchio 动力学库
├── qpOASES/         # QP 求解器
├── quill/           # Quill 日志工具
└── urdfdom/         # URDF 解析器
```

编译时 CMake 会自动包含这些依赖（`CMakeLists.txt` 第9-25行）：

```cmake
# CMakeLists.txt, 第9-25行
set(dirEigen "third_party/eigen3")
set(dirGlfw "third_party/glfw")
set(dirPino "third_party/pinocchio")
set(dirJson "third_party/jsoncpp")
set(dirQuill "third_party/quill")
...
include_directories(${allInc})
```

这也意味着，如果你想换用系统安装的其他版本的依赖，只需要修改 CMakeLists.txt 中的对应路径即可。

---

### 2.3 运行第一个仿真

#### 2.3.1 启动仿真

编译完成后，在 `build/` 目录下会生成多个可执行文件。先运行最简单的纯 WBC 行走示例：

```bash
cd ~/Documents/github_repos/wbc_repos/Openloong-dyn-control/build
./walk_wbc
```

稍等片刻，你会看到一个 MuJoCo 可视化窗口弹出，青龙机器人缓缓站立，然后开始向前行走。

#### 2.3.2 运行其他 Demo

仓库提供了多种仿真示例，各有侧重：

| 可执行文件 | 源文件 | 功能说明 |
|-----------|--------|---------|
| `walk_wbc` | `demo/walk_wbc.cpp` | **纯 WBC 行走**（无 MPC），演示 WBC 的基本行走能力 |
| `walk_mpc_wbc` | `demo/walk_mpc_wbc.cpp` | **MPC + WBC 行走**，比纯 WBC 更稳定，能适应更复杂地形 |
| `jump_mpc` | `demo/jump_mpc.cpp` | **跳跃**，基于 MPC 的跳跃控制 |
| `walk_wbc_joystick` | `demo/walk_wbc_joystick.cpp` | **键盘控制行走**，可用键盘控制前进后退和转弯 |
| `walk_mpc_wbc_joystick` | `demo/walk_mpc_wbc_joystick.cpp` | **MPC + 键盘控制** |
| `walk_wbc_staircase` | `demo/walk_wbc_staircase.cpp` | **上台阶**，演示盲踩障碍物能力 |
| `float_control` | `demo/float_control.cpp` | **浮动基座控制**，调试用 |

#### 2.3.3 MuJoCo 可视化操作

MuJoCo 仿真窗口支持以下交互操作：

| 操作 | 功能 |
|------|------|
| 鼠标左键拖拽 | 旋转视角 |
| 鼠标右键拖拽 | 平移视角 |
| 滚轮 | 缩放 |
| 按键 **`1`** | 暂停/恢复仿真 |
| 按键 **`2`** | 单步仿真 |
| 按键 **`Space`** | 复位视角跟踪 |
| **`Ctrl + 鼠标右键`** | 选中并拖动物体 |

注意：仿真默认以 **实时模式** 运行。如果仿真速度慢于实时，可以通过修改 `scene.xml` 中的 `timestep` 参数调整（默认 0.001 秒），或以 `--fast` 参数运行（需要查看具体 demo 是否支持）。

---

### 2.4 代码组织结构

整个仓库的代码组织结构清晰，模块边界分明：

```
Openloong-dyn-control/
├── algorithm/          # 核心算法模块
│   ├── mpc.*           # 模型预测控制
│   ├── wbc_priority.*  # 全身控制 + QP 求解
│   ├── priority_tasks.* # 任务优先级管理
│   ├── pino_kin_dyn.*  # 运动学/动力学（Pinocchio 封装）
│   ├── StateEst.*      # 状态估计
│   ├── gait_scheduler.* # 步态调度
│   ├── foot_placement.* # 落脚点规划
│   ├── joystick_interpreter.* # 摇杆/键盘指令解释
│   └── Eul_W_filter.*  # 欧拉角滤波
├── common/             # 通用模块
│   ├── data_bus.h      # 数据总线（结构体定义）
│   ├── PVT_ctrl.*      # 关节 PD/PVT 控制
│   ├── data_logger.*   # 数据记录
│   └── joint_ctrl_config.json # 关节参数配置文件
├── demo/               # 可执行示例
│   ├── walk_wbc.cpp
│   ├── walk_mpc_wbc.cpp
│   ├── jump_mpc.cpp
│   └── ...
├── math/               # 数学工具
│   ├── useful_math.*   # 实用数学函数
│   ├── LPF_fst.*       # 一阶低通滤波
│   └── bezier_1D.*     # Bezier 曲线插值
├── sim_interface/      # 仿真接口
│   ├── MJ_interface.*  # MuJoCo 封装
│   └── GLFW_callbacks.* # 窗口交互回调
├── models/             # 机器人模型
│   ├── AzureLoong.xml  # MuJoCo 模型
│   ├── AzureLoong.urdf # URDF 模型
│   └── meshes/         # STL 网格文件
├── third_party/        # 第三方依赖
└── CMakeLists.txt      # 顶层构建文件
```

**设计原则：**

- **模块化**：每个模块以 `类` 形式封装，对外提供 `dataBusRead()`、`cal()`（或 `step()`/`update()`）、`dataBusWrite()` 三个接口。
- **总线数据交互**：使用 `DataBus` 结构体作为共享数据容器，模块间不直接调用，降低了耦合度（参见 `common/data_bus.h`）。
- **"读取-计算-写入"范式**：每个模块的计算步骤严格遵循三段式，代码可读性和可调试性强。

---

### 2.5 开发工具推荐

#### 2.5.1 代码编辑

- **VS Code**：推荐配合以下扩展使用：
  - C/C++（Microsoft）
  - CMake Tools
  - Clang-Format（代码风格统一）
  
- **CLion**：JetBrains 出品的 C++ IDE，对 CMake 项目有原生支持，调试体验好。

#### 2.5.2 仿真与可视化

- **MuJoCo Viewer**：仓库自带，按 `1` 键暂停后可以用鼠标右键拖动观察机器人各部位状态。
- **Matlab/Octave**：`record/plotData.m` 提供了一个简单的数据可视化脚本，可用于分析 `DataLogger` 记录的 `.log` 文件。

```matlab
% record/plotData.m - 读取并绘制日志数据
% 在 Matlab 中运行即可查看各传感器数据曲线
```

#### 2.5.3 调试与分析

- **gdb / lldb**：直接调试可执行文件
- **Valgrind**：检查内存泄漏（低配机器上谨慎使用，MuJoCo 渲染会消耗较多资源）
- **perf / flamegraph**：当需要分析控制时序性能时，可用 perf 生成火焰图

#### 2.5.4 首要阅读入口

对于初次接触本仓库的开发者，建议按以下顺序阅读源码：

1. **`common/data_bus.h`**：理解数据结构，知道系统中有哪些信息在流转。
2. **`demo/walk_wbc.cpp`**：理解主循环的控制流程，追踪每一步调用了哪些模块。
3. **`algorithm/mpc.h`**（如果走 MPC 路线）或 **`algorithm/wbc_priority.h`**：理解核心算法接口。
4. **`algorithm/pino_kin_dyn.h`**：理解运动学/动力学计算是如何封装的。

---

> **下一步**：在运行环境就绪后，请进入第二部分（第3-4章），深入学习 MPC 的数学模型与代码实现。

---

*本教程对应的代码仓库：[Openloong-dyn-control](https://github.com/loongOpen/Openloong-dyn-control)*
*反馈与讨论：[GitHub Discussions](https://github.com/orgs/loongOpen/discussions)*


---

# 第二部分：数学基础

> **目标读者**：具有工科线性代数基础，但可能已经遗忘的读者。
> **写作风格**：从直观理解出发，逐步深入到数学严谨性，所有推导不跳步。

---

## 第3章 线性代数与数值优化基础

在开始学习全身控制之前，我们先花一些时间打好数学基础。不要觉得这是"浪费时间"——事实上，全身控制中 90% 的代码最终都可以归结为矩阵运算和优化问题求解。如果线性代数基础不牢，后面的内容会读得十分吃力；反之，如果你的线性代数直觉够好，你会发现在机器人控制中遇到的大部分问题都只是"换个角度看矩阵乘法"而已。

### 3.1 向量与矩阵的基本运算

#### 3.1.1 向量：不只是坐标

我们从最熟悉的向量说起。一个向量 $\mathbf{v} \in \mathbb{R}^n$ 就是一个 $n$ 维的有序数组。在机器人学中，向量几乎无处不在：

- 关节位置向量 $\mathbf{q} \in \mathbb{R}^{n_q}$：每个分量是一个关节的角度
- 末端位置向量 $\mathbf{p} \in \mathbb{R}^3$：足端或手端的 3D 位置
- 力/力矩向量 $\mathbf{f} \in \mathbb{R}^6$：包含 3 个力和 3 个力矩

**点积（内积）** 是最基本的向量运算：
$$
\mathbf{a} \cdot \mathbf{b} = \sum_{i=1}^n a_i b_i = \|\mathbf{a}\| \|\mathbf{b}\| \cos\theta
$$

点积的几何意义非常直观：它衡量两个向量在方向上的"对齐程度"——当两个向量方向相同时点积最大，垂直时为零，相反时为负。

在机器人学中，点积最直接的应用是**功率计算**：关节力矩 $\tau$ 和关节速度 $\dot{q}$ 的点积正是该关节的瞬时功率：
$$
P = \tau \cdot \dot{q} = \sum_{i=1}^n \tau_i \dot{q}_i
$$

**外积（叉积）** 仅在三维空间中定义：
$$
\mathbf{a} \times \mathbf{b} = 
\begin{bmatrix} a_2 b_3 - a_3 b_2 \\ a_3 b_1 - a_1 b_3 \\ a_1 b_2 - a_2 b_1 \end{bmatrix}
$$

叉积的结果是一个**同时垂直于 $\mathbf{a}$ 和 $\mathbf{b}$** 的向量，大小等于 $\|\mathbf{a}\| \|\mathbf{b}\| \sin\theta$。这恰恰是力对某点产生力矩的计算方式：
$$
\boldsymbol{\tau} = \mathbf{r} \times \mathbf{f}
$$

叉积还可以写成**反对称矩阵**的形式，这在后面雅可比矩阵的推导中非常有用：
$$
\mathbf{a} \times \mathbf{b} = [\mathbf{a}]_\times \mathbf{b} = 
\begin{bmatrix} 0 & -a_3 & a_2 \\ a_3 & 0 & -a_1 \\ -a_2 & a_1 & 0 \end{bmatrix} \mathbf{b}
$$

仓库中 `useful_math.cpp` 的 `CrossProduct_A` 函数正是构造这个反对称矩阵：
```cpp
Eigen::Matrix<double, 3, 3> CrossProduct_A(Eigen::Matrix<double, 3, 1> A)
{
    Eigen::Matrix<double, 3, 3> M;
    M << 0.0, -A[2], A[1],
        A[2], 0.0, -A[0],
        -A[1], A[0], 0.0;
    return M;
}
```

**范数**衡量向量的大小。最常用的是 $\ell_2$ 范数（欧几里得范数）：
$$
\|\mathbf{v}\|_2 = \sqrt{v_1^2 + v_2^2 + \cdots + v_n^2}
$$

在 WBC 代码中，范数经常用于判断误差是否足够小——例如在逆运动学迭代中（`pino_kin_dyn.cpp` 的 `computeInK_Leg` 函数）：
```cpp
if (errCompact.norm() < eps) {
    success = true;
    break;
}
```

#### 3.1.2 矩阵：线性变换的编码

矩阵 $\mathbf{A} \in \mathbb{R}^{m \times n}$ 可以看作一个将 $n$ 维空间映射到 $m$ 维空间的线性变换。矩阵乘法 $\mathbf{A}\mathbf{x}$ 的含义就是：**将向量 $\mathbf{x}$ 通过线性变换 $\mathbf{A}$ 映射到新的向量**。

几个需要牢记的矩阵运算：

**矩阵乘法**：$\mathbf{C} = \mathbf{A}\mathbf{B}$，其中 $C_{ij} = \sum_k A_{ik} B_{kj}$。注意矩阵乘法不满足交换律——$\mathbf{A}\mathbf{B} \ne \mathbf{B}\mathbf{A}$（通常情况）。

**转置**：$(\mathbf{A}^\top)_{ij} = A_{ji}$。几何上，转置对应着"把行空间映射到列空间"的变换。对于旋转矩阵 $\mathbf{R}$，转置就是它的逆：$\mathbf{R}^\top = \mathbf{R}^{-1}$。

**逆矩阵**：$\mathbf{A}^{-1}$ 满足 $\mathbf{A}^{-1}\mathbf{A} = \mathbf{A}\mathbf{A}^{-1} = \mathbf{I}$。只有方阵且满秩时才可逆。逆矩阵对应着"撤销"线性变换 $\mathbf{A}$ 的作用。

#### 3.1.3 代码示例：Eigen 3 基本用法

Openloong 仓库使用 Eigen 3 作为线性代数库。以下是最基本的用法：

```cpp
#include "Eigen/Dense"
#include <iostream>

int main() {
    // 定义向量
    Eigen::VectorXd v(3);      // 动态大小的向量
    v << 1.0, 2.0, 3.0;        // 逗号初始化

    // 定义矩阵
    Eigen::MatrixXd M(3, 3);   // 动态大小的矩阵
    M << 1, 0, 0,
         0, 1, 0,
         0, 0, 1;              // 单位矩阵

    // 矩阵-向量乘法
    Eigen::VectorXd result = M * v;

    // 转置
    Eigen::MatrixXd Mt = M.transpose();

    // 逆矩阵（仅对方阵）
    Eigen::MatrixXd Minv = M.inverse();

    // 解线性方程组 A*x = b
    Eigen::VectorXd b(3);
    b << 1, 2, 3;
    Eigen::VectorXd x = M.ldlt().solve(b);  // 比求逆更高效、更稳定

    return 0;
}
```

> **为什么用 `.ldlt().solve()` 而不是 `.inverse()`？** 因为 LDLT 分解（一种 Cholesky 分解的变体）的计算复杂度为 $O(n^3/3)$，比显式求逆的 $O(n^3)$ 快约 3 倍，且数值稳定性更好。在机器人实时控制中，每一微秒都很宝贵。

在 `pino_kin_dyn.h` 中，我们看到 Eigen 被大量用于存储机器人的状态和动力学量：
```cpp
Eigen::VectorXd q, dq, ddq;         // 关节位置、速度、加速度
Eigen::MatrixXd dyn_M, dyn_C, dyn_G; // 质量矩阵、科里奥利矩阵、重力向量
Eigen::Matrix<double, 6, -1> J_l;   // 左腿雅可比矩阵（6×model_nv）
```

### 3.2 特征值分解与奇异值分解（SVD）

#### 3.2.1 特征值分解：理解矩阵的"拉伸"

对于一个方阵 $\mathbf{A} \in \mathbb{R}^{n \times n}$，如果存在向量 $\mathbf{v} \ne \mathbf{0}$ 和标量 $\lambda$ 使得：
$$
\mathbf{A}\mathbf{v} = \lambda \mathbf{v}
$$

那么 $\mathbf{v}$ 就是 $\mathbf{A}$ 的**特征向量**，$\lambda$ 是对应的**特征值**。

**直观理解**：在 $\mathbf{v}$ 这个方向上，矩阵 $\mathbf{A}$ 的作用仅仅是"拉伸"（缩放）——不会改变方向。特征值 $\lambda$ 就是拉伸倍数，特征向量 $\mathbf{v}$ 就是拉伸发生的方向。

特征值分解将矩阵分解为：
$$
\mathbf{A} = \mathbf{V} \boldsymbol{\Lambda} \mathbf{V}^{-1}
$$

其中 $\boldsymbol{\Lambda}$ 是对角线为特征值的对角矩阵，$\mathbf{V}$ 的列是特征向量。

**为什么这对机器人学重要？** 考虑质量矩阵 $\mathbf{M}(q)$——它是对称正定矩阵，因此其特征值全为正。最大的特征值对应着"在该方向上的惯性最大"，即最难加速的方向。这在规划快速运动时非常关键。

#### 3.2.2 SVD：任何矩阵都能分解为"旋转×拉伸×旋转"

奇异值分解（Singular Value Decomposition, SVD）是线性代数中最强大的工具之一。它说：**任何矩阵** $\mathbf{A} \in \mathbb{R}^{m \times n}$ 都可以分解为：
$$
\mathbf{A} = \mathbf{U} \boldsymbol{\Sigma} \mathbf{V}^\top
$$

其中：
- $\mathbf{U} \in \mathbb{R}^{m \times m}$ 和 $\mathbf{V} \in \mathbb{R}^{n \times n}$ 是**正交矩阵**（即旋转/反射）
- $\boldsymbol{\Sigma} \in \mathbb{R}^{m \times n}$ 是对角矩阵，对角线元素 $\sigma_1 \ge \sigma_2 \ge \cdots \ge \sigma_r > 0$ 称为**奇异值**

**几何理解**：SVD 告诉我们，任何线性变换都可以分解为三个步骤：
1. **旋转**（$\mathbf{V}^\top$）：将标准坐标系旋转到"输入"方向
2. **拉伸**（$\boldsymbol{\Sigma}$）：沿新坐标轴方向拉伸（奇异值是拉伸倍数）
3. **旋转**（$\mathbf{U}$）：再旋转到"输出"方向

这就像拧毛巾：找到最佳的扭转方向，挤压，再换到观察角度。

#### 3.2.3 在机器人学中的应用

**可操作度（Manipulability）**：雅可比矩阵 $\mathbf{J}(\mathbf{q})$ 的奇异值反映了机器人在各方向上的运动能力。可操作度定义为：
$$
w = \sqrt{\det(\mathbf{J}\mathbf{J}^\top)} = \prod_{i=1}^r \sigma_i
$$

当 $w$ 接近零时，机器人处于**奇异位形**——在某个方向上完全失去运动能力。比如膝关节完全伸直时，无法再通过膝关节运动改变足端高度。

**条件数**：$\kappa = \sigma_{\max} / \sigma_{\min}$ 衡量雅可比矩阵的"病态程度"。条件数越大，矩阵越接近奇异，数值求解越不稳定。在 WBC 中，当任务雅可比矩阵条件数很大时，我们需要引入阻尼项来保证数值稳定性。

#### 3.2.4 代码示例：Eigen SVD 求解

Eigen 的 SVD 求解非常简单：

```cpp
#include "Eigen/Dense"
#include <iostream>

int main() {
    Eigen::MatrixXd A(3, 2);
    A << 1, 2,
         3, 4,
         5, 6;

    // 计算 SVD
    Eigen::JacobiSVD<Eigen::MatrixXd> svd(A, Eigen::ComputeFullU | Eigen::ComputeFullV);

    // 获取分解结果
    Eigen::MatrixXd U = svd.matrixU();
    Eigen::VectorXd S = svd.singularValues();
    Eigen::MatrixXd V = svd.matrixV();

    std::cout << "奇异值: " << S.transpose() << std::endl;

    return 0;
}
```

在仓库的 `useful_math.cpp` 中，`pseudoInv_SVD` 函数（下一节详细讨论）正是基于 SVD 实现的。

### 3.3 伪逆（Pseudoinverse）

#### 3.3.1 从最小二乘问题出发

考虑线性方程组 $\mathbf{A}\mathbf{x} = \mathbf{b}$，其中 $\mathbf{A} \in \mathbb{R}^{m \times n}$。

- 当 $m = n$ 且 $\mathbf{A}$ 可逆时，我们有唯一解 $\mathbf{x} = \mathbf{A}^{-1}\mathbf{b}$
- 当 $m > n$ 时（方程多于未知数），通常无解——这就是**超定系统**

但在机器人学中，我们经常遇到"无解"的情况。例如：我们希望同时控制末端的位置和姿态，但关节数量不够。这时怎么办？

**答案是**：找一个"尽可能满足"的解——即最小化残差 $\|\mathbf{A}\mathbf{x} - \mathbf{b}\|^2$ 的 $\mathbf{x}$。这就是**最小二乘解**。

Moore-Penrose 伪逆 $\mathbf{A}^\dagger$ 给出了这个解：
$$
\mathbf{x}^* = \mathbf{A}^\dagger \mathbf{b} = \arg\min_{\mathbf{x}} \|\mathbf{A}\mathbf{x} - \mathbf{b}\|^2
$$

#### 3.3.2 SVD 计算伪逆

利用 SVD，伪逆的计算非常简单优雅：
$$
\mathbf{A} = \mathbf{U}\boldsymbol{\Sigma}\mathbf{V}^\top \quad \Longrightarrow \quad \mathbf{A}^\dagger = \mathbf{V}\boldsymbol{\Sigma}^\dagger \mathbf{U}^\top
$$

其中 $\boldsymbol{\Sigma}^\dagger$ 是将 $\boldsymbol{\Sigma}$ 中的非零奇异值取倒数：
$$
\Sigma^\dagger_{ii} = \begin{cases} 1/\sigma_i & \sigma_i > \epsilon \\ 0 & \sigma_i \le \epsilon \end{cases}
$$

这正是仓库中 `useful_math.cpp` 的 `pseudoInv_SVD` 实现：

```cpp
Eigen::MatrixXd pseudoInv_SVD(const Eigen::MatrixXd &mat)
{
    auto svd = mat.jacobiSvd(Eigen::ComputeFullU | Eigen::ComputeFullV);
    const auto &singularValues = svd.singularValues();
    Eigen::MatrixXd singularValuesInv;
    double maxSgVal{0};
    for (unsigned int i = 0; i < singularValues.size(); ++i)
    {
        if (singularValues(i) > maxSgVal)
            maxSgVal = singularValues(i);
    }
    // 容差：小于 eps*max_dim*max_val 的奇异值视为零
    double tolerance = std::numeric_limits<double>::epsilon() 
                       * std::max(mat.rows(), mat.cols()) * maxSgVal;
    singularValuesInv = Eigen::MatrixXd::Zero(mat.cols(), mat.rows());
    for (unsigned int i = 0; i < singularValues.size(); ++i)
    {
        if (singularValues(i) > tolerance)
            singularValuesInv(i, i) = Scalar{1} / singularValues(i);
        else
            singularValuesInv(i, i) = Scalar{0};  // 截断奇异值
    }
    return svd.matrixV() * singularValuesInv * svd.matrixU().adjoint();
};
```

这里的**截断容差**非常重要：它将太小的奇异值设为零。这相当于说"在奇异方向上，不做任何控制"——这正是解决奇异位形问题的工程方案。

#### 3.3.3 加权伪逆：不同维度重要性不同

有时，不同的关节或不同的任务方向重要性不同。例如，在行走时，摆动腿足端的高度方向（z）比水平方向（x, y）需要更精确的控制。为此，我们引入**加权伪逆**：

$$
\mathbf{A}^\dagger_{\mathbf{W}} = \mathbf{W}^{-1}\mathbf{A}^\top(\mathbf{A}\mathbf{W}^{-1}\mathbf{A}^\top)^{-1}
$$

其中 $\mathbf{W}$ 是一个正定的权重对角矩阵。权重越大，对应变量在优化中的"成本"越高，实际变化越小。

仓库中 `useful_math.cpp` 的 `pseudoInv_right_weighted` 实现了加权伪逆：

```cpp
Eigen::MatrixXd pseudoInv_right_weighted(const Eigen::MatrixXd &M, 
                                          const Eigen::DiagonalMatrix<double, -1> &W)
{
    double damp = 0;
    Eigen::MatrixXd Mres;
    Mres = M * W.inverse() * M.transpose();
    Mres.diagonal().array() += damp;  // 可添加阻尼项
    Mres = W.inverse() * M.transpose() 
           * Mres.completeOrthogonalDecomposition().pseudoInverse();
    return Mres;
}
```

#### 3.3.4 动力学加权伪逆

更进一步的，当我们在任务空间控制机器人时，应该考虑动力学的"惯性"特性。质量矩阵 $\mathbf{M}(q)$ 定义了各关节之间的惯性耦合——在某个方向上使劲，其他方向也会动。**动力学加权伪逆**使用质量矩阵（或其逆）作为权重：

```cpp
Eigen::MatrixXd dyn_pseudoInv(const Eigen::MatrixXd &M, const Eigen::MatrixXd &dyn_M, bool isMinv)
{
    double damp = 0;
    Eigen::MatrixXd Minv;
    if (isMinv)
        Minv = dyn_M;             // 直接传入 M^{-1}
    else
        Minv = dyn_M.llt().solve( // 计算 M^{-1}
            Eigen::MatrixXd::Identity(dyn_M.rows(), dyn_M.cols()));

    Eigen::MatrixXd temp = M * Minv * M.transpose();
    temp.diagonal().array() += damp;
    Eigen::MatrixXd res = Minv * M.transpose() 
                         * temp.completeOrthogonalDecomposition().pseudoInverse();
    return res;
}
```

这里 $\mathbf{M}^{-1}$ 的作用是把"任务空间"的优先级映射回"关节空间"的扭矩分配。这背后的物理直觉是：**惯性大的关节"不愿意"快速运动，惯性小的关节可以更灵活地响应任务需求**。

### 3.4 二次规划（QP）问题

#### 3.4.1 标准形式

二次规划（Quadratic Programming, QP）是最优化的一个子领域，其标准形式为：

$$
\begin{aligned}
\min_{\mathbf{x}} \quad & \frac{1}{2} \mathbf{x}^\top \mathbf{H} \mathbf{x} + \mathbf{f}^\top \mathbf{x} \\
\text{s.t.} \quad & \mathbf{l} \le \mathbf{A} \mathbf{x} \le \mathbf{u}
\end{aligned}
$$

- $\mathbf{H} \in \mathbb{R}^{n \times n}$：Hessian 矩阵，**必须对称正定**（保证问题有唯一最小值）
- $\mathbf{f} \in \mathbb{R}^n$：线性项系数
- $\mathbf{A} \in \mathbb{R}^{m \times n}$：约束矩阵
- $\mathbf{l}, \mathbf{u} \in \mathbb{R}^m$：约束的下界和上界

如果 $\mathbf{l} = \mathbf{u}$，则是**等式约束**；如果 $\mathbf{l} < \mathbf{u}$，则是**不等式约束**。

#### 3.4.2 几何直觉

把 QP 的目标函数画成等高线：$\frac{1}{2}\mathbf{x}^\top\mathbf{H}\mathbf{x} + \mathbf{f}^\top\mathbf{x}$ 的等高线是**椭圆**（因为 $\mathbf{H}$ 正定，所以等高线是同心椭圆，而不是双曲线或抛物线）。

QP 的求解就是：**在由约束 $\mathbf{l} \le \mathbf{A}\mathbf{x} \le \mathbf{u}$ 定义的多面体（可行域）内，找到使目标函数最小的点**。

如果无约束，最小值在椭圆中心（即 $-\mathbf{H}^{-1}\mathbf{f}$）。有约束时，最小值要么在椭圆中心（如果它在可行域内），要么在可行域的边界上。

#### 3.4.3 MPC 和 WBC 中 QP 问题的来源

**模型预测控制（MPC）**中的 QP：MPC 在每个时间步求解一个有限时域最优控制问题。目标函数通常最小化状态误差和控制量的加权平方和，约束来自系统动力学、执行器限制和接触力约束。

在 `mpc.h` 中可以看到 QP 问题的维度定义：
```cpp
const uint16_t  nx = 12;    // 状态维度（位置、姿态、动量...）
const uint16_t  nu = 13;    // 控制输入维度
const uint16_t  nc = ...;   // 约束数量
```

**全身控制（WBC）**中的 QP：WBC 中有一个重要的 QP 步骤是计算关节力矩（`wbc_priority.cpp` 的 `computeTau()` 函数）。变量是 $\mathbf{x} = [\delta\ddot{\mathbf{q}}_b; \Delta\mathbf{F}_r]$，即基座加速度修正和接触力修正。目标函数最小化这两者，约束包括浮动基座动力学、摩擦锥和力矩限制。

在 `wbc_priority.h` 中：
```cpp
WBC_priority(int model_nv_In, int QP_nvIn, int QP_ncIn, double miu_In, double dt);
// QP_nvIn=18, QP_ncIn=22 — 18个变量，22个约束
```

### 3.5 qpOASES 求解器原理

#### 3.5.1 在线活跃集法

qpOASES 使用**在线活跃集法（Online Active Set）**来求解 QP。其核心思想是：

一个不等式约束要么是"活跃的"（在最优解处等号成立），要么是"非活跃的"（不等式严格成立）。如果我们提前知道哪些约束在最优解处是活跃的，就可以把这些约束当作等式约束来处理，QP 就简化为了一个等式约束 QP，可以直接求解。

活跃集法从一个初始的活跃集猜测出发，迭代地：
1. **求解当前活跃集下的等式约束 QP**
2. 检查结果是否满足所有非活跃约束
3. 如果不满足，调整活跃集（添加或移除约束）
4. 重复直到收敛

#### 3.5.2 冷启动 vs 热启动

**冷启动**：每次求解 QP 时从零开始，没有初始猜测。在机器人实时控制中，冷启动通常需要更多的迭代，计算时间不确定。

**热启动**：利用上一时刻的 QP 解作为当前时刻的初始猜测。因为机器人的状态在相邻时间步间变化很小，热启动能大幅加速求解。qpOASES 天然支持热启动——这正是其名称中"在线"的含义。

在 `wbc_priority.cpp` 中每次调用 QP 求解：
```cpp
res = QP_prob.init(qp_H, qp_g, qp_A, NULL, NULL, qp_lbA, qp_ubA, nWSR, &cpu_time, xOpt_iniGuess);
```

注意 `xOpt_iniGuess` 被设为零——这是冷启动。在更高效的实现中（比如 `mpc.cpp`），可以用上一时刻的解来初始化。

#### 3.5.3 QP 求解的数值稳定性

QP 求解中常见的数值问题：

1. **Hessian 矩阵接近奇异**：如果 $\mathbf{H}$ 的条件数很大，求解过程对舍入误差非常敏感。可以通过添加正则化项 $\epsilon\mathbf{I}$ 来解决。

2. **约束冲突**：有时约束之间相互矛盾（例如，位置上限低于下限），QP 求解器会返回不可行。在实际 WBC 中，需要使用"软约束"（将约束作为目标函数的惩罚项）来避免这个问题。

3. **缩放不当**：如果不同变量的数量级差异很大（如关节位置是弧度，力是牛顿），会导致 $\mathbf{H}$ 条件数恶化。好的做法是对变量进行归一化。

### 3.6 代码实践：Eigen 3 使用示例

以下是一个完整的 Eigen 使用示例，涵盖了本章学到的所有概念：

```cpp
#include "Eigen/Dense"
#include "useful_math.h"
#include <iostream>

int main() {
    // ======== 1. 矩阵构造与基本运算 ========
    std::cout << "======== 矩阵构造与基本运算 ========" << std::endl;
    
    // 固定大小的矩阵（编译期优化更好）
    Eigen::Matrix3d R;
    R = Eigen::AngleAxisd(0.5, Eigen::Vector3d::UnitZ())  // Z轴旋转 0.5rad
      * Eigen::AngleAxisd(0.3, Eigen::Vector3d::UnitY())  // Y轴旋转 0.3rad
      * Eigen::AngleAxisd(0.1, Eigen::Vector3d::UnitX()); // X轴旋转 0.1rad
    
    std::cout << "旋转矩阵 R:\n" << R << std::endl;
    std::cout << "R^T * R = I? (应是单位阵)\n" << R.transpose() * R << std::endl;
    std::cout << "行列式 det(R) = " << R.determinant() << " (应为1)" << std::endl;
    
    // 动态大小的向量
    Eigen::VectorXd q(20);  // 20个关节的关节位置
    q.setRandom();          // 随机初始化
    
    // ======== 2. SVD 分解 ========
    std::cout << "\n======== SVD 分解 ========" << std::endl;
    
    Eigen::MatrixXd J(6, 20);  // 6×20 的雅可比矩阵
    J.setRandom();
    
    Eigen::JacobiSVD<Eigen::MatrixXd> svd(J, Eigen::ComputeFullU | Eigen::ComputeFullV);
    std::cout << "奇异值: " << svd.singularValues().transpose() << std::endl;
    std::cout << "条件数: " << svd.singularValues()(0) / svd.singularValues()(svd.singularValues().size()-1) << std::endl;
    std::cout << "可操作度: " << svd.singularValues().prod() << std::endl;
    
    // ======== 3. 伪逆 ========
    std::cout << "\n======== 伪逆 ========" << std::endl;
    
    Eigen::MatrixXd J_pinv = pseudoInv_SVD(J);
    
    // 验证伪逆性质: J * J^† * J = J
    Eigen::MatrixXd check = J * J_pinv * J;
    std::cout << "J * J^† * J 与 J 的误差: " << (check - J).norm() << std::endl;
    
    // ======== 4. 加权伪逆 ========
    std::cout << "\n======== 加权伪逆 ========" << std::endl;
    
    Eigen::DiagonalMatrix<double, -1> W(20);
    W.diagonal() << Eigen::VectorXd::Ones(20) * 0.1;  // 所有关节权重 0.1
    W.diagonal()(18) = 10.0;  // 膝关节权重很高 = 不希望膝关节运动
    
    Eigen::MatrixXd J_pinv_w = pseudoInv_right_weighted(J, W);
    
    // ======== 5. 动力学加权伪逆 ========
    std::cout << "\n======== 动力学加权伪逆 ========" << std::endl;
    
    // 模拟质量矩阵（对称正定）
    Eigen::MatrixXd M(20, 20);
    M.setIdentity();
    for (int i = 0; i < 20; i++) M(i, i) = 1.0 + i * 0.1;  // 惯性随关节增大
    
    Eigen::MatrixXd J_pinv_dyn = dyn_pseudoInv(J, M, false);
    
    // ======== 6. 解线性方程组 ========
    std::cout << "\n======== 解线性方程组 ========" << std::endl;
    
    Eigen::VectorXd b(20);
    b.setRandom();
    Eigen::VectorXd x = M.ldlt().solve(b);
    std::cout << "M * x - b 的误差: " << (M * x - b).norm() << std::endl;
    
    return 0;
}
```

编译时链接 Eigen 库，不需要额外的库文件——Eigen 是纯头文件库。

---

## 第4章 刚体运动学与动力学

### 4.1 旋转的数学表达

在三维空间中描述旋转，我们面临一个基本问题：旋转有 3 个自由度，但不同的表示方法以不同的方式描述这 3 个自由度。

#### 4.1.1 旋转矩阵 SO(3)

旋转矩阵 $\mathbf{R} \in \mathbb{R}^{3 \times 3}$ 满足两个性质：
1. **正交性**：$\mathbf{R}^\top \mathbf{R} = \mathbf{I}$，$\det(\mathbf{R}) = 1$
2. 所有这样的矩阵构成**特殊正交群** $\text{SO}(3)$

旋转矩阵将向量从一个坐标系变换到另一个坐标系。如果 $\mathbf{p}$ 在坐标系 $\{B\}$ 中的坐标为 $\mathbf{p}^B$，则它在 $\{A\}$ 中的坐标为：
$$
\mathbf{p}^A = \mathbf{R}^A_B \, \mathbf{p}^B
$$

**冗余性**：旋转矩阵用 9 个参数描述 3 个自由度，6 个约束（正交性 + 单位行列式）。这带来了一些问题：数值计算中累积误差会破坏正交性，需要定期"重新正交化"。

#### 4.1.2 欧拉角：直观但有万向锁

欧拉角使用三个角度来描述旋转。Openloong 仓库使用 **ZYX 约定**（偏航-俯仰-滚转，yaw-pitch-roll）：

```cpp
// useful_math.cpp 中的 eul2Rot
Eigen::Matrix<double, 3, 3> eul2Rot(double roll, double pitch, double yaw)
{
    Eigen::Matrix<double, 3, 3> Rx, Ry, Rz;
    Rz << cos(yaw), -sin(yaw), 0,
          sin(yaw),  cos(yaw), 0,
          0,         0,        1;
    Ry << cos(pitch), 0, sin(pitch),
          0,          1, 0,
         -sin(pitch), 0, cos(pitch);
    Rx << 1, 0,         0,
          0, cos(roll), -sin(roll),
          0, sin(roll),  cos(roll);
    return Rz * Ry * Rx;  // 注意顺序：先滚转，再俯仰，最后偏航
}
```

这意味着 $\mathbf{R} = \mathbf{R}_z(\text{yaw}) \cdot \mathbf{R}_y(\text{pitch}) \cdot \mathbf{R}_x(\text{roll})$。

**万向锁问题**：当 pitch = ±90° 时，roll 和 yaw 的旋转轴重合——我们"丢失"了一个自由度。在机器人行走中，虽然正常情况下机器人不会出现 pitch=90°，但在处理大角度旋转时这确实是个隐患。

#### 4.1.3 四元数：无奇异的优雅表示

四元数 $\mathbf{q} = w + x\mathbf{i} + y\mathbf{j} + z\mathbf{k}$（其中 $w^2 + x^2 + y^2 + z^2 = 1$）用 4 个参数无奇异性地表示旋转。

**为什么四元数更好？**
- 无万向锁问题
- 插值更平滑（球面线性插值）
- 复合旋转只需一次乘法（没有三角函数的计算）

仓库中的 `eul2quat` 函数通过旋转矩阵做桥梁：
```cpp
Eigen::Quaterniond eul2quat(double roll, double pitch, double yaw)
{
    Eigen::Matrix3d R = eul2Rot(roll, pitch, yaw);
    Eigen::Quaternion<double> quatCur;
    quatCur = R;  // 旋转矩阵到四元数的转换
    return quatCur;
}
```

Eigen 的 `Quaterniond` 类内部自动处理了矩阵到四元数的转换，类型安全且高效。

#### 4.1.4 互相转换与直观类比

**直观类比**：

- **旋转矩阵**像"地图"——精确但冗余。你拿着地图可以找到任何地方，但地图包本身很大（9个数字）。
- **欧拉角**像"导航指令"——"向前走、右转、再向前"——非常直观，但在北极附近会迷路（万向锁）。
- **四元数**像"GPS 坐标"——四个数字，没有奇异，精确且高效。

**相互转换**：

仓库中 `diffRot` 函数计算两个旋转矩阵之间的"差"（返回旋转向量形式的误差）：
```cpp
Eigen::Matrix<double, 3, 1> diffRot(const Eigen::Matrix3d &Rcur, Eigen::Matrix3d &Rdes)
{
    Eigen::Matrix3d R = Rcur.transpose() * Rdes;  // 相对旋转
    // 从旋转矩阵提取旋转向量
    double sita = atan2(l.norm(), R(0, 0) + R(1, 1) + R(2, 2) - 1);
    w = sita * l / l.norm();
    w = Rcur * w;  // 转换到世界坐标系
    return w;
}
```

这个函数在 WBC 中用于计算姿态误差——非常高频地调用。

`quat2axisAngle` 将四元数转换为轴角表示：
```cpp
Eigen::Matrix<double, 4, 1> quat2axisAngle(const Eigen::Quaternion<double> &quat)
{
    double angle = 2.0 * acos(quat.w());
    double s = sqrt(1 - quat.w() * quat.w());
    res(0) = quat.x() / s;  // 轴 x 分量
    res(1) = quat.y() / s;  // 轴 y 分量
    res(2) = quat.z() / s;  // 轴 z 分量
    res(3) = angle;         // 旋转角度
    return res;
}
```

#### 4.1.5 四元数积分

在浮动基座机器人中，我们还需要积分四元数——给定角速度 $\boldsymbol{\omega}$ 和当前姿态，计算下一个姿态。`pino_kin_dyn.cpp` 中的 `intQuat` 函数实现了这一点：

```cpp
Eigen::Quaterniond Pin_KinDyn::intQuat(const Eigen::Quaterniond &quat, 
                                        const Eigen::Matrix<double, 3, 1> &w)
{
    Eigen::Matrix3d Rcur = quat.normalized().toRotationMatrix();
    Eigen::Matrix3d Rinc = Eigen::Matrix3d::Identity();
    double theta = w.norm();
    if (theta > 1e-8)
    {
        Eigen::Vector3d w_norm = w / theta;
        // 构造反对称矩阵
        Eigen::Matrix3d a;
        a << 0, -w_norm(2), w_norm(1),
             w_norm(0), 0, -w_norm(0),
            -w_norm(1), w_norm(0), 0;
        // Rodrigues 公式：绕单位轴旋转 theta
        Rinc = Eigen::Matrix3d::Identity() + a * sin(theta) + a * a * (1 - cos(theta));
    }
    Eigen::Matrix3d Rend = Rcur * Rinc;
    return Eigen::Quaterniond(Rend);
}
```

该函数使用 **Rodrigues 公式**计算绕单位轴 $\hat{\boldsymbol{\omega}}$ 旋转 $\|\boldsymbol{\omega}\|$ 弧度的增量旋转矩阵：
$$
\mathbf{R}_{\text{inc}} = \mathbf{I} + [\hat{\boldsymbol{\omega}}]_\times \sin\theta + [\hat{\boldsymbol{\omega}}]_\times^2 (1 - \cos\theta)
$$

### 4.2 齐次变换矩阵与正向运动学

#### 4.2.1 SE(3)：齐次变换矩阵

旋转 + 平移 = **齐次变换矩阵** $\mathbf{T} \in \text{SE}(3)$（特殊欧氏群）：

$$
\mathbf{T} = \begin{bmatrix} \mathbf{R} & \mathbf{p} \\ \mathbf{0}^\top & 1 \end{bmatrix} \in \mathbb{R}^{4 \times 4}
$$

它表示从坐标系 $\{B\}$ 到 $\{A\}$ 的变换：
$$
\begin{bmatrix} \mathbf{p}^A \\ 1 \end{bmatrix} = \mathbf{T}^A_B \begin{bmatrix} \mathbf{p}^B \\ 1 \end{bmatrix}
$$

**为什么用齐次坐标？** 因为齐次变换矩阵可以将旋转和平移统一为矩阵乘法，从而可以连续复合多个变换：
$$
\mathbf{T}^A_C = \mathbf{T}^A_B \cdot \mathbf{T}^B_C
$$

在 Pinocchio 库中，`pinocchio::SE3` 类正是表示齐次变换矩阵，其内部存储为旋转矩阵 + 平移向量。

#### 4.2.2 DH 参数 vs URDF 格式

**DH 参数（Denavit-Hartenberg）**：传统方法，用 4 个参数（$a, \alpha, d, \theta$）描述每个关节。每个关节对应一个 4×4 变换矩阵。缺点是标准不统一（有多种 DH 约定），且对树状结构（如人形机器人有双臂）不友好。

**URDF（Unified Robot Description Format）**：基于 XML 的现代格式，Openloong 使用的正是 URDF。URDF 精确描述每个连杆的几何、惯性、碰撞模型和关节类型（旋转、棱柱、浮动）。Pinocchio 可以直接加载 URDF：

```cpp
// pino_kin_dyn.cpp 中构建模型
pinocchio::urdf::buildModel(urdf_pathIn, root_joint, model_biped);
```

URDF 中定义的关节和连杆形成一棵树。Pinocchio 通过 `getJointId("joint_name")` 来获取关节索引，如 `pino_kin_dyn.h` 中定义的：
```cpp
r_ankle_joint = model_biped.getJointId("J_ankle_r_roll");
l_ankle_joint = model_biped.getJointId("J_ankle_l_roll");
```

#### 4.2.3 正向运动学

**正向运动学（Forward Kinematics, FK）**：已知关节角度 $\mathbf{q}$，计算任意连杆的位姿（位置 + 旋转）。

在 Openloong 代码中，`computeJ_dJ()` 函数在执行 FK 的同时还计算雅可比矩阵：
```cpp
void Pin_KinDyn::computeJ_dJ()
{
    pinocchio::forwardKinematics(model_biped, data_biped, q);
    pinocchio::updateGlobalPlacements(model_biped, data_biped);
    
    // 获取足端位置和姿态
    fe_l_pos = data_biped.oMi[l_ankle_joint].translation();
    fe_l_rot = data_biped.oMi[l_ankle_joint].rotation();
}
```

`data_biped.oMi[joint_id]` 给出了以世界坐标系为参考的该关节的齐次变换矩阵（位置 + 旋转）。

### 4.3 雅可比矩阵

#### 4.3.1 定义：从关节速度到末端速度

雅可比矩阵 $\mathbf{J}(\mathbf{q}) \in \mathbb{R}^{6 \times n}$ 是机器人学中最重要的概念之一，它将关节速度映射到末端空间速度：

$$
\mathbf{v}_{\text{end}} = \mathbf{J}(\mathbf{q}) \dot{\mathbf{q}}
$$

其中 $\mathbf{v}_{\text{end}} = [\mathbf{v}; \boldsymbol{\omega}] \in \mathbb{R}^6$ 包含线速度和角速度。

**注意**：$\mathbf{J}$ 是 $\mathbf{q}$ 的函数——随着机器人姿势改变，雅可比矩阵也在变化。这就是为什么我们必须在每个控制周期重新计算它。

#### 4.3.2 几何雅可比 vs 解析雅可比

**几何雅可比**：将末端速度表示为 $\mathbf{v} = [\dot{\mathbf{p}}; \boldsymbol{\omega}]$，其中 $\boldsymbol{\omega}$ 是瞬时角速度向量。几何雅可比更直观，不依赖于末端姿态的参数化方式。

**解析雅可比**：如果末端姿态用某种参数（如欧拉角 $\boldsymbol{\Theta}$）表示，则 $\dot{\boldsymbol{\Theta}} = \mathbf{J}_a(\mathbf{q})\dot{\mathbf{q}}$。解析雅可比依赖于参数化方式。

两者的关系：$\mathbf{J}_a = \mathbf{E}(\boldsymbol{\Theta})^{-1} \mathbf{J}$，其中 $\mathbf{E}(\boldsymbol{\Theta})$ 将角速度转换为欧拉角速率。

在 `Eul_W_filter.cpp` 中，我们看到了这个转换矩阵的具体形式（ZYX 约定）：
```cpp
F(0,3) = dt;                                   // d(roll)/dt -> roll
F(1,4) = dt * cos(roll_Old);                   // pitch dot -> pitch
F(2,5) = dt * cos(roll_Old) / cos(pitch_Old);  // yaw dot -> yaw
```

#### 4.3.3 角速度雅可比 + 线速度雅可比

雅可比的前 3 行对应线速度，后 3 行对应角速度：
$$
\mathbf{J}(\mathbf{q}) = \begin{bmatrix} \mathbf{J}_v(\mathbf{q}) \\ \mathbf{J}_\omega(\mathbf{q}) \end{bmatrix}
$$

- $\mathbf{J}_v$ 的每一列 $i$ 等于：$\mathbf{z}_{i-1} \times (\mathbf{p}_{\text{end}} - \mathbf{p}_{i-1})$（对于旋转关节）
- $\mathbf{J}_\omega$ 的每一列 $i$ 等于：$\mathbf{z}_{i-1}$（旋转轴方向）

其中 $\mathbf{z}_{i-1}$ 是关节 $i$ 的旋转轴在世界坐标系中的方向，$\mathbf{p}_{i-1}$ 是关节 $i$ 的原点位置。

#### 4.3.4 雅可比导数 dJ

雅可比矩阵的导数 $\dot{\mathbf{J}}(\mathbf{q}, \dot{\mathbf{q}})$ 用于计算末端加速度：
$$
\mathbf{a}_{\text{end}} = \mathbf{J}(\mathbf{q}) \ddot{\mathbf{q}} + \dot{\mathbf{J}}(\mathbf{q}, \dot{\mathbf{q}}) \dot{\mathbf{q}}
$$

这就是为什么在 WBC 的任务加速度计算中，我们需要 $\dot{\mathbf{J}}$ 来补偿速度项。

在 `pino_kin_dyn.cpp` 的 `computeJ_dJ()` 中：
```cpp
pinocchio::computeJointJacobiansTimeVariation(model_biped, data_biped, q, dq);
pinocchio::getJointJacobianTimeVariation(model_biped, data_biped, r_ankle_joint, 
    pinocchio::LOCAL_WORLD_ALIGNED, dJ_r);
```

### 4.4 牛顿-欧拉递推（RNEA）与逆动力学

#### 4.4.1 从正运动学到逆动力学

给定关节角度 $\mathbf{q}$、速度 $\dot{\mathbf{q}}$ 和加速度 $\ddot{\mathbf{q}}$，**逆动力学（Inverse Dynamics）**计算所需的关节力矩 $\boldsymbol{\tau}$。

**物理直觉**：要让人形机器人按特定的加速度运动，每个关节需要多大的扭矩？

#### 4.4.2 正向递推：速度/加速度从基座向末端传递

第一步，从基座（根节点）开始，依次向外递推每个连杆的角速度、角加速度和线加速度。

**角速度递推**（从连杆 $i$ 到 $i+1$）：
$$
\boldsymbol{\omega}_{i+1} = \boldsymbol{\omega}_i + \dot{q}_{i+1} \mathbf{z}_{i+1}
$$

其中 $\dot{q}_{i+1}$ 是关节速度，$\mathbf{z}_{i+1}$ 是关节轴方向。

**角加速度递推**：
$$
\dot{\boldsymbol{\omega}}_{i+1} = \dot{\boldsymbol{\omega}}_i + \ddot{q}_{i+1} \mathbf{z}_{i+1} + \boldsymbol{\omega}_i \times (\dot{q}_{i+1} \mathbf{z}_{i+1})
$$

注意科里奥利项 $\boldsymbol{\omega}_i \times (\dot{q}_{i+1} \mathbf{z}_{i+1})$——这来自旋转坐标系的导数。

**线加速度递推**：
$$
\dot{\mathbf{v}}_{i+1} = \dot{\mathbf{v}}_i + \dot{\boldsymbol{\omega}}_i \times \mathbf{r}_{i,i+1} + \boldsymbol{\omega}_i \times (\boldsymbol{\omega}_i \times \mathbf{r}_{i,i+1})
$$

其中 $\mathbf{r}_{i,i+1}$ 是从关节 $i$ 到 $i+1$ 的向量。

#### 4.4.3 反向递推：力/力矩从末端向基座传递

第二步，从末端（叶子节点）开始，利用牛顿-欧拉方程反向递推每个连杆受到的力和力矩。

**牛顿方程**（力的平衡）：
$$
\mathbf{f}_i = m_i \dot{\mathbf{v}}_{C_i}
$$

**欧拉方程**（力矩的平衡）：
$$
\boldsymbol{\tau}_i = \mathbf{I}_{C_i} \dot{\boldsymbol{\omega}}_i + \boldsymbol{\omega}_i \times (\mathbf{I}_{C_i} \boldsymbol{\omega}_i)
$$

然后通过关节约束，得到关节力矩：
$$
\tau_i = \mathbf{z}_i^\top \cdot \boldsymbol{\tau}_i \quad (\text{旋转关节})
$$

#### 4.4.4 为什么 RNEA 比拉格朗日法高效

**RNEA（Recursive Newton-Euler Algorithm）**的复杂度为 $O(n)$，其中 $n$ 是关节数。而拉格朗日法的复杂度为 $O(n^4)$，因为需要显式构造质量矩阵及其导数。

对于像 Openloong 这样具有 30+ 关节的机器人，RNEA 的 $O(n)$ 复杂度是实时控制的唯一选择。事实上，Pinocchio 的实现（`pinocchio::rnea()`）使用空间向量代数（6D 力/运动旋量）进一步优化了这个递推过程。

#### 4.4.5 数学形式

在仓库中，逆动力学的计算结果可以表示为：
$$
\boldsymbol{\tau} = \text{RNEA}(\mathbf{q}, \dot{\mathbf{q}}, \ddot{\mathbf{q}})
$$

这等价于：
$$
\boldsymbol{\tau} = \mathbf{M}(\mathbf{q})\ddot{\mathbf{q}} + \mathbf{C}(\mathbf{q}, \dot{\mathbf{q}})\dot{\mathbf{q}} + \mathbf{G}(\mathbf{q})
$$

Pinocchio 提供了多个相关的函数：
- `pinocchio::rnea()`：直接计算逆动力学（最常用，也最高效）
- `pinocchio::crba()`：计算质量矩阵（Composite Rigid Body Algorithm）
- `pinocchio::computeCoriolisMatrix()`：计算科里奥利矩阵
- `pinocchio::computeGeneralizedGravity()`：计算重力项

Openloong 使用分开调用的方式，因为 WBC 需要分别访问 $\mathbf{M}$、$\mathbf{C}$ 和 $\mathbf{G}$：

```cpp
void Pin_KinDyn::computeDyn()
{
    pinocchio::crba(model_biped, data_biped, q);
    data_biped.M.triangularView<Eigen::Lower>() = data_biped.M.transpose().triangularView<Eigen::Lower>();
    dyn_M = data_biped.M;

    pinocchio::computeCoriolisMatrix(model_biped, data_biped, q, dq);
    dyn_C = data_biped.C;

    pinocchio::computeGeneralizedGravity(model_biped, data_biped, q);
    dyn_G = data_biped.g;
}
```

注意 `data_biped.M.triangularView<Eigen::Lower>() = ...` 这一行——Pinocchio 的 CRBA 只填充了下三角部分，我们需要手动还原对称的上三角。

### 4.5 质量矩阵与非线性项

#### 4.5.1 M(q)：惯性矩阵

质量矩阵 $\mathbf{M}(\mathbf{q}) \in \mathbb{R}^{n \times n}$ 是对称正定矩阵。它的物理意义：

- **对角元** $M_{ii}$：关节 $i$ 本身的转动惯量（加上它驱动所有后续连杆的等效惯量）
- **非对角元** $M_{ij}$：关节 $i$ 和 $j$ 之间的惯性耦合——加速关节 $i$ 会对关节 $j$ 产生多大的力矩

人形机器人的质量矩阵是一个有趣的观察窗口。例如，$M_{1,25}$ 可能表示躯干的俯仰运动与右腿膝关节之间的耦合——这解释了为什么在行走时，摆动手臂可以抵消腿部的惯性效应。

#### 4.5.2 C(q,dq)：科里奥利 + 向心力

科里奥利矩阵 $\mathbf{C}(\mathbf{q}, \dot{\mathbf{q}})$ 描述了两个效应：

1. **向心力**：当一个关节快速旋转时，它会使后面所有连杆受到一个离心方向的"甩出力"
2. **科里奥利力**：当一个连杆既有旋转运动又有径向运动时，会产生交叉耦合效应

在快速行走或奔跑时，科里奥利效应变得非常显著——这就是为什么简单的 "PD + 重力补偿" 控制策略在高速运动时失效的原因。

#### 4.5.3 G(q)：重力项

$\mathbf{G}(\mathbf{q})$ 是最直观的一项——它表示重力对各关节产生的力矩。例如，当机器人向前弯腰时，重力会在腰部关节产生一个向下的力矩。

#### 4.5.4 h(q,dq)：统一处理

在实际 WBC 实现中，我们经常把科里奥利力和重力统一为非线性项：
$$
\mathbf{h}(\mathbf{q}, \dot{\mathbf{q}}) = \mathbf{C}(\mathbf{q}, \dot{\mathbf{q}})\dot{\mathbf{q}} + \mathbf{G}(\mathbf{q})
$$

```cpp
// pino_kin_dyn.cpp
dyn_Non = dyn_C * dq + dyn_G;
```

完整的动力学方程：
$$
\mathbf{M}(\mathbf{q})\ddot{\mathbf{q}} + \mathbf{h}(\mathbf{q}, \dot{\mathbf{q}}) = \mathbf{S}\boldsymbol{\tau} + \mathbf{J}_c^\top \mathbf{f}_c
$$

其中 $\mathbf{S}$ 是**选择矩阵**（浮动基座的前 6 个自由度为 0，只有驱动关节被赋予扭矩），$\mathbf{J}_c^\top \mathbf{f}_c$ 是接触力的贡献。

在 `wbc_priority.cpp` 的计算中，这个方程被用作等式约束：
```cpp
eigen_qp_A1.block<6, 6>(0, 0) = Sf * dyn_M * St_qpV1;     // δq̈_b 的系数
eigen_qp_A1.block<6, 12>(0, 6) = -Sf * Jfe.transpose();    // δF_r 的系数
Eigen::VectorXd eqRes = -Sf * dyn_M * ddq_final_kin 
                         - Sf * dyn_Non + Sf * Jfe.transpose() * Fr_ff;
```

这实际上就是 $\mathbf{S}\boldsymbol{\tau} = \mathbf{M}\ddot{\mathbf{q}} + \mathbf{h} - \mathbf{J}_c^\top\mathbf{f}_c$ 的矩阵表示。

### 4.6 质心动量矩阵 Ag

#### 4.6.1 质心动力学

**质心动量矩阵** $\mathbf{A}_g(\mathbf{q}) \in \mathbb{R}^{6 \times n}$（也称离心力矩阵 Centroidal Momentum Matrix）将关节速度映射到机器人的总动量和角动量：

$$
\mathbf{h}_G = \mathbf{A}_g(\mathbf{q}) \dot{\mathbf{q}}
$$

其中 $\mathbf{h}_G = [\mathbf{L}_G; \mathbf{P}_G] \in \mathbb{R}^6$ 是机器人的质心动量：
- $\mathbf{P}_G = m \dot{\mathbf{p}}_{\text{CoM}}$：总线动量（总质量 × 质心速度）
- $\mathbf{L}_G$：绕质心的总角动量

#### 4.6.2 为什么质心动量对双足步行如此重要？

双足机器人行走的本质是"受控的摔倒"。质心动量直接驱动质心的运动，而质心的运动决定了机器人的整体平衡。

**关键洞察**：对于双足机器人，**只有接触力**可以改变质心动量：
$$
\frac{d}{dt}\mathbf{h}_G = \sum_i \begin{bmatrix} \mathbf{J}_{c_i}^\top \mathbf{f}_{c_i} \end{bmatrix} + \begin{bmatrix} \mathbf{0} \\ m\mathbf{g} \end{bmatrix}
$$

这意味着如果我们知道质心动量的变化率，就可以反推所需的接触力——这正是 MPC 和 WBC 中大范围使用质心动量的原因。

#### 4.6.3 代码实现

仓库中使用 Pinocchio 计算质心动量矩阵：

```cpp
pinocchio::dccrba(model_biped, data_biped, q, dq);  // dAg
pinocchio::computeCentroidalMomentum(model_biped, data_biped, q, dq);
dyn_Ag = data_biped.Ag;    // 质心动量矩阵
dyn_dAg = data_biped.dAg;  // 质心动量矩阵的时间导数
```

在 `wbc_priority.cpp` 中，$\mathbf{A}_g$ 和 $\dot{\mathbf{A}}_g$ 被用于 WBC 的动力学约束中。

### 4.7 Pinocchio 库原理与核心接口

#### 4.7.1 Pinocchio 的核心算法

Pinocchio 是一个高效的 C++ 机器人动力学库，实现了以下核心算法：

| 算法 | 函数 | 复杂度 | 计算内容 |
|------|------|--------|----------|
| RNEA | `rnea()` | $O(n)$ | 逆动力学：$\boldsymbol{\tau} = f(\mathbf{q},\dot{\mathbf{q}},\ddot{\mathbf{q}})$ |
| ABA | `aba()` | $O(n)$ | 正动力学：$\ddot{\mathbf{q}} = f(\mathbf{q},\dot{\mathbf{q}},\boldsymbol{\tau})$ |
| CRBA | `crba()` | $O(n^2)$ | 质量矩阵 $\mathbf{M}(\mathbf{q})$ |
| Jacobian | `computeJointJacobians()` | $O(n)$ | 所有关节的雅可比矩阵 |
| 质心动力学 | `dccrba()` | $O(n)$ | 质心动量矩阵 $\mathbf{A}_g$ 及其导数 |

所有这些算法都基于**空间向量代数（Spatial Vector Algebra）**，使用 6D 运动/力旋量（screw）来统一表示速度和力，大大简化了推导和实现。

#### 4.7.2 Pinocchio 的 API 设计

Pinocchio 将模型和计算数据分离：
- **`pinocchio::Model`**：机器人的运动学/动力学模型，通常是固定的（URDF 加载后不再改变）
- **`pinocchio::Data`**：计算过程中产生的中间数据，每次调用算法都会更新

```cpp
pinocchio::Model model_biped;
pinocchio::Data data_biped(model_biped);  // Data 绑定到 Model
```

在仓库中，`Pin_KinDyn` 类封装了两个模型：
- `model_biped` + `data_biped`：浮动基座模型（6 个基座自由度 + 关节自由度）
- `model_biped_fixed` + `data_biped_fixed`：固定基座模型（只有关节自由度）

#### 4.7.3 关键框架约定

Pinocchio 有自己的框架约定，理解这些约定对于正确使用非常重要。在 `pino_kin_dyn.cpp` 中：

```cpp
// q = [global_base_position(3), global_base_quaternion(4), joint_positions]
// v = [local_base_velocity_linear(3), local_base_velocity_angular(3), joint_velocities]
```

注意速度是在**局部坐标系**（body frame）中定义的，而位置是在**全局坐标系**中定义的。这就是为什么 `dataBusRead()` 中有坐标变换：

```cpp
dq.block(0, 0, 3, 1) = robotState.base_rot.transpose() * dq.block(0, 0, 3, 1);
dq.block(3, 0, 3, 1) = robotState.base_rot.transpose() * dq.block(3, 0, 3, 1);
```

将全局速度转换到局部坐标系，以匹配 Pinocchio 的约定。

### 4.8 代码实践：利用 Pinocchio 计算动力学量

以下是一个完整的示例，展示如何加载 URDF、计算正向运动学、雅可比矩阵和动力学量：

```cpp
#include "pino_kin_dyn.h"
#include <iostream>

int main() {
    // 1. 加载 URDF 构建运动学/动力学模型
    Pin_KinDyn kinDynSolver("../models/AzureLoong.urdf");
    int nv = kinDynSolver.model_nv;  // 自由度总数
    std::cout << "模型自由度: " << nv << std::endl;
    
    // 2. 初始化状态向量
    // q (nv+1): [base_pos(3), base_quat(4), joint_pos(nv-6)]
    // dq (nv):  [base_lin_vel(3), base_ang_vel(3), joint_vel(nv-6)]
    Eigen::VectorXd q = Eigen::VectorXd::Zero(nv + 1);
    Eigen::VectorXd dq = Eigen::VectorXd::Zero(nv);
    
    // 设置初始姿态（直立站立）
    q(2) = 0.95;  // 基座高度
    q(6) = 1.0;   // 四元数 w = 1 (无旋转)
    
    // 3. 设置状态到 Pinocchio
    kinDynSolver.q = q;
    kinDynSolver.dq = dq;
    
    // 4. 计算正向运动学和雅可比矩阵
    kinDynSolver.computeJ_dJ();
    
    // 输出结果
    std::cout << "左足位置 (世界坐标系): " 
              << kinDynSolver.fe_l_pos.transpose() << std::endl;
    std::cout << "右足位置 (世界坐标系): " 
              << kinDynSolver.fe_r_pos.transpose() << std::endl;
    std::cout << "质心位置: " 
              << kinDynSolver.CoM_pos.transpose() << std::endl;
    std::cout << "左腿雅可比矩阵 (6×" << nv << "):\n" 
              << kinDynSolver.J_l << std::endl;
    
    // 5. 计算动力学量
    kinDynSolver.computeDyn();
    
    std::cout << "质量矩阵 M(" << nv << "×" << nv << ") 完成计算\n";
    std::cout << "M 的迹 (惯性总和): " 
              << kinDynSolver.dyn_M.trace() << std::endl;
    std::cout << "重力向量 G 的范数: " 
              << kinDynSolver.dyn_G.norm() << std::endl;
    
    // 6. 验证质量矩阵的对称正定性
    Eigen::VectorXd test_vec = Eigen::VectorXd::Random(nv);
    double quad_form = test_vec.transpose() * kinDynSolver.dyn_M * test_vec;
    std::cout << "二次型 v^T*M*v = " << quad_form << " (应 > 0)" << std::endl;
    
    // 7. 使用质心动量矩阵
    std::cout << "质心动量矩阵 A_g (" << nv << "×" << nv << ") 已计算\n";
    
    return 0;
}
```

在实际的 `walk_wbc.cpp` 主循环中，每个控制周期都会按以下顺序更新：
```cpp
// 1. 读取传感器数据
mj_interface.updateSensorValues();
mj_interface.dataBusWrite(RobotState);

// 2. 状态估计
StateModule.set(RobotState);
StateModule.update();
StateModule.get(RobotState);

// 3. 更新运动学和动力学
kinDynSolver.dataBusRead(RobotState);
kinDynSolver.computeJ_dJ();   // FK + 雅可比 + dJ
kinDynSolver.computeDyn();    // M, C, G, Ag, ...
kinDynSolver.dataBusWrite(RobotState);

// 4. WBC 计算（使用上述结果）
WBC_solv.dataBusRead(RobotState);
WBC_solv.computeDdq(kinDynSolver);
WBC_solv.computeTau();
WBC_solv.dataBusWrite(RobotState);
```

---

## 第5章 状态估计基础

### 5.1 卡尔曼滤波的直观理解

#### 5.1.1 预测 + 更新：一切滤波的核心

想象你正在用手机导航。你面前有两个信息来源：
1. **你对运动的感觉**（我们称之为"预测"或"模型"）：你知道自己以约 1m/s 的速度向东走，所以你的位置应该约每步移动 0.5 米
2. **GPS 信号**（我们称之为"观测"或"测量"）：GPS 告诉你当前位置

问题来了：GPS 有噪声（可能突然跳几米），而你的感觉也有累积误差（你以为走了 0.5 米，实际可能走了 0.6 米）。哪个更可信？答案取决于当前的情况——当 GPS 信号好时，更相信 GPS；当走进隧道时，更相信自己的感觉。

**卡尔曼滤波**做的正是这件事：在每一步中，先用模型**预测**下一个状态，再用观测**更新**这个预测，且两者的权重由各自的"可信度"（协方差）自动决定。

#### 5.1.2 一维例子：温度估计

假设你想估计一个房间的温度。

**预测**：温度在短时间内的变化很小，可以近似认为不变：
$$
\hat{T}_{t|t-1} = T_{t-1} \quad (\text{模型})
$$
但模型的置信度会随时间下降——我们增加过程噪声 $Q$：
$$
P_{t|t-1} = P_{t-1} + Q
$$

**观测**：你有一个温度计，读数为 $Z_t = 25.2^\circ\text{C}$，但温度计有噪声 $R$。

**更新**：卡尔曼给出了最优的融合方式：
$$
K_t = \frac{P_{t|t-1}}{P_{t|t-1} + R} \quad (\text{卡尔曼增益})
$$
$$
T_t = \hat{T}_{t|t-1} + K_t (Z_t - \hat{T}_{t|t-1})
$$
$$
P_t = (1 - K_t) P_{t|t-1}
$$

**分析**：
- 如果模型非常可信（$P_{t|t-1}$ 很小），则 $K_t \to 0$，几乎完全相信模型
- 如果观测非常可信（$R$ 很小），则 $K_t \to 1$，几乎完全相信温度计
- 这就是卡尔曼增益 $K_t$ 的物理含义：**相信模型还是相信传感器的自动权衡**

#### 5.1.3 完整数学推导（5 个经典公式）

对于线性系统：
$$
\mathbf{x}_k = \mathbf{A}\mathbf{x}_{k-1} + \mathbf{B}\mathbf{u}_{k-1} + \mathbf{w}_{k-1}
$$
$$
\mathbf{z}_k = \mathbf{C}\mathbf{x}_k + \mathbf{v}_k
$$

其中 $\mathbf{w} \sim \mathcal{N}(0, \mathbf{Q})$ 是过程噪声，$\mathbf{v} \sim \mathcal{N}(0, \mathbf{R})$ 是观测噪声。

卡尔曼滤波的 5 个公式：

**时间更新（预测）**：
$$
\begin{aligned}
\hat{\mathbf{x}}_{k|k-1} &= \mathbf{A}\hat{\mathbf{x}}_{k-1|k-1} + \mathbf{B}\mathbf{u}_{k-1} \quad &\text{(1) 状态预测}\\
\mathbf{P}_{k|k-1} &= \mathbf{A}\mathbf{P}_{k-1|k-1}\mathbf{A}^\top + \mathbf{Q} \quad &\text{(2) 协方差预测}
\end{aligned}
$$

**测量更新（校正）**：
$$
\begin{aligned}
\mathbf{K}_k &= \mathbf{P}_{k|k-1}\mathbf{C}^\top(\mathbf{C}\mathbf{P}_{k|k-1}\mathbf{C}^\top + \mathbf{R})^{-1} \quad &\text{(3) 卡尔曼增益}\\
\hat{\mathbf{x}}_{k|k} &= \hat{\mathbf{x}}_{k|k-1} + \mathbf{K}_k(\mathbf{z}_k - \mathbf{C}\hat{\mathbf{x}}_{k|k-1}) \quad &\text{(4) 状态更新}\\
\mathbf{P}_{k|k} &= (\mathbf{I} - \mathbf{K}_k\mathbf{C})\mathbf{P}_{k|k-1} \quad &\text{(5) 协方差更新}
\end{aligned}
$$

在 Openloong 的姿态滤波器中（`Eul_W_filter.cpp`），我们看到了完整的实现：

```cpp
// 预测步骤
kal_X = F * kal_X;                         // 公式(1)
P = F * P * F.transpose() + Q;             // 公式(2)

// 卡尔曼增益
S = H * P * H.transpose() + R;             // 创新协方差
K = P * H.transpose() * S.inverse();       // 公式(3)

// 更新步骤
kal_Y = kal_Z - H * kal_X;                // 创新（残差）
kal_X = kal_X + K * kal_Y;                // 公式(4)
P = (Matrix<double,6,6>::Identity() - K * H) * P;  // 公式(5)
```

### 5.2 扩展卡尔曼滤波（EKF）

#### 5.2.1 为什么需要 EKF？

卡尔曼滤波要求系统是**线性的**——状态转移和观测方程都必须是线性变换。但机器人系统几乎总是非线性的：

- 旋转运动的动力学是 $\dot{\mathbf{R}} = \mathbf{R}[\boldsymbol{\omega}]_\times$，这是非线性
- IMU 的测量模型涉及三角函数
- 足端位置的计算涉及正向运动学，包含 $\sin$ 和 $\cos$

**EKF 的核心思想**：对非线性函数进行一阶泰勒展开近似，然后应用标准卡尔曼滤波框架。

#### 5.2.2 线性化：一阶泰勒展开

对于非线性系统：
$$
\mathbf{x}_k = f(\mathbf{x}_{k-1}, \mathbf{u}_{k-1}) + \mathbf{w}_{k-1}
$$
$$
\mathbf{z}_k = h(\mathbf{x}_k) + \mathbf{v}_k
$$

EKF 的线性化就是在当前估计值处求雅可比矩阵：
$$
\mathbf{F}_k = \left.\frac{\partial f}{\partial \mathbf{x}}\right|_{\hat{\mathbf{x}}_{k-1}, \mathbf{u}_{k-1}}
$$
$$
\mathbf{H}_k = \left.\frac{\partial h}{\partial \mathbf{x}}\right|_{\hat{\mathbf{x}}_{k|k-1}}
$$

然后用这些雅可比矩阵替代标准 KF 中的 $\mathbf{A}$ 和 $\mathbf{C}$。

在 `Eul_W_filter.cpp` 中，状态转移矩阵 $\mathbf{F}$ 正是通过线性化欧拉角运动学得到的：

```cpp
F.setIdentity();
F(0,3) = dt;                                            // roll 关于角速度 x 的导数
F(0,4) = dt * sin(roll_Old) * sin(pitch_Old) / cos(pitch_Old);  // roll 关于角速度 y
F(0,5) = dt * cos(roll_Old) * sin(pitch_Old) / cos(pitch_Old);  // roll 关于角速度 z
F(1,4) = dt * cos(roll_Old);                            // pitch 关于角速度 y
F(1,5) = -dt * sin(roll_Old);                           // pitch 关于角速度 z
F(2,4) = dt * sin(roll_Old) / cos(pitch_Old);           // yaw 关于角速度 y
F(2,5) = dt * cos(roll_Old) / cos(pitch_Old);           // yaw 关于角速度 z
```

这些正是欧拉角运动学 $\dot{\boldsymbol{\Theta}} = \mathbf{E}(\boldsymbol{\Theta})^{-1}\boldsymbol{\omega}$ 的离散化线性化形式。

#### 5.2.3 EKF vs UKF vs PF

| 滤波器 | 假设 | 复杂度 | 优缺点 |
|--------|------|--------|--------|
| **EKF** | 一阶线性化 | $O(n^3)$ | 简单高效，但强非线性时误差大 |
| **UKF** | 无迹变换（采样点） | $O(n^3)$ | 不需要计算雅可比，弱非线性时更准 |
| **PF** | 粒子采样 | $O(Nn)$ | 完全非线性、非高斯，但计算量大 |

对于人形机器人的状态估计，EKF 在精度和效率之间取得了良好的平衡，因此被 Openloong 采用。

### 5.3 IMU 测量模型

#### 5.3.1 加速度计模型

加速度计测量的是**比力（specific force）**——即单位质量感受到的力。它无法区分重力和加速度：
$$
\mathbf{a}_{\text{meas}} = \mathbf{a}_{\text{true}} - \mathbf{g} + \mathbf{b}_a + \mathbf{n}_a
$$

其中：
- $\mathbf{a}_{\text{true}}$：真实的体加速度（不是重力引起的）
- $\mathbf{g}$：重力向量（$[0, 0, -9.81]^\top$）
- $\mathbf{b}_a$：加速度计偏置（缓慢变化）
- $\mathbf{n}_a$：高斯白噪声

**关键点**：当机器人静止时，加速度计读数为 $-\mathbf{g}$（即向上 9.81m/s²）——这告诉我们重力方向，从而可以得到滚转角和俯仰角。

#### 5.3.2 陀螺仪模型

陀螺仪测量角速度：
$$
\boldsymbol{\omega}_{\text{meas}} = \boldsymbol{\omega}_{\text{true}} + \mathbf{b}_g + \mathbf{n}_g
$$

其中 $\mathbf{b}_g$ 是陀螺仪偏置，$\mathbf{n}_g$ 是噪声。

#### 5.3.3 为什么不能直接积分得到位置？

你可能认为：既然有加速度，两次积分就能得到位置。但这里有一个致命问题：

**漂移**：加速度计有偏置 $\mathbf{b}_a$，假设偏置仅为 0.01 m/s²，那么在 10 秒后：
$$
\text{位置误差} = \frac{1}{2} \times 0.01 \times 10^2 = 0.5 \text{m}
$$

60 秒后，误差达到 **18 米**！这就是为什么仅凭 IMU 无法确定绝对位置——必须借助其他传感器（如视觉、GPS、接触约束）来修正。

这也是为什么 `StateEst.cpp` 中的 EKF 状态向量包含 $\mathbf{b}_a$ 作为待估计的状态：

```cpp
// 状态向量 X (15维):
// X[0:3]  = base_pos      (基座位置)
// X[3:6]  = base_vel      (基座速度)
// X[6:9]  = fe_l_pos_W   (左足位置)
// X[9:12] = fe_r_pos_W   (右足位置)
// X[12:15]= delta_acc     (加速度偏置)
```

### 5.4 运动学约束

#### 5.4.1 摆动腿触地时速度为零

当摆动腿接触地面时（脚完全着地），我们有一个重要的"虚拟观测"：触地瞬间足端速度为零。

为什么是"虚拟观测"？因为没有任何传感器直接测量足端速度——但我们从运动学约束推导出它应该为零。

在 `StateEst.cpp` 中，这一约束被编码在观测方程中：

```cpp
for (int i = 0; i < 2; i++)
{
    // 对接触的腿：足端速度 = 0（通过正运动学计算）
    // 对非接触的腿：不使用速度约束（自由运动）
    vbW.col(i) = leg_contact[i] * Rrpy_woOff * (velTmp.col(i) + omegaLVec.cross(peB.col(i))) 
               + (1 - leg_contact[i]) * (-base_vel);
}
```

当 `leg_contact[i] = 1`（接触）时，足端速度按照 $\mathbf{v}_{\text{foot}} = \mathbf{R}(\boldsymbol{\Theta}) \times (\mathbf{v}_{\text{foot, local}} + \boldsymbol{\omega} \times \mathbf{p}_{\text{foot}})$ 计算——期望结果应为零。

#### 5.4.2 足底力传感器与接触检测

Openloong 使用两种方式判断接触：
1. **力传感器阈值**：如果 $F_z > 100\text{N}$，认为接触
2. **步态阶段**：根据步态调度器确定当前支撑腿

在 `StateEst.cpp` 的 `update()` 中：

```cpp
if (legState == DataBus::LSt) {         // 左腿支撑
    leg_contact[0] = true;               // 左腿接触
    leg_contact[1] = false;              // 右腿摆动
}
else if (legState == DataBus::RSt) {    // 右腿支撑
    leg_contact[1] = true;
    leg_contact[0] = false;
}
else {                                   // 双足支撑
    leg_contact[0] = true;
    leg_contact[1] = true;
}
```

判断是否正确接触至关重要——如果错误地将摆动腿判为接触，EKF 会引入错误的速度约束，导致位置估计发散；反之，如果漏判了接触腿，则缺乏足够约束，位置估计也会漂移。

**信任区域（Trust Region）**机制进一步细化了约束的可信度：

```cpp
void StateEst::getTrustRegion_wt_h()
{
    for (int i = 0; i < 2; i++)
    {
        // 接触时权重为 1（完全信任），非接触时权重很大（忽略约束）
        C(i * 3) = leg_contact[i] + (1 - leg_contact[i]) * TR_k;
        C(i * 3 + 1) = leg_contact[i] + (1 - leg_contact[i]) * TR_k;
        C(i * 3 + 2) = leg_contact[i] + (1 - leg_contact[i]) * TR_k;
    }
}
```

其中 `TR_k = 100`——当腿不在接触时，该约束的协方差被放大 100 倍，相当于在更新中几乎忽略它。

### 5.5 代码实践：状态估计完整流程

以下展示 Openloong 中状态估计的完整数据流：

```cpp
// 每个控制周期执行：
// 1. 读取 IMU 和传感器数据
StateModule.set(RobotState);
//   - 加速度计读数 → freeAcc
//   - 陀螺仪读数 → omegaL
//   - 欧拉角（来自 IMU 姿态估计）→ eul
//   - 足端位置（来自正向运动学）→ fe_l_pos_L, fe_r_pos_L

// 2. EKF 更新
StateModule.update();
//   预测：X = A*X + B*freeAcc
//         P = A*P*A' + Q
//   更新：K = P*C'/(C*P*C' + R)
//         X = X + K*(Y - C*X)
//         P = (I - K*C)*P

// 3. 读取估计结果
StateModule.get(RobotState);
//   - base_pos_est: 优化的基座位置（修正了 IMU 积分漂移）
//   - base_vel_est: 优化的基座速度
//   - delta_acc: 估计的加速度偏置
//   - fe_l_pos_W_est, fe_r_pos_W_est: 优化的足端世界坐标

// 4. 力估计（基于动力学）
StateModule.setF(RobotState);
//   读取：dyn_M, dyn_Non, J_l, J_r, dq, torJoint
StateModule.updateF();
//   计算：FLest = -Jinv * (J*dM^{-1}*(tau - Non) + dJ*dq)
StateModule.getF(RobotState);
//   输出：FL_est, FR_est (左右足的地面反作用力)
```

**状态向量定义**（`StateEst.h`）：
```
X = [base_pos(3);       // 基座在世界坐标系中的位置
     base_vel(3);       // 基座线速度
     fe_l_pos_W(3);     // 左足在世界坐标系中的位置
     fe_r_pos_W(3);     // 右足在世界坐标系中的位置
     delta_acc(3)]      // 加速度计偏置
```

**观测向量定义**：
```
Y = [-pbW_L(3);         // 左足位置（负值，体坐标系→世界坐标系）
     -pbW_R(3);         // 右足位置
     vbW_L(3);          // 左足速度（接触时应为 0）
     vbW_R(3);          // 右足速度
     h_L(1);            // 左足高度约束
     h_R(1)]            // 右足高度约束
```

整个估计流程的核心思想是：**IMU 提供高频的短时运动信息（陀螺仪积分得到姿态，加速度计二次积分得到位置），但会漂移；运动学约束（足端接触时速度为零）提供低频的绝对修正；EKF 以最优方式融合这两种信息**。

这就像一个人走路时的直觉：你可以通过内耳前庭感知自己在动（IMU），但只有当你踩到地面（接触约束）时，你才知道自己确切的位置。


---

# 第三部分：步态规划与模型预测控制

> **导读**：本章是全书的技术核心。第6章从双足步行最本质的问题出发——什么时候迈哪条腿、往哪里迈、怎么迈——逐步构建完整的步态规划系统。第7章则深入机器人全身控制的最前沿方法：模型预测控制（MPC），揭示如何通过滚动优化让机器人在复杂环境中做出最优决策。两章内容紧密耦合：步态规划告诉机器人"何时何地落脚"，MPC则负责"如何用力、保持平衡"。

---

## 第6章：步态规划与落脚点控制

### 6.1 步态周期、相位与双足步行的基本概念

#### 6.1.1 从人类走路说起

观察人类走路：左腿向前→右腿向前→左腿向前…… 这样一个重复的过程就是**步态周期**（Gait Cycle）。一个完整的步态周期包含两个关键阶段：

- **支撑相（Stance Phase）**：脚与地面接触，承担身体重量。约占周期的60%。
- **摆动相（Swing Phase）**：脚离开地面，向前摆动到新位置。约占周期的40%。

在双足步行中，我们还需要区分**单支撑**（Single Support，仅一条腿着地）和**双支撑**（Double Support，两条腿同时着地）。有趣的是，OpenLoong 的实现**没有显式的双支撑阶段**——它的设计中，摆动时间总是等于支撑时间（`swing time always equals to stance time`），这意味着切换是瞬时的。这个设计选择简化了状态机逻辑，但对控制器的鲁棒性提出了更高要求。

#### 6.1.2 相位变量 —— 步态的时间标尺

步态规划的核心之一是定义一个**归一化的相位变量**（Phase Variable）$\phi \in [0, 1]$：

$$
\phi = \frac{t_{\text{elapsed}}}{T_{\text{swing}}}
$$

其中：
- $t_{\text{elapsed}}$ 是当前摆动相已过去的时间
- $T_{\text{swing}}$ 是预设的摆动周期（OpenLoong 默认 $T_{\text{swing}} = 0.4\text{s}$）

$\phi = 0$ 表示摆动刚刚开始（脚离地），$\phi = 1$ 表示摆动即将结束（脚即将触地）。这个简单的标量贯穿了整个步态规划系统——它既是状态切换的条件，也是轨迹生成的自变量。

在 `gait_scheduler.cpp` 第108行可以看到相位的更新逻辑：

```cpp
dPhi = 1.0 / tSwing * dt;   // 每个时间步的相位增量
phi += dPhi;                 // 相位累积
```

#### 6.1.3 双足步行的核心控制问题

将双足步行分解为两个核心子问题：

1. **什么时候切换支撑腿？** → 由步态调度器（Gait Scheduler）解决
2. **下一条腿往哪里放？** → 由落脚点规划器（Foot Placement）解决

这两个模块加在一起，就构成了"时空规划器"——步态调度器决定时间上的切换时刻，落脚点规划器决定空间上的落点位置。

---

### 6.2 有限状态机步态调度器实现（gait_scheduler.cpp）

#### 6.2.1 状态定义

OpenLoong 的步态调度器是一个简洁的有限状态机（FSM），定义在 `data_bus.h` 第139-154行：

```cpp
enum MotionState { Stand, Walk, Walk2Stand };  // 机器人整体运动状态
enum LegState { LSt, RSt, DSt };               // 当前支撑腿状态
```

- `Stand`：静止站立，相位不更新
- `Walk`：行走模式，相位持续累积，触发步态切换
- `Walk2Stand`：从行走过渡回站立的中间状态
- `LSt`：左腿支撑（Left Stance），右腿处于摆动相
- `RSt`：右腿支撑（Right Stance），左腿处于摆动相
- `DSt`：双支撑（Double Support），仅在切换时短暂出现

#### 6.2.2 状态机的运行机制

`GaitScheduler::step()`（第79-211行）是步态调度器的核心函数。我们把它拆解为几个关键逻辑块：

**1. 地面反力估计**

第82-85行使用动力学模型估计地面反力（Ground Reaction Force）：

```cpp
FLest = -pseudoInv_SVD(J_l * dyn_M.inverse() * J_l.transpose()) *
        (J_l * dyn_M.inverse() * (tauAll - dyn_Non) + dJ_l * dq);
```

这里，$J_l$ 是左腿足端的雅可比矩阵，$\text{dyn\_M}$ 是质量矩阵，$\text{dyn\_Non}$ 是非线性项（科里奥利力和重力），$\tau$ 是关节力矩。这个公式本质上是利用动力学模型和关节力矩传感器信息，通过逆动力学计算出足端与地面的接触力 $\mathbf{F}_{est}$。

> **直观理解**：就像你站在体重秤上——通过身体的动力学状态（关节位置、速度、力矩）和机器人的动力学模型，我们可以"估算"出脚底与地面之间的相互作用力。

**2. 站立模式下的行为**

第97-104行，Stand 模式下各变量被冻结：

```cpp
if (motionState == DataBus::Stand) {
    dPhi = 0;           // 相位不更新
    phi = 0;
    isIni = false;
    enableNextStep = false;
    stepNumCur = 0;
}
```

**3. 行走模式下的相位推进**

第106-108行很简单：

```cpp
else if (motionState == DataBus::Walk) {
    enableNextStep = true;
    dPhi = 1.0 / tSwing * dt;   // 相位匀速前进
}
```

#### 6.2.3 初始化步态

第117-131行的初始化逻辑值得注意：

```cpp
if (!isIni && start_walk) {
    isIni = true;
    legState = firstleg;
    if (legState == DataBus::LSt) {         // 左腿先支撑
        swingStartPos_W = fe_r_pos_W;       // → 右腿摆动
        stanceStartPos_W = fe_l_pos_W;      // → 左腿支撑
    } else {
        swingStartPos_W = fe_l_pos_W;
        stanceStartPos_W = fe_r_pos_W;
    }
}
```

这里 `firstleg` 在构造器中默认是 `DataBus::LSt`（左支撑），因此第一次步态周期的起始配置是**左腿支撑、右腿摆动**。这个选择是任意的，但一旦确定就贯穿整个步态序列。

---

### 6.3 触地检测与状态切换逻辑

#### 6.3.1 为什么需要触地检测？

机器人必须知道摆动腿何时触地，才能正确切换到下一支撑相。但触地是个物理事件，不是精确可预测的——地形不平、模型误差、控制偏差都可能导致脚提前或延迟触地。因此需要**基于力传感器的触地检测**。

#### 6.3.2 开关条件

在 `gait_scheduler.cpp` 第133-160行，我们看到两个并行的切换逻辑：

**正常行走时的切换**（`enableNextStep = true`）：

```cpp
if (legState == DataBus::LSt && FRest[2] >= 280 && phi >= 0.6) {
    legState = DataBus::RSt;       // 切换到右腿支撑
    swingStartPos_W = fe_l_pos_W;
    stanceStartPos_W = fe_r_pos_W;
    phi = 0;                       // 相位重置
    stepNumCur++;
}
```

这里包含了两个条件必须同时满足：
- $\text{FRest}[2] \geq 280\,\text{N}$：右腿（摆动腿）的垂直地面反力足够大，说明脚已可靠触地
- $\phi \geq 0.6$：摆动已完成至少60%，避免过早切换

**停止模式下的切换**（`enableNextStep = false`，即 Walk2Stand）：

```cpp
if (legState == DataBus::LSt && FRest[2] >= 200) {  // 力阈值更低
    touchDown = true;
    legState = DataBus::DSt;       // 切换到双支撑
}
```

这里阈值从280N降到了200N，且不要求 $\phi$ 条件——过渡到站立的过程中，只要脚触地就立即确认，不再迈出下一步。

> **为什么需要 $\phi \geq 0.6$？** 这个经验值确保了摆动腿有足够的时间完成前摆运动。如果切换太早（$\phi$ 太小），腿还没摆到位就切换，步幅会过小，甚至导致机器人来不及调整姿态。如果切换太晚（$\phi$ 接近1），可能导致脚拖地或踩空。0.6 是一个保守且安全的阈值。

#### 6.3.3 切换后的状态维护

第182-209行维护了每步后的状态信息：

```cpp
if (legState == DataBus::LSt) {
    posHip_W = hip_r_pos_W;      // 对侧髋（支撑侧髋）
    posST_W = fe_l_pos_W;        // 支撑腿足端位置
    theta0 = -3.1415 * 0.5;      // 摆动腿偏航偏移
    legStateNext = DataBus::RSt;  // 下一步是右支撑
}
```

这里的 $\theta_0 = \pm \frac{\pi}{2}$ 是一个关键参数。它表示摆动腿相对于机器人躯干的偏航偏移角，$\theta_0 = -\pi/2$ 意味着右腿作为摆动腿时，默认姿态相对于躯干偏左（负y方向）90°。这个参数在落脚点规划中用于计算摆动腿的最终朝向。

---

### 6.4 Raibert 落脚点启发式 —— 原理与数学推导

#### 6.4.1 从"跑步机实验"说起

想象你在跑步机上跑步：当跑步机速度增加时，你的脚会自然地更靠前落地；当速度减小时，落脚点会向后移。这个直觉告诉我们：**落脚点与期望速度和当前速度之间存在某种关系**。

Marc Raibert 在1980年代对单腿跳跃机器人的研究中首次系统性地提出了这个关系——著名的 **Raibert 落脚点启发式**（Raibert Foot Placement Heuristic）。虽然最初用于单腿跳跃，但它被广泛证实在双足步行中也非常有效。

#### 6.4.2 数学推导

Raibert 的核心思想是：**机器人的落脚点应该使得从落脚点到质心的线段，在支撑相结束时恰好与期望速度对齐**。

考虑一个简化的倒立摆模型（LIPM），机器人在支撑相期间以恒定高度摆动。根据倒立摆动力学，支撑相结束时的质心速度 $\mathbf{v}_{end}$ 与起始速度 $\mathbf{v}_{start}$ 和落脚点位置 $\mathbf{p}_{foot}$ 之间存在关系。

Raibert 给出了一个简洁的启发式公式：

$$
\mathbf{p}_{foot} = \mathbf{p}_{hip} + k(\mathbf{v}_{des} - \mathbf{v}_{cur}) \cdot T_{stance} + \frac{1}{2} \mathbf{v}_{cur} T_{swing}
$$

其中：
- $\mathbf{p}_{foot}$：期望的落脚点位置（世界系）
- $\mathbf{p}_{hip}$：摆动腿髋关节的当前位置（世界系）
- $\mathbf{v}_{des}$：期望的质心速度
- $\mathbf{v}_{cur}$：当前的质心速度
- $T_{stance}$：支撑相时间（这里等于 $T_{swing}$）
- $k$：增益系数，调节速度反馈的强度

##### 三项的物理含义

1. **$\mathbf{p}_{hip}$（髋位置项）**：落脚点的基准位置。如果没有其他修正，脚应该落在髋的正下方。

2. **$k(\mathbf{v}_{des} - \mathbf{v}_{cur}) \cdot T_{stance}$（速度反馈项）**：如果当前速度太慢（$\mathbf{v}_{cur} < \mathbf{v}_{des}$），脚往前多迈一点，让倒立摆"推"着机器人加速；如果太快，脚往后收，产生制动力。这本质上是一个 **P 控制器**，作用于期望速度和实际速度的偏差。

3. **$\frac{1}{2} \mathbf{v}_{cur} T_{swing}$（前馈补偿项）**：补偿在摆动相期间身体继续向前移动造成的偏移。当机器人在摆动相期间以速度 $\mathbf{v}_{cur}$ 向前运动时，髋关节在摆动结束时会比开始时向前移动了 $\mathbf{v}_{cur} \cdot T_{swing}/2$（假设线性运动）。

#### 6.4.3 代码中的实现

在 `foot_placement.cpp` 第53-55行：

```cpp
/* 线性速度部分 */
posDes_W = hipPos_W                                    // 髋位置基准
         + KP * (desV_W - curV_W) * (-1)               // 速度反馈修正（注意负号）
         + 0.5 * tSwing * curV_W                       // 前馈补偿
         + curV_W * (1 - phi) * tSwing;                // 实时修正项
```

注意这里出现了4项，比标准 Raibert 公式多了一项 `curV_W * (1 - phi) * tSwing`。这个额外的项是**实时修正项**——当 $\phi$ 接近0时（摆动刚开始），修正量最大；当 $\phi$ 接近1时（摆动快结束），修正量趋近0。这个项反映了：在摆动的整个过程中，机器人的质心一直在向前移动，因此落脚点的期望位置也应该"实时更新"。

#### 6.4.4 偏航（角速度）的落脚点修正

除了前进速度，机器人还需要处理偏航转动。第58-61行：

```cpp
double thetaF;
thetaF = yawCur + theta0
       + omegaZ_W * (1 - phi) * tSwing     // 角速度实时补偿
       + 0.5 * omegaZ_W * tSwing           // 角速度前馈
       + kp_wz * (omegaZ_W - desWz_W);     // 角速度反馈

posDes_W(0) += 0.5 * hip_width * (cos(thetaF) - cos(yawCur + theta0));
posDes_W(1) += 0.5 * hip_width * (sin(thetaF) - sin(yawCur + theta0));
```

这组公式的含义是：当机器人希望转向时（$\omega_z^{des} \neq \omega_z^{cur}$），落脚点在 y 方向上应该偏移，使得两条腿的连线产生一个转角。`hip_width` 是髋关节宽度（0.229m），$\theta_0 = \pm \pi/2$ 是摆动腿的初始偏航角。

> **具体来说**：如果机器人想向右转（$\omega_z^{des} > 0$），右边摆动腿的落脚点会偏左，左边摆动腿的落脚点会偏右，从而产生一个偏转力矩，实现转向。

---

### 6.5 摆动腿三维轨迹生成：贝塞尔曲线

#### 6.5.1 为什么需要轨迹规划？

落脚点只是"目的地"，摆动腿需要平滑地从当前位置移动到目的位置。一个优秀的摆动轨迹应该满足：
- **连续性**：位置、速度、加速度连续，避免冲击
- **避障**：脚在摆动过程中要抬高，避免绊倒
- **可调性**：步高、步长应可独立调节

#### 6.5.2 X-Y 平面：摆线轨迹

在 `foot_placement.cpp` 第94-98行：

```cpp
if (phi < 1.0) {
    pDesCur[0] = posStart_W(0) + (posDes_W(0) - posStart_W(0))
                 / (2 * 3.1415) * (2 * 3.1415 * phi - sin(2 * 3.1415 * phi));
    pDesCur[1] = posStart_W(1) + (posDes_W(1) - posStart_W(1))
                 / (2 * 3.1415) * (2 * 3.1415 * phi - sin(2 * 3.1415 * phi));
}
```

这是**摆线**（Cycloid）轨迹的公式。归一化后，在 $x$ 方向上的运动为：

$$
x(\phi) = x_0 + \frac{\Delta x}{2\pi}(2\pi\phi - \sin(2\pi\phi))
$$

摆线的速度特性非常理想：
- 起始速度为零：$\dot{x}(0) = 0$
- 中间速度先加速后减速
- 终点速度为零：$\dot{x}(1) = 0$

这意味着摆动脚从静止开始加速，到中间达到最大速度，然后再减速到静止——完美避免了脚与地面之间的相对速度冲击。

#### 6.5.3 Z 方向：贝塞尔曲线组合

在 `foot_placement.cpp` 第120行，垂向轨迹调用了一个自定义函数：

```cpp
pDesCur[2] = posStart_W(2) + Trajectory(0.2, stepHeight, posDes_W(2) - posStart_W(2)) + zStretch;
```

`Trajectory` 函数（第123-153行）使用贝塞尔曲线（Bézier Curve）构建了一个分段轨迹。让我们深入理解：

**什么是贝塞尔曲线？**

一个 $n$ 阶贝塞尔曲线由 $n+1$ 个控制点 $\{P_0, P_1, ..., P_n\}$ 定义：

$$
B(s) = \sum_{i=0}^{n} \binom{n}{i} (1-s)^{n-i} s^i P_i, \quad s \in [0, 1]
$$

其中 $\binom{n}{i}$ 是二项式系数，$P_i$ 是控制点。当参数 $s$ 从0变到1时，曲线平滑地从 $P_0$ 移动到 $P_n$。

在 `bezier_1D.cpp` 中，`getOut` 函数实现了这一公式：

```cpp
double Bezier_1D::getOut(double s) {
    double res = 0;
    int Np = P.size();
    for (int i = 0; i < Np; i++) {
        res += nchoosek(Np-1, i) * pow(1-s, Np-1-i) * pow(s, i) * P[i];
    }
    return res;
}
```

**OpenLoong 的 Z 方向轨迹设计**：

`Trajectory` 函数中，前5个控制点为0，后3个控制点为1。这意味着在参数 $s$ 从0到1的过程中：
- 前一半的控制点权重高时，输出接近0
- 后一半的控制点权重高时，输出接近1

这实际上构造了一个 **S 形曲线**，天然具备"平滑加速→高速通过→平滑减速"的特性。

轨迹分为两段：

1. **上升段**（$\phi < 0.2$）：
   ```cpp
   output = hei * Bswpid.getOut(phi / phase);  // 从0到stepHeight的平滑上升
   ```

2. **下降段**（$\phi \geq 0.2$）：
   ```cpp
   double s = Bswpid.getOut((1.4 - phi) / (1.4 - phase));
   if (s > 0)
       output = hei * s + len * (1.0 - s);  // 从stepHeight到地面长度的平滑过渡
   else
       output = len;                        // 直接到达目的地高度
   ```

这里的 `len` 是 `posDes_W(2) - posStart_W(2)`，即期望高度相对于起始高度的变化量。`hei` 是步高（默认0.12m）。

> **设计智慧**：Z 方向轨迹并不是简单的"先升后降"对称曲线。上升阶段陡峭（快速抬脚），下降阶段平缓（缓慢落地找地）。这种非对称设计减少了脚在空中停留的时间，同时为触地检测争取了更大的时间窗口。

---

### 6.6 缓动轨迹（Ramp Trajectory）与平滑过渡

#### 6.6.1 为什么需要缓动？

控制系统中经常需要将某个变量从当前值平滑地过渡到目标值。如果直接跳变，会产生巨大的加速度，导致机器人抖动或失稳。Ramp Trajectory 就是为此设计的简单而有效的工具。

#### 6.6.2 实现原理

在 `ramp_trajectory.cpp` 中：

```cpp
void RampTrajectory::setPara(double yDesIn, double timeToReach) {
    yDes = yDesIn;
    k = (yDesIn - yOld) / timeToReach;  // 计算恒定速率
}

double RampTrajectory::step() {
    y = yOld + k * dt;                   // 按恒定速率递增
    if (fabs(yDes - y) < fabs(1.5 * k * dt))
        y = yDes;                        // 接近目标时直接赋值
    yOld = y;
    return y;
}
```

这是一个**一阶线性缓动**（First-order Ramp）：从当前值 $y_{old}$ 以恒定速率 $k$ 向目标值 $y_{des}$ 逼近。速率 $k = (y_{des} - y_{old}) / T_{reach}$ 由期望到达时间 $T_{reach}$ 决定。

当缓存值接近目标（偏差小于 $1.5 \cdot k \cdot dt$）时，直接赋目标值——这个"容差带"避免了在数值精度限制下的无限震荡。

#### 6.6.3 在系统中的使用

虽然 RampTrajectory 类本身没有在步态规划代码中被直接调用，但它在 `joystick_interpreter.cpp` 中承担了关键角色——将用户输入的期望速度（通过键盘/摇杆）平滑地过渡到 MPC 的参考信号，避免速度指令的突变。

---

### 6.7 完整流程图与代码逐行解析

#### 6.7.1 步态规划器的数据流

整个步态规划系统的主循环（以 `walk_mpc_wbc_joystick.cpp` 为参考）按以下顺序执行：

```
主循环 (1kHz)
  │
  ├─ 读取传感器数据 (mj_interface)
  ├─ 状态估计 (StateModule)
  ├─ 运动学/动力学计算 (kinDynSolver)
  │
  ├─ [若为 Walk/Walk2Stand 状态]
  │   ├─ 摇杆解释器 (jsInterp.step())
  │   ├─ 步态调度器
  │   │   ├─ gaitScheduler.dataBusRead()
  │   │   ├─ gaitScheduler.step()      ← 状态切换+相位更新
  │   │   └─ gaitScheduler.dataBusWrite()
  │   ├─ 落脚点规划
  │   │   ├─ footPlacement.dataBusRead()
  │   │   ├─ footPlacement.getSwingPos()  ← 轨迹生成
  │   │   └─ footPlacement.dataBusWrite()
  │   └─ MPC (200Hz, 每5个1kHz步执行一次)
  │       ├─ MPC_solv.dataBusRead()
  │       ├─ MPC_solv.cal()
  │       └─ MPC_solv.dataBusWrite()
  │
  ├─ WBC 求解器
  ├─ PVT 关节控制器
  └─ 输出力矩到电机
```

#### 6.7.2 GaitScheduler::step() 完整执行流

```
step()
  │
  ├─ 1. 估计地面反力 (FLest, FRest)
  │      方程: F = -J_pinv * (J * M^{-1} * (τ - N) + dJ * dq)
  │
  ├─ 2. 处理 Walk2Stand 状态→Stand 的切换
  │
  ├─ 3. 根据 motionState 设定 dPhi
  │      Stand → dPhi = 0
  │      Walk  → dPhi = 1/tSwing * dt
  │
  ├─ 4. 更新相位: phi += dPhi
  │
  ├─ 5. 初始化摆动 (第一次行走)
  │      设定 swingStartPos = 对侧足位
  │      设定 legState = firstleg
  │
  ├─ 6. 切换逻辑
  │      if (LSt && FRest[2]>=280N && phi>=0.6):
  │          legState = RSt, phi = 0
  │      if (RSt && FLest[2]>=280N && phi>=0.6):
  │          legState = LSt, phi = 0
  │
  ├─ 7. 钳位 phi ∈ [0, 1]
  │
  └─ 8. 更新支撑/摆动腿相关信息 (posHip, posST, theta0)
```

#### 6.7.3 FootPlacement::getSwingPos() 完整执行流

```
getSwingPos()
  │
  ├─ 1. 构造旋转矩阵 Rz(yawCur)
  ├─ 2. 计算增益矩阵 KP = Rz * diag(kp_vx, kp_vy, 0) * Rz^T
  │
  ├─ 3. 线性速度落脚点 (Raibert 启发式)
  │      posDes = hipPos + KP*(desV - curV)*(-1)               ← 速度反馈
  │              + 0.5*tSwing*curV                             ← 前馈补偿
  │              + curV*(1-phi)*tSwing                         ← 实时修正
  │
  ├─ 4. 偏航落脚点修正
  │      thetaF = yawCur + theta0 + omegaZ*(1-phi)*tSwing     ← 实时偏航补偿
  │              + 0.5*omegaZ*tSwing                          ← 偏航前馈
  │              + kp_wz*(omegaZ - desWz)                     ← 偏航反馈
  │      posDes += hip_width/2 * (cos/sin 修正)
  │
  ├─ 5. 足端偏移量 (身体坐标系下的偏置)
  │      xOff_L = -0.07, yOff_L = 0.04, zOff_W = -0.035
  │      根据左/右支撑腿，将偏移量旋转到世界系
  │
  ├─ 6. Z 方向轨迹 (贝塞尔曲线)
  │      pDesCur[2] = startZ + Trajectory(phi, stepHeight, Δz)
  │
  ├─ 7. X-Y 方向轨迹 (摆线)
  │      pDesCur[0/1] = start + Δ/(2π)*(2π*phi - sin(2π*phi))
  │
  └─ 8. 触地前的腿拉伸 (zStretch)
         在 phi≥0.98 时逐渐降低脚高度，确保触地
```

---

### 6.8 参数影响分析与调优实验

#### 6.8.1 关键参数一览

| 参数 | 位置 | 默认值 | 作用 |
|------|------|--------|------|
| `tSwing` | `gait_scheduler.h` | 0.4s | 摆动周期，决定步行频率 |
| `kp_vx` | `foot_placement` | 0.03 | 前进速度反馈增益 |
| `kp_vy` | `foot_placement` | 0.03 | 侧向速度反馈增益 |
| `kp_wz` | `foot_placement` | 0.03 | 偏航速度反馈增益 |
| `stepHeight` | `foot_placement` | 0.12m | 最大抬脚高度 |
| `FzThreshold` | `gait_scheduler.h` | 280N | 触地检测力阈值 |
| `phi切换阈值` | `gait_scheduler.cpp` | 0.6 | 最早允许切换的相位 |

#### 6.8.2 参数调优建议

**1. 摆动周期 `tSwing`**：
- 减小（如0.3s）：步频加快，步行速度提升，但对执行器带宽要求更高
- 增大（如0.5s）：步频减慢，更稳定，但速度降低
- 建议：在机器人物理限制（电机速度/力矩）允许范围内尽量小

**2. 速度反馈增益 `kp_vx`**：
- 增大：对速度偏差的响应更强，收敛更快，但可能引起振荡
- 减小：响应柔和，但跟踪期望速度时有稳态误差
- 建议：从0.01开始逐步增加，观察质心速度的跟踪效果

**3. 步高 `stepHeight`**：
- 增大：可跨越更高障碍，但增加膝部力矩消耗
- 减小：更节能，但容易绊到障碍物
- 建议：平地行走0.10-0.15m，不平整地面0.15-0.20m

**4. 触地检测阈值**：
- 增高：降低误触发（如摆动过程中的意外碰撞），但可能错过真实触地
- 降低：更灵敏地检测触地，但可能误触发
- 建议：280N（约机器人重量的40%）在大多数情况下工作良好

**5. 相位切换阈值**：
- 增大（如0.8）：摆动腿有更长时间完成轨迹，但步频降低
- 减小（如0.4）：切换更快，但摆动腿可能来不及调整到位
- 建议：0.6是一个兼顾安全和效率的折中点

---

## 第7章：模型预测控制（MPC）

### 7.1 MPC 基本原理 —— 滚动优化与反馈

#### 7.1.1 一个生活中的例子

假设你正在开车去一个陌生的目的地。你不会只踩一脚油门然后就完全不动方向盘——你会不断观察前方的路况，根据当前的位置和速度，判断接下来几秒应该加速、减速还是转向。每隔几秒，你就重新进行一次规划。这就是 MPC 的核心思想。

**【模型预测控制（Model Predictive Control, MPC）】** 是一种基于模型的优化控制方法，其核心是：

1. **使用模型预测未来**：根据当前状态 $x_k$ 和系统模型，预测未来 $N$ 步的状态 $\hat{x}_{k+1}, \hat{x}_{k+2}, ..., \hat{x}_{k+N}$
2. **在预测窗口内求解优化问题**：找出一系列控制输入 $u_k, u_{k+1}, ..., u_{k+N-1}$，使得预测轨迹与期望轨迹的偏差最小，同时满足约束
3. **仅执行第一个控制输入**：应用 $u_k$ 到系统
4. **滚动到下一个时刻**：在 $k+1$ 时刻，用新测得的 $x_{k+1}$ 重复上述过程

#### 7.1.2 数学形式

标准的 MPC 问题可形式化为：

$$
\min_{u_k, ..., u_{k+N-1}} \sum_{i=0}^{N-1} \left[ (x_{k+i} - x_{ref,i})^T Q (x_{k+i} - x_{ref,i}) + u_{k+i}^T R u_{k+i} \right] + \text{terminal cost}
$$

s.t.

$$
x_{k+i+1} = A x_{k+i} + B u_{k+i} \quad \text{(系统动力学约束)}
$$

$$
u_{min} \leq u_{k+i} \leq u_{max} \quad \text{(输入约束)}
$$

$$
g(x_{k+i}, u_{k+i}) \leq 0 \quad \text{(其他约束：摩擦锥等)}
$$

#### 7.1.3 为什么双足机器人需要 MPC？

双足机器人的平衡控制有几个特殊挑战：

1. **不稳定的开环动力学**：倒立摆模型本质不稳定，需要持续调节
2. **接触约束是时变的**：单支撑/双支撑/摆动腿，接触状态不断变化
3. **物理约束必须严格满足**：摩擦力不能超过摩擦锥、足端不能穿透地面
4. **多目标优化**：同时跟踪质心位置、姿态、速度，还要满足约束

MPC 非常适合处理这些问题——它可以在线求解一个包含所有约束的优化问题，输出最优的足端反力，让机器人在复杂情况下也能保持平衡。

---

### 7.2 单刚体模型（SRBM）的完整推导（重点！）

这是本章最核心的部分。我们将从牛顿-欧拉方程开始，一步一步推导出用于 MPC 的单刚体模型。

#### 7.2.1 为什么用单刚体模型？

人形机器人有几十个自由度，全状态模型（Full-body Model）的维度非常高，直接用于在线优化计算量过大。**单刚体模型（Single Rigid Body Model, SRBM）** 将整个机器人近似为一个刚体，忽略关节动力学，只考虑：

- 刚体的质心（CoM）位置和速度（3D）
- 刚体的姿态（欧拉角）和角速度（3D）
- 足端与地面的接触力（作为控制输入）

这个简化使得状态维度从几十降到12，同时保留了平衡控制最关键的物理特性。

> **使用条件**：SRBM 在以下条件下是足够准确的近似：
> - 机器人运动速度不太快（$\leq$ 1.5m/s）
> - 关节运动相对于质心运动是"小幅度"的
> - 腿的质量远小于躯干质量（OpenLoong 大约 80% 的质量集中在躯干）

#### 7.2.2 符号定义

| 符号 | 含义 | 维数 |
|------|------|------|
| $m$ | 机器人总质量（77.35 kg） | 1 |
| $\mathbf{I}$ | 躯干惯量张量（在躯干坐标系中） | 3×3 |
| $\mathbf{g}$ | 重力加速度（-9.8 m/s²，z方向） | 3×1 |
| $\mathbf{p}$ | 质心位置（世界系） | 3×1 |
| $\mathbf{v}$ | 质心线速度（世界系） | 3×1 |
| $\boldsymbol{\Theta} = [\phi, \theta, \psi]^T$ | 欧拉角（roll, pitch, yaw） | 3×1 |
| $\boldsymbol{\omega}$ | 角速度（世界系） | 3×1 |
| $\mathbf{r}_i$ | 第 $i$ 个足端到质心的位置向量（世界系） | 3×1 |
| $\mathbf{f}_i$ | 第 $i$ 个足端的接触力（世界系） | 3×1 |
| $\boldsymbol{\tau}_i$ | 第 $i$ 个足端的接触力矩（世界系） | 3×1 |

#### 7.2.3 线性动量动力学

**牛顿第二定律**：机器人的总动量 $ \mathbf{P} = m\mathbf{v}$ 对时间的变化率等于所有外力的矢量和。

$$
\frac{d\mathbf{P}}{dt} = m \dot{\mathbf{v}} = \sum_{i=1}^{n_c} \mathbf{f}_i + m\mathbf{g}
$$

其中 $n_c$ 是接触足的数量（单支撑时 $n_c=1$，双支撑时 $n_c=2$）。

展开为三个分量：

$$
\begin{cases}
m\dot{v}_x = f_{1x} + f_{2x} + \cdots \\
m\dot{v}_y = f_{1y} + f_{2y} + \cdots \\
m\dot{v}_z = f_{1z} + f_{2z} + \cdots + mg
\end{cases}
$$

这是最简单的部分——线加速度正比于接触力之和加上重力。

#### 7.2.4 角动量动力学

**欧拉方程**：角动量 $\mathbf{L} = \mathbf{I}\boldsymbol{\omega}$ 对时间的变化率等于所有外力矩之和。

$$
\frac{d\mathbf{L}}{dt} = \mathbf{I}\dot{\boldsymbol{\omega}} + \boldsymbol{\omega} \times (\mathbf{I}\boldsymbol{\omega}) = \sum_{i=1}^{n_c} \left( \mathbf{r}_i \times \mathbf{f}_i + \boldsymbol{\tau}_i \right)
$$

这里：
- $\mathbf{r}_i \times \mathbf{f}_i$：接触力对质心产生的力矩（叉积）
- $\boldsymbol{\tau}_i$：接触力矩（足端传递到躯干的纯力矩）

> **重要简化**：在 OpenLoong 的 MPC 实现中，**角速度项 $\boldsymbol{\omega} \times (\mathbf{I}\boldsymbol{\omega})$ 被忽略了**。这等价于假设机器人在平衡控制期间旋转速度较慢，科里奥利力矩可以忽略。在 $\boldsymbol{\omega}$ 较小时（$< 1 \text{rad/s}$），这个近似是合理的。

忽略 $\boldsymbol{\omega} \times (\mathbf{I}\boldsymbol{\omega})$ 后，角动量方程简化为：

$$
\mathbf{I}\dot{\boldsymbol{\omega}} = \sum_{i=1}^{n_c} \left( \mathbf{r}_i \times \mathbf{f}_i + \boldsymbol{\tau}_i \right)
$$

#### 7.2.5 状态空间表达

将上述方程组合成状态空间形式。

**选择状态向量**（12维，与 `mpc.h` 第18行一致）：

$$
\mathbf{x} = [\underbrace{\phi, \theta, \psi}_{\text{欧拉角}}, \underbrace{p_x, p_y, p_z}_{\text{质心位置}}, \underbrace{\omega_x, \omega_y, \omega_z}_{\text{角速度}}, \underbrace{v_x, v_y, v_z}_{\text{线速度}}]^T \in \mathbb{R}^{12}
$$

**选择输入向量**（13维，与 `mpc.h` 第18行一致）：

$$
\mathbf{u} = [\underbrace{f_{Lx}, f_{Ly}, f_{Lz}}_{\text{左足力}}, \underbrace{\tau_{Lx}, \tau_{Ly}, \tau_{Lz}}_{\text{左足力矩}}, \underbrace{f_{Rx}, f_{Ry}, f_{Rz}}_{\text{右足力}}, \underbrace{\tau_{Rx}, \tau_{Ry}, \tau_{Rz}}_{\text{右足力矩}}, \underbrace{F_z}_{\text{总垂直力}}]^T \in \mathbb{R}^{13}
$$

> 注意：$F_z$ 是一个"人工"输入，用于处理总垂直力的约束。虽然从 SRBM 的角度看，$f_{Lz} + f_{Rz}$ 已经决定了总垂直力，但在 QP 问题中加入一个额外的 $F_z$ 变量可以更灵活地处理接触约束。

**连续时间状态空间方程**：

$$
\dot{\mathbf{x}}(t) = \mathbf{A}_c \mathbf{x}(t) + \mathbf{B}_c(\mathbf{r}_1, \mathbf{r}_2) \mathbf{u}(t) + \mathbf{C}_c
$$

其中：

**矩阵 $\mathbf{A}_c$**（12×12）：

$$
\mathbf{A}_c = \begin{bmatrix}
\mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{R}_{\psi}^T & \mathbf{0}_{3\times3} \\
\mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{I}_{3\times3} \\
\mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} \\
\mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3}
\end{bmatrix}
$$

这个矩阵描述了状态之间的耦合关系：
- $\dot{\phi}, \dot{\theta}, \dot{\psi}$（欧拉角变化率）与 $\boldsymbol{\omega}$ 通过旋转矩阵 $\mathbf{R}_{\psi}^T$ 关联
- $\dot{p}_x, \dot{p}_y, \dot{p}_z$（质心速度）等于 $\mathbf{v}$
- 角加速度和线加速度由输入决定（输入矩阵 $\mathbf{B}_c$）

**矩阵 $\mathbf{B}_c(\mathbf{r}_1, \mathbf{r}_2)$**（12×13）：

$$
\mathbf{B}_c = \begin{bmatrix}
\mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times1} \\
\mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times3} & \mathbf{0}_{3\times1} \\
\mathbf{I}_c^{-1} [\mathbf{r}_1]_{\times} & \mathbf{I}_c^{-1} & \mathbf{I}_c^{-1} [\mathbf{r}_2]_{\times} & \mathbf{I}_c^{-1} & \mathbf{0}_{3\times1} \\
\frac{1}{m} \mathbf{I}_{3\times3} & \mathbf{0}_{3\times3} & \frac{1}{m} \mathbf{I}_{3\times3} & \mathbf{0}_{3\times3} & \frac{1}{m} \mathbf{e}_3
\end{bmatrix}
$$

其中：
- $[\mathbf{r}_i]_{\times}$ 是向量 $\mathbf{r}_i$ 的叉积矩阵（skew-symmetric matrix）
- $\mathbf{I}_c$ 是躯干在世界系下的惯量张量

**叉积矩阵** $[\mathbf{r}]_{\times}$ 定义为：

$$
[\mathbf{r}]_{\times} = \begin{bmatrix}
0 & -r_z & r_y \\
r_z & 0 & -r_x \\
-r_y & r_x & 0
\end{bmatrix}
$$

这个矩阵使得 $[\mathbf{r}]_{\times} \mathbf{f} = \mathbf{r} \times \mathbf{f}$。

在 `useful_math.cpp` 第240-247行中实现：

```cpp
Eigen::Matrix<double, 3, 3> CrossProduct_A(Eigen::Matrix<double, 3, 1> A) {
    Eigen::Matrix<double, 3, 3> M;
    M << 0.0, -A[2], A[1],
         A[2], 0.0, -A[0],
        -A[1], A[0], 0.0;
    return M;
}
```

**常数项 $\mathbf{C}_c$**（12×1）：

$$
\mathbf{C}_c = \begin{bmatrix}
\mathbf{0}_{3\times1} & \mathbf{0}_{3\times1} & \mathbf{0}_{3\times1} & \mathbf{g}
\end{bmatrix}^T
$$

重力只出现在线速度导数的 z 分量：$\dot{v}_z = ... + g$。

#### 7.2.6 详细推导过程

我们从牛顿-欧拉方程出发，一步步建立上面的状态空间表达：

**第一步：线速度动力学**

$$
m\dot{\mathbf{v}} = \sum_{i=1}^{2} \mathbf{f}_i + m\mathbf{g}
$$

两边除以 $m$：

$$
\dot{\mathbf{v}} = \frac{1}{m}(\mathbf{f}_L + \mathbf{f}_R) + \mathbf{g}
$$

**第二步：角速度动力学**

$$
\mathbf{I}\dot{\boldsymbol{\omega}} = \sum_{i=1}^{2} (\mathbf{r}_i \times \mathbf{f}_i + \boldsymbol{\tau}_i)
$$

两边左乘 $\mathbf{I}^{-1}$：

$$
\dot{\boldsymbol{\omega}} = \mathbf{I}^{-1} \sum_{i=1}^{2} (\mathbf{r}_i \times \mathbf{f}_i + \boldsymbol{\tau}_i)
$$

利用叉积矩阵的性质 $\mathbf{r}_i \times \mathbf{f}_i = [\mathbf{r}_i]_{\times} \mathbf{f}_i$：

$$
\dot{\boldsymbol{\omega}} = \mathbf{I}^{-1} \left( [\mathbf{r}_L]_{\times} \mathbf{f}_L + \boldsymbol{\tau}_L + [\mathbf{r}_R]_{\times} \mathbf{f}_R + \boldsymbol{\tau}_R \right)
$$

**第三步：姿态运动学**

欧拉角的变化率 $\dot{\boldsymbol{\Theta}}$ 与角速度 $\boldsymbol{\omega}$ 之间的关系由旋转矩阵 $\mathbf{R}_{\psi}$ 关联：

在 MPC 实现中，使用了简化关系 $\dot{\boldsymbol{\Theta}} = \mathbf{R}_{\psi}^T \boldsymbol{\omega}$，其中 $\mathbf{R}_{\psi}$ 是绕 z 轴旋转 $\psi$ 的旋转矩阵：

$$
\mathbf{R}_{\psi} = \begin{bmatrix}
\cos\psi & -\sin\psi & 0 \\
\sin\psi & \cos\psi & 0 \\
0 & 0 & 1
\end{bmatrix}
$$

这个简化假设了 roll 和 pitch 角较小，使得 $\mathbf{R} \approx \mathbf{R}_z(\psi)$。

**第四步：位置运动学**

$$
\dot{\mathbf{p}} = \mathbf{v}
$$

> 直观解释：质心位置的变化率就是质心速度。

**第五步：组装**

将以上所有方程组合，得到前面展示的 $\mathbf{A}_c$ 和 $\mathbf{B}_c$。

#### 7.2.7 将姿态变换到世界系

在 MPC 的实现中，有一个重要的细节：惯量张量 $\mathbf{I}$ 最初定义在躯干坐标系（Body Frame）中。由于躯干姿态在运动中不断变化，需要将惯量张量旋转到世界系。

在 `mpc.cpp` 第233行：

```cpp
Ic_W_inv = (R_curz[i] * Ic * R_curz[i].transpose()).inverse();
```

其中：
- $\mathbf{I}_c$ 是躯干坐标系中的惯量张量（常数，见第191行）
- $\mathbf{R}_{curz}[i]$ 是第 $i$ 个预测步的偏航旋转矩阵
- $\mathbf{I}_{c,W} = \mathbf{R}_{curz}[i] \cdot \mathbf{I}_c \cdot \mathbf{R}_{curz}[i]^T$ 是世界系下的惯量张量

OpenLoong 中使用的惯量张量为：

$$
\mathbf{I}_c = \begin{bmatrix}
12.61 & 0 & 0.37 \\
0 & 11.15 & 0.01 \\
0.37 & 0.01 & 2.15
\end{bmatrix} [\text{kg} \cdot \text{m}^2]
$$

注意非对角线元素的存在——这意味着躯干的质量分布不是完全对称的。

---

### 7.3 离散化与预测模型构建

#### 7.3.1 零阶保持离散化

连续时间模型 $\dot{\mathbf{x}} = \mathbf{A}_c\mathbf{x} + \mathbf{B}_c\mathbf{u} + \mathbf{C}_c$ 需要离散化为：

$$
\mathbf{x}_{k+1} = \mathbf{A} \mathbf{x}_k + \mathbf{B} \mathbf{u}_k + \mathbf{C}
$$

采用**零阶保持（Zero-Order Hold, ZOH）** 离散化，假设在采样周期 $dt$ 内，输入 $\mathbf{u}$ 保持不变：

$$
\mathbf{A} = e^{\mathbf{A}_c dt} \approx \mathbf{I} + \mathbf{A}_c dt
$$

$$
\mathbf{B} = \int_0^{dt} e^{\mathbf{A}_c \tau} d\tau \cdot \mathbf{B}_c \approx \mathbf{B}_c dt
$$

$$
\mathbf{C} = \int_0^{dt} e^{\mathbf{A}_c \tau} d\tau \cdot \mathbf{C}_c \approx \mathbf{C}_c dt
$$

在 `mpc.cpp` 第224-228行：

```cpp
// 连续时间矩阵
Ac[i].block<3, 3>(0, 6) = R_curz[i].transpose();   // 姿态运动学
Ac[i].block<3, 3>(3, 9) = Eigen::MatrixXd::Identity(3, 3);  // 位置运动学

// ZOH 离散化
A[i] = Eigen::MatrixXd::Identity(nx, nx) + dt * Ac[i];
```

以及第241行：

```cpp
B[i] = dt * Bc[i];  // 输入矩阵离散化
```

这里 $dt = 0.005\text{s}$（200Hz），注意这个离散化是最简单的一阶近似。对于 $f_{MPC}=200\text{Hz}$ 的控制频率，$$e^{\mathbf{A}_c dt} \approx \mathbf{I} + \mathbf{A}_c dt$$ 是足够精确的。

#### 7.3.2 预测时域与控制时域

在 `mpc.h` 中定义了两个关键参数：

```cpp
const uint16_t mpc_N = 10;   // 预测时域长度 (N)
const uint16_t ch = 3;       // 控制时域长度 (CH)
```

- **预测时域 $N = 10$**：MPC 预测未来 $10 \times 5\text{ms} = 50\text{ms}$ 内的系统状态
- **控制时域 $CH = 3$**：MPC 只优化前 $3$ 步的输入，之后的输入保持最后一步的值不变

控制时域小于预测时域是 MPC 的标准做法——它减少了优化变量的数量（从 $N \times n_u$ 降到 $CH \times n_u$），降低了计算负担。这也反映了"控制仅在近期最活跃"的直觉。

#### 7.3.3 预测方程构建

从初始状态 $\mathbf{x}_0$ 出发，整个预测轨迹可以写成矩阵形式：

$$
\mathbf{X} = \boldsymbol{\mathcal{A}} \mathbf{x}_0 + \boldsymbol{\mathcal{B}} \mathbf{U}
$$

其中：
- $\mathbf{X} = [\mathbf{x}_1^T, \mathbf{x}_2^T, ..., \mathbf{x}_N^T]^T \in \mathbb{R}^{12N}$ 是全部预测状态的列向量
- $\mathbf{U} = [\mathbf{u}_0^T, \mathbf{u}_1^T, ..., \mathbf{u}_{CH-1}^T]^T \in \mathbb{R}^{13 \cdot CH}$ 是全部控制输入的列向量
- $\boldsymbol{\mathcal{A}}$ 和 $\boldsymbol{\mathcal{B}}$ 是预测矩阵

**$\boldsymbol{\mathcal{A}}$ 矩阵**（`Aqp`，第244-247行）：

每个预测步 $i$ 的状态由下式给出：

$$
\mathbf{x}_i = \left(\prod_{j=0}^{i-1} \mathbf{A}_j\right) \mathbf{x}_0
$$

代码中的实现：

```cpp
for (int i = 0; i < mpc_N; i++)
    Aqp.block<nx, nx>(i * nx, 0) = Eigen::MatrixXd::Identity(nx, nx);
for (int i = 0; i < mpc_N; i++)
    for (int j = 0; j < i + 1; j++)
        Aqp.block<nx, nx>(i * nx, 0) = A[j] * Aqp.block<nx, nx>(i * nx, 0);
```

注意这里 $\mathbf{x}_0$ 是当前状态，所以实际的映射关系是 $\mathbf{x}_i = \mathbf{Aqp}_i \cdot \mathbf{x}_0$，其中 $\mathbf{Aqp}_i = \prod_{j=0}^{i-1} \mathbf{A}_j$。

**$\boldsymbol{\mathcal{B}}$ 矩阵**（`Bqp`，第249-267行）：

考虑输入的时变特性：前 $CH$ 步的输入是优化变量，之后输入保持为 $\mathbf{u}_{CH-1}$。

代码实现了一个巧妙的矩阵变换：

```cpp
// Aqp1: 状态转移累积矩阵
for (int i = 0; i < mpc_N; i++)
    for (int j = 0; j < i + 1; j++)
        Aqp1.block<nx, nx>(i * nx, j * nx) = Eigen::MatrixXd::Identity(nx, nx);
for (int i = 1; i < mpc_N; i++)
    for (int j = 0; j < i; j++)
        for (int k = j + 1; k < (i + 1); k++)
            Aqp1.block<nx, nx>(i * nx, j * nx) = A[k] * Aqp1.block<nx, nx>(i * nx, j * nx);

// Bqp1: 输入到状态增量的映射
for (int i = 0; i < mpc_N; i++)
    Bqp1.block<nx, nu>(i * nx, i * nu) = B[i];

// Bqp11: 将控制输入扩展到整个预测时域
Bqp11.block<nu * ch, nu * ch>(0, 0) = Eigen::MatrixXd::Identity(nu * ch, nu * ch);
for (int i = 0; i < (mpc_N - ch); i++)
    Bqp11.block<nu, nu>(nu * ch + i * nu, nu * (ch - 1)) = Eigen::MatrixXd::Identity(nu, nu);

Bqp = Aqp1 * Bqp1 * Bqp11;
```

这个三层矩阵乘法的作用：
1. `Bqp1`：将第 $i$ 个输入映射到第 $i$ 个状态增量
2. `Bqp11`：将 $CH$ 个优化输入扩展到 $N$ 个预测步的输入（后面的步重复最后一步）
3. `Aqp1`：累积状态转移，得到每个步长上所有历史输入的贡献

---

### 7.4 MPC 代价函数设计

#### 7.4.1 代价函数的一般形式

$$
J(\mathbf{x}_0, \mathbf{U}) = \sum_{i=1}^{N} \|\mathbf{x}_i - \mathbf{x}_{i,ref}\|_{\mathbf{L}}^2 + \sum_{i=0}^{CH-1} \|\mathbf{u}_i - \mathbf{u}_{i,ref}\|_{\mathbf{K}}^2
$$

其中 $\|\mathbf{e}\|_{\mathbf{L}}^2 = \mathbf{e}^T \mathbf{L} \mathbf{e}$ 是加权二范数。

**矩阵形式**：

$$
J = \| \boldsymbol{\mathcal{A}} \mathbf{x}_0 + \boldsymbol{\mathcal{B}} \mathbf{U} - \mathbf{X}_{ref} \|_{\mathcal{L}}^2 + \| \mathbf{U} - \mathbf{U}_{ref} \|_{\mathcal{K}}^2
$$

其中 $\mathcal{L} = \text{blkdiag}(\mathbf{L}_0, \mathbf{L}_1, ..., \mathbf{L}_{N-1})$，$\mathcal{K} = \text{blkdiag}(\mathbf{K}_0, \mathbf{K}_1, ..., \mathbf{K}_{CH-1})$。

展开得：

$$
J = (\boldsymbol{\mathcal{A}} \mathbf{x}_0 + \boldsymbol{\mathcal{B}} \mathbf{U} - \mathbf{X}_{ref})^T \mathcal{L} (\boldsymbol{\mathcal{A}} \mathbf{x}_0 + \boldsymbol{\mathcal{B}} \mathbf{U} - \mathbf{X}_{ref}) + (\mathbf{U} - \mathbf{U}_{ref})^T \mathcal{K} (\mathbf{U} - \mathbf{U}_{ref})
$$

#### 7.4.2 转化为 QP 标准形式

将 $J$ 展开并忽略常数项后，可得 QP 的 Hessian 矩阵和梯度向量：

$$
\mathbf{H} = 2(\boldsymbol{\mathcal{B}}^T \mathcal{L} \boldsymbol{\mathcal{B}} + \alpha \mathcal{K})
$$

$$
\mathbf{c} = 2 \boldsymbol{\mathcal{B}}^T \mathcal{L} (\boldsymbol{\mathcal{A}} \mathbf{x}_0 - \mathbf{X}_{ref}) + 2\alpha \mathcal{K} \mathbf{U}_{ref}
$$

在 `mpc.cpp` 第284-285行：

```cpp
H = 2 * (Bqp.transpose() * L * Bqp + alpha * K) +
    1e-10 * Eigen::MatrixXd::Identity(nx * mpc_N, nx * mpc_N);
c = 2 * Bqp.transpose() * L * (Aqp * X_cur - Xd) +
    2 * alpha * K * delta_U;
```

其中：
- `alpha` 是输入代价的缩放因子（$\alpha = 1e-6$）
- 对角加载项 `1e-10 * I` 确保 Hessian 矩阵正定，提高数值稳定性
- `delta_U` 是输入的参考偏移量（来自重力补偿）

#### 7.4.3 权重矩阵的设计

权重矩阵在 `set_weight` 函数中设置（第87-130行）。

**状态权重 $\mathbf{L}$**（12维对角矩阵）：

```cpp
L_diag << 1.0, 1.0, 1.0,      // 欧拉角 (roll, pitch, yaw)
         1e-3, 100.0, 1.0,     // 质心位置 (x, y, z)
         1e-3, 1e-3, 1e-3,    // 角速度
         1, 100.0, 1.0;        // 线速度 (x, y, z)
```

**输入权重 $\mathbf{K}$**（13维对角矩阵）：

```cpp
K_diag << 1.0, 1.0, 1.0,    // 左足力
          1.0, 1, 1.0,       // 左足力矩
          1.0, 1.0, 1.0,     // 右足力
          1.0, 1, 1.0,       // 右足力矩
          1.0;               // 总垂直力
```

> **权重解读**：
> - 对 $p_y$（位置 y, 权重100）和 $v_y$（速度 y, 权重100）的高权重说明：侧向稳定性是最关键的——机器人最容易在侧向失稳。
> - 对角速度的低权重（1e-3）说明：角速度本身的跟踪不是重点，重点是姿态（欧拉角）的跟踪。
> - 对 $p_z$（位置 z, 权重1）和 $v_z$（速度 z, 权重1）的适中权重说明：垂向运动也需要控制，但不如侧向那么关键。

**偏航旋转后的权重自适应**（第116-129行）：

权重矩阵在偏航方向上进行旋转，使侧向权重始终对齐到机器人的前进方向：

```cpp
L.block<3, 3>(i*nx+3, i*nx+3) = R_curz[i] * L.block<3, 3>(i*nx+3, i*nx+3) * R_curz[i].transpose();
```

这个操作保证了：无论机器人朝哪个方向，"侧向"总是对应的侧向方向。例如，如果机器人转了90°，原来在 y 方向的高权重会通过旋转映射到新的侧向方向。

---

### 7.5 摩擦锥约束与线性化

#### 7.5.1 为什么要考虑摩擦约束？

如果机器人施加的足端力超出了地面摩擦所能提供的最大值，脚就会打滑。因此，接触力必须满足摩擦锥约束。

#### 7.5.2 摩擦锥的线性化

理想的摩擦锥约束为：

$$
\sqrt{f_x^2 + f_y^2} \leq \mu f_z, \quad f_z > 0
$$

这是一个二阶锥约束，直接处理在 QP 中计算量较大。实际中将其线性化为**四棱锥近似**：

$$
\begin{cases}
-\mu f_z \leq f_x \leq \mu f_z \\
-\mu f_z \leq f_y \leq \mu f_z
\end{cases}
$$

在 `mpc.cpp` 第294-303行：

```cpp
Asfr111 << -1.0, 0.0, -1.0/sqrt(2.0) * miu,
            1.0, 0.0, -1.0/sqrt(2.0) * miu,
            0.0, -1.0, -1.0/sqrt(2.0) * miu,
            0.0, 1.0, -1.0/sqrt(2.0) * miu;
```

注意代码中的因子是 $1/\sqrt{2} \approx 0.707$ 而不是直觉的 $\mu$。这是因为线性化处理将 $\mu$ 乘以 $1/\sqrt{2}$：在四棱锥的顶点处，对角线方向（$f_x = f_y$）的允许力幅为 $\mu f_z / \sqrt{2}$，与圆形锥的半径一致。

这4行构成了摩擦锥约束矩阵 $\mathbf{A}_{fr}^{111}$。每行对应一个不等式：
- 第1行：$f_x \leq f_z/\sqrt{2} \cdot \mu$ → $-f_x - \mu/\sqrt{2} \cdot f_z \leq 0$
- 第2行：$\mu/\sqrt{2} \cdot f_z - f_x \leq 0$ → $f_x - \mu/\sqrt{2} \cdot f_z \leq 0$
- 第3行：$-f_y - \mu/\sqrt{2} \cdot f_z \leq 0$
- 第4行：$f_y - \mu/\sqrt{2} \cdot f_z \leq 0$

然后将世界系下的力约束转换到足端坐标系（摩擦锥在足端坐标系中定义）：

```cpp
Asfr11 = Asfr111 * R_w2f;  // R_w2f = R_f2w^T
```

#### 7.5.3 地面接触力矩约束

除了力，足端接触力矩也受限制——如果力矩过大，足端可能绕着边缘翻转。

##### x-y 方向力矩约束

力矩约束确保足端压力中心（Center of Pressure, CoP）落在足底支撑多边形内。对于矩形脚底（尺寸 $l_x \times l_y$），CoP 约束为：

$$
-\frac{l_x}{2} \leq \frac{\tau_y}{f_z} \leq \frac{l_x}{2}, \quad -\frac{l_y}{2} \leq \frac{\tau_x}{f_z} \leq \frac{l_y}{2}
$$

这等价于线性不等式 $\tau_y \pm \frac{l_x}{2} f_z \leq 0$ 和 $\tau_x \pm \frac{l_y}{2} f_z \leq 0$。

在代码第306-347行中，`delta_foot` 定义了足底的几何尺寸：

```cpp
delta_foot[0] = 0.073;   // +x 方向
delta_foot[1] = 0.125;   // -x 方向
delta_foot[2] = 0.025;   // +y 方向
delta_foot[3] = 0.025;   // -y 方向
```

这些值定义了足端支撑多边形——脚掌前后长度约 $0.073 + 0.125 = 0.198\text{m}$，宽度约 $0.025 + 0.025 = 0.05\text{m}$。

##### z 方向力矩约束

z 方向的纯力矩（$\tau_z$）也受摩擦限制。由于脚底与地面接触，绕 z 轴的最大摩擦力矩正比于垂直力：

$$
|\tau_z| \leq \mu \cdot \sqrt{l_x^2 + l_y^2} \cdot f_z
$$

在代码第362-370行中实现：

```cpp
Astz_r[i].block<1, 3>(0, 0) = -sqrt(p[i](0)^2 + p[i](1)^2 + p[i](2)^2) * miu *
                               Eigen::Matrix<double, 1, 3>(0.0, 0.0, 1.0) * R_w2f;
Astz_r[i].block<1, 3>(0, 3) = Eigen::Matrix<double, 1, 3>(0.0, 0.0, 1.0) * R_w2f;
```

---

### 7.6 QP 问题组装与 qpOASES 求解

#### 7.6.1 qpOASES 求解器

OpenLoong 使用 [qpOASES](https://github.com/coin-or/qpOASES) 作为 QP 求解器。qpOASES 是一个专门针对 MPC 应用设计的在线主动集 QP 求解器，它利用热启动（Warm Start）技术——用上一次的求解结果作为下一次的初始解，大幅提高求解速度。

在 `mpc.h` 第96-109行中定义了 qpOASES 的接口变量：

```cpp
qpOASES::QProblem QP;                                    // QP 问题实例
qpOASES::real_t qp_H[nu*ch * nu*ch];                    // Hessian 矩阵 (39×39)
qpOASES::real_t qp_As[nc*ch * nu*ch];                   // 约束矩阵 (228×39)
qpOASES::real_t qp_c[nu*ch];                            // 梯度向量 (39)
qpOASES::real_t qp_lbA[nc*ch], qp_ubA[nc*ch];           // 不等式约束边界
qpOASES::real_t qp_lu[nu*ch], qp_uu[nu*ch];             // 输入上下界
qpOASES::int_t nWSR=100;                                // 最大迭代次数
qpOASES::real_t cpu_time=0.1;                           // 最大 CPU 时间
```

#### 7.6.2 QP 问题结构

OpenLoong 的 MPC 构成以下 QP 问题：

$$
\min_{\mathbf{U}} \quad \frac{1}{2} \mathbf{U}^T \mathbf{H} \mathbf{U} + \mathbf{c}^T \mathbf{U}
$$

s.t.

$$
\mathbf{U}_{min} \leq \mathbf{U} \leq \mathbf{U}_{max} \quad \text{(输入上下界)}
$$

$$
\mathbf{A}_s \mathbf{U} \leq \mathbf{b}_s \quad \text{(线性化约束)}
$$

其中 $\mathbf{A}_s$ 是包含摩擦锥约束、力矩约束的总约束矩阵，$n_c$ 是约束的总维度。

从 `mpc.h` 中可以看到约束的维度计算：

```cpp
const uint16_t ncfr_single = 4;          // 单腿摩擦锥约束数
const uint16_t ncfr = ncfr_single * 2;   // 双腿
const uint16_t ncstxya = 1;              // 单边界力矩约束维度
const uint16_t ncstxy_single = ncstxya * 4;  // 单腿 4 个边界
const uint16_t ncstxy = ncstxy_single * 2;   // 双腿
const uint16_t ncstza = 2;               // z 方向力矩约束维度
const uint16_t ncstz_single = ncstza * 4; // 单腿 4 个边界（正负 x/y）
const uint16_t ncstz = ncstz_single * 2;  // 双腿
const uint16_t nc = ncfr + ncstxy + ncstz; // 总约束数 = 8 + 8 + 16 = 32
```

控制时域 $CH = 3$，所以总约束数为 $nc \cdot CH = 32 \times 3 = 96$。

#### 7.6.3 约束的组装

第443-464行，根据当前和预测的腿状态（单/双支撑），将对应的约束激活。

关键点：**只有处于支撑相的腿才施加力/力矩约束**。摆动腿的力被钳位到零：

```cpp
// 左腿支撑（LSt）
u_low(i * nu + j) = min[j];      // 左腿有完整的力范围
u_low(i * nu + j + nu/2) = 0.0;  // 右腿（摆动腿）力为零
u_up(i * nu + j) = max[j];
u_up(i * nu + j + nu/2) = 0.0;
```

以及在约束矩阵 $A_s$ 中，通过设置 ubA 的对应行为零来激活不等式约束：

```cpp
if (legState[i] == DataBus::LSt) {
    ubA.block<ncfr_single, 1>(ncfr * i, 0).setZero();        // 左腿摩擦锥有效
    ubA.block<ncfr_single, 1>(ncfr * i + ncfr_single, 0)     // 右腿约束被松弛
        = 1e7 * 相应行;   // 等效于无约束
}
```

#### 7.6.4 求解与结果提取

第435-491行执行 QP 求解：

```cpp
res = QP.init(qp_H, qp_c, qp_As, qp_lu, qp_uu, qp_lbA, qp_ubA, nWSR, &cpu_time, xOpt_iniGuess);

if (res != qpOASES::SUCCESSFUL_RETURN) {
    printf("failed!!!!!!!!!!!!!\n");
}

QP.getPrimalSolution(xOpt);
if (qp_Status == 0) {
    for (int i = 0; i < nu * ch; i++)
        Ufe(i) = xOpt[i];  // 提取最优解
}
```

`Ufe` 包含了整个控制时域的最优输入序列。我们只需要第一个控制输入 $\mathbf{u}_0$ 来驱动机器人。

#### 7.6.5 预测状态计算

第493-504行计算 MPC 预测的下一个状态：

```cpp
dX_cal = Ac[0] * X_cur + Bc[0] * Ufe.block<nu, 1>(0, 0);
Eigen::Matrix<double, nx, 1> delta_X;
for (int i = 0; i < 3; i++) {
    delta_X(i) = 0.5 * dX_cal(i + 6) * dt * dt;     // 姿态的二阶泰勒展开
    delta_X(i + 3) = 0.5 * dX_cal(i + 9) * dt * dt;  // 位置的二阶泰勒展开
    delta_X(i + 6) = dX_cal(i + 6) * dt;              // 角速度一阶展开
    delta_X(i + 9) = dX_cal(i + 9) * dt;              // 线速度一阶展开
}
X_cal = (Aqp * X_cur + Bqp * Ufe).block<nx, 1>(nx * 0, 0) + delta_X;
```

这里 `X_cal` 是经过 MPC 优化后的下一个系统状态预测值。注意，这里同时使用了一阶（$\dot{\mathbf{x}} dt$）和二阶（$0.5\ddot{\mathbf{x}} dt^2$）项，提高了预测精度。

---

### 7.7 200Hz 控制律：多速率协调

#### 7.7.1 为什么是 200Hz？

在 `walk_mpc_wbc_joystick.cpp` 中可以看到 MPC 以 200Hz（每5个1kHz主循环步执行一次）运行：

```cpp
const double dt = 0.001;       // 1kHz 主循环
const double dt_200Hz = 0.005; // 200Hz MPC

// ...

MPC_count = MPC_count + 1;
if (MPC_count > (dt_200Hz / dt - 1)) {  // 每5步执行一次
    MPC_solv.dataBusRead(RobotState);
    MPC_solv.cal();
    MPC_count = 0;
}
```

200Hz 的频率选择是基于以下权衡：

| 因素 | 高频率 | 低频率 |
|------|--------|--------|
| 模型精度 | 离散化误差小 | 离散化误差大 |
| 扰动响应 | 快速 | 延迟大 |
| 计算开销 | 高（可能超时） | 低 |
| QP 求解质量 | 迭代次数受限 | 可充分求解 |

200Hz（5ms）是双足控制领域的"甜蜜点"——它足够快以捕捉行走动态（摆动相通常400ms，一个控制周期仅占1.25%），又足够慢以让 QP 求解器有充足时间完成迭代。

#### 7.7.2 多速率协调架构

该架构涉及三个时间尺度：

```
1kHz (1ms)  ───┬─── 主控循环
                │     ├─ 传感器读取
                │     ├─ 状态估计
                │     ├─ 运动学/动力学
                │     ├─ 步态调度
                │     ├─ 落脚点规划
                │     ├─ WBC 整体系数控制
                │     └─ PVT 关节控制
                │
200Hz (5ms)  ──┼─── MPC 优化
                │     ├─ 读取状态
                │     ├─ 构建 QP 问题
                │     ├─ 求解（qpOASES）
                │     └─ 输出足端力指令
                │
25-50Hz ───────┴─── 用户指令（摇杆输入）
                      ├─ 期望速度/转向
                      └─ 状态切换
```

MPC 的输出（足端力和力矩）被传递给 WBC 作为前馈力项（`Fr_ff`），WBC 再以 1kHz 运行，将这些力指令分配到各关节力矩。

#### 7.7.3 热启动策略

MPC 使用 qpOASES 的热启动功能（`xOpt_iniGuess`，第473行）：

```cpp
copy_Eigen_to_real_t(xOpt_iniGuess, Guess_value, nu * ch, 1);
```

`Guess_value` 根据当前腿状态设置了初始猜测——例如在双支撑时，将垂直力近似平分到两条腿（各 $0.5mg$）：

```cpp
if (legState[i] == DataBus::DSt) {
    Guess_value(i * nu + 2) = -0.5 * m * g;   // fz_L
    Guess_value(i * nu + 8) = -0.5 * m * g;   // fz_R
}
```

最优初始化使 qpOASES 的主动集求解器通常能在 10-50 次迭代内收敛，远小于设定的最大迭代次数（`nWSR = 1000000`）。

---

### 7.8 完整代码逐行解析（mpc.cpp）

#### 7.8.1 构造函数（第11-85行）

```cpp
MPC::MPC(double dtIn) : QP(nu * ch, nc * ch)
```

- 初始化 `QP` 对象，指定 QP 问题的变量数（$nu \times ch = 13 \times 3 = 39$）和约束数（$nc \times ch = 32 \times 3 = 96$）
- 设置机器人参数：$m = 77.35\text{kg}$，$g = -9.8\text{m/s}^2$，$\mu = 0.5$
- 设置足底几何参数：`delta_foot[4]`，定义 CoP 约束边界
- 设置输入上下界：
  - 水平力：$\pm 1000\text{N}$
  - 垂直力：$[0, -3mg]$（即 $[0, 2276]\text{N}$，注意 z 轴向下为正？实际是 $f_z$ 向上为正，故 $max[2] = -3mg$ 实际上是很大的负力？让我们检查：$g = -9.8$，$m = 77.35$，$-3 \times 77.35 \times (-9.8) = 2274$，正值。等等，代码中 $max[2] = -3.0 * m * g = -3.0 * 77.35 * (-9.8) = 2274$，这是允许的最大垂直反力（正值向上））
  - 力矩：$\pm 20\text{Nm}$（x），$\pm 80\text{Nm}$（y），$\pm 100\text{Nm}$（z）
- 将 qpOASES 的打印级别设为 `PL_LOW`（只输出关键信息）

#### 7.8.2 set_weight 函数（第87-130行）

此函数设置代价函数的权重矩阵，并执行偏航自适应旋转。

```
关键操作：
1. 将 12 维 L_diag 和 13 维 K_diag 扩展为完整的 N 步对角矩阵
2. 对位置权重 (3:6)、角速度权重 (6:9)、线速度权重 (9:12) 分别旋转
3. 对每个足端的力权重 (0:3, 6:9) 和力矩权重 (3:6, 9:12) 分别旋转
```

第118-121行是一处非常精细的设计：

```cpp
L.block<3, 3>(i*nx+3, i*nx+3) = R_curz[i] * L.block<3, 3>(i*nx+3, i*nx+3) * R_curz[i].transpose();
```

这实现了权重矩阵的**相似变换**——在世界系中，权重的方向始终跟随机器人的偏航角对齐。例如，如果机器人向东走，$p_y$ 是南北方向（侧向）；如果机器人向北走，$p_y$ 是东西方向（侧向）。由于侧向权重（100）远大于前进权重（1e-3），这个旋转确保**高权重始终落在侧向**，无论机器人朝向如何。

#### 7.8.3 dataBusRead 函数（第132-216行）

这个函数从 DataBus 读取当前状态、期望轨迹和足端位置信息。

**状态读取**（第135-138行）：

```cpp
X_cur.block<3, 1>(0, 0) = Data.base_rpy;              // 当前姿态（欧拉角）
X_cur.block<3, 1>(3, 0) = Data.q.block<3, 1>(0, 0);   // 当前质心位置
X_cur.block<3, 1>(6, 0) = Data.dq.block<3, 1>(3, 0);  // 当前角速度
X_cur.block<3, 1>(9, 0) = Data.dq.block<3, 1>(0, 0);  // 当前线速度
```

注意 `dq` 的前3维是线速度，后3维是角速度（`data_bus.h` 第224-225行）：

```cpp
dq.block<3, 1>(0, 0) = vCoM_W;        // 线速度 (0:3)
dq.block<3, 1>(3, 0) << base_omega_W; // 角速度 (3:6)
```

**期望轨迹读取**（第139-174行）：

当 MPC 启用时（EN=true），期望轨迹从摇杆解释器读取：

```cpp
// 将期望轨迹队列向前移位
for (int i = 0; i < (mpc_N - 1); i++)
    Xd.block<nx, 1>(nx * i, 0) = Xd.block<nx, 1>(nx * (i + 1), 0);

// 将最新的期望值填入末尾
for (int j = 0; j < 3; j++)
    Xd(nx * (mpc_N - 1) + j) = Data.js_eul_des(j);      // 期望姿态
for (int j = 0; j < 3; j++)
    Xd(nx * (mpc_N - 1) + 3 + j) = Data.js_pos_des(j); // 期望位置
for (int j = 0; j < 3; j++)
    Xd(nx * (mpc_N - 1) + 6 + j) = Data.js_omega_des(j); // 期望角速度
for (int j = 0; j < 3; j++)
    Xd(nx * (mpc_N - 1) + 9 + j) = Data.js_vel_des(j);  // 期望速度
```

这里实现了一个滑动窗口：每步将期望轨迹前移一个步长，在末尾填入最新的期望值。这种设计让 MPC 能够"预见"期望轨迹的变化，提前作出反应。

**足端位置读取**（第181-188行）：

```cpp
pCoM = X_cur.block<3, 1>(3, 0);                     // 质心当前位置
pe.block<3, 1>(0, 0) = Data.fe_l_pos_W;             // 左足位置
pe.block<3, 1>(3, 0) = Data.fe_r_pos_W;             // 右足位置

pf2com.block<3, 1>(0, 0) = pe.block<3, 1>(0, 0) - pCoM;  // 左足→质心的向量
pf2com.block<3, 1>(3, 0) = pe.block<3, 1>(3, 0) - pCoM;  // 右足→质心的向量
```

$pf2com$（$\mathbf{r}_i$）是足端到质心的位置向量，在角动量动力学中用于计算力矩 $\mathbf{r}_i \times \mathbf{f}_i$。

**腿状态预测**（第193-205行）：

```cpp
for (int i = 0; i < mpc_N; i++) {
    double aa = i * dt / 0.4;    // 从当前时刻开始的相位
    double phip = Data.phi + aa; // 预测的未来相位
    if (phip > 1)
        legState[i] = legStateNext;  // 超过相位的步进入下一状态
    else
        legState[i] = legStateCur;
}
```

这个循环使用当前相位 $\phi$ 和步态周期（0.4s），预测未来 $N$ 步内每条腿的支撑/摆动状态。这是 MPC 正确施加时变约束的关键——它知道在未来哪个时刻是哪条腿支撑，从而正确设置输入边界条件。

#### 7.8.4 cal 函数：核心计算（第218-516行）

这是 MPC 的核心函数，我们在前面各节中已经逐块分析过。下面是完整的执行流：

```
cal()
  │
  ├─ 1. 构建预测矩阵
  │     ├─ 离散化 A[i] = I + dt * Ac[i]
  │     ├─ 离散化 B[i] = dt * Bc[i]
  │     ├─ 构建 Aqp (状态转移累积)
  │     ├─ 构建 Bqp (输入到状态的映射)
  │     └─ 构建 Cqp (重力补偿)
  │
  ├─ 2. 组装 QP 代价函数
  │     ├─ H = 2*(Bqp^T * L * Bqp + alpha * K) + 正则化
  │     └─ c = 2*Bqp^T * L * (Aqp*X_cur - Xd) + 2*alpha*K*delta_U
  │
  ├─ 3. 组装 QP 约束
  │     ├─ 摩擦锥约束 (Asfr)
  │     ├─ x-y 方向力矩约束 (Astxy)
  │     └─ z 方向力矩约束 (Astz)
  │
  ├─ 4. 设置输入边界
  │     └─ 根据 legState[i] 设置 u_low/u_up
  │
  ├─ 5. 调用 qpOASES 求解
  │     ├─ QP.init(H, c, As, lu, uu, lbA, ubA, ...)
  │     └─ QP.getPrimalSolution(xOpt)
  │
  ├─ 6. 提取最优解到 Ufe
  │
  ├─ 7. 计算预测状态 X_cal
  │
  └─ 8. 重置 QP 对象 (QP.reset())
```

#### 7.8.5 dataBusWrite 函数（第518-546行）

将 MPC 的计算结果写回 DataBus，供 WBC 使用：

```cpp
Data.Xd = Xd;                              // 期望轨迹
Data.X_cur = X_cur;                        // 当前状态
Data.fe_react_tau_cmd = Ufe;               // 最优足端力/力矩（整个控制时域）
Data.X_cal = X_cal;                        // 预测的下一个状态
Data.dX_cal = dX_cal;                      // 状态变化率
Data.qp_nWSR_MPC = nWSR;                   // QP 迭代次数
Data.qp_cpuTime_MPC = cpu_time;            // QP 求解时间
Data.qpStatus_MPC = qp_Status;             // QP 求解状态

Data.Fr_ff = Ufe.block<12, 1>(0, 0);       // 第一个控制步的接触力（前馈）
```

最关键的是 `Fr_ff`——它提取了第一个控制周期（$i=0$）的足端力 $\mathbf{f}_L, \boldsymbol{\tau}_L, \mathbf{f}_R, \boldsymbol{\tau}_R$，作为前馈力项传递给 WBC 求解器。

此外还生成了 WBC 的期望加速度和期望速度：

```cpp
Data.des_ddq.block<2, 1>(0, 0) << dX_cal(9), dX_cal(10);  // x, y 加速度
Data.des_ddq(5) = k * (Xd(6 + 2) - Data.dq(5));             // z 角加速度（偏航）

Data.des_dq.block<3, 1>(0, 0) << Xd(9 + 0), Xd(9 + 1), Xd(9 + 2);  // 线速度期望
Data.des_dq(5) = Xd(6 + 2);                                               // 偏航角速度期望

Data.base_rpy_des << 0.005, 0.00, Xd(2);  // 基座期望姿态（roll 少量偏移）
Data.base_pos_des << Xd(3 + 0), Xd(3 + 1), Xd(3 + 2);  // 基座期望位置
```

---

### 7.9 权重参数对运动的影响与调优策略

#### 7.9.1 参数影响分析

**状态权重 $L$ 的影响**：

| 权重参数 | 增大效果 | 减小效果 |
|----------|----------|----------|
| 姿态 ($L_{0:2}$) | 躯干更加刚硬，抗扰动能力强，但能量消耗增大 | 躯干柔软，舒适性提高，但容易倾斜过大 |
| 位置-y ($L_4$) | 侧向偏差小，行走更直 | 侧向偏差大，可能左右晃 |
| 位置-z ($L_5$) | 质心高度更稳定 | 质心高度可能波动 |
| 角速度 ($L_{6:8}$) | 转动更平滑 | 转动可能有冲击 |
| 速度-y ($L_{10}$) | 侧向速度抑制强 | 侧向运动更自由 |

**输入权重 $K$ 的影响**：

| 权重参数 | 增大效果 | 减小效果 |
|----------|----------|----------|
| 力权重 ($K_{0:2}, K_{6:8}$) | 足端力更小，运动更柔和 | 足端力更大，跟踪精度高 |
| 力矩权重 ($K_{3:5}, K_{9:11}$) | 足端力矩受抑，更接近点接触 | 足端力矩自由，CoP 范围更大 |

**缩放因子 $\alpha$ 的影响**：

$\alpha$ 平衡状态跟踪和输入代价。增大 $\alpha$ 会使 MPC 更"节俭"——用更小的力完成任务，但跟踪精度下降。减小 $\alpha$ 会使 MPC 更"激进"——大力精确跟踪，但可能造成振荡。

#### 7.9.2 调优策略

**实践建议的调优顺序**：

1. **先调侧向稳定性**：增大 $L_4$（位置-y）和 $L_{10}$（速度-y），这是机器人最容易失稳的方向
2. **再调节姿态刚度**：调整 $L_{0:2}$ 使躯干姿态偏差在允许范围内（通常 $\pm 5^\circ$）
3. **然后调节输入水平**：调整 $\alpha$ 使足端力不会过大（不超过体重的2倍）
4. **最后微调**：观察实际行走效果，微调各权重

**常用的参数整定方法**：

- **从保守开始**：用小权重和大的 $\alpha$ 起步，确保机器人不会剧烈动作
- **逐步加大**：逐步增加状态权重，观察跟踪精度的提升
- **侧向优先**：在 OpenLoong 的参数中，$p_y$ 和 $v_y$ 的权重远大于其他方向——这完全正确，因为双足机器人的侧向稳定性是最薄弱的。

#### 7.9.3 一个具体的调优案例

假设机器人行走时出现以下问题：

**问题**：机器人行走时躯干在前进方向俯仰（pitch）幅度过大。

**分析**：说明对 $\theta$（pitch 角）的跟踪权重不够，或者对 $v_x$ 的速度跟踪权重不匹配。

**解决方案**：
- 增加 $L_1$（pitch 角权重）：从 1 增加到 10 或 100
- 同时稍微降低 $\alpha$：允许更大的足端力来维持姿态

**问题**：机器人行走时侧向（y方向）晃动严重。

**分析**：侧向稳定性不足。

**解决方案**：
- 增加 $L_4$（$p_y$ 位置权重）：从 100 增加到 500
- 增加 $L_{10}$（$v_y$ 速度权重）：从 100 增加到 200
- 确保 $kp\_vy$ 在落脚点规划中也相应增加

---

## 总结

第6章和第7章共同构成了 OpenLoong 双足步行控制系统的"决策-执行"闭环：

- **步态调度器**回答"什么时候迈哪条腿"——通过相位 $\phi$ 和触地检测
- **落脚点规划器**回答"腿往哪里迈"——基于 Raibert 启发式生成期望落地位置
- **摆动轨迹生成器**回答"腿怎么迈过去"——摆线和贝塞尔曲线提供平滑轨迹
- **MPC**回答"用多大力来平衡"——基于单刚体模型滚动优化，输出最优足端反力
- **WBC**将这些力分配到每个关节——整个系统在 1kHz/200Hz 的多速率框架中协调运行

理解这一整套流水线，你就掌握了现代人形机器人运动控制的核心技术。

---

> **延伸阅读**：
> - Raibert, M. H. (1986). *Legged Robots That Balance*. MIT Press. —— Raibert 落脚点启发式的原始出处
> - Kuindersma, S., et al. (2016). "Optimization-based locomotion planning, estimation, and control design for the Atlas humanoid robot." *Autonomous Robots*, 40(3), 429-455. —— MPC 在 Atlas 机器人上的经典应用
> - Di Carlo, J., et al. (2018). "Dynamic locomotion in the MIT Cheetah 3 through convex model-predictive control." *IEEE/RSJ IROS 2018*. —— SRBM + MPC 的现代经典


---

# 第8章：全身控制（WBC）+ 第9章：状态估计实现

---

# 第8章 全身控制（Whole-Body Control, WBC）

## 8.1 为什么需要 WBC？

### 8.1.1 从简单 PID 控制到全身协调的演进

想象你在控制一个双足机器人。最简单的做法是什么？对每个关节独立地施加一个 PID 控制器，让关节跟踪期望的位置和速度。这种方法在固定基座机械臂上工作得很好——因为基座被牢牢固定在地上，每个关节的动力学相对独立。

但对于一个**浮动基座**的双足机器人来说，情况完全不同：

- 基座是浮动的，没有固连到惯性系
- 腿部与地面之间存在复杂的**接触约束**
- 身体各部分的运动通过动力学**强耦合**在一起
- 手臂摆动会影响躯干姿态，躯干姿态变动又会影响腿部的支撑

如果你对每个关节独立 PID，会发生什么？打个比方：你试图同时控制机器人的每个关节去跟踪各自的目标，但这些目标之间可能互相冲突。比如，你让左腿关节跟踪一个位置，同时又让躯干跟踪一个姿态——如果地面接触已经限死了左腿的位置，躯干的姿态误差只能靠违反接触约束来补偿，结果就是机器人摔倒。

这就是为什么双足机器人控制不能简单"分关节"处理，而需要**全身控制（WBC）**。

### 8.1.2 WBC 解决的核心问题

WBC 的核心思想是：**把机器人看作一个受约束的完整动力学系统，在满足所有约束的前提下，同时实现多个控制任务**。它要解决三个核心问题：

**（1）多任务协调**

机器人需要同时做很多事情：保持平衡、跟踪质心轨迹、摆动腿跟随期望轨迹、手臂摆幅、头部随动……这些任务共享同一组关节，它们之间可能存在冲突。WBC 通过**优先级机制**来化解冲突——高优先级任务（如平衡）优先满足，低优先级任务在剩余的自由度空间中优化。

**（2）接触力优化**

双足机器人与环境的唯一交互就是足底接触力。这些力既要支撑机器人重量、提供运动所需的加速度，又要满足摩擦锥约束（不打滑）。WBC 将接触力作为优化变量之一，在满足动力学和物理约束的前提下，找到最优的力分配方案。

**（3）动力学一致性**

WBC 的求解结果必须满足机器人的完整动力学方程：

$$M(q)\ddot{q} + h(q,\dot{q}) = S^T \tau + J_c(q)^T F_r$$

其中 $M$ 是惯性矩阵，$h$ 包含科氏力和重力，$S$ 是驱动选择矩阵，$J_c$ 是接触雅可比，$F_r$ 是接触力。这个方程保证了求出的关节加速度 $\ddot{q}$ 和接触力 $F_r$ 在物理上是可实现的。

---

## 8.2 任务空间与关节空间

### 8.2.1 任务定义：6D 空间

在 WBC 中，一个"任务"是指在某个特定空间中的运动要求。任务空间通常是 6 维的：3 个位置自由度 + 3 个姿态自由度。

例如：
- **基座任务**：控制躯干在世界系中的位置 $(x,y,z)$ 和姿态 $(roll,pitch,yaw)$
- **摆动腿任务**：控制摆动足足端的位置和姿态
- **手部任务**：控制手部的位置和姿态

有些任务可能是部分维度的，例如只控制高度 $P_z$（1维），或只控制水平位置 $P_x,P_y$（2维）。

### 8.2.2 任务雅可比 $J_{task}$

任务空间与关节空间之间的桥梁是**任务雅可比矩阵**。关节速度 $\dot{q} \in \mathbb{R}^{n}$（$n$ 为广义坐标维度）映射到任务速度 $\dot{x} \in \mathbb{R}^{m}$（$m$ 为任务维度）：

$$\dot{x} = J_{task}(q) \dot{q}$$

其中 $J_{task} \in \mathbb{R}^{m \times n}$ 是任务雅可比矩阵。

在 Openloong 的代码中，这个映射通过 Pinocchio 动力学库自动计算。例如，基座雅可比 `J_base` 将关节速度映射到浮动基座在世界系中的 6D 速度；足端雅可比 `J_l`（左腿）和 `J_r`（右腿）将关节速度映射到足端的 6D 空间速度。

### 8.2.3 任务加速度公式

对任务速度公式求导，得到任务加速度：

$$\ddot{x} = J_{task}(q)\ddot{q} + \dot{J}_{task}(q,\dot{q})\dot{q}$$

这个公式是 WBC 中所有任务计算的基础。它将关节空间中的加速度 $\ddot{q}$ 映射到任务空间中的加速度 $\ddot{x}$，同时考虑了任务雅可比的时间导数项 $\dot{J}_{task}\dot{q}$（即"科氏加速度"项）。

在优先级任务求解中，我们通常设置一个期望的任务加速度 $\ddot{x}_{des}$，然后反解所需的关节加速度 $\ddot{q}$：

$$\ddot{x}_{des} = J_{task}\ddot{q}_{des} + \dot{J}_{task}\dot{q}$$

代入 PD 反馈项：$\ddot{x}_{des} = \ddot{x}_{ref} + K_p(x_{des} - x) + K_d(\dot{x}_{des} - \dot{x})$，得到：

$$J_{task}\ddot{q}_{des} = \ddot{x}_{ref} + K_p e_x + K_d \dot{e}_x - \dot{J}_{task}\dot{q}$$

这正是 `priority_tasks.cpp` 中 `computeAll()` 函数第 78 行所实现的计算：

```cpp
Eigen::VectorXd ddxcmd = taskLib[curId].ddxDes + taskLib[curId].kp * taskLib[curId].errX + taskLib[curId].kd * taskLib[curId].derrX;
taskLib[curId].ddq = des_ddq + dyn_pseudoInv(taskLib[curId].Jpre, dyn_M_inv, true) * (ddxcmd - taskLib[curId].dJ * dq);
```

---

## 8.3 分层优先级控制的基本思想

### 8.3.1 直觉比喻：任务优先级就像"先后顺序"

想象你在叠放物品：最紧急重要的是氧气面罩（优先级最高），其次是救生衣，最后才是行李。高优先级物品先放好，低优先级物品只能在不影响高优先级物品的前提下摆放。

WBC 的优先级控制与此完全类似：

- **最高优先级任务**（如接触约束）：必须严格满足，不容商量
- **中间优先级任务**（如躯干跟踪）：在满足高优先级任务的前提下尽量满足
- **最低优先级任务**（如手臂摆动）：在满足所有高优先级任务后，利用"剩余的自由度"来优化

### 8.3.2 数学形式化

从数学上看，分层优先级控制可以用递推的方式描述。

设我们有两个任务，优先级从高到低：

**任务 1（高优先级）**：找到 $\ddot{q}_1$ 使得：
$$J_1 \ddot{q} = \ddot{x}_{1,des}$$

这个方程的解空间可以表示为：
$$\ddot{q} = J_1^+ \ddot{x}_{1,des} + (I - J_1^+ J_1) y$$

其中 $y$ 是任意向量，$J_1^+$ 是 $J_1$ 的伪逆。$(I - J_1^+ J_1)y$ 是解在 $J_1$ 零空间中的分量——它不影响任务 1 的满足程度。

**任务 2（低优先级）**：在任务 1 的零空间中优化：
$$\ddot{q}_2 = \ddot{q}_1 + N_1 J_2^+ (\ddot{x}_{2,des} - J_2 \ddot{q}_1)$$

其中 $N_1 = I - J_1^+ J_1$ 是任务 1 的零空间投影矩阵。

这个公式的意思是：先取任务 1 的解 $\ddot{q}_1$，然后加上**任务 2 在任务 1 零空间中的修正**。这样修正后，任务 2 得到部分满足，同时任务 1 的满足程度不受影响（因为修正量在 $J_1$ 的零空间中）。

---

## 8.4 零空间投影法——数学原理

### 8.4.1 投影矩阵基础

先从线性代数中投影的概念开始。给定一个矩阵 $J \in \mathbb{R}^{m \times n}$，考虑线性方程 $Jx = b$。

- **值域（Range）**：$Range(J) = \{Jx \mid x \in \mathbb{R}^n\}$，即所有可能的输出
- **零空间（Null Space）**：$Null(J) = \{x \mid Jx = 0\}$，即所有被映射到零的输入

### 8.4.2 投影矩阵 $N = I - J^+J$

定义伪逆 $J^+$ 满足 $JJ^+J = J$ 和 $J^+JJ^+ = J^+$。那么：

$$N = I - J^+J$$

$N$ 称为**零空间投影矩阵**，它具有以下关键性质：

**性质 1：幂等性** $N^2 = N$

证明：$N^2 = (I-J^+J)(I-J^+J) = I - 2J^+J + J^+JJ^+J = I - 2J^+J + J^+J = I - J^+J = N$

**性质 2：零空间投影** $JN = 0$

证明：$JN = J(I-J^+J) = J - JJ^+J = J - J = 0$

对任意向量 $y$，$Ny$ 位于 $J$ 的零空间中，即 $J(Ny) = 0$。

**性质 3：互补性** $I - N = J^+J$ 是 $Range(J^+)$ 的投影（值域投影）

这意味着任何向量 $x$ 可以分解为两个正交分量：
$$x = (J^+J)x + (I-J^+J)x$$
前一个分量位于 $J$ 的值域中，后一个位于 $J$ 的零空间中。

### 8.4.3 完整数学推导：从任务 1 到任务 N 的递推

现在我们来推导多任务场景下的完整解。

**第一步：任务 1（最高优先级）**

方程：$J_1 \ddot{q} = \ddot{x}_{1,des}$

解的通解形式为：
$$\ddot{q}_1 = J_1^+ \ddot{x}_{1,des} + N_1 z_1$$

其中 $N_1 = I - J_1^+ J_1$，$z_1$ 是任意向量。$z_1$ 的自由度就是任务 1 的零空间维度。

**第二步：任务 2（第二优先级）**

我们希望找到 $\ddot{q}_2$，使得：
1. $J_1\ddot{q}_2 = \ddot{x}_{1,des}$（任务 1 仍然满足）
2. $J_2 \ddot{q}_2$ 尽可能接近 $\ddot{x}_{2,des}$（在任务 1 零空间中优化）

条件 1 意味着 $\ddot{q}_2 = \ddot{q}_1 + N_1 \delta$，其中 $\delta$ 是任意修正量。

代入条件 2：$J_2 (\ddot{q}_1 + N_1 \delta) = \ddot{x}_{2,des}$

整理得：$(J_2 N_1) \delta = \ddot{x}_{2,des} - J_2 \ddot{q}_1$

这个方程的解为：$\delta = (J_2 N_1)^+ (\ddot{x}_{2,des} - J_2 \ddot{q}_1)$

所以：
$$\ddot{q}_2 = \ddot{q}_1 + N_1 (J_2 N_1)^+ (\ddot{x}_{2,des} - J_2 \ddot{q}_1)$$

定义 $J_{2|1} = J_2 N_1$ 为任务 2 在任务 1 零空间中的"投影雅可比"，则上式简化为：
$$\ddot{q}_2 = \ddot{q}_1 + N_1 J_{2|1}^+ (\ddot{x}_{2,des} - J_2 \ddot{q}_1)$$

**第三步：递推到第 k 个任务**

对于第 k 个任务，递归零空间投影矩阵定义为：
$$N_k = N_{k-1} (I - J_{k|k-1}^+ J_{k|k-1})$$

其中 $J_{k|k-1} = J_k N_{k-1}$ 是第 k 个任务雅可比在前 k-1 个任务的联合零空间中的投影。

递归解为：
$$\ddot{q}_k = \ddot{q}_{k-1} + N_{k-1} J_{k|k-1}^+ (\ddot{x}_{k,des} - J_k \ddot{q}_{k-1})$$

这个递归过程持续到所有任务处理完毕。最终 $\ddot{q}_K$ 就是满足所有优先级约束的关节加速度解。

### 8.4.4 加权伪逆的作用

在实际应用中，我们通常使用**加权伪逆**而不是普通伪逆。这是因为：
1. 某些关节的运动范围受限制，给予较小的权重
2. 某些任务需要更精确的跟踪，给予较大的权重

加权右伪逆的定义为：
$$J_W^+ = W^{-1} J^T (J W^{-1} J^T)^{-1}$$

其中 $W$ 是正定权重矩阵。在代码中，`pseudoInv_right_weighted` 函数（`useful_math.cpp` 第 51-60 行）实现了这个计算：

```cpp
Eigen::MatrixXd pseudoInv_right_weighted(const Eigen::MatrixXd &M, const Eigen::DiagonalMatrix<double, -1> &W)
{
    double damp = 0;
    Eigen::MatrixXd Mres;
    Mres = M * W.inverse() * M.transpose();
    Mres.diagonal().array() += damp;
    Mres = W.inverse() * M.transpose() * Mres.completeOrthogonalDecomposition().pseudoInverse();
    return Mres;
}
```

注意这里使用了阻尼最小二乘法（加了 `damp` 项），提高了数值稳定性。

此外，还有一种**动力学加权伪逆**，使用惯性矩阵 $M$ 作为权重矩阵：
$$J_M^+ = M^{-1} J^T (J M^{-1} J^T)^{-1}$$

这保证了求解出的关节加速度在动力学意义上是最优的（最小化动能变化）。这在代码的 `dyn_pseudoInv` 函数中实现（`useful_math.cpp` 第 71-89 行）：

```cpp
Eigen::MatrixXd dyn_pseudoInv(const Eigen::MatrixXd &M, const Eigen::MatrixXd &dyn_M, bool isMinv)
{
    Eigen::MatrixXd Minv;
    if (isMinv)
        Minv = dyn_M;
    else
        Minv = dyn_M.llt().solve(Eigen::MatrixXd::Identity(dyn_M.rows(), dyn_M.cols()));

    Eigen::MatrixXd temp = M * Minv * M.transpose();
    temp.diagonal().array() += damp;
    Eigen::MatrixXd res = Minv * M.transpose() * temp.completeOrthogonalDecomposition().pseudoInverse();
    return res;
}
```

---

## 8.5 行走模式的任务定义与优先级排序

### 8.5.1 行走模式的 5 级任务

在 `wbc_priority.cpp` 的构造函数（第 57-75 行）中，行走模式定义了 7 个任务，但只有 5 个被用于优先级排序：

```cpp
kin_tasks_walk.addTask("static_Contact");     // 任务0
kin_tasks_walk.addTask("Roll_Pitch_Yaw_Pz");  // 任务1
kin_tasks_walk.addTask("RedundantJoints");    // 任务2
kin_tasks_walk.addTask("PxPy");              // 任务3
kin_tasks_walk.addTask("SwingLeg");           // 任务4
kin_tasks_walk.addTask("HandTrackJoints");    // 任务5
kin_tasks_walk.addTask("PosRot");             // 任务6

std::vector<std::string> taskOrder_walk;
taskOrder_walk.emplace_back("static_Contact");    // 最高优先级
taskOrder_walk.emplace_back("PosRot");            // 第2优先级
taskOrder_walk.emplace_back("SwingLeg");          // 第3优先级
taskOrder_walk.emplace_back("RedundantJoints");   // 第4优先级
taskOrder_walk.emplace_back("HandTrackJoints");   // 第5优先级
```

注意 "Roll_Pitch_Yaw_Pz" 和 "PxPy" 没有被加入到排序中——它们实际上是 `PosRot` 的组成部分。

下面详细解释每个任务的目标函数和约束：

#### 任务 1（最高优先级）：static_Contact（接触约束）

- **目标**：保持支撑腿足端固定不动
- **任务维度**：6D（位置 3 + 姿态 3）
- **雅可比**：支撑腿的足端雅可比 $J_c$（代码第 409 行：`kin_tasks_walk.taskLib[id].J = Jc`）
- **期望加速度**：$\ddot{x}_{des} = 0$（足端不动）
- **PD 增益**：$K_p = 0, K_d = 0$（纯运动学约束，不需要反馈）
- **权重**：所有关节权重为 1

为什么这个任务优先级最高？因为接触约束是**硬约束**——如果支撑腿足端不能保持固定，机器人就无法站稳。这个任务必须被精确满足。

#### 任务 2：PosRot（基座位置姿态跟踪）

- **目标**：跟踪期望的基座位置和姿态
- **任务维度**：6D
- **雅可比**：基座雅可比 $J_{base}$
- **误差**：$e_{pos} = base\_pos\_des - q(0:3)$，$e_{rot} = diffRot(base\_rot, desRot)$（代码第 471-481 行）
- **误差限幅**：水平位置误差限制在 ±0.02m 内（防止过大误差导致剧烈动作）
- **PD 增益**：$K_p = 500$（位置/姿态），$K_d = 10$

这是一个中等优先级的任务。行走时，我们希望躯干保持水平稳定，所以 $K_p$ 设置得较高，但优先级低于接触约束。

#### 任务 3：SwingLeg（摆动腿轨迹跟踪）

- **目标**：跟踪摆动腿的足端位置和姿态轨迹
- **任务维度**：6D
- **雅可比**：摆动腿足端雅可比 $J_{sw}$，但剔除了腰部关节（第 511 行：`J.block(0, 22, 6, 3).setZero()`）
- **误差**：$e_{pos} = swing\_fe\_pos\_des\_W - fe\_pos\_sw\_W$（第 500 行）
- **PD 增益**：$K_p = 500$，$K_d = 20$

为什么摆动腿优先级低于 PosRot？因为摆动腿的轨迹误差不会导致机器人立即摔倒，而躯干姿态的误差会直接影响平衡。当然，这是一个设计选择，不是绝对的。

#### 任务 4：RedundantJoints（冗余关节归零）

- **目标**：头部偏航、头部俯仰、腰部俯仰/滚转/偏航归零
- **任务维度**：5D
- **雅可比**：稀疏矩阵，直接选择对应关节（第 425-430 行）
- **PD 增益**：$K_p = 100$，$K_d = 20$

这些"冗余"关节不直接影响行走，但在行走时希望它们回到中位，以减少不必要的能耗。

#### 任务 5：HandTrackJoints（手臂摆动）

- **目标**：手臂关节跟踪与髋关节运动耦合的期望轨迹
- **任务维度**：14D（双臂各 7 个关节）
- **雅可比**：直接选择对应关节（第 531-532 行：`J.block(0, 6, 14, 14) = I_{14}`）
- **目标位置**：与髋部俯仰角耦合（第 518-521 行），实现行走时手臂自然摆动
- **PD 增益**：$K_p = 200$，$K_d = 10$

手臂摆动是优先级最低的任务。这是因为手臂主要用于保持美观和自然性，不影响机器人的基本行走功能。

### 8.5.2 站立模式的任务排序

站立模式的任务更加丰富（第 88-96 行）：

```cpp
taskOrder_stand.emplace_back("static_Contact");
taskOrder_stand.emplace_back("CoMXY_HipRPY");
taskOrder_stand.emplace_back("Pz");
taskOrder_stand.emplace_back("HandTrackJoints");
taskOrder_stand.emplace_back("HeadRP");
```

站立时，接触约束仍然是最高优先级。但第二优先级变成了质心水平位置（CoM XY）+ 髋部姿态（Hip RPY）的组合任务，这是因为站立时维持质心位置和髋部水平更加重要。

---

## 8.6 QP 问题构建

优先级零空间投影法求出的 $\ddot{q}$ 是一个**运动学**层面的解，它只满足了任务空间到关节空间的映射关系，但没有考虑**动力学约束**（力矩限制、接触力限制等）。

因此，WBC 的第二步是将问题构建为一个**二次规划（QP）**，在运动学解的基础上，同时优化关节加速度和接触力，满足所有动力学约束。

### 8.6.1 优化变量

优化变量 $\mathbf{x} \in \mathbb{R}^{18}$：

$$\mathbf{x} = \begin{bmatrix} \Delta \ddot{q}_{base} (6) \\ \Delta F_r (12) \end{bmatrix}$$

- $\Delta \ddot{q}_{base} \in \mathbb{R}^6$：浮动基座 6D 加速度的修正量
- $\Delta F_r \in \mathbb{R}^{12}$：足底接触力的修正量（左右各 6D = 12）

注意：优化变量不是直接的全部关节加速度，而是**基座加速度的修正量** + **接触力的修正量**。关节加速度中使用运动学求解的 $\ddot{q}_{final\_kin}$ 作为基准，QP 只优化基座部分的修正。

$$ddq_{opt} = ddq_{final\_kin} + \begin{bmatrix} \Delta\ddot{q}_{base} \\ 0_{12} \end{bmatrix}$$

这样做的好处是：QP 只需要 18 个变量（而不是 30 个），大大减小了计算量。

### 8.6.2 H 矩阵（代价函数）

代价函数的形式为：
$$\min_{\mathbf{x}} \frac{1}{2} \mathbf{x}^T H \mathbf{x}$$

其中 $H \in \mathbb{R}^{18 \times 18}$ 是对角矩阵（代码第 320-334 行）：

```cpp
Eigen::MatrixXd eigen_qp_H = Eigen::MatrixXd::Zero(QP_nv, QP_nv);
Q2 = Eigen::MatrixXd::Identity(6, 6);
Q1 = Eigen::MatrixXd::Identity(12, 12);

if (motionStateCur == DataBus::Stand) {
    eigen_qp_H.block<6, 6>(0, 0) = Q2 * 2.0 * 1e7;     // Δddq_base 权重
    eigen_qp_H.block<12, 12>(6, 6) = Q1 * 2.0 * 1e1;    // ΔFr 权重
    // 对踝关节滚转方向施加额外惩罚
    eigen_qp_H(9,9) *= 100;   // 左踝滚转
    eigen_qp_H(10,10) *= 100; // 左踝俯仰
    eigen_qp_H(15,15) *= 100; // 右踝滚转
    eigen_qp_H(16,16) *= 100; // 右踝俯仰
} else {
    eigen_qp_H.block<6, 6>(0, 0) = Q2 * 2.0 * 1e7;
    eigen_qp_H.block<12, 12>(6, 6) = Q1 * 2.0 * 1e1;
}
```

$H$ 矩阵具体为：

$$H = \begin{bmatrix}
2\times 10^7 I_6 & \mathbf{0}_{6\times 12} \\
\mathbf{0}_{12\times 6} & 2\times 10 I_{12}
\end{bmatrix}$$

- **基座加速度修正权重 $10^7$**：巨大权重，因为希望 QP 尽量不修改运动学层求出的基座加速度
- **接触力修正权重 $10^1$**：相对小得多的权重，允许 QP 在力的层面做较大调整
- **站立时踝关节加权重**：踝关节滚转和俯仰（index 9,10,15,16）的权重额外乘 100，因为站立时踝关节力矩限制更加关键

### 8.6.3 动力学等式约束

浮动基座动力学方程（前 6 行对应浮动机座）：

$$S_f (M \ddot{q} + h) = S_f J_c^T F_r$$

展开为 QP 的等式约束 $A_{eq}x = b_{eq}$：

$$A_{eq} \in \mathbb{R}^{6 \times 18}, \quad b_{eq} \in \mathbb{R}^6$$

代码中（第 202-208 行）：

```cpp
Eigen::MatrixXd eigen_qp_A1 = Eigen::MatrixXd::Zero(6, QP_nv);
eigen_qp_A1.block<6, 6>(0, 0) = Sf * dyn_M * St_qpV1;      // [Sf*M*S1] 对应 Δddq_base
eigen_qp_A1.block<6, 12>(0, 6) = -Sf * Jfe.transpose();     // [-Sf*Jc^T] 对应 ΔFr

Eigen::VectorXd eqRes = Eigen::VectorXd::Zero(6);
eqRes = -Sf * dyn_M * ddq_final_kin - Sf * dyn_Non + Sf * Jfe.transpose() * Fr_ff;
```

所以等式约束为：
$$S_f M S_1 \cdot \Delta\ddot{q}_{base} - S_f J_c^T \cdot \Delta F_r = -S_f M \ddot{q}_{kin} - S_f h + S_f J_c^T F_{r,ff}$$

其中 $S_1 = [I_6, \mathbf{0}_{6\times 12}]^T$ 是基座选择矩阵。这个约束的物理意义是：**优化后的基座加速度和接触力必须满足浮动基座的动力学方程**。

### 8.6.4 摩擦锥约束（不等式约束）

为了防止足底打滑，接触力必须满足摩擦锥约束。这里使用**线性化摩擦锥**（4 边棱锥近似）：

码中构造矩阵 $W \in \mathbb{R}^{16 \times 12}$（第 227-238 行）：

```cpp
Eigen::MatrixXd W = Eigen::MatrixXd::Zero(16, 12);
W(0, 0) = 1; W(0, 2) = sqrt(2)/2.0 * miu;
W(1, 0) = -1; W(1, 2) = sqrt(2)/2.0 * miu;
W(2, 1) = 1; W(2, 2) = sqrt(2)/2.0 * miu;
W(3, 1) = -1; W(3, 2) = sqrt(2)/2.0 * miu;
W.block<4, 4>(4, 2) = Eigen::MatrixXd::Identity(4, 4);  // Fz, τx, τy, τz
W.block<8, 6>(8, 6) = W.block<8, 6>(0, 0);               // 右腿同理
```

对于左腿（前 8 行），摩擦锥约束的完整形式为：

$$
\underbrace{\begin{bmatrix}
1 & 0 & \frac{\sqrt{2}}{2}\mu & 0 & 0 & 0 \\
-1 & 0 & \frac{\sqrt{2}}{2}\mu & 0 & 0 & 0 \\
0 & 1 & \frac{\sqrt{2}}{2}\mu & 0 & 0 & 0 \\
0 & -1 & \frac{\sqrt{2}}{2}\mu & 0 & 0 & 0 \\
0 & 0 & 1 & 0 & 0 & 0 \\
0 & 0 & 0 & 1 & 0 & 0 \\
0 & 0 & 0 & 0 & 1 & 0 \\
0 & 0 & 0 & 0 & 0 & 1
\end{bmatrix}}_{W_L}
\underbrace{\begin{bmatrix} F_x \\ F_y \\ F_z \\ \tau_x \\ \tau_y \\ \tau_z \end{bmatrix}}_{F_{r,L}}
\leq
\begin{bmatrix} 0 \\ 0 \\ 0 \\ 0 \\ F_{z,max} \\ \tau_{x,max} \\ \tau_{y,max} \\ \tau_{z,max} \end{bmatrix}
$$

物理意义：
- 第 1-4 行：$|F_x| \leq \frac{\sqrt{2}}{2}\mu F_z$，$|F_y| \leq \frac{\sqrt{2}}{2}\mu F_z$（摩擦锥）
- 第 5 行：$F_z \leq F_{z,max}$（法向力上限）
- 第 6-8 行：足端力矩限制 $\tau_x, \tau_y, \tau_z$

摩擦系数 $\mu = 0.5$（代码第 31 行）。

### 8.6.5 力限幅约束

摩擦力矩的上下限（代码第 33-37 行）：

```cpp
f_z_low = 10;
f_z_upp = 1400;
tau_upp_stand_L << 15, 30, 40;   // 站立时足端力矩上限(Nm)
tau_low_stand_L << -15, -30, -40;
tau_upp_walk_L << 15, 40, 40;    // 行走时足端力矩上限
tau_low_walk_L << -15, -40, -40;
```

在行走模式且处于单腿支撑时，非支撑腿的接触力被强制置零（第 262-298 行）：

```cpp
if (legStateCur == DataBus::LSt) {  // 左腿支撑
    f_upp(12) = 0; f_upp(13) = 0; f_upp(14) = 0; f_upp(15) = 0;
    f_low(12) = 0; f_low(13) = 0; f_low(14) = 0; f_low(15) = 0;
}
```

### 8.6.6 完整约束矩阵维度汇总

| 约束类型 | 行数 | 对应代码 |
|---------|------|---------|
| 动力学等式约束 | 6 | `eigen_qp_A1` (第 202 行) |
| 摩擦锥 + 力限幅 | 16 | `eigen_qp_A2` (第 300 行) |
| **总计** | **22** | `QP_nc = 22` |

约束矩阵 $A \in \mathbb{R}^{22 \times 18}$：

$$A = \begin{bmatrix}
A_{eq} (6 \times 18) \\
A_{ineq} (16 \times 18)
\end{bmatrix}$$

其中 $A_{eq}$ 对应动力学等式，$A_{ineq} = [\mathbf{0}_{16\times 6}, W_{16\times 12}]$。

上下界向量 $lbA, ubA \in \mathbb{R}^{22}$：
- 前 6 行（等式）：$lbA = ubA = eqRes$
- 后 16 行（不等式）：$lbA = f_{low} - W \cdot F_{r,ff}$，$ubA = f_{upp} - W \cdot F_{r,ff}$

---

## 8.7 从期望加速度到关节力矩的完整计算链

整个 WBC 的计算流程可以用下图表示：

```
MPC/上位控制器
    │
    ├─ des_ddq, des_dq, des_delta_q (期望状态)
    ├─ Fr_ff (前馈接触力)
    │
    ▼
┌──────────────────────────────────────┐
│ 1. Priority Task Solver              │
│    computeDdq()                      │
│    ├─ 任务定义 & 优先级排序            │
│    ├─ 零空间投影递推                  │
│    └─ 输出: ddq_final_kin (运动学解)  │
└──────────────────────┬───────────────┘
                       ▼
┌──────────────────────────────────────┐
│ 2. QP Solver                         │
│    computeTau()                      │
│    ├─ 构建 H, A, lbA, ubA            │
│    ├─ qpOASES 求解                   │
│    └─ 输出: Δddq_base, ΔFr           │
└──────────────────────┬───────────────┘
                       ▼
┌──────────────────────────────────────┐
│ 3. 结果整合                          │
│    ├─ ddq_opt = ddq_final_kin + Δdq   │
│    ├─ Fr_opt = Fr_ff + ΔFr            │
│    └─ τ = M·ddq_opt + h - Jc^T·Fr_opt │
└──────────────────────────────────────┘
                       ▼
                  关节力矩 τ_joint (输出)
```

### 步骤 1：computeDdq()——运动学层求解

在 `wbc_priority.cpp` 第 397-729 行，`computeDdq()` 函数完成以下工作：

1. **任务定义**（第 401-705 行）：根据行走/站立模式，配置每个任务的雅可比、误差、PD 增益
2. **优先级递推**（第 707-726 行）：调用 `kin_tasks_walk.computeAll()` 或 `kin_tasks_stand.computeAll()`，执行零空间投影递推
3. **输出**：`ddq_final_kin`, `dq_final_kin`, `delta_q_final_kin`

### 步骤 2：computeTau()——动力学层求解

在 `wbc_priority.cpp` 第 199-395 行，`computeTau()` 函数完成以下工作：

1. **约束构建**（第 199-318 行）：构建动力学等式约束、摩擦锥约束
2. **代价函数构建**（第 320-334 行）：构建 H 矩阵
3. **QP 求解**（第 346-374 行）：调用 qpOASES 求解器
4. **结果提取**（第 376-391 行）：提取优化后的加速度和接触力，计算关节力矩

### 步骤 3：力矩计算

最终的关节力矩通过动力学方程计算（代码第 389-391 行）：

```cpp
Eigen::VectorXd tauRes;
tauRes = dyn_M * eigen_ddq_Opt + dyn_Non - Jfe.transpose() * eigen_fr_Opt;
tauJointRes = tauRes.block(6, 0, model_nv - 6, 1);
```

完整的力矩公式为：

$$\tau = M(q) \ddot{q}_{opt} + h(q,\dot{q}) - J_c(q)^T F_{r,opt}$$

其中 $\ddot{q}_{opt}$ 和 $F_{r,opt}$ 是优化后的值，$h$ 包含科氏力和重力项。计算出的 $\tau$ 只取关节部分（去掉浮动基座的 6 维），输出到电机。

### WBC 的输入与输出

**输入**（来自 MPC 或上位控制器）：
| 变量 | 维度 | 含义 | 数据源 |
|------|------|------|--------|
| `des_ddq` | `model_nv` | 期望关节加速度 | `DataBus.des_ddq` |
| `des_dq` | `model_nv` | 期望关节速度 | `DataBus.des_dq` |
| `des_delta_q` | `model_nv` | 期望位置增量 | `DataBus.des_delta_q` |
| `Fr_ff` | 12 | 前馈接触力（左右足各6D） | `DataBus.Fr_ff` |

**输出**（写入 `DataBus`）：
| 变量 | 维度 | 含义 |
|------|------|------|
| `wbc_delta_q_final` | `model_nv` | 最优位置修正量 |
| `wbc_dq_final` | `model_nv` | 最优速度 |
| `wbc_ddq_final` | `model_nv` | 最优加速度 |
| `wbc_tauJointRes` | `model_nv - 6` | 关节力矩指令 |
| `wbc_FrRes` | 12 | 最优接触力 |

---

## 8.8 完整代码逐行解析

### 8.8.1 wbc_priority.h：类结构解析

```cpp
class WBC_priority {
public:
    int model_nv;                          // 广义坐标速度维度 (浮动基6 + 关节31 = 37)
    Eigen::Vector3d tau_upp_stand_L;       // 站立时足端力矩上限 (体坐标系)
    Eigen::Vector3d tau_low_stand_L;       // 站立时足端力矩下限
    Eigen::Vector3d tau_upp_walk_L;        // 行走时足端力矩上限
    Eigen::Vector3d tau_low_walk_L;        // 行走时足端力矩下限
    double f_z_low{0}, f_z_upp{0};         // 法向接触力上下限
    DataBus::LegState legStateCur;         // 当前腿状态 (LSt/RSt/DSt)
    DataBus::MotionState motionStateCur;   // 当前运动状态 (Stand/Walk/Walk2Stand)

    // --- 动力学相关 ---
    Eigen::MatrixXd dyn_M, dyn_M_inv;      // 惯性矩阵及其逆
    Eigen::MatrixXd dyn_Ag, dyn_dAg;       // 重力项及其雅可比
    Eigen::VectorXd dyn_Non;               // 非线性项 (科氏力+重力): c*dq+g

    // --- 雅可比矩阵 ---
    Eigen::MatrixXd Jc, dJc;              // 支撑腿足端雅可比及其导数
    Eigen::MatrixXd Jfe, dJfe, Jfe_L, Jfe_R; // 双腿足端雅可比
    Eigen::MatrixXd J_hd_l, J_hd_r;       // 左右手雅可比
    Eigen::MatrixXd Jsw, dJsw;            // 摆动腿雅可比
    Eigen::MatrixXd J_base, dJ_base;      // 基座雅可比
    Eigen::MatrixXd Jcom;                 // 质心雅可比

    // --- 优先级任务管理器 ---
    PriorityTasks kin_tasks_walk, kin_tasks_stand; // 行走/站立模式的任务集

    // --- QP 相关 ---
    qpOASES::QProblem QP_prob;            // qpOASES QP 求解器实例
    static const int QP_nv_des=18;        // QP 变量数: Δddq_base(6) + ΔFr(12)
    static const int QP_nc_des=22;        // QP 约束数: 动力学(6) + 摩擦锥/力限幅(16)
```

关键成员解析：
- `Sf` (第 68 行)：浮动基座选择矩阵 $[I_6, \mathbf{0}_{6\times 31}]$，提取动力学方程的前 6 行
- `St_qpV1` (第 69 行)：QP 变量到广义坐标的映射：$\ddot{q}_{base} = S_1 \cdot \Delta\ddot{q}_{base}$
- `St_qpV2`：关节选择矩阵 $\begin{bmatrix}\mathbf{0}_{31\times 6} \\ I_{31}\end{bmatrix}$

### 8.8.2 computeDdq() 方法逐行解释

**任务定义阶段**（以行走模式的 static_Contact 为例）：

```cpp
// wbc_priority.cpp 第 401-412 行
int id = kin_tasks_walk.getId("static_Contact");
kin_tasks_walk.taskLib[id].errX = Eigen::VectorXd::Zero(6);  // 位置误差 = 0 (接触点不动)
kin_tasks_walk.taskLib[id].derrX = Eigen::VectorXd::Zero(6); // 速度误差 = 0
kin_tasks_walk.taskLib[id].ddxDes = Eigen::VectorXd::Zero(6);// 期望加速度 = 0
kin_tasks_walk.taskLib[id].dxDes = Eigen::VectorXd::Zero(6); // 期望速度 = 0
kin_tasks_walk.taskLib[id].kp = Eigen::MatrixXd::Identity(6, 6) * 0; // Kp = 0 (纯约束)
kin_tasks_walk.taskLib[id].kd = Eigen::MatrixXd::Identity(6, 6) * 0; // Kd = 0
kin_tasks_walk.taskLib[id].J = Jc;         // 支撑腿雅可比
kin_tasks_walk.taskLib[id].dJ = dJc;       // 雅可比时间导数
kin_tasks_walk.taskLib[id].W.diagonal() = Eigen::VectorXd::Ones(model_nv); // 单位权重
```

对于 RedundantJoints 任务（代码第 413-432 行），雅可比是稀疏矩阵，直接选择对应关节：

```cpp
kin_tasks_walk.taskLib[id].J = Eigen::MatrixXd::Zero(5, model_nv);
kin_tasks_walk.taskLib[id].J(0, 20) = 1; // 对应关节索引20 (head yaw)
kin_tasks_walk.taskLib[id].J(1, 21) = 1; // 对应关节索引21 (head pitch)
kin_tasks_walk.taskLib[id].J(2, 22) = 1; // 对应关节索引22 (waist pitch)
kin_tasks_walk.taskLib[id].J(3, 23) = 1; // 对应关节索引23 (waist roll)
kin_tasks_walk.taskLib[id].J(4, 24) = 1; // 对应关节索引24 (waist yaw)
```

**零空间递推求解阶段**（`priority_tasks.cpp` 第 66-108 行）：

```cpp
void PriorityTasks::computeAll(...) {
    int curId = startId;
    int parentId = taskLib[curId].parentId;
    int childId = taskLib[curId].childId;

    for (int i = 0; i < taskLib.size(); i++) {
        if (parentId == -1) {
            // 第一个任务：无零空间约束
            taskLib[curId].N = I;  // 零空间 = 全空间
            taskLib[curId].Jpre = taskLib[curId].J * taskLib[curId].N;
            // 位置层解：
            taskLib[curId].delta_q = des_delta_q + Jpre⁺ * errX;
            // 速度层解：
            taskLib[curId].dq = des_dq;
            // 加速度层解：
            ddxcmd = ddxDes + Kp*errX + Kd*derrX;
            taskLib[curId].ddq = des_ddq + dyn_Jpre⁺ * (ddxcmd - dJ*dq);
        } else {
            // 后续任务：在父任务零空间中优化
            taskLib[curId].N = taskLib[parentId].N * (I - Jpre⁺ * Jpre);
            taskLib[curId].Jpre = taskLib[curId].J * taskLib[curId].N;

            // 位置层递推 (公式 8.5-1)
            taskLib[curId].delta_q = parent.delta_q + Jpre⁺ * (errX - J * parent.delta_q);

            // 速度层递推 (公式 8.5-2)
            taskLib[curId].dq = parent.dq + Jpre⁺ * (dxDes - J * parent.dq);

            // 加速度层递推 (公式 8.5-3)
            ddxcmd = ddxDes + Kp*errX + Kd*derrX;
            taskLib[curId].ddq = parent.ddq + dyn_Jpre⁺ * (ddxcmd - dJ*dq - J*parent.ddq);
        }

        if (childId != -1) {
            parentId = curId;
            curId = childId;
            childId = taskLib[curId].childId;
        } else
            break;
    }
    // 最后一个任务的解就是最终输出
    out_delta_q = taskLib[curId].delta_q;
    out_dq = taskLib[curId].dq;
    out_ddq = taskLib[curId].ddq;
}
```

这里的关键是递推公式中 `Jpre` 的使用。`Jpre` 是任务雅可比 $J$ 在累积零空间 $N$ 上的投影。对于第 k 个任务：

$$J_{pre,k} = J_k N_{k-1}$$

这保证了第 k 个任务只在前 k-1 个任务的零空间中求解。

### 8.8.3 computeTau() 方法逐行解释

**第 202-208 行：构建动力学等式约束**

```cpp
eigen_qp_A1.block<6, 6>(0, 0) = Sf * dyn_M * St_qpV1;  // Sf·M·S1
eigen_qp_A1.block<6, 12>(0, 6) = -Sf * Jfe.transpose(); // -Sf·Jc^T
eqRes = -Sf * dyn_M * ddq_final_kin - Sf * dyn_Non + Sf * Jfe.transpose() * Fr_ff;
```

**第 227-238 行：构建摩擦锥矩阵**

摩擦锥矩阵 $W$ 的构造需要特别注意：它将世界坐标系下的接触力 $F_r$ 映射到摩擦锥约束空间。由于接触力最初在世界系中计算，而力矩约束在体坐标系中更直观，所以需要坐标变换矩阵 `Mw2b`（第 220-225 行）：

```cpp
Mw2b.block(0, 0, 3, 3) = Rfe.transpose();   // 左腿位置部分
Mw2b.block(3, 3, 3, 3) = Rfe.transpose();   // 左腿力矩部分
Mw2b.block(6, 6, 3, 3) = Rfe.transpose();   // 右腿位置部分
Mw2b.block(9, 9, 3, 3) = Rfe.transpose();   // 右腿力矩部分
```

最终 $W_{final} = W \cdot Mw2b$。

**第 346-361 行：调用 qpOASES 求解**

```cpp
copy_Eigen_to_real_t(qp_H, eigen_qp_H, ...);      // 复制H矩阵
copy_Eigen_to_real_t(qp_A, eigen_qp_A_final, ...); // 复制A矩阵
copy_Eigen_to_real_t(qp_lbA, eigen_qp_lbA, ...);   // 复制下界
copy_Eigen_to_real_t(qp_ubA, eigen_qp_ubA, ...);   // 复制上界

for (int i = 0; i < QP_nv; i++) {
    xOpt_iniGuess[i] = 0;  // 初始猜测 = 0
    qp_g[i] = 0;           // 线性项 = 0 (仅有二次项)
}

nWSR = 200;       // 最大迭代次数
cpu_time = timeStep; // 最大求解时间 (= 1ms)

res = QP_prob.init(qp_H, qp_g, qp_A, NULL, NULL, qp_lbA, qp_ubA, nWSR, &cpu_time, xOpt_iniGuess);
qpStatus = qpOASES::getSimpleStatus(res);
```

**第 370-391 行：提取结果并计算关节力矩**

```cpp
QP_prob.getPrimalSolution(xOpt);

// 最优加速度 = 运动学解 + QP修正
eigen_ddq_Opt = ddq_final_kin;
eigen_ddq_Opt.block<6, 1>(0, 0) += eigen_xOpt.block<6, 1>(0, 0);

// 最优接触力 = 前馈力 + QP修正
eigen_fr_Opt = Fr_ff + eigen_xOpt.block<12, 1>(6, 0);

// 关节力矩 = M*ddq_opt + h - Jc^T*Fr_opt
tauRes = dyn_M * eigen_ddq_Opt + dyn_Non - Jfe.transpose() * eigen_fr_Opt;
tauJointRes = tauRes.block(6, 0, model_nv - 6, 1);
```

### 8.8.4 copy_Eigen_to_real_t 辅助函数

```cpp
// wbc_priority.cpp 第 731-742 行
void WBC_priority::copy_Eigen_to_real_t(qpOASES::real_t* target, const Eigen::MatrixXd &source, int nRows, int nCols)
{
    int count = 0;
    for (int i = 0; i < nRows; i++) {
        for (int j = 0; j < nCols; j++) {
            target[count++] = isinf(source(i, j)) ? qpOASES::INFTY : source(i, j);
        }
    }
}
```

qpOASES 使用行优先存储的 C 数组，而 Eigen 默认是列优先。这个函数将 Eigen 矩阵转换为 qpOASES 所需的格式。注意 `isinf` 检查：Eigen 中的无穷大被映射到 qpOASES 的 `INFTY`。

---

## 8.9 WBC vs MPC：角色分工与协同

### 8.9.1 角色定位

在 Openloong 控制框架中，MPC 和 WBC 是两级级联控制器：

| 特性 | MPC（模型预测控制） | WBC（全身控制） |
|------|-------------------|----------------|
| **时间尺度** | 前瞻 10 步（~100ms） | 实时跟踪（1ms） |
| **频率** | 50-100 Hz | 1000 Hz |
| **模型** | 简化模型（如 LIPM 或 VHIP） | 完整多刚体动力学 |
| **优化变量** | CoM 位置/速度 + 足端力 | 全线加速度 + 接触力 |
| **约束** | 简化的 ZMP/CoP 约束 | 完整摩擦锥 + 力矩限制 |
| **输出** | 期望状态 $X_d$ + 前馈力 $F_{r,ff}$ | 关节力矩 $\tau$ |

### 8.9.2 信息流

MPC → WBC 的信息传递路径：

```
┌─────────────┐    期望状态 X_d (位置/速度/加速度)    ┌─────────────┐
│             │ ──────────────────────────────────→  │             │
│    MPC      │    前馈接触力 Fr_ff                   │    WBC      │
│  (50-100Hz) │ ──────────────────────────────────→  │  (1000 Hz)  │
│             │                                      │             │
│  前瞻规划   │                                      │  实时跟踪    │
└─────────────┘                                      └─────────────┘
                                                           │
                                                           ▼
                                                     关节力矩 τ
```

MPC 负责**前瞻规划**，在简化的动力学模型上预测未来 10 步的最优状态轨迹和前馈力。WBC 负责**实时跟踪**，在全动力学模型上对 MPC 的期望轨迹进行高精度跟踪，同时保证所有物理约束被满足。

### 8.9.3 为什么需要两级？

想象一个简单的场景：机器人正在步行，MPC 预测到下一步需要将 CoM 前移 5cm。它计算出了：
- 期望的 CoM 轨迹（$X_d$）
- 前馈接触力（$F_{r,ff}$）

但 MPC 使用的简化模型（例如线性倒立摆）忽略了：
- 腿部质量分布
- 手臂摆动的影响
- 关节力矩限制
- 精确的摩擦锥

这些细节正是 WBC 来处理的。WBC 以 MPC 的输出为"参考"，在完整动力学模型上求解精确的关节力矩，同时保证：
1. 支撑腿接触约束严格满足
2. 摩擦锥约束不被违反
3. 关节力矩不超限

简而言之：**MPC 告诉机器人"去哪里"，WBC 告诉机器人"怎么去"**。

---

# 第9章 状态估计实现

## 9.1 EKF 状态向量与观测向量设计

### 9.1.1 为什么需要状态估计？

双足机器人的传感器存在各种噪声和偏置：
- IMU 加速度计有偏置，积分导致位置漂移
- IMU 陀螺仪有漂移，纯积分姿态会发散
- 足端位置编码器有量化误差
- 接触力传感器有噪声

我们需要一个**状态估计器**来融合多传感器信息，得到对机器人状态的最优估计。

### 9.1.2 状态向量 $X \in \mathbb{R}^{15}$

EKF 的状态向量定义在 `StateEst.h` 第 57-60 行：

```
X(15): [base_pos(3), base_vel(3), fe_l_pos_W(3), fe_r_pos_W(3), delta_acc(3)]^T
```

| 状态分量 | 维度 | 含义 | 符号 |
|---------|------|------|------|
| `base_pos` | 3 | 基座在世界系中的位置 | $p_b$ |
| `base_vel` | 3 | 基座在世界系中的线速度 | $\dot{p}_b$ |
| `fe_l_pos_W` | 3 | 左足端在世界系中的位置 | $p_{l}$ |
| `fe_r_pos_W` | 3 | 右足端在世界系中的位置 | $p_{r}$ |
| `delta_acc` | 3 | 加速度计偏置 | $\delta_a$ |

### 9.1.3 观测向量 $Y \in \mathbb{R}^{14}$

```
Y(14): [fe_l_pos_B(3), fe_r_pos_B(3), fe_l_vel_B(3), fe_r_vel_B(3), fe_l_z(1), fe_r_z(1)]^T
```

| 观测分量 | 维度 | 含义 | 测量方式 |
|---------|------|------|---------|
| 左足端位置 | 3 | 左足在体坐标系中的位置 | 正运动学（编码器） |
| 右足端位置 | 3 | 右足在体坐标系中的位置 | 正运动学（编码器） |
| 左足端速度 | 3 | 左足在体坐标系中的线速度 | 运动学微分 |
| 右足端速度 | 3 | 右足在体坐标系中的线速度 | 运动学微分 |
| 左足高度 | 1 | 支撑时接地高度（≈0.07m） | 接触先验 |
| 右足高度 | 1 | 支撑时接地高度（≈0.07m） | 接触先验 |

### 9.1.4 状态向量和观测向量的设计理念

状态向量的设计非常巧妙：

**为什么选择足端位置作为状态？** 因为足端位置可以通过 IMU 积分和运动学进行预测，也可以通过编码器直接测量，两者形成很好的"预测-校正"对。

**为什么加速度偏置是状态？** IMU 加速度计存在随时间缓慢变化的偏置，如果不估计它，位置积分会持续漂移。将其作为状态，EKF 可以自动估计并补偿这个偏置。

**观测向量的最后两维是什么？** 当足部接触地面时，足端高度应该等于地面高度（设为 0.07m）。这个观测提供了"绝对"的高度信息，可以有效抑制垂向漂移。

---

## 9.2 过程模型与观测模型推导

### 9.2.1 过程模型：恒定速度模型 + 恒定偏置

EKF 的预测步骤使用线性过程模型 $X_{k+1} = A X_k + B u_k + w_k$。

**状态转移矩阵 $A \in \mathbb{R}^{15 \times 15}$**（`StateEst.cpp` 第 27-32 行）：

```cpp
A.block<3, 3>(0, 0) = I_3;           // base_pos = base_pos + dt * base_vel
A.block<3, 3>(0, 3) = I_3 * dt;      //
A.block<3, 3>(3, 3) = I_3;           // base_vel = base_vel (恒定速度)
A.block<6, 6>(6, 6) = I_6;           // fe_pos_W = fe_pos_W (恒定位置)
A.block<3, 3>(12, 12) = I_3;         // delta_acc = delta_acc (恒定偏置)
A.block<3, 3>(3, 12) = I_3 * dt;     // base_vel += dt * delta_acc
```

写成矩阵形式：

$$A = \begin{bmatrix}
I_3 & \Delta t I_3 & \mathbf{0}_3 & \mathbf{0}_3 & \mathbf{0}_3 \\
\mathbf{0}_3 & I_3 & \mathbf{0}_3 & \mathbf{0}_3 & \Delta t I_3 \\
\mathbf{0}_3 & \mathbf{0}_3 & I_3 & \mathbf{0}_3 & \mathbf{0}_3 \\
\mathbf{0}_3 & \mathbf{0}_3 & \mathbf{0}_3 & I_3 & \mathbf{0}_3 \\
\mathbf{0}_3 & \mathbf{0}_3 & \mathbf{0}_3 & \mathbf{0}_3 & I_3
\end{bmatrix}$$

物理意义解释：
- **基座位置**（第 1-3 行）：恒定速度模型 $p_{k+1} = p_k + \Delta t \cdot v_k$
- **基座速度**（第 4-6 行）：受到加速度偏置影响 $v_{k+1} = v_k + \Delta t \cdot \delta_a$
- **足端位置**（第 7-12 行）：在世界系中恒定（足端不动）
- **加速度偏置**（第 13-15 行）：随机游走模型

**控制输入矩阵 $B \in \mathbb{R}^{15 \times 3}$**：

```cpp
B.block<3, 3>(3, 0) = I_3 * dt;  // 加速度测量转换为速度增量
```

物理意义：加速度计测量值 $a_{meas}$（减去重力后）作为控制输入：

$$v_{k+1} = v_k + \Delta t \cdot (a_{meas} + \delta_a)$$

等等，这里似乎符号反了？让我们看 `update()` 函数中的预测步骤：

```cpp
X = A * X + B * freeAcc;  // freeAcc 是去偏置后的加速度
```

实际上 `freeAcc` 已经减去了重力，并且去除了偏置（在第 166-167 行）：

```cpp
Vector3d accTmp = {acc[0], acc[1], acc[2]};
freeAcc = eul2Rot(0.0, 0.0, offYaw).transpose() * accTmp;
```

所以控制输入是原始加速度计测量经过简单旋转后的值。EKF 估计的 `delta_acc` 会补偿剩余的偏置。

### 9.2.2 观测模型

观测矩阵 $C \in \mathbb{R}^{14 \times 15}$（`StateEst.cpp` 第 41-48 行）：

```cpp
C.block<3, 3>(0, 0) = I_3;              // Y[0:3] = base_pos - fe_l_pos_W
C.block<3, 3>(3, 0) = I_3;              // Y[3:6] = base_pos - fe_r_pos_W
C.block<3, 3>(0, 6) = -I_3;             //  = -(fe_l_pos_W)
C.block<3, 3>(3, 9) = -I_3;             //  = -(fe_r_pos_W)
C.block<3, 3>(6, 3) = -I_3;             // Y[6:9] = -base_vel + fe_l_vel_B 的体→世变换
C.block<3, 3>(9, 3) = -I_3;             // Y[9:12] = -base_vel + fe_r_vel_B
C.block<2, 6>(12, 6) = e;               // Y[12:14] = fe_l_z, fe_r_z
```

等等，这里的代码看起来有些令人困惑。我们来看 `update()` 中如何构建观测 $Y$：

```cpp
// 第 273-282 行
pbW = Rrpy_woOff * peB;   // 足端体坐标系位置 → 世界系
// ...
vbW.col(i) = leg_contact[i] * Rrpy_woOff * (velTmp.col(i) + omegaLVec.cross(peB.col(i)))
           + (1 - leg_contact[i]) * (-base_vel);

// 第 285-288 行
Y.segment<3>(0) = -pbW.block<3, 1>(0, 0);  // Y[0:3] = -pbl = -(fe_l_pos_W - base_pos) = base_pos - fe_l_pos_W
Y.segment<3>(3) = -pbW.block<3, 1>(0, 1);  // Y[3:6] = base_pos - fe_r_pos_W
Y.segment<3>(6) = vbW.block<3, 1>(0, 0);   // Y[6:9] = vbW_l (足端速度观测)
Y.segment<3>(9) = vbW.block<3, 1>(0, 1);   // Y[9:12] = vbW_r
```

而 `pbW = Rrpy_woOff * peB` 将足端在体坐标系的位置转换到世界坐标系。所以观测模型 $Y = C \cdot X$ 对应的是：

$$Y = \begin{bmatrix}
p_b - p_l^{W} \\
p_b - p_r^{W} \\
\dot{p}_b - \dot{p}_l^{W} \\
\dot{p}_b - \dot{p}_r^{W} \\
p_{l,z}^{W} \\
p_{r,z}^{W}
\end{bmatrix}$$

这里的 $C$ 矩阵需要从状态 $X$ 提取对应的分量。实际代码中，观测的构建分为两步：
1. 用 $C$ 矩阵计算预测观测值 $C \cdot X$
2. 用实际的传感器测量构建 $Y$

然后计算新息（innovation）：$Y - C \cdot X$。

---

## 9.3 卡尔曼增益与协方差更新

### 9.3.1 噪声协方差矩阵设计

**过程噪声 $Q \in \mathbb{R}^{15 \times 15}$**：

$Q$ 矩阵由对角分量组合而成（`StateEst.cpp` 第 244-262 行）：

```cpp
diagQ.segment<3>(0) = KF_Q_wPCoM;    // 位置噪声: [5e-6, 5e-6, 5e-6]
diagQ.segment<3>(3) = KF_Q_wVCoM;    // 速度噪声: [1e-8, 2e-8, 1e-6]
diagQ.segment<6>(6) = Xi * KF_Q_wfeW; // 足端位置噪声 (信任区域调节)
diagQ.segment<3>(12) = KF_Q_waL;     // 加速度偏置噪声: [1e-8, 1e-8, 1e-8]
```

其中 `Xi` 是信任区域矩阵（`getTrustRegion_wt_h()` 函数），根据摆动相位的值动态调整对足端位置状态的信任程度：

$$Q_{fe} = Xi \cdot Q_{fe,base}$$

$Xi$ 在支撑相时为 $I$（完全信任），在摆动相时信任度降低。

**观测噪声 $R \in \mathbb{R}^{14 \times 14}$**：

```cpp
diagR.segment<6>(0) = KF_R_wfeL;    // 足端位置观测噪声: [1e-7, 1e-7, 1e-10, 6e-7, 8e-8, 1e-11]
diagR.segment<6>(6) = Xiv * KF_R_wdfeL; // 足端速度观测噪声 (信任区域调节)
diagR.segment<2>(12) = Xih * KF_R_wh;   // 足端高度观测噪声 (信任区域调节)
```

### 9.3.2 信任区域机制（Trust Region）

`getTrustRegion_wt_h()` 函数（`StateEst.cpp` 第 179-212 行）实现了一个根据行走相位动态调整噪声协方差的机制：

```cpp
// 利用 phi (行走相位 0-1) 和 legState 判断哪条腿在支撑
for (int i = 0; i < 2; i++) {
    // 法向力信任度：摆动时降低
    C(i * 3 + 2) = leg_contact[i] + (1 - leg_contact[i]) * TR_k;   // Fz方向

    // 速度信任度：摆动时显著降低
    Cv(i * 3) = leg_contact[i] * aa[0] + (1 - leg_contact[i]) * TR_k;
}
```

当腿处于摆动相（`leg_contact[i] = false`）时，对应的足端位置和速度噪声协方差乘以一个很大的倍数（$TR_k = 100$），使得 EKF 更加"不信任"摆动腿的观测信息。这非常合理——摆动腿的足端不与地面接触，其位置/速度观测包含更多不确定性。

### 9.3.3 卡尔曼滤波核心方程

**预测步骤**（`StateEst.cpp` 第 266-267 行）：

```cpp
X = A * X + B * freeAcc;            // 状态预测
P = A * P * A.transpose() + Q;      // 协方差预测
```

**校正步骤**（第 296-302 行）：

```cpp
S_inv = C * P * C.transpose() + R;  // 新息协方差
S_inv = S_inv.inverse();            // 求逆

K = P * C.transpose() * S_inv;      // 卡尔曼增益

P = (I - K * C) * P;                // 协方差更新
X = X + K * (Y - C * X);            // 状态更新
```

经典卡尔曼滤波的五条公式，简洁明了。

### 9.3.4 协方差初始化

```cpp
// StateEst.cpp 第 104-110 行
P0.setZero();
for (int i = 0; i < 15; i++)
    P0(i, i) = 0.1;      // 初始协方差
flag_init = false;
X = X0;
P = P0;
```

初始协方差 $P_0 = 0.1 \times I_{15}$，表示对初始状态估计有中等程度的不确定性。

---

## 9.4 欧拉角/角速度滤波（Eul_W_filter）

### 9.4.1 互补滤波思想

EKF 之前有一个专门的欧拉角/角速度滤波器（`Eul_W_filter.cpp`）。其本质是一个**基于运动学模型的卡尔曼滤波器**，核心思想是互补滤波：

- **加速度计**：低频段可靠，可提供姿态基准（重力方向）
- **陀螺仪**：高频段可靠，但积分有漂移

滤波器状态为 6 维：姿态角 $(roll, pitch, yaw)$ + 角速度 $(\omega_x, \omega_y, \omega_z)$。

### 9.4.2 状态转移模型：角速度→姿态的运动学

状态转移矩阵 $F \in \mathbb{R}^{6 \times 6}$（`Eul_W_filter.cpp` 第 38-45 行）基于欧拉角运动学微分方程：

```cpp
F.setIdentity();
F(0, 3) = dt;
F(0, 4) = dt * sin(roll_Old) * sin(pitch_Old) / cos(pitch_Old);
F(0, 5) = dt * cos(roll_Old) * sin(pitch_Old) / cos(pitch_Old);
F(1, 4) = dt * cos(roll_Old);
F(1, 5) = -dt * sin(roll_Old);
F(2, 4) = dt * sin(roll_Old) / cos(pitch_Old);
F(2, 5) = dt * cos(roll_Old) / cos(pitch_Old);
```

这个矩阵对应欧拉角运动学方程：

$$\begin{bmatrix}
\dot{\phi} \\
\dot{\theta} \\
\dot{\psi}
\end{bmatrix} = \begin{bmatrix}
1 & \sin\phi\tan\theta & \cos\phi\tan\theta \\
0 & \cos\phi & -\sin\phi \\
0 & \sin\phi / \cos\theta & \cos\phi / \cos\theta
\end{bmatrix} \begin{bmatrix}
\omega_x \\
\omega_y \\
\omega_z
\end{bmatrix}$$

离散化后得到 $F$ 矩阵。注意这是**非线性**的（依赖于当前姿态角），所以每个时间步都需要重新计算。

### 9.4.3 滤波参数

```cpp
// StateEst.cpp 第 72-86 行
eul_w_filter.Q.setIdentity();
eul_w_filter.Q(0, 0) = 1e-8;  // roll 过程噪声
eul_w_filter.Q(1, 1) = 1e-8;  // pitch 过程噪声
eul_w_filter.Q(2, 2) = 1e-8;  // yaw 过程噪声
eul_w_filter.Q(3, 3) = 5e-7;  // ωx 过程噪声
eul_w_filter.Q(4, 4) = 5e-7;  // ωy 过程噪声
eul_w_filter.Q(5, 5) = 2e-5;  // ωz 过程噪声

eul_w_filter.R.setIdentity();
eul_w_filter.R(0, 0) = 1e-6;  // roll 观测噪声
eul_w_filter.R(1, 1) = 1e-6;  // pitch 观测噪声
eul_w_filter.R(2, 2) = 1e-6;  // yaw 观测噪声
eul_w_filter.R(3, 3) = 1e-4;  // ωx 观测噪声
eul_w_filter.R(4, 4) = 1e-4;  // ωy 观测噪声
eul_w_filter.R(5, 5) = 1e-5;  // ωz 观测噪声
```

注意到 `Q(5,5)`（偏航角速度的过程噪声）明显大于其他两个轴，这是因为偏航角不能通过加速度计直接观测，所以过程模型对偏航的预测更不准确。

同样地，`R(3,3)` 和 `R(4,4)`（俯仰/滚转角速度的观测噪声）大于 `R(0,0)` 和 `R(1,1)`（姿态角的观测噪声），因为加速度计提供的姿态角信息比陀螺仪直接测量的角速度更可靠。

### 9.4.4 在 EKF 中的调用

`Eul_W_filter` 在 `StateEst::set()` 中被调用（`StateEst.cpp` 第 151-163 行）：

```cpp
void StateEst::set(DataBus &Data) {
    // ... 读取传感器数据 ...

    // 运行欧拉角/角速度滤波
    eul_w_filter.run(eul_woOff_ary, omegaL_ary);
    eul_w_filter.getData(Eul_filtered, wL_filtered);

    // 使用滤波后的值更新状态
    eul_woOff << Eul_filtered[0], Eul_filtered[1], Eul_filtered[2];
    omegaL << wL_filtered[0], wL_filtered[1], wL_filtered[2];
    omegaW = Rrpy_woOff * omegaL;

    // ... 继续 EKF 的 set 流程 ...
}
```

所以完整的信号处理链是：

```
IMU (加速度计+陀螺仪)
    │
    ├─ 加速度计 → 欧拉角计算
    │                 │
    ├─ 陀螺仪 → 角速度 ─┤
                        ▼
               Eul_W_filter (卡尔曼滤波融合)
                        │
                        ▼
              滤波后的姿态 + 角速度
                        │
                        ▼
              主 EKF (状态估计)
```

---

## 9.5 代码逐行解析（StateEst.cpp）

### 9.5.1 初始化：构造函数

```cpp
// StateEst.cpp 第 16-87 行
StateEst::StateEst(double dtIn) : eul_w_filter(dtIn) {
    dt = dtIn;

    // 构建状态转移矩阵 A (15×15)
    A.block<3, 3>(0, 0) = I_3;
    A.block<3, 3>(0, 3) = I_3 * dt;
    A.block<3, 3>(3, 3) = I_3;
    A.block<6, 6>(6, 6) = I_6;
    A.block<3, 3>(12, 12) = I_3;
    A.block<3, 3>(3, 12) = I_3 * dt;

    // 构建控制输入矩阵 B (15×3)
    B.block<3, 3>(3, 0) = I_3 * dt;

    // 构建观测矩阵 C (14×15)
    // ... (之前已经详细分析过)

    // 初始化协方差和状态
    P.setIdentity();
    X.setZero();
    P0.setIdentity();
    X0.setZero();
}
```

### 9.5.2 set()：读取传感器数据并预处理

```cpp
// StateEst.cpp 第 138-177 行
void StateEst::set(DataBus &Data) {
    // 1. 读取 IMU 数据
    acc << Data.baseAcc[0], Data.baseAcc[1], Data.baseAcc[2];          // 加速度计
    eul << Data.rpy[0], Data.rpy[1], Data.rpy[2];                      // 原始欧拉角
    omegaL << Data.baseAngVel[0], Data.baseAngVel[1], Data.baseAngVel[2]; // 原始角速度

    // 2. 去除偏航偏置
    eul_woOff << eul[0], eul[1], eul[2] - offYaw;
    Rrpy_woOff = eul2Rot(eul_woOff(0), eul_woOff(1), eul_woOff(2));

    // 3. 运行欧拉角/角速度卡尔曼滤波
    eul_w_filter.run(eul_woOff_ary, omegaL_ary);
    eul_w_filter.getData(Eul_filtered, wL_filtered);

    // 4. 读取运动学数据
    fe_l_pos_L = Data.fe_l_pos_L;  // 左足在体坐标系中的位置
    fe_r_pos_L = Data.fe_r_pos_L;  // 右足在体坐标系中的位置
    fe_l_vel_L = Data.fe_l_vel_L;  // 左足在体坐标系中的线速度
    fe_r_vel_L = Data.fe_r_vel_L;  // 右足在体坐标系中的线速度
}
```

### 9.5.3 update()：卡尔曼滤波核心

完整流程在 `StateEst.cpp` 第 215-330 行。我们拆解分析：

```cpp
void StateEst::update() {
    // 第 226-237 行：判断接触状态
    if (legState == DataBus::LSt) {     // 左腿支撑
        leg_contact[0] = true;
        leg_contact[1] = false;
    } else if (legState == DataBus::RSt) { // 右腿支撑
        leg_contact[1] = true;
        leg_contact[0] = false;
    } else {                            // 双脚支撑
        leg_contact[0] = true;
        leg_contact[1] = true;
    }

    // 第 239-241 行：存储足端位置（体坐标系）
    peB.col(0) = fe_l_pos_L;
    peB.col(1) = fe_r_pos_L;

    // 第 242 行：更新信任区域
    getTrustRegion_wt_h();

    // 第 244-262 行：根据信任区域构建 Q 和 R
    diagQ.segment<3>(0) = KF_Q_wPCoM;          // 位置噪声
    diagQ.segment<3>(3) = KF_Q_wVCoM;          // 速度噪声
    diagQ.segment<6>(6) = Xi * KF_Q_wfeW;      // 足端位置噪声（动态调节）
    diagQ.segment<3>(12) = KF_Q_waL;           // 加速度偏置噪声
    Q = diagQ.asDiagonal().toDenseMatrix() + B * KF_Q_waU.asDiagonal() * B.transpose();

    diagR.segment<6>(0) = KF_R_wfeL;           // 足端位置观测噪声
    diagR.segment<6>(6) = Xiv * KF_R_wdfeL;    // 足端速度观测噪声（动态调节）
    diagR.segment<2>(12) = Xih * KF_R_wh;      // 足端高度观测噪声（动态调节）
    R = diagR.asDiagonal();

    // 第 266-267 行：预测步骤
    X = A * X + B * freeAcc;                   // 状态预测
    P = A * P * A.transpose() + Q;              // 协方差预测

    // 第 270-293 行：构建观测值 Y
    pbW = Rrpy_woOff * peB;                     // 足端位置：体→世
    vbW.col(i) = Rrpy_woOff * (vel + ω × peB);  // 足端速度：体→世（含哥氏项）

    Y.segment<3>(0) = -pbW.col(0);              // 左足位置观测
    Y.segment<3>(3) = -pbW.col(1);              // 右足位置观测
    Y.segment<3>(6) = vbW.col(0);               // 左足速度观测
    Y.segment<3>(9) = vbW.col(1);               // 右足速度观测
    Y(12) = leg_contact[0] * 0.07 + ...;        // 左足高度观测
    Y(13) = leg_contact[1] * 0.07 + ...;        // 右足高度观测

    // 第 296-302 行：校正步骤
    S_inv = C * P * C.transpose() + R;          // 新息协方差
    S_inv = S_inv.inverse();
    K = P * C.transpose() * S_inv;              // 卡尔曼增益
    P = (I - K * C) * P;                        // 协方差更新
    X = X + K * (Y - C * X);                   // 状态更新

    // 第 304-308 行：初始化阶段特殊处理
    if (!startFlag) {
        X = X0;     // 使用初始状态
        P = P0;     // 使用初始协方差
    }

    // 第 314-320 行：从状态向量中提取估计值
    base_pos = X.segment<3>(0);                 // 基座位置估计
    base_vel = X.segment<3>(3);                 // 基座速度估计
    delta_acc = X.segment<3>(12);               // 加速度偏置估计
    fe_l_pos_W = X.segment<3>(6);               // 左足位置估计
    fe_r_pos_W = X.segment<3>(9);               // 右足位置估计
}
```

### 9.5.4 get()：将估计值写回 DataBus

```cpp
// StateEst.cpp 第 332-374 行
void StateEst::get(DataBus &Data) {
    // 写入估计值
    Data.base_pos_est = base_pos;
    Data.base_vel_est = base_vel;
    Data.fe_l_pos_W_est = fe_l_pos_W;
    Data.fe_r_pos_W_est = fe_r_pos_W;
    Data.eul_est = eul_woOff;       // 注意：不含偏航偏置！
    Data.omegaW_est = omegaW;

    // 覆盖原始数据
    Data.base_pos = Data.base_pos_est;
    Data.base_vel = Data.base_vel_est;
    Data.baseAcc[0] += delta_acc[0];  // 补偿加速度偏置
    Data.baseAcc[1] += delta_acc[1];
    Data.baseAcc[2] += delta_acc[2];
    Data.base_rpy = Data.eul_est;
    Data.base_omega_W = Data.omegaW_est;
    Data.base_rot = Rrpy_woOff;

    // 更新广义坐标 q 和 dq
    Data.q.block<3, 1>(0, 0) = Data.base_pos;
    Data.dq.block<3, 1>(0, 0) = Data.base_vel;
    auto quatNow = eul2quat(Data.base_rpy[0], Data.base_rpy[1], Data.base_rpy[2]);
    Data.q(3) = quatNow.x();
    Data.q(4) = quatNow.y();
    Data.q(5) = quatNow.z();
    Data.q(6) = quatNow.w();
    Data.dq.block<3, 1>(3, 0) = Data.base_omega_W;
}
```

这里的关键点是**偏置补偿**：加速度计测量值 `Data.baseAcc` 被加上 `delta_acc` 来补偿偏置，补偿后的加速度将用于后续的控制计算。

### 9.5.5 接触力估计（setF / updateF / getF）

`StateEst` 还提供了接触力估计功能（`StateEst.cpp` 第 376-405 行）：

```cpp
void StateEst::updateF() {
    // 利用动力学逆解算足底接触力
    τ_all = [0; 0; 0; 0; 0; 0; τ_joint]  // 前6维为0（浮动基座无力矩）
    F_L = -J_l⁺ · (J_l · M⁻¹ · (τ_all - h) + dJ_l · dq)
    F_R = -J_r⁺ · (J_r · M⁻¹ · (τ_all - h) + dJ_r · dq)
}
```

这个力的估计不依赖力传感器，而是利用动力学模型逆解算。公式来源于：

$$M\ddot{q} + h = S^T\tau + J^T F$$

解出 $F$：

$$F = -(J M^{-1} J^T)^{-1} (J M^{-1}(S^T\tau - h) + \dot{J}\dot{q})$$

---

## 9.6 状态估计对控制性能的影响

### 9.6.1 估计误差如何传递到 WBC？

状态估计是 WBC 的"眼睛"。估计误差通过以下路径影响控制性能：

```
估计误差
    │
    ├─ 基座位置误差 → des_delta_q 偏差 → 关节位置跟踪误差
    ├─ 基座速度误差 → des_dq 偏差 → 关节速度跟踪误差
    ├─ 姿态误差 → diffRot() 姿态误差计算错误 → 躯干控制失稳
    ├─ 足端位置误差 → 摆动腿轨迹跟踪误差 → 落足点偏差
    └─ 加速度偏置误差 → 动力学计算偏误 → 关节力矩不准确
```

具体来说，WBC 的 `dataBusRead()` 函数（`wbc_priority.cpp` 第 99-178 行）从 `DataBus` 读取的状态值（包括 `base_pos`, `base_rot`, `q`, `dq` 等）全部来自状态估计的输出。如果这些估计值有偏差，WBC 计算的任务误差 $e_{rr} = x_{des} - x_{est}$ 就会错误，进而导致错误的关节力矩指令。

### 9.6.2 传感器噪声对稳定性的影响

**加速度计噪声**：直接影响 $freeAcc$ 的计算，进而影响 EKF 预测步骤的状态估计。加速度计偏置是 EKF 状态之一，所以低频偏置可以被自动估计和补偿。但高频噪声只能通过增大 $Q$ 矩阵来平滑。

**陀螺仪噪声**：通过 `Eul_W_filter` 滤波后进入主 EKF。陀螺仪噪声主要影响姿态估计的短期精度。在 `Eul_W_filter` 中，$R$ 矩阵的角速度分量（index 3-5）设置为 $10^{-4}$ 到 $10^{-5}$，提供了适度的平滑。

**编码器噪声**：影响足端位置和速度的测量。在 $R$ 矩阵中，足端位置观测噪声设置为 $10^{-7}$ 量级，足端速度观测噪声设置为 $10^{-5}$ 量级。足端位置的信噪比更好。

**接触状态误判**：如果 `leg_contact` 判断错误（比如摆动腿被误判为支撑腿），信任区域机制会给错误的足端信息以高权重，导致状态估计发散。这是最危险的情况之一。

### 9.6.3 实际调参建议

1. **增大 $Q$ 使滤波器响应更快**：如果机器人运动剧烈，需要增大过程噪声 $Q$，让 EKF 更相信测量值而不是预测值
2. **增大 $R$ 使滤波更平滑**：如果传感器噪声大，增大观测噪声 $R$，让 EKF 更依赖过程模型
3. **信任区域参数调节**：`TR_k`（默认 100）控制摆动相时对足端观测的信任折扣，如果摆动腿抖动明显，可以增大这个值
4. **初始协方差 $P_0$**：设置为 $0.1 I$，如果机器人初始位姿不确定，可以增大到 $I$ 甚至 $10I$

---

# 小结

本教程的第 8 章和第 9 章详细介绍了 Openloong 双足机器人控制系统的两个核心模块：

**第 8 章（全身控制 WBC）**：从任务空间和零空间投影的数学原理出发，详细推导了分层优先级控制的递推公式，完整解析了行走和站立模式下的 5 级任务定义与排序，深入分析了 QP 问题的矩阵维度和约束构建，最后逐行解释了 `wbc_priority.cpp` 和 `priority_tasks.cpp` 的核心代码。

**第 9 章（状态估计）**：详细介绍了 15 维状态向量的 EKF 设计，分析了过程模型和观测模型的物理意义，解释了信任区域机制如何动态调整噪声协方差，深入解析了 `Eul_W_filter` 作为姿态互补滤波器的实现，最后逐行分析了 `StateEst.cpp` 的完整代码流程。

理解这两章的核心算法是掌握双足机器人全身运动控制的关键。WBC 保证了机器人能够在复杂动力学约束下精确跟踪期望轨迹，而状态估计为 WBC 提供了准确可靠的机器运动状态反馈。


---

# 第四部分：系统集成

---

## 第10章 控制循环与数据流

> **章节导读**：本章以 `walk_mpc_wbc.cpp` 为主线，逐步解析 OpenLoong 机器人控制系统的整体架构。你将看到从 `main()` 入口开始，仿真引擎如何以 1kHz 步长驱动控制循环，数据总线如何在各算法模块之间流转，以及"读取-计算-写入"模式如何让整个系统清晰可调试。

### 10.1 主循环整体架构（1kHz 仿真步长）

#### 10.1.1 `main()` 函数入口分析

所有控制逻辑的入口位于 `demo/walk_mpc_wbc.cpp` 的第 32 行的 `main()` 函数。在进入主循环之前，程序完成了三项关键初始化：

**1. 全局模型加载（第 28-30 行）**

```cpp
mjModel* mj_model = mj_loadXML("../models/scene.xml", 0, error, 1000);
mjData* mj_data = mj_makeData(mj_model);
```

这里通过 `mj_loadXML()` 加载场景文件 `scene.xml`，该文件通过 `<include file="AzureLoong.xml"/>` 将机器人模型包含进来。`mj_makeData()` 则为仿真分配运行时数据结构。

**2. 各模块实例化（第 34-43 行）**

```cpp
UIctr uiController(mj_model,mj_data);           // UI 控制
MJ_Interface mj_interface(mj_model, mj_data);    // MuJoCo 数据接口
Pin_KinDyn kinDynSolver("../models/AzureLoong.urdf"); // 运动学/动力学
DataBus RobotState(kinDynSolver.model_nv);       // 数据总线
WBC_priority WBC_solv(...);                      // WBC 求解器
MPC MPC_solv(dt_200Hz);                          // MPC 控制器
GaitScheduler gaitScheduler(0.25, ...);          // 步态调度器
PVT_Ctr pvtCtr(...,"../common/joint_ctrl_config.json"); // 关节控制
FootPlacement footPlacement;                     // 落脚点规划
JoyStickInterpreter jsInterp(...);               // 摇杆输入解释器
DataLogger logger("../record/datalog.log");      // 数据记录
```

这些模块按照依赖关系排列：`DataBus` 在最前面，因为它作为共享数据容器被后续所有模块引用。

**3. 初始位姿设置（第 64-92 行）**

```cpp
mju_copy(mj_data->qpos, mj_model->key_qpos, mj_model->nq*1);
```

通过逆运动学计算初始关节角度，确保机器人以直立姿态开始仿真。

#### 10.1.2 主循环结构

主循环位于第 123-252 行，是一个嵌套的双层循环结构：

```
外循环（60 FPS）：渲染更新
  └── 内循环（1kHz）：仿真与控制
       ├── mj_step()        物理仿真推进 1ms
       ├── 传感器读取
       ├── 运动学/动力学计算
       ├── 摇杆输入处理
       ├── 步态调度与落脚点规划
       ├── MPC 求解（每5步）
       ├── WBC 求解
       ├── PVT 关节控制
       ├── 力矩下发
       └── 数据记录
```

外循环以 60 FPS 运行，用于渲染可视化。内循环以 1kHz（`mj_step` 每次推进 1ms）运行，完成所有控制和仿真计算。嵌套结构的设计保证了可视化渲染不阻塞控制计算。

关键代码段（第 123-126 行）：

```cpp
while (!glfwWindowShouldClose(uiController.window)) {
    simstart = mj_data->time;
    while (mj_data->time - simstart < 1.0 / 60.0 && uiController.runSim) {
        mj_step(mj_model, mj_data);
        // ... 所有控制和仿真计算 ...
    }
    uiController.updateScene();
}
```

这种设计确保无论控制循环多快，渲染都能以稳定的帧率运行。

### 10.2 DataBus 数据总线设计原理

#### 10.2.1 为什么需要 DataBus？

在机器人控制系统中，多个算法模块需要相互交换数据：

- 状态估计器需要传感器数据 → 输出机器人状态
- 步态调度器需要时间信息 → 输出当前步态相位
- MPC 需要状态和步态信息 → 输出最优轨迹
- WBC 需要状态和轨迹 → 输出关节指令

如果模块之间直接相互调用，会形成复杂的网状依赖，如图 10-1(a) 所示。DataBus 的设计理念是：所有模块只与一个中心数据结构交互，将网状依赖变为星型结构，如图 10-1(b) 所示。

```
(a) 无数据总线            (b) 有数据总线
    传感器──→估计器              传感器
       ↕      ↕                   │
      MPC ←→ WBC                  ↓
       ↕      ↕                DataBus ←→ 估计器
    步态调度 落脚点               ↕  ↕  ↕
                               MPC WBC 步态调度
```

**图 10-1：数据总线将网状依赖变为星型结构**

这种设计带来三个关键好处：

1. **模块解耦**：每个模块只需知道 DataBus 的接口，无需了解其他模块的实现细节
2. **数据一致性**：所有模块在同一时间步看到相同的数据快照，避免时序竞争
3. **可测试性**：可以注入任意数据到 DataBus 来测试单个模块

#### 10.2.2 DataBus 的数据结构全景

`DataBus` 结构体定义在 `common/data_bus.h` 中。它包含了机器人控制所需的全部运行时数据，按功能分为以下类别：

**表 10-1：DataBus 主要字段分类**

| 功能类别 | 主要字段 | 说明 |
|---------|---------|------|
| 传感器反馈 | `rpy[3]`, `fL[3]`, `fR[3]` | 机身姿态、足底力 |
|  | `basePos[3]`, `baseLinVel[3]` | 机身位置、线速度 |
|  | `baseAngVel[3]`, `baseAcc[3]` | 机身角速度、加速度 |
|  | `motors_pos_cur`, `motors_vel_cur` | 关节位置、速度反馈 |
| PVT 控制 | `motors_pos_des`, `motors_vel_des` | 关节期望位置、速度 |
|  | `motors_tor_des`, `motors_tor_out` | 关节期望力矩、输出力矩 |
| 状态变量 | `q`, `dq`, `ddq` | 广义坐标、速度、加速度 |
|  | `pCoM_W`, `base_pos`, `base_rot` | 质心位置、机身位姿 |
|  | `J_*`, `dJ_*` | 各类雅可比矩阵及其导数 |
|  | `dyn_M`, `dyn_C`, `dyn_G` | 动力学矩阵 |
| 状态估计 | `base_pos_est`, `base_vel_est` | 估计的机身位置、速度 |
|  | `eul_est`, `omegaW_est` | 估计的姿态、角速度 |
| 摇杆输入 | `js_eul_des`, `js_pos_des` | 期望姿态、位置 |
|  | `js_omega_des`, `js_vel_des` | 期望角速度、线速度 |
| MPC | `Xd`, `X_cur` | 期望状态、当前状态 |
|  | `fe_react_tau_cmd` | 足底反力指令 |
| WBC | `des_ddq`, `des_dq`, `des_q` | 期望加速度、速度、位置 |
|  | `wbc_delta_q_final`, `wbc_dq_final` | WBC 输出的关节修正 |
|  | `wbc_tauJointRes`, `wbc_FrRes` | WBC 输出的关节力矩、足底力 |
| 落脚点规划 | `swingStartPos_W`, `swingDesPosFinal_W` | 摆动足起始/目标位置 |
|  | `posHip_W`, `posST_W` | 髋关节位置、支撑足位置 |
| 步态状态 | `legState`, `motionState` | 腿状态（支撑/摆动）、运动状态 |
|  | `tSwing`, `phi`, `leg_contact` | 摆动时间、相位、接触标志 |

#### 10.2.3 数据总线 vs 直接函数调用

理解 DataBus 的好处，最好的方法是思考如果不使用数据总线会怎样。

假设 MPC 需要调用 WBC 的结果，WBC 又需要运动学结果，运动学又需要传感器数据。如果使用直接函数调用，代码会变成：

```cpp
// 无数据总线的假想代码
sensor.read();
kinematics.calc(sensor.q, sensor.dq);
mpc.calc(kinematics.pCoM, kinematics.J);
wbc.calc(kinematics.M, kinematics.C, mpc.Xd, mpc.Fr);
```

任何一个环节的接口变化都会引起连锁修改。使用 DataBus 后：

```cpp
// 使用数据总线
sensor.dataBusWrite(bus);     // 传感器写入数据
kinDyn.dataBusRead(bus);      // 运动学读取传感器数据
kinDyn.compute();             // 计算
kinDyn.dataBusWrite(bus);     // 运动学写回结果
mpc.dataBusRead(bus);         // MPC 读取所需数据
mpc.calc();
mpc.dataBusWrite(bus);        // MPC 写回结果
```

每个模块只通过 `dataBusRead()` 和 `dataBusWrite()` 与总线交互，接口极其稳定。

### 10.3 读取-计算-写入（Read-Calc-Write）模式

#### 10.3.1 模式定义

系统中所有算法模块都遵循统一的 **Read-Calc-Write** 三阶段模式：

1. **Read**：从 DataBus 读取本模块所需的输入数据
2. **Calc**：执行核心算法计算
3. **Write**：将计算结果写回 DataBus

这一模式在 `walk_mpc_wbc.cpp` 的主循环中体现得淋漓尽致。让我们以状态估计（即运动学/动力学计算）为例来说明。

#### 10.3.2 示例：运动学/动力学模块的三步曲

在 `walk_mpc_wbc.cpp` 第 132-136 行：

```cpp
// Read
kinDynSolver.dataBusRead(RobotState);
// Calc
kinDynSolver.computeJ_dJ();
kinDynSolver.computeDyn();
// Write
kinDynSolver.dataBusWrite(RobotState);
```

每一步的具体含义：

**Read 阶段**（`dataBusRead`）：从 DataBus 复制当前关节位置 `q` 和速度 `dq` 到模块内部变量。

**Calc 阶段**：调用 `computeJ_dJ()` 计算所有运动学量（足端位置、雅可比矩阵等），调用 `computeDyn()` 计算动力学矩阵（质量矩阵 M、科里奥利力 C、重力 G 等）。

**Write 阶段**（`dataBusWrite`）：将计算得到的雅可比矩阵、动力学矩阵等回写至 DataBus，供后续模块（如 WBC）使用。

#### 10.3.3 为什么这种模式有利于调试和测试？

**原因 1：单步验证**

由于每个模块的输入输出都是 DataBus 中的明确字段，可以保存任意时刻的 DataBus 快照，离线重放验证单个模块的正确性。

**原因 2：数据流可视化**

在 DataBus 的每个字段前加上时间戳，就可以生成完整的数据流图。例如，可以追踪一个传感器值从读取到最终生成力矩指令的完整路径：

```
sensordata → qpos → q → J_* → wbc_delta_q → motors_pos_des → motors_tor_out
```

**原因 3：模块替换**

如果需要替换某个算法模块（例如更换不同类型的 MPC），只需要新模块同样实现 `dataBusRead`/`calc`/`dataBusWrite` 接口，主循环代码几乎无需修改。

### 10.4 多速率控制

#### 10.4.1 为什么需要多速率？

机器人控制系统中不同任务的实时性要求不同：

- **物理仿真**需要 1kHz 才能准确模拟接触动力学
- **MPC 优化求解**涉及复杂的 QP 问题，每步计算耗时较长，1kHz 执行不现实
- **WBC 求解**介于两者之间

为此，系统采用了多速率设计。主循环以 1kHz 运行，但不同模块以不同频率执行。

**表 10-2：系统中不同模块的执行频率**

| 模块 | 频率 | 周期 | 每 N 步执行一次 |
|-----|------|------|----------------|
| mj_step（物理仿真） | 1000 Hz | 1ms | 每一步 |
| 传感器读取 | 1000 Hz | 1ms | 每一步 |
| 运动学/动力学 | 1000 Hz | 1ms | 每一步 |
| 步态调度 | 1000 Hz | 1ms | 每一步 |
| 落脚点规划 | 1000 Hz | 1ms | 每一步 |
| MPC | 200 Hz | 5ms | 每 5 步 |
| WBC | 1000 Hz | 1ms | 每一步 |
| PVT 关节控制 | 1000 Hz | 1ms | 每一步 |
| 渲染更新 | 60 Hz | ~16.7ms | 每次外循环 |

#### 10.4.2 多速率同步机制

多速率同步通过简单的计数器加模运算实现。相关代码在 `walk_mpc_wbc.cpp` 第 114 和 162-168 行：

```cpp
int MPC_count = 0;  // 第 114 行：MPC 步数计数器

// 第 162-168 行：MPC 多速率控制
MPC_count = MPC_count + 1;
if (MPC_count > (dt_200Hz / dt - 1)) {
    MPC_solv.dataBusRead(RobotState);
    MPC_solv.cal();
    MPC_solv.dataBusWrite(RobotState);
    MPC_count = 0;
}
```

其中 `dt = 0.001`（1ms），`dt_200Hz = 0.005`（5ms），所以 `dt_200Hz / dt - 1 = 4`。也就是说，MPC 每累积 5 步（即每 5ms）执行一次。

#### 10.4.3 多速率设计要点

需要注意的关键设计原则：

1. **数据保持**：在 MPC 不执行的中间 4 步中，上一次的计算结果保留在 DataBus 中，WBC 仍然可以读取使用
2. **解耦性**：每个模块都有自己的计数器，互不影响
3. **确定性**：由于仿真步长固定，多速率行为完全确定，可重复

### 10.5 walk_mpc_wbc 完整控制流解析

#### 10.5.1 逐行解读

让我们从 `main()` 开始，逐段追踪控制流和数据流。为便于阅读，将主循环内部分为 8 个阶段。

**阶段 1：物理仿真推进（第 126 行）**

```cpp
mj_step(mj_model, mj_data);
```

`mj_step()` 是 MuJoCo 的核心函数，将物理仿真向前推进一个 `timestep`（默认 1ms）。它完成：
- 积分关节位置和速度
- 计算接触力和关节力矩
- 更新传感器数据

**阶段 2：传感器数据读取（第 129-130 行）**

```cpp
mj_interface.updateSensorValues();
mj_interface.dataBusWrite(RobotState);
```

`updateSensorValues()` 从 `mj_data` 读取原始传感器数据，`dataBusWrite()` 将其写入 DataBus。此时 DataBus 包含：
- `motors_pos_cur`：当前关节角度
- `motors_vel_cur`：当前关节角速度
- `rpy[3]`：机身欧拉角
- `basePos[3]`、`baseLinVel[3]`、`baseAcc[3]`、`baseAngVel[3]`：机身运动状态

**阶段 3：运动学/动力学计算（第 132-136 行）**

```cpp
kinDynSolver.dataBusRead(RobotState);
kinDynSolver.computeJ_dJ();
kinDynSolver.computeDyn();
kinDynSolver.dataBusWrite(RobotState);
```

此阶段完成：
- 根据关节位置 `q` 计算雅可比矩阵 `J_*` 及其导数 `dJ_*`
- 计算动力学矩阵：质量矩阵 `dyn_M`、科里奥利力 `dyn_C`、重力 `dyn_G`
- 计算机身位姿、足端位置等

输出写入 DataBus 后，为后续 WBC 提供了所需的运动学和动力学信息。

**阶段 4：摇杆输入处理（第 140-149 行）**

```cpp
jsInterp.setIniPos(RobotState.q(0), RobotState.q(1), RobotState.base_rpy(2));
jsInterp.step();
jsInterp.dataBusWrite(RobotState);
```

`JoyStickInterpreter` 生成期望的机身速度和位置轨迹。它使用斜坡轨迹生成器，将速度指令平滑地过渡到目标值。输出写入 DataBus 的 `js_*` 字段。

**阶段 5：步态调度与落脚点规划（第 150-159 行）**

```cpp
gaitScheduler.dataBusRead(RobotState);
gaitScheduler.step();
gaitScheduler.dataBusWrite(RobotState);

footPlacement.dataBusRead(RobotState);
footPlacement.getSwingPos();
footPlacement.dataBusWrite(RobotState);
```

步态调度器根据时间和运动状态，确定当前是左脚支撑还是右脚支撑。落脚点规划器根据期望速度，计算摆动足的期望落点位置。

**阶段 6：MPC 求解（第 162-168 行）**

```cpp
MPC_count = MPC_count + 1;
if (MPC_count > (dt_200Hz / dt - 1)) {
    MPC_solv.dataBusRead(RobotState);
    MPC_solv.cal();
    MPC_solv.dataBusWrite(RobotState);
    MPC_count = 0;
}
```

每 5 步执行一次。MPC 求解器读取当前状态和期望轨迹，通过模型预测控制计算最优足底反力，并写入 DataBus 的 `Xd`、`X_cal`、`fe_react_tau_cmd` 等字段。

**阶段 7：WBC 求解（第 172-175 行）**

```cpp
WBC_solv.dataBusRead(RobotState);
WBC_solv.computeDdq(kinDynSolver);
WBC_solv.computeTau();
WBC_solv.dataBusWrite(RobotState);
```

WBC（全身控制）求解器读取 DataBus 中的运动学、动力学和 MPC 结果，通过优先级任务框架计算期望关节加速度、速度和力矩。

**阶段 8：关节指令合成与下发（第 178-219 行）**

```cpp
// 合成最终关节指令
if (simTime <= startSteppingTime) {
    // 初始站立阶段：使用逆运动学结果
    RobotState.motors_pos_des = eigen2std(resLeg.jointPosRes + resHand.jointPosRes);
} else {
    // 行走阶段：使用 WBC 输出
    RobotState.motors_pos_des = eigen2std(pos_des.block(7, 0, model_nv - 6, 1));
    RobotState.motors_vel_des = eigen2std(RobotState.wbc_dq_final);
    RobotState.motors_tor_des = eigen2std(RobotState.wbc_tauJointRes);
}

// PVT 控制器
pvtCtr.dataBusRead(RobotState);
pvtCtr.calMotorsPVT();
pvtCtr.dataBusWrite(RobotState);

// 下发力矩
mj_interface.setMotorsTorque(RobotState.motors_tor_out);
```

PVT 控制器根据期望位置、速度、力矩和当前反馈，计算最终输出力矩。`setMotorsTorque()` 将力矩写入 `mj_data->ctrl`，供下一次 `mj_step()` 使用。

#### 10.5.2 完整数据流图

下面用文字描述各阶段之间 DataBus 中关键数据的流转：

```
mj_step()
    │
    ▼
[MuJoCo 内部状态更新]
    │
    ▼
updateSensorValues() ──→ DataBus.motors_pos_cur
    │                      DataBus.motors_vel_cur
    │                      DataBus.rpy[], basePos[], etc.
    ▼
kinDynSolver.dataBusRead() ──→ DataBus.q, dq
    │                            （由 updateQ() 根据传感器值组装）
    │ calc → DataBus.J_*, dyn_M, dyn_C, dyn_G, pCoM_W
    ▼
jsInterp.step() ──→ DataBus.js_pos_des, js_vel_des, js_eul_des
    │
    ▼
gaitScheduler.step() ──→ DataBus.legState, tSwing, phi
    │
    ▼
footPlacement.getSwingPos() ──→ DataBus.swingDesPosFinal_W
    │
    ▼
MPC_solv.cal() (每5步) ──→ DataBus.Xd, fe_react_tau_cmd, Fr_ff
    │
    ▼
WBC_solv.computeDdq()+computeTau()
    │ ──→ DataBus.wbc_delta_q_final
    │ ──→ DataBus.wbc_dq_final
    │ ──→ DataBus.wbc_tauJointRes
    ▼
pvtCtr.calMotorsPVT() ──→ DataBus.motors_tor_out
    │
    ▼
setMotorsTorque() ──→ mj_data->ctrl
    │
    ▼
mj_step()  // 下一个仿真步
```

### 10.6 模块化设计的优点与扩展性

#### 10.6.1 如何添加新的算法模块？

要在现有系统中添加一个新的算法模块（例如一个姿态估计器），只需要三步：

**步骤 1**：在 DataBus 中添加新字段

```cpp
// 在 data_bus.h 中
Eigen::Vector3d attitude_est;  // 新增的姿态估计值
```

**步骤 2**：实现新模块类，遵循 Read-Calc-Write 模式

```cpp
class AttitudeEstimator {
public:
    void dataBusRead(DataBus &bus) {
        // 读取陀螺仪、加速度计数据
        gyro_ = bus.baseAngVel;
        acc_ = bus.baseAcc;
    }
    void calc() {
        // 执行姿态估计算法
    }
    void dataBusWrite(DataBus &bus) {
        bus.attitude_est = estimated_attitude_;
    }
};
```

**步骤 3**：在主循环中插入调用

```cpp
// 在 walk_mpc_wbc.cpp 的传感器读取之后
attEst.dataBusRead(RobotState);
attEst.calc();
attEst.dataBusWrite(RobotState);
```

无需修改任何其他模块的代码。

#### 10.6.2 如何替换现有模块？

假设想将当前的 MPC 求解器替换为一个不同的实现：

1. 新 MPC 类实现相同的 `dataBusRead()`、`cal()`、`dataBusWrite()` 接口
2. 在主循环入口处替换实例化代码
3. 主循环中调用代码无需任何修改

这种设计使得系统非常便于进行算法对比实验——同一份主循环代码，只需替换一个模块，就可以公平比较不同算法的性能。

---

## 第11章 MuJoCo 仿真接口

> **章节导读**：本章介绍 OpenLoong 如何使用 MuJoCo 物理引擎进行仿真。你将了解传感器数据如何从 MuJoCo 中读取、执行器指令如何下发、不同仿真场景如何配置，以及为什么同时需要 URDF 和 MuJoCo XML 两套模型描述。

### 11.1 MuJoCo 仿真引擎简介

MuJoCo（Multi-Joint dynamics with Contact）是一款专为机器人和生物力学领域设计的物理仿真引擎。它的核心设计哲学可以概括为"即用型"——加载模型即可运行，无需繁琐的参数调整。

#### 11.1.1 MuJoCo 的设计哲学

**自动生成接触**：不同于其他引擎需要手动指定碰撞对，MuJoCo 自动检测所有几何体之间的接触。用户只需列出需要排除的相邻连杆对（在 `<contact>` 段中通过 `<exclude>` 标签定义）。

**软接触模型**：MuJoCo 使用弹性接触模型而非硬约束，这意味着接触力是连续变化的，数值稳定性更好。

**凸优化求解器**：MuJoCo 将物理方程求解转化为凸优化问题，保证了求解的可靠性和效率。

#### 11.1.2 关键特性

- **多体动力学**：支持自由关节、球关节、铰链关节等，自动推导运动方程
- **即用特性**：加载 XML 模型后自动完成惯性参数、运动学树、碰撞检测的配置
- **高性能**：C 语言实现，支持 1kHz 以上的实时仿真
- **传感器系统**：内置 IMU、力传感器、触觉传感器等

### 11.2 传感器数据读取

传感器数据读取的核心代码在 `sim_interface/MJ_interface.cpp` 中。`MJ_Interface` 类封装了所有与 MuJoCo 数据交互的操作。

#### 11.2.1 `updateSensorValues()` 方法分析

该方法（第 53-89 行）负责从 `mj_data` 中提取所有传感器数据，主要完成三类信息读取：

**1. 关节状态读取（第 55-60 行）**

```cpp
for (int i = 0; i < jointNum; i++) {
    motor_pos_old[i] = motor_pos[i];
    motor_pos[i] = mj_data->qpos[jntId_qpos[i]];
    motor_vel[i] = mj_data->qvel[jntId_qvel[i]];
}
```

`jntId_qpos` 和 `jntId_qvel` 是构造函数中通过 `mj_name2id()` 和 `mj_model->jnt_qposadr[]`、`mj_model->jnt_dofadr[]` 初始化的索引数组，用于在 MuJoCo 的 `qpos`/`qvel` 数组中定位特定关节的数据。

**2. IMU 数据读取（第 61-89 行）**

机身 IMU 数据来自 MuJoCo 的传感器系统。在 `AzureLoong.xml` 中，传感器定义如下（第 360-366 行）：

```xml
<sensor>
    <framequat name="baselink-quat" objtype="site" objname="imu" />
    <velocimeter name="baselink-velocity" site="imu" />
    <gyro name="baselink-gyro" site="imu" />
    <accelerometer name="baselink-baseAcc" site="imu" />
    <touch name="lf-touch" site="lf-tc" />
    <touch name="rf-touch" site="rf-tc" />
</sensor>
```

代码中通过 `mj_name2id()` 获取传感器 ID，然后从 `mj_data->sensordata[mj_model->sensor_adr[id]]` 读取数据。

注意四元数的坐标系转换（第 63-67 行）：MuJoCo 的四元数顺序为 `[w, x, y, z]`，代码中将其转换为 `[x, y, z, w]` 以便与 Eigen 库兼容：

```cpp
for (int i = 0; i < 4; i++)
    baseQuat[i] = mj_data->sensordata[mj_model->sensor_adr[orientataionSensorId] + i];
double tmp = baseQuat[0];
baseQuat[0] = baseQuat[1];
baseQuat[1] = baseQuat[2];
baseQuat[2] = baseQuat[3];
baseQuat[3] = tmp;
```

**表 11-1：机身传感器与 MuJoCo 数据类型对应关系**

| 物理量 | MuJoCo 传感器类型 | XML 名称 | DataBus 字段 |
|-------|------------------|----------|-------------|
| 机身姿态 | `framequat` | baselink-quat | `rpy[3]`（转换为欧拉角） |
| 线速度 | `velocimeter` | baselink-velocity | `baseLinVel[3]` |
| 角速度 | `gyro` | baselink-gyro | `baseAngVel[3]` |
| 加速度 | `accelerometer` | baselink-baseAcc | `baseAcc[3]` |

**3. 足底力传感器（第 105-110 行）**

足底力通过 MuJoCo 的 `<touch>` 传感器获取。`f3d[3][2]` 的第一维为三维力分量，第二维为左右脚（0 左，1 右）。在 `dataBusWrite()` 中传入 DataBus 的 `fL[3]` 和 `fR[3]` 字段。

需要注意的是，足底触觉传感器的精度受 MuJoCo 接触模型参数影响，在实际机器人中可能需要使用真实的六维力/力矩传感器数据进行校准。

#### 11.2.2 `dataBusWrite()` 与 `updateQ()`

`dataBusWrite()` 方法（第 98-123 行）将 `MJ_Interface` 中的数据写入 DataBus，并调用 `updateQ()` 组装广义坐标向量。

`updateQ()` 是 DataBus 的一个成员方法（`data_bus.h` 第 202-236 行），它完成从原始传感器数据到广义坐标 `q` 和广义速度 `dq` 的组装：

```cpp
void updateQ() {
    // 计算角速度（机身坐标系转世界坐标系）
    base_omega_W << baseAngVel[0], baseAngVel[1], baseAngVel[2];
    auto Rcur = eul2Rot(rpy[0], rpy[1], rpy[2]);
    base_omega_W = Rcur * base_omega_W;

    // q = [base_pos(3), base_quat(4), joint_positions]
    q(0) = basePos[0]; q(1) = basePos[1]; q(2) = basePos[2];
    q(3) = quatNow.x(); q(4) = quatNow.y();
    q(5) = quatNow.z(); q(6) = quatNow.w();
    for (int i = 0; i < model_nv - 6; i++)
        q(i + 7) = motors_pos_cur[i];

    // dq = [base_lin_vel(3), base_ang_vel(3), joint_velocities]
    dq.block<3,1>(0,0) = vCoM_W;
    dq.block<3,1>(3,0) << base_omega_W[0], base_omega_W[1], base_omega_W[2];
    for (int i = 0; i < model_nv - 6; i++)
        dq(i + 6) = motors_vel_cur[i];
}
```

这里 `model_nv` 是自由度数量（自由关节 6 个 + 所有旋转关节），`model_nv - 6` 即为关节电机的数量。

### 11.3 执行器指令下发

#### 11.3.1 `setMotorsTorque()` 方法

执行器指令下发比传感器读取简单得多，因为 MuJoCo 使用力矩控制模式：

```cpp
void MJ_Interface::setMotorsTorque(std::vector<double> &tauIn) {
    for (int i = 0; i < jointNum; i++)
        mj_data->ctrl[i] = tauIn.at(i);
}
```

它将 PVT 控制器计算得到的最终力矩值直接写入 `mj_data->ctrl` 数组。下一次调用 `mj_step()` 时，MuJoCo 会将这些力矩施加到对应的关节执行器上。

#### 11.3.2 MuJoCo 执行器模型

在 `AzureLoong.xml` 的第 305-357 行定义了所有执行器：

```xml
<actuator>
    <motor name="M_arm_l_01" joint="J_arm_l_01" gear="1"
           ctrllimited="true" ctrlrange="-80 80"/>
    <!-- ... 更多执行器 ... -->
    <motor name="M_knee_l_pitch" joint="J_knee_l_pitch" gear="18.2"
           ctrllimited="true" ctrlrange="-21.7582 21.7582"/>
</actuator>
```

每个 `<motor>` 类型执行器的关键参数：

- **`joint`**：关联的关节名称
- **`gear`**：减速比。注意代码中实际输出力矩为 `tauDes / gear[i]`（`PVT_ctrl.cpp` 第 87 行），这是因为 MuJoCo 的 motor 执行器在 `gear` 参数作用下，实际施加到关节的力矩为 `ctrl * gear`。因此代码中需要先除以 gear，使得最终施加到关节的力矩等于期望值
- **`ctrllimited`** 和 **`ctrlrange`**：力矩限幅，作为硬限位保护

**表 11-2：关键关节执行器参数**

| 执行器名称 | gear | 力矩范围 (Nm) |
|-----------|------|--------------|
| M_knee_l_pitch | 18.2 | ±396 |
| M_hip_l_pitch | 18.2 | ±396 |
| M_hip_l_roll | 16.227 | ±320 |
| M_waist_pitch | 81 | ±315 |
| M_ankle_l_pitch | 15.916 | ±58.5 |
| M_arm_l_01 | 1 | ±80 |

注意头部、腰部和腿部关节使用了高减速比（gear > 1），而手臂关节的 gear 为 1（直驱）。

### 11.4 仿真场景配置

MuJoCo 的场景文件以 XML 格式编写，通过 `<include>` 标签组合机器人模型和环境配置。

#### 11.4.1 `scene.xml`：基础场景

文件位置：`models/scene.xml`

```xml
<mujoco model="scene">
    <include file="AzureLoong.xml"/>
    <visual>
        <headlight diffuse="0.6 0.6 0.6" ambient="0.3 0.3 0.3"/>
        <global azimuth="150" elevation="-20"/>
    </visual>
    <asset>
        <texture name="groundplane" builtin="checker" .../>
        <material name="groundplane" texture="groundplane" texrepeat="5 5"/>
    </asset>
    <worldbody>
        <light pos="0 0 1.5" dir="0 0 -1" directional="true"/>
        <geom name="floor" size="0 0 1" pos="0 0 0" type="plane"
              material="groundplane"/>
    </worldbody>
</mujoco>
```

场景特点：平坦地面，棋盘格纹理，适合基本行走测试。

#### 11.4.2 `scene_board.xml`：平板场景

文件位置：`models/scene_board.xml`

该场景在地面上放置了三个旋转不同角度的平板：

```xml
<geom type="box" size=".3 .6 .02" pos="1 0.4 .025"
      material="block" euler="0 0 0.5"/>
<geom type="box" size=".3 .6 .02" pos="3 0.4 .025"
      material="block" euler="0 0 -0.3"/>
<geom type="box" size=".3 .6 .02" pos="5 0.4 .025"
      material="block" euler="0 0 0.2"/>
```

每个平板尺寸为 0.6m×0.6m×0.02m，以不同偏航角放置在地面上，用于测试机器人在不规则支撑面上的行走能力。

#### 11.4.3 `scene_staircase.xml`：楼梯场景

文件位置：`models/scene_staircase.xml`

该场景构建了一个逐步升高的楼梯序列，从 `pos="0.5 0.4 .0"`（高度 0.02m）到 `pos="15 0.4 .0"`（高度 1.4m），共约 30 级台阶。台阶宽度 2m（y 方向），每级台阶宽度 0.5m（x 方向），高度递增约 0.05m。

这个场景用于测试机器人的爬楼梯能力。

#### 11.4.4 自定义场景

要创建一个自定义场景，只需：

1. 在 `models/` 目录下新建一个 XML 文件
2. 使用 `<include file="AzureLoong.xml"/>` 包含机器人模型
3. 在 `<worldbody>` 中添加自定义地形和障碍物
4. 修改 `walk_mpc_wbc.cpp` 第 29 行的 `mj_loadXML()` 参数，指向新场景文件

### 11.5 URDF vs MuJoCo XML

#### 11.5.1 两个模型的分工

OpenLoong 同时维护两套模型描述文件：

| 文件 | 用途 | 格式 |
|-----|------|------|
| `models/AzureLoong.urdf` | Pinocchio 运动学/动力学计算 | URDF |
| `models/AzureLoong.xml` | MuJoCo 物理仿真 | MuJoCo XML |

在代码中，URDF 由 `Pin_KinDyn` 加载（`walk_mpc_wbc.cpp` 第 36 行），MuJoCo XML 由 `mj_loadXML` 加载（第 29 行）。

#### 11.5.2 两个模型的差异

虽然描述的是同一台机器人，但两个模型文件有若干重要差异：

**差异 1：表达能力**

URDF 是 ROS 生态的标准格式，但表达能力有限：
- 不支持自由关节（floating base），需要使用虚拟关节模拟
- 不支持直接定义传感器
- 不支持物理参数（如接触摩擦、阻尼等）

MuJoCo XML 提供了更丰富的描述能力，包括传感器定义、接触参数、可视化效果等。

**差异 2：运动学树结构**

MuJoCo XML 在保持基本运动学链条一致的同时，对 URDF 中的坐标系进行了调整，以利用 MuJoCo 的 body/joint 层次结构优势。

**差异 3：碰撞几何**

MuJoCo XML 使用 STL 网格文件（在 `<asset>` 段中定义）提供更精细的碰撞检测，而 URDF 通常使用简化的碰撞几何体以提高计算效率。

#### 11.5.3 为什么需要两套模型？

简单回答：**各取所长**。

- **Pinocchio**（使用 URDF）专长于运动学和动力学计算，提供了高效的正/逆运动学求解、雅可比矩阵计算、RNEA 等算法
- **MuJoCo**（使用 XML）专长于物理仿真，提供了接触检测、约束求解、传感器模拟等功能

两套模型的对应关系通过**关节名称的一致性**来维护。从 `MJ_Interface.h` 第 30-36 行可以看到，关节名称列表与 URDF 中的关节名称完全相同：

```cpp
const std::vector<std::string> JointName = {
    "J_arm_l_01", "J_arm_l_02", ..., "J_ankle_r_roll"
};
```

这使得两套模型在数据层面可以无缝对接。

### 11.6 可视化与交互

#### 11.6.1 GLFW 窗口管理

窗口管理由 `UIctr` 类实现（`sim_interface/GLFW_callbacks.h`）。它封装了 GLFW 库的初始化、窗口创建、事件处理等操作。

在 `walk_mpc_wbc.cpp` 的第 46-49 行：

```cpp
uiController.iniGLFW();
uiController.enableTracking();
uiController.createWindow("Demo", false);
```

`enableTracking()` 开启视角跟踪功能，使相机自动跟随机器人机身运动。

#### 11.6.2 键盘交互

`GLFW_callbacks.h` 中的 `ButtonState` 结构体定义了键盘按键状态映射：

```cpp
struct ButtonState {
    bool key_w{false};
    bool key_s{false};
    bool key_a{false};
    bool key_d{false};
    bool key_h{false};
    bool key_j{false};
    bool key_space{false};
};
```

**表 11-3：键盘快捷键功能**

| 按键 | 功能 |
|------|------|
| 1 | 暂停/继续仿真 |
| 2 | 单步仿真 |
| W/S | 前进/后退 |
| A/D | 左转/右转 |
| Space | 跳跃（预留） |
| 鼠标左键拖拽 | 旋转视角 |
| 鼠标滚轮 | 缩放 |

#### 11.6.3 摇杆输入解释器

`JoyStickInterpreter` 类（`algorithm/joystick_interpreter.h`）将期望速度指令转换为平滑的运动轨迹。

核心逻辑在 `step()` 方法中（`joystick_interpreter.cpp` 第 23-32 行）：

```cpp
void JoyStickInterpreter::step() {
    vx_L = vxLGen.step();
    vy_L = vyLGen.step();
    wz_L = wzLGen.step();
    thetaZ = thetaZ + wz_L * dt;
    vx_W = cos(thetaZ) * vx_L - sin(thetaZ) * vy_L;
    vy_W = sin(thetaZ) * vx_L + cos(thetaZ) * vy_L;
    px_W += vx_W * dt;
    py_W += vy_W * dt;
}
```

它使用 `RampTrajectory` 类生成平滑的加速度受限轨迹，避免速度突变导致机器人失稳。体坐标系下的速度指令通过旋转矩阵转换为世界坐标系下的位置增量。

---

## 第12章 关节控制层

> **章节导读**：本章深入 OpenLoong 的关节控制层，解析从 WBC 高层规划到最终电机力矩输出的完整链路。你将了解 PVT 三级控制架构、PD 控制与前馈的设计原理、关节指令合成流程，以及安全保护机制。

### 12.1 扭矩控制模式与 PVT 控制

#### 12.1.1 位置-速度-扭矩（PVT）三级控制架构

OpenLoong 的关节控制采用 **PVT**（Position-Velocity-Torque）三级控制架构，即每个关节分别接收期望位置、期望速度和期望扭矩三个指令：

```
WBC 输出 ──→ 期望位置 (P_des)
            期望速度 (V_des)    ──→ PVT 控制器 ──→ 最终力矩 (τ_out)
            期望扭矩 (T_des)
```

这种设计的原因在于：

1. **冗余与降级**：当某个控制层级失效时，其他层级仍然提供一定的控制能力
2. **渐进收敛**：位置控制保证最终位置精度，速度控制抑制超调，扭矩前馈提高响应速度
3. **兼容不同电机**：某些电机驱动器原生支持 PVT 模式

#### 12.1.2 PVT 控制器的设计思路

PVT 控制器的核心思想是：**将位置控制和速度控制的结果作为反馈项，扭矩指令作为前馈项**，三者求和得到最终指令。

```
τ = Kp * (q_des - q) + Kd * (dq_des - dq) + τ_ff
  ↑         ↑           ↑                    ↑
最终力矩  位置PD项    速度PD项           扭矩前馈
```

代码实现位于 `PVT_ctrl.cpp` 的 `calMotorsPVT()` 方法（第 79-91 行）。

### 12.2 PD 控制与前馈

#### 12.2.1 控制律公式

PVT 控制器的核心公式为：

$$ \tau = K_p \cdot (q_{des} - q) + K_d \cdot (\dot{q}_{des} - \dot{q}) + \tau_{ff} $$

其中各符号含义：

| 符号 | 含义 | 来源 |
|------|------|------|
| $q_{des}$ | 期望关节位置 | WBC 输出 / 逆运动学 |
| $q$ | 当前关节位置 | 传感器反馈 |
| $\dot{q}_{des}$ | 期望关节速度 | WBC 输出 |
| $\dot{q}$ | 当前关节速度 | 传感器反馈 |
| $\tau_{ff}$ | 前馈力矩 | WBC 输出 |
| $K_p$ | 位置增益 | `joint_ctrl_config.json` 中的 `kp` |
| $K_d$ | 速度增益 | `joint_ctrl_config.json` 中的 `kd` |

代码实现（`PVT_ctrl.cpp` 第 83 行）：

```cpp
tauDes = PV_enable[i] * pvt_Kp[i] * (motor_pos_des[i] - motor_pos_cur[i])
       + PV_enable[i] * pvt_Kd[i] * (motor_vel_des[i] - motor_vel[i]);
```

之后再加上低通滤波后的前馈力矩（第 84 行）：

```cpp
tauDes = tau_out_lpf[i].ftOut(tauDes) + motor_tor_des[i];
```

#### 12.2.2 PD 参数设计原则

PD 参数决定了关节的动态响应特性。`joint_ctrl_config.json` 中为每个关节分别配置了 `kp` 和 `kd` 参数。

**表 12-1：各关节 PD 参数典型值**

| 关节 | kp | kd | 说明 |
|------|----|----|------|
| J_knee_l/r_pitch | 2000 | 200 | 膝关节，承受最大载荷，刚度最高 |
| J_waist_pitch/roll/yaw | 5000 | 800 | 腰部，需要高刚度维持上身稳定 |
| J_hip_l/r_pitch | 800 | 100 | 髋关节俯仰，中等刚度 |
| J_ankle_l/r_pitch | 1000 | 160 | 踝关节俯仰，较高刚度维持平衡 |
| J_ankle_l/r_roll | 600 | 100 | 踝关节滚转，比俯仰略低 |
| J_arm_l/r_01-02 | 800 | 40 | 肩关节，大臂 |
| J_arm_l/r_03 | 400 | 8 | 上臂旋转 |
| J_arm_l/r_04 | 600 | 60 | 肘关节 |
| J_arm_l/r_05-07 | 100-300 | 6-10 | 手腕，低刚度柔顺控制 |

设计原则：

1. **承载越大，刚度越高**：膝关节（kp=2000）> 髋关节（kp=800）> 手臂（kp=100-800）
2. **阻尼比匹配**：$K_d \approx 2\sqrt{K_p \cdot I}$（其中 $I$ 为关节转动惯量），通常 $K_d$ 取值在 $0.1 \sim 0.3 \times K_p$ 之间
3. **上半身柔顺**：手臂和手腕的刚度较低，便于与环境和物体进行安全交互

#### 12.2.3 前馈项的作用

前馈力矩项 $\tau_{ff}$ 来自 WBC 的输出，其作用有两方面：

1. **补偿动力学**：机器人运动时，关节需要克服科里奥利力、离心力和重力等动力学效应。WBC 通过动力学模型计算出这些补偿力矩，作为前馈项叠加到 PD 控制的输出上
2. **提高响应速度**：纯 PD 控制是"被动响应"——只有当位置偏差出现后才会产生纠正力矩。前馈力矩是"主动预测"——在偏差出现之前就施加正确的力矩，大幅提高动态响应速度

对比实验效果：

```
纯 PD 控制：          τ = Kp*e + Kd*ė
                    （偏差出现后才响应，有延迟）

PD + 前馈：          τ = Kp*e + Kd*ė + τ_ff
                    （前馈项提前补偿，响应更快）
```

#### 12.2.4 `joint_ctrl_config.json`：PD 参数配置文件

配置文件位置：`common/joint_ctrl_config.json`

每个关节的配置结构如下（以左膝为例）：

```json
"J_knee_l_pitch": {
    "PVT_LPF_Fc": 50,      // PVT 低通滤波器截止频率 (Hz)
    "kd": 200.0,            // 微分增益（速度增益）
    "kp": 2000.0,           // 比例增益（位置增益）
    "maxPos": 0.08727,      // 位置上限 (rad)
    "maxSpeed": 19.16,      // 速度上限 (rad/s)
    "maxTorque": 396.0,     // 力矩上限 (Nm)
    "minPos": -2.35619,     // 位置下限 (rad)
    "gear": 18.2            // 减速比
}
```

PVT 低通滤波器（`PVT_LPF_Fc`）用于滤除前馈力矩中的高频噪声，避免控制器输出过于剧烈的力矩变化。代码中通过 `tau_out_lpf[i]`（一阶低通滤波器）实现（`PVT_ctrl.cpp` 第 44-45 行）：

```cpp
tau_out_lpf[i].setPara(fc, timeStepIn);
tau_out_lpf[i].ftOut(0);
```

#### 12.2.5 动态 PD 参数调整

`walk_mpc_wbc.cpp` 第 208-214 行展示了在仿真运行中动态调整 PD 参数的用法：

```cpp
pvtCtr.setJointPD(100, 10, "J_ankle_l_pitch");
pvtCtr.setJointPD(100, 10, "J_ankle_l_roll");
pvtCtr.setJointPD(100, 10, "J_ankle_r_pitch");
pvtCtr.setJointPD(100, 10, "J_ankle_r_roll");
pvtCtr.setJointPD(1000, 100, "J_knee_l_pitch");
pvtCtr.setJointPD(1000, 100, "J_knee_r_pitch");
```

在仿真前 3 秒（初始站立阶段），使用较小的 PD 参数和位置增量限制（`calMotorsPVT(100.0/1000.0/180.0*3.1415)`）让机器人缓慢进入初始位置。3 秒后切换到较大的 PD 参数并解除增量限制，进入正常行走控制。

### 12.3 关节指令合成流程

#### 12.3.1 从 WBC 到 PVT 的完整链路

关节指令的合成从 WBC 输出开始，经过 PVT 计算，最终输出力矩：

```
WBC 输出：
  wbc_delta_q_final  ──→ 积分得到期望位置 q_des
  wbc_dq_final       ──→ 期望速度 dq_des
  wbc_tauJointRes    ──→ 前馈力矩 τ_ff
                                  │
                                  ▼
  DataBus 中转：
    motors_pos_des    ← q_des（关节位置部分 block 7:end）
    motors_vel_des    ← dq_des
    motors_tor_des    ← τ_ff
                                  │
                                  ▼
  PVT 控制器（dataBusRead → calMotorsPVT → dataBusWrite）：
    τ = Kp*(P_des - P_cur) + Kd*(V_des - V_cur) + τ_ff
                                  │
                                  ▼
  motors_tor_out ──→ setMotorsTorque() ──→ mj_data->ctrl
```

#### 12.3.2 PVT 计算详细过程

`calMotorsPVT()` 方法（`PVT_ctrl.cpp` 第 79-91 行）的完整流程：

1. **计算 PD 项**（第 83 行）：
   $$ \tau_{PD} = K_p \cdot (p_{des} - p_{cur}) + K_d \cdot (v_{des} - v_{cur}) $$

2. **低通滤波并叠加前馈**（第 84 行）：
   $$ \tau_{des} = LPF(\tau_{PD}) + \tau_{ff} $$

3. **力矩限幅**（第 85-86 行）：
   $$ \tau_{des} = \text{clip}(\tau_{des}, -\tau_{max}, \tau_{max}) $$

4. **考虑减速比**（第 87 行）：
   $$ \tau_{motor} = \tau_{des} / gear $$

有两种 PVT 计算模式：

- **`calMotorsPVT()`**：无限制模式，直接使用期望位置
- **`calMotorsPVT(double deltaP_Lim)`**：增量限制模式（第 94-110 行），每步最大位置增量受限，用于初始阶段的平滑到达

#### 12.3.3 力矩限幅与安全保护

力矩限幅在三个层级实施：

**层级 1：配置文件限幅**（`joint_ctrl_config.json` 中的 `maxTorque`）

```cpp
if (fabs(tauDes) >= fabs(maxTor[i]))
    tauDes = sign(tauDes) * maxTor[i];
```

**层级 2：MuJoCo 执行器限幅**（`AzureLoong.xml` 中的 `ctrlrange`）

```xml
<motor name="M_knee_l_pitch" joint="J_knee_l_pitch" gear="18.2"
       ctrllimited="true" ctrlrange="-21.7582 21.7582"/>
```

注意配置文件和 XML 中的限幅值通过减速比关联：`maxTorque / gear ≈ ctrlrange`。

**层级 3：位置限幅**（配置文件中的 `minPos` / `maxPos`）

位置限幅作用于 PVT 控制器的期望位置输入（增量限制模式），防止指令超出关节物理极限。

### 12.4 关节限位与安全保护

#### 12.4.1 位置限位：软限位与硬限位

**软限位**（代码层面）：通过 `calMotorsPVT(deltaP_Lim)` 的增量限制模式实现。该模式确保期望位置的变化率不超过设定值，从而防止关节超速。

**硬限位**（物理层面）：在 MuJoCo XML 中，每个关节都通过 `range` 属性定义了位置极限：

```xml
<joint name="J_knee_l_pitch" limited="true" range="-2.35619 0.08727"/>
```

当关节到达极限位置时，MuJoCo 的物理引擎会自动产生约束力阻止进一步运动。

#### 12.4.2 速度与力矩保护

速度保护通过配置文件的 `maxSpeed` 字段设定。当 PVT 控制器检测到期望速度超出限制时，会对其进行截断。

力矩保护如前所述，通过配置文件和 XML 的双重限幅实现。

#### 12.4.3 急停机制

`UIctr` 类提供了仿真暂停功能。在 `walk_mpc_wbc.cpp` 第 125 行：

```cpp
while (mj_data->time - simstart < 1.0 / 60.0 && uiController.runSim) {
```

当用户按下键盘的 `1` 键时，`runSim` 被置为 `false`，内循环停止执行，仿真暂停。再次按 `1` 键恢复运行。按下 `2` 键则单步执行一次 `mj_step()`，用于逐帧调试。

在实际机器人系统中，急停通常通过硬件或底层驱动器实现，上位机控制器负责检测异常状态并触发急停信号。

---

## 本章小结

第四部分（第 10-12 章）完整解析了 OpenLoong 机器人控制系统的集成方案：

- **第 10 章**从 `walk_mpc_wbc.cpp` 的主循环出发，揭示了 DataBus 数据总线的设计理念、Read-Calc-Write 模式、多速率同步机制，以及系统整体的模块化架构
- **第 11 章**深入 MuJoCo 仿真接口，说明了传感器读取、执行器指令下发、场景配置的方法，并解释了同时维护 URDF 和 MuJoCo XML 两套模型的原因
- **第 12 章**聚焦关节控制层，从 PVT 三级控制架构到 PD 参数设计，从前馈补偿到安全保护，完整覆盖了从高层算法到电机力矩输出的链路

三个章节共同构成了一个从算法到仿真、从高层到底层的完整知识体系，为读者理解双足机器人控制系统的工程实现提供了清晰的脉络。


---

# 第五部分：应用实践

---

## 第13章 运动示例详解

本章深入剖析 `demo/` 目录下的各运动示例，逐一拆解其核心控制逻辑。通过对比，理解不同控制器组合（纯 WBC、MPC+WBC）在不同场景下的设计思路。

### 13.1 纯 WBC 行走（walk_wbc）—— 最小可行示例

文件：`demo/walk_wbc.cpp`

**核心思想**：不依赖 MPC 提供前馈力，仅由 WBC 完成轨迹跟踪和力分配。这是理解 WBC 工作机制的最佳起点。

#### 13.1.1 代码结构：main() 函数简析

`walk_wbc.cpp` 的控制循环结构如下：

```
mj_step() → 传感器读取 → 数据写入DataBus → 运动学/动力学解算
  → 步态调度(GaitScheduler) → 落脚点规划(FootPlacement)
  → 设置WBC期望(des_dq, des_ddq, Fr_ff)
  → WBC解算(computeDdq → computeTau)
  → 关节指令集成(integrateDIY + PVT) → 力矩下发
```

关键初始化：

```cpp
// walk_wbc.cpp L24-42
mjModel* mj_model = mj_loadXML("../models/scene_board.xml", 0, error, 1000);
WBC_priority WBC_solv(kinDynSolver.model_nv, 18, 22, 0.7, mj_model->opt.timestep);
GaitScheduler gaitScheduler(0.4, mj_model->opt.timestep);
PVT_Ctr pvtCtr(mj_model->opt.timestep, "../common/joint_ctrl_config.json");
FootPlacement footPlacement;
JoyStickInterpreter jsInterp(mj_model->opt.timestep);
```

注意这里加载的是 `scene_board.xml`（带障碍板的场景），但该示例**没有**使用 MPC，纯靠 WBC 自身的力控鲁棒性跨越障碍。

#### 13.1.2 控制流：没有 MPC，只有 WBC

WBC 的核心输入由三部分组成：

```cpp
// walk_wbc.cpp L169-188
RobotState.Fr_ff = Eigen::VectorXd::Zero(12);
RobotState.des_ddq = Eigen::VectorXd::Zero(mj_model->nv);
RobotState.des_dq = Eigen::VectorXd::Zero(mj_model->nv);
RobotState.des_delta_q = Eigen::VectorXd::Zero(mj_model->nv);

// 前馈足端力（固定值）
RobotState.Fr_ff << 0, 0, 370, 0, 0, 0,
                    0, 0, 370, 0, 0, 0;

// 速度指令来自joystick interpreter
if (simTime > startWalkingTime + 1) {
    RobotState.des_delta_q.block<2, 1>(0, 0) << jsInterp.vx_W * dt, jsInterp.vy_W * dt;
    RobotState.des_dq.block<2, 1>(0, 0) << jsInterp.vx_W, jsInterp.vy_W;
    double k = 5;
    RobotState.des_ddq.block<2, 1>(0, 0) << k * (jsInterp.vx_W - RobotState.dq(0)),
                                             k * (jsInterp.vy_W - RobotState.dq(1));
}
```

- **前馈力 `Fr_ff`**：左右足各 370N 垂直力（约等于机器人自重的一半），是一个粗糙的估计值
- **期望位置增量 `des_delta_q`**：由摇杆速度 × 时间步长得到
- **期望速度 `des_dq`**：由摇杆速度直接设定
- **期望加速度 `des_ddq`**：由速度误差的比例反馈构成

WBC 接收到这些输入后，在 `computeDdq()` 中求解优先级任务 QP：

1. **StanceLeg（支撑腿）**：保持足端位置/姿态固定（优先级最高）
2. **SwingLeg（摆动腿）**：跟踪落脚点轨迹
3. **CoMTrack（质心轨迹）**：跟踪期望 CoM 位置
4. **HandTrackJoints（手臂运动）**：保持手臂姿态
5. **RedundantJoints（冗余关节）**：头、腰归零

#### 13.1.3 与 MPC+WBC 模式的区别

| 特性 | 纯 WBC (walk_wbc) | MPC+WBC (walk_mpc_wbc) |
|------|------------------|----------------------|
| 前馈力 | 固定值（凭经验设定） | MPC 优化计算 |
| 期望轨迹 | 简单的比例-微分 | MPC 预测未来 N 步 |
| 抗扰动能力 | 依赖 WBC 快速调节 | MPC 提前规划补偿 |
| 计算开销 | 低（~1kHz 可运行） | 高（需 200Hz MPC + 1kHz WBC） |
| 参数调节 | 较少 | 较多（MPC 权重矩阵） |

纯 WBC 模式虽然朴素，但对于理解 WBC 的工作原理至关重要——读者可先掌握这个最小示例，再过渡到 MPC+WBC 模式。

---

### 13.2 MPC+WBC 行走与盲踩障碍（walk_mpc_wbc）

文件：`demo/walk_mpc_wbc.cpp`

这是仓库中最核心的示例，完整展示了 MPC + WBC 双层控制架构。

#### 13.2.1 核心示例：MPC 提供前馈力 + 期望轨迹，WBC 精确跟踪

MPC 工作于 200Hz（每 5ms 一次），WBC 工作于 1kHz（每 1ms 一次）。

```cpp
// walk_mpc_wbc.cpp L27-28
const double dt = 0.001;          // WBC 周期
const double dt_200Hz = 0.005;    // MPC 周期
```

MPC 采用**单刚体模型（Single Rigid Body Model, SRBM）**，将机器人简化为一个具有惯量的刚体，四肢仅提供足端力。SRBM 的状态向量为 12 维：

```
X = [roll, pitch, yaw, pCoM_x, pCoM_y, pCoM_z, ω_x, ω_y, ω_z, vCoM_x, vCoM_y, vCoM_z]^T
```

控制量为双足足端力（每足 6 维力 + 1 标量，共 13 维）：

```
U = [fL_x, fL_y, fL_z, τL_x, τL_y, τL_z, fR_x, fR_y, fR_z, τR_x, τR_y, τR_z, α]^T
```

其中 α 是虚拟变量。

MPC 的优化问题为：

```
min Σ (X_k - Xd_k)^T L (X_k - Xd_k) + U_k^T K U_k
s.t. 动力学约束（SRBM）、摩擦锥约束、足端力范围
```

在控制循环中，MPC 每 5 步（即 5ms）求解一次 QP 问题：

```cpp
// walk_mpc_wbc.cpp L256-262
MPC_count = MPC_count + 1;
if (MPC_count > (dt_200Hz / dt - 1)) {
    MPC_solv.dataBusRead(RobotState);
    MPC_solv.cal();    // 求解 QP
    MPC_count = 0;
}
```

当 MPC 启用时，其计算的 `fe_react_tau_cmd` 会写入 `RobotState`，WBC 读取后将其作为前馈力和期望状态。`walk_mpc_wbc.cpp` 中的权重设置：

```cpp
// L302-312
L_diag << 1.0, 1.0, 1.0,       // eul
          1e-3, 100.0, 1.0,   // pCoM
          1e-3, 1e-3, 1e-3,   // ω
          1, 100.0, 1.0;      // vCoM
K_diag << 1.0, 1.0, 1.0,     // fL
          1.0, 1, 1.0,
          1.0, 1.0, 1.0,     // fR
          1.0, 1.0, 1.0, 1.0;
MPC_solv.set_weight(1e-6, L_diag, K_diag);
```

**关键解读**：`L_diag` 中 `pCoM_z` 权重为 100.0（CoM 高度控制严格），`vCoM_x` 权重为 1（速度跟踪较松），`yaw` 权重仅 1e-3（弱约束）。这组权重的物理含义是：**优先保持机器人站立高度，速度跟踪适度即可**。

#### 13.2.2 盲踩障碍的原理：MPC 预测模型"看不到"障碍

`walk_wbc.cpp` 和 `walk_mpc_wbc.cpp` 均加载 `models/scene_board.xml`，该场景在平坦地面上放置了三个倾斜的薄板：

```xml
<!-- scene_board.xml L22-24 -->
<geom type="box" size=".3 .6 .02" pos="1 0.4 .025" material="block" euler="0 0 0.5"/>
<geom type="box" size=".3 .6 .02" pos="3 0.4 .025" material="block" euler="0 0 -0.3"/>
<geom type="box" size=".3 .6 .02" pos="5 0.4 .025" material="block" euler="0 0 0.2"/>
```

这些障碍板的高度仅 2cm，但带有偏航角。

**盲踩的技术要点**：

1. MPC 的 SRBM 预测模型**不包含地面高度变化**的信息，即"看不到"障碍
2. WBC 的支撑腿任务强制足端接触地面（通过接触约束），当足端踏上障碍板时，接触点高度自然变化
3. WBC 通过足端力反馈和位置修正，自动适应接触面的高度变化
4. 由于障碍板较薄（2cm），高度变化在 WBC 的跟踪带宽内，无需显式检测障碍

换言之，"盲踩"并非魔法——它依赖于 WBC 的高带宽力控和地形变化的幅值在系统适应能力范围内。如果障碍高度过大（>5cm），纯盲踩就会失效，需要引入视觉或足底力传感器的地形感知。

#### 13.2.3 scene_board.xml 中的障碍物配置

`scene_board.xml` 在标准场景 `scene.xml` 的基础上增加了三个 box geom。材质 `material="block"` 使用了纹理 `asset/block.png`，并设置 `reflectance="0"`（无反射，即摩擦力不特殊处理）。尺寸上每个板子宽 0.6m（沿 y 轴），保证机器人双脚都能踩到。

---

### 13.3 MPC 跳跃（jump_mpc）

文件：`demo/jump_mpc.cpp`

跳跃控制是全身运动控制中难度最高的场景之一，涉及爆发力输出、空中姿态保持和落地缓冲三个阶段。

#### 13.3.1 跳跃控制的特殊挑战

与行走相比，跳跃的三个核心难点：

| 挑战 | 描述 | 解决方案 |
|------|------|---------|
| 爆发力 | 需要短时间内输出远大于体重的足端力 | MPC 中 CoM 高度、速度权重加大 |
| 空中姿态 | 腾空后足端离地，仅靠角动量控制姿态 | 切换为纯 PVT 位置控制（MPC 禁用） |
| 落地缓冲 | 冲击力大，易失稳 | 足端力反馈触发状态切换，落地后 MPC 重新介入 |

#### 13.3.2 MPC 如何规划跳跃轨迹？

`jump_mpc.cpp` 将跳跃分为 4 个阶段（`jump_state` 状态机）：

```
prepare (0→prepareTime) → squat (prepareTime→startJumpingTime)
→ jump&flight (jump_state=0→3→4) → land&recover (jump_state=5)
```

**下蹲阶段（`simTime < startJumpingTime`）**：

```cpp
// jump_mpc.cpp L137-151
fe_l_pos_L_des(2) = Ramp(fe_l_pos_L_des(2), stand_z, 0.1 * dt);
fe_r_pos_L_des(2) = Ramp(fe_r_pos_L_des(2), stand_z, 0.1 * dt);
```

足端相对基座高度从 -1.01 缓慢下降到 `stand_z = -0.8`，即机器人下蹲约 21cm。此阶段仅用 IK + PVT，MPC 未激活。

**起跳阶段（`jump_state == 0`）**：

```cpp
// jump_mpc.cpp L161-202
double jump_vel_des[3] = {0.0, 0.0, sqrt(2.0 * 9.8 * jump_z)};
// jump_z = 0.2m → 起跳速度 ≈ 1.98 m/s
double jump_acc_t = 2.0 * (0.9 + stand_z) / (jump_vel_des[2]);
```

MPC 在起跳瞬间启用，权重矩阵显著变化：

```cpp
// jump_mpc.cpp L168-180
L_diag << 50.0, 50.0, 1.0,   // eul（姿态严格跟踪）
          50.0, 50.0, 200.0, // pCoM（高度权重最大）
          0.1, 0.1, 0.1,     // ω（宽松）
          0.01, 0.1, 20.0;   // vCoM（垂向速度严格）
```

对比行走时的权重：跳跃时 `pCoM_z` 权重 200（vs 行走的 100），`vCoM_z` 权重 20（vs 行走的 1），这反映了跳跃对垂直爆发力的更高要求。

**空中阶段（`jump_state == 3`）**：

MPC 禁用，切换为纯位置控制——这是关键设计。因为腾空后足端不再接触地面，MPC 的 SRBM 模型（依赖地反力）不再适用。足端在体坐标系下向回收缩，准备落地：

```cpp
// jump_mpc.cpp L203-230
fe_l_pos_W_des[2] = Ramp(fe_l_pos_W_des[2], stand_z, 5.0 * dt);
```

足端在世界的 z 坐标快速回到下蹲高度。同时通过 `pvtCtr.enablePV()` 启用位置-速度控制模式（禁用前馈力矩）。

**落地缓冲阶段（`jump_state == 4 → 5`）**：

落地检测通过估计的足端接触力实现：

```cpp
// jump_mpc.cpp L254
if (FLest(2) > 1000 && FRest(2) > 1000) {
    jump_state = 5;
    // MPC 重新启用，权重改为缓冲模式
}
```

检测到双足着地力均 > 1000N 后，MPC 重新启用，但权重矩阵切换为缓冲模式：

```cpp
// jump_mpc.cpp L272-281
L_diag << 2.0, 10.0, 1.0,     // eul
          100.0, 100.0, 200.0, // pCoM
          1e-4, 1e-4, 1e-4,   // ω（几乎不约束角速度）
          0.5, 0.01, 0.5;     // vCoM
```

此时 `pCoM_z` 仍保持 200 的高权重以吸收冲击，但角速度权重降至 1e-4（允许机体有一定晃动来缓冲）。

#### 13.3.3 起跳-腾空-落地三个阶段的分析

总结跳跃的三个阶段控制模式：

| 阶段 | MPC | WBC | 关节控制 | 关键信号 |
|------|-----|-----|---------|---------|
| 下蹲 | 禁用 | 未启用 | 纯 IK + PVT | 足端位置斜坡 |
| 起跳 | 启用（高权重） | 未启用 | MPC 计算力矩直接下发 | 足端力优化 |
| 腾空 | 禁用 | 未启用 | 纯 PVT 位置控 | 足端回收 |
| 落地 | 启用（缓冲权重） | 未启用 | MPC + PVT | 足端力 > 1000N 触发 |

值得注意的是，跳跃示例中**没有使用 WBC**——这与其他示例不同。MPC 计算的足端反作用力通过雅可比映射直接转换为关节力矩：

```cpp
// jump_mpc.cpp L298-312
Uje = Jac_stand.transpose() * (-1.0) * RobotState.fe_react_tau_cmd.block<nu - 1, 1>(0, 0);
for (int i = 0; i < 12; i++) {
    pvtCtr.disablePV(model_nv-6-12 + i);
    RobotState.motors_tor_des[model_nv-6-12 + i] = Uje(i);
}
```

---

### 13.4 摇杆交互控制

文件：`demo/walk_wbc_joystick.cpp` 和 `demo/walk_mpc_wbc_joystick.cpp`

这两个文件分别在纯 WBC 和 MPC+WBC 的基础上增加了实时摇杆交互。

#### 13.4.1 交互方式

两个示例均通过键盘按键模拟摇杆输入（在 `GLFW_callbacks.h` 中实现 `UIctr::getButtonState()`）：

| 按键 | 功能 |
|------|------|
| Space | 启动/停止行走（切换 Walk/Stand 状态） |
| W | 加速前进 |
| S | 减速至停止 |
| A | 左转（yaw 正方向） |
| D | 右转（yaw 负方向） |
| H | 重置摇杆位置 |

#### 13.4.2 joystick_interpreter 的原理

文件：`algorithm/joystick_interpreter.h` 和 `algorithm/joystick_interpreter.cpp`

`JoyStickInterpreter` 的核心是一个加速度-速度-位置三层的斜坡轨迹生成器。

```cpp
// joystick_interpreter.h
class JoyStickInterpreter {
public:
    double vx_W{0.0}, vy_W{0.0}, vz_W{0.0}; // World 系速度
    double px_W{0.0}, py_W{0.0}, pz_W{0.0}; // World 系位置
    double vx_L{0.0}, vy_L{0.0}, wz_L{0.0}; // 体坐标系速度
    
    RampTrajectory vxLGen, vyLGen, wzLGen, thetazGen;
};
```

工作流程：

```
每次调用 step()：
  1. RampTrajectory 根据设定的目标值和到达时间，生成平滑的期望值
  2. 体坐标系速度 vx_L, vy_L, wz_L → 结合 thetaZ → 转换为世界坐标系 vx_W, vy_W
  3. 积分得到世界坐标系位置 px_W, py_W
  4. thetaZ 由单独的轨迹生成器 thetazGen 管理
```

`setVxDesLPara(目标速度, 过渡时间)` 和 `setWzDesLPara(目标角速度, 过渡时间)` 用于设定目标。`RampTrajectory ` 类在手，可以实现从当前值到目标值的平滑过渡，避免了速度突变引起的机器人抖动。

方法 `dataBusWrite(DataBus &dataBus)` 将生成的期望状态写入 `RobotState` 的相关字段：

```cpp
// 写入的内容
RobotState.js_pos_des(0) = px_W;   // 期望 x 位置
RobotState.js_pos_des(1) = py_W;   // 期望 y 位置
RobotState.js_pos_des(2) = pz_W;   // 期望 z 位置（需外部设置）
RobotState.js_eul_des(2) = thetaZ; // 期望偏航角
```

**与 WBC 的衔接**：WBC 读取 `RobotState.js_pos_des` 和 `RobotState.js_eul_des` 作为 `base_pos_des` 和 `base_rpy_des`（加上从 MPC 获取的加速度/速度期望），构成完整的全身目标。

---

### 13.5 楼梯行走（walk_wbc_staircase）

文件：`demo/walk_wbc_staircase.cpp`、`models/scene_staircase.xml`

#### 13.5.1 楼梯场景的特殊需求

`scene_staircase.xml` 构造了一个从 0m 逐渐上升到 2.7m 的楼梯：

```xml
<!-- scene_staircase.xml L22-50 -->
<geom type="box" size="1.0 2 .01" pos="0.5 0.4 .0"/>   <!-- 起始平台 -->
<geom type="box" size="0.5 2 .05" pos="1 0.4 .0"/>     <!-- 每级台阶宽 1m、高递增 0.05m  -->
<geom type="box" size="0.5 2 .1"  pos="1.5 0.4 .0"/>
<!-- ... 共 27 级台阶，最后一级高 1.4m -->
<geom type="box" size="1.0 2 1.4" pos="15 0.4 .0"/>
```

台阶高度从 0.05m 逐步递增到 1.4m（最后一级是顶部平台），每级台阶宽 0.5m（x 方向）。

#### 13.5.2 落脚点规划如何适应楼梯？

楼梯行走的关键在于 **落脚点高度主动抬升**。与平地行走不同，楼梯场景中 `FootPlacement` 的 `stepHeight` 参数设得非常高：

```cpp
// walk_wbc_staircase.cpp L53
footPlacement.stepHeight = 0.4;  // 相比之下平地仅 0.12
```

但光靠摆腿高度还不够，还需要主动检测台阶高度。该示例采用了一种简单而有效的策略：**利用 WBC 的力控鲁棒性，让足端自然地"探索"台阶高度**。WBC 的支撑腿任务强制足端接触地面，当摆动腿落下时，如果碰到台阶，接触自然发生，WBC 会将该足切换为支撑腿。

此外，期望的基座高度也做了适应性调整：

```cpp
// walk_wbc_staircase.cpp L176-181
RobotState.base_pos_des(2) = stand_legLength + foot_height
                             + (RobotState.basePos[0] - 0.025) * 0.1;
// 随前进距离 x 增加，基座高度线性增加（坡度 0.1）
```

这一简单的斜坡补偿使得机器人在逐步上升的楼梯上保持基座水平，避免了基座相对楼梯"下陷"。

**注意事项**：该示例对楼梯起始位置敏感。若机器人起始位置偏离 `x=0.025`，需要相应地调整补偿公式。

---

### 13.6 浮动基座控制（float_control）

文件：`demo/float_control.cpp`、`models/scene_float.xml`

#### 13.6.1 浮动基座 vs 固定基座

之前的示例中，机器人通过 `scene_board.xml` 或 `scene_staircase.xml` 加载，基座（base_link）通过 `freejoint` 与地面连接——这是**浮动基座（Floating Base）**模式。但在 `walk_wbc.cpp` 等示例中，机器人始终在地面上行走，基座虽然没有固定，但受重力影响约束在地面附近。

`float_control.cpp` 则完全不同——它加载 `scene_float.xml`，该场景**没有地面**。机器人在自由空间中浮动，仅受重力影响。

#### 13.6.2 自由落体/姿态控制

该示例的实现极为简洁——**仅使用 IK + PVT 控制**：

```cpp
// float_control.cpp 核心循环
// 1. 固定足端和手部的期望位置/姿态（体坐标系）
fe_l_pos_L_des << -0.018, 0.0937, -stand_legLength;
fe_r_pos_L_des << -0.018, -0.0952, -stand_legLength;
// ... 固定手部姿态 ...

// 2. 逆运动学求解关节角
resLeg  = kinDynSolver.computeInK_Leg(...);
resHand = kinDynSolver.computeInK_Hand(...);

// 3. PVT 执行关节位置跟踪
RobotState.motors_pos_des = eigen2std(resLeg.jointPosRes + resHand.jointPosRes);
pvtCtr.calMotorsPVT();
```

**为什么不需要 WBC 或 MPC？** 浮动基座场景中没有任何接触约束，机器人仅需保持自身姿态和足端位置。IK 可以直接将足端位姿映射为关节角，PVT 跟踪即可。WBC 的任务优先级框架在无接触的情况下反而冗余。

浮动基座控制的应用场景包括：

- 水下机器人控制
- 太空/微重力环境
- 自由落体中的姿态修正
- 弹跳/跳跃的空中阶段

---

### 13.7 各示例的完整控制流对比表

| 示例文件 | 场景 | MPC | WBC | GaitScheduler | FootPlacement | 摇杆交互 | 核心控制方式 |
|---------|------|-----|-----|---------------|---------------|---------|------------|
| `walk_wbc.cpp` | scene_board（带障碍） | ✗ | ✓ | ✓ | ✓ | ✗(自动) | WBC 力控 |
| `walk_mpc_wbc.cpp` | scene（平地） | ✓ | ✓ | ✓ | ✓ | ✗(自动) | MPC 前馈 + WBC 跟踪 |
| `walk_wbc_joystick.cpp` | scene_board（带障碍） | ✗ | ✓ | ✓ | ✓ | ✓(键盘) | WBC 力控 + 交互 |
| `walk_mpc_wbc_joystick.cpp` | scene（平地） | ✓ | ✓ | ✓ | ✓ | ✓(键盘) | MPC + WBC + 交互 |
| `walk_wbc_staircase.cpp` | scene_staircase（楼梯） | ✗ | ✓ | ✓ | ✓ | ✓(键盘) | WBC + 基座高度补偿 |
| `jump_mpc.cpp` | scene（平地） | ✓ | ✗ | ✗ | ✗ | ✗ | MPC 力矩直接映射 |
| `float_control.cpp` | scene_float（无地面） | ✗ | ✗ | ✗ | ✗ | ✗ | IK + PVT |
| `walk_wbc_speed_test.cpp` | 无仿真 | ✗ | ✓ | ✓ | ✓ | ✗ | 纯计算性能测试 |

从表中可以清晰看出设计模式：

- **行走类示例**：遵循"步态调度 → 落脚点规划 → WBC 跟踪"的通用框架，MPC 作为可选项（有则更平滑，无则更简单）
- **特殊场景**（跳跃、浮动基座）：打破通用框架，针对特定物理需求定制控制流
- **摇杆交互**：增加的用户交互层不影响底层控制架构

---

## 第14章 调试、分析与优化

运动控制系统的开发离不开反复的调试和数据分析。本章介绍 OpenLoong 框架提供的工具和方法论。

### 14.1 数据记录器（DataLogger）使用

文件：`common/data_logger.h`、`common/data_logger.cpp`

#### 14.1.1 record/ 目录下的记录文件

`DataLogger` 基于 [Quill](https://github.com/odygrd/quill) 高性能日志库实现。它在 `record/` 目录下生成两类文件：

| 文件 | 用途 |
|------|------|
| `record/datalog.log` | 二进制格式的记录数据（数值矩阵） |
| `record/matlabReadDataScript.txt` | 自动生成的 Matlab 读取脚本 |

每次仿真运行时，数据会被逐行记录至 `datalog.log`。每一行对应一个仿真步长的时间戳，各变量按列排列。

#### 14.1.2 如何开启数据记录？

在每个 demo 的 `main()` 中，数据记录的启用分为三步：

**第一步：初始化 Logger**

```cpp
DataLogger logger("../record/datalog.log");
```

**第二步：注册变量**

```cpp
logger.addIterm("simTime", 1);          // 标量
logger.addIterm("motors_pos_cur", 31);  // 31 维向量
logger.addIterm("rpy", 3);              // 3 维向量
logger.finishItermAdding();
```

`addIterm` 的第二个参数是变量的维度。`finishItermAdding()` 会在 `record/` 目录下自动生成 `matlabReadDataScript.txt`，其中包含了每个变量对应的列范围。

**第三步：循环中记录**

```cpp
logger.startNewLine();
logger.recItermData("simTime", simTime);
logger.recItermData("motors_pos_cur", RobotState.motors_pos_cur);
logger.recItermData("rpy", RobotState.rpy);  // 接收 double[3] 指针
logger.finishLine();
```

`finishLine()` 会检查所有已注册的变量是否都已被记录——如果有遗漏，会打印警告并抛出异常。

### 14.2 Matlab 数据分析与可视化

`record/` 目录下的 `.m` 脚本可以直接用于数据分析。

#### 14.2.1 使用自动生成的脚本

`walk_mpc_wbc_joystick.cpp` 运行后，`record/matlabReadDataScript.txt` 会自动生成如下内容：

```matlab
clear variables; close all
dataRec=load('datalog.log');
dyn_time=dataRec(:,1:1);
motors_pos_cur=dataRec(:,2:32);
motors_pos_des=dataRec(:,33:63);
motors_tor_cur=dataRec(:,64:94);
motors_tor_des=dataRec(:,95:125);
motors_tor_out=dataRec(:,126:156);
motors_vel_des=dataRec(:,157:187);
motors_vel_cur=dataRec(:,188:218);
FL_est=dataRec(:,219:221);
FR_est=dataRec(:,222:224);
wbc_FrRes=dataRec(:,225:236);
base_pos_des=dataRec(:,237:239);
base_pos=dataRec(:,240:242);
base_pos_est=dataRec(:,243:245);
baseLinVel=dataRec(:,246:248);
base_vel_est=dataRec(:,249:251);
base_rpy=dataRec(:,252:254);
eul_est=dataRec(:,255:257);
Ufe=dataRec(:,258:270);
legState=dataRec(:,271:271);
motionState=dataRec(:,272:272);
```

这个脚本可以直接在 Matlab 中运行，将所有变量加载到工作区。

#### 14.2.2 `plotData.m` 绘图脚本

文件：`record/plotData.m`

对于跳跃示例（`jump_mpc.cpp`），`plotData.m` 提供了以下可视化：

1. **关节角度对比图**：绘制所有关节的期望角度 vs 实际角度（线性图）
2. **关节力矩对比图**：力矩指令 vs 实际输出力矩
3. **足端接触力**（Ufe）：12 个足端力/力矩分量的时间历程
4. **足端位置轨迹**：足端在世界坐标系中的位置变化

建议的调试流程：

1. 运行一次仿真，产生 `datalog.log`
2. 在 Matlab 中运行 `matlabReadDataScript.txt`（或直接执行自动生成的脚本）
3. 使用 `plotData.m` 快速查看关键曲线
4. 如果发现问题，在代码中增加 `logger.addIterm()` 注册新的调试变量
5. 迭代

#### 14.2.3 常用分析指标

| 指标 | 如何计算（Matlab） | 用途 |
|------|-------------------|------|
| 关节跟踪误差 | `motors_pos_cur - motors_pos_des` | 判断 WBC/PVT 跟踪性能 |
| CoM 高度波动 | `std(base_pos(:,3))` | 评估行走平稳性 |
| 足端力震荡 | `std(diff(Ufe))` | 检测力控震荡 |
| 偏航角偏差 | `base_rpy(:,3) - eul_est(:,3)` | 评估状态估计精度 |
| 计算耗时 | `datalog.log` 最后一列 `runTime` | 评估实时性 |

### 14.3 参数调优方法论

参数调优是全身运动控制中最花时间的环节。以下是从物理直觉出发的调参路线。

#### 14.3.1 调参顺序：由粗到精

推荐按照 **稳定性 → 跟踪精度 → 能量效率** 的顺序进行：

```
第1层：稳定性（机器人不倒）
  ├── PVT 关节 PD 参数
  ├── 前馈足端力 Fr_ff
  └── 基座期望高度

第2层：跟踪精度（行走质量）
  ├── WBC 任务优先级权重
  ├── WBC 任务 PD 增益
  └── FootPlacement 参数

第3层：能量效率（经济性）
  ├── MPC 权重矩阵 L_diag / K_diag
  ├── 摆腿轨迹
  └── 步长/步频
```

**不要一次调多个参数**。每一步只改一个参数，观察效果，记录结果。

#### 14.3.2 MPC 参数调优

MPC 的核心调优参数是权重矩阵 `L_diag`（状态跟踪权重）和 `K_diag`（控制量权重）。

文件位置：各 demo 中调用 `MPC_solv.set_weight(alpha, L_diag, K_diag)` 的位置。

**L_diag 分量含义**（12 维）：

| 索引 | 物理量 | 增大效果 | 减小效果 |
|------|--------|---------|---------|
| 0-2 | roll, pitch, yaw | 姿态更硬，抗倾斜强 | 姿态跟随松，晃动大 |
| 3-5 | pCoM_x, pCoM_y, pCoM_z | 质心位置严格跟踪 | 质心偏移容忍大 |
| 6-8 | ω_x, ω_y, ω_z | 角速度抑制强 | 允许快速转向 |
| 9-11 | vCoM_x, vCoM_y, vCoM_z | 速度跟踪严格 | 速度波动容忍大 |

**K_diag 分量含义**（13 维，前 6 为左足力/力矩，后 6 为右足力/力矩，最后 1 为虚拟变量）：

增大 `K_diag` 会使 MPC 输出的足端力更小（更"懒惰"），但跟踪效果会变差。一个常用的直觉是：**行走时 K_diag 取 1.0，跳跃时取 0.1（允许更大出力）**。

**α 参数**：`set_weight` 的第一个参数，用于整体缩放控制量惩罚。典型值 1e-6。增大 α 会使所有足端力变小。

**实际调优示例**：

```cpp
// 保守行走（步态稳健）
L_diag << 10.0, 10.0, 5.0,     // eul（姿态严格）
          1e-3, 100.0, 10.0,   // pCoM（高度严格，xy宽松）
          1e-3, 1e-3, 1e-3,   // ω
          0.1, 0.1, 5.0;      // vCoM

// 快速行走（机动性强）
L_diag << 1.0, 1.0, 0.1,      // eul（姿态宽松）
          1e-3, 1.0, 1.0,     // pCoM
          1e-3, 1e-3, 1e-3,   // ω
          10.0, 10.0, 1.0;    // vCoM（速度跟踪严格）
```

#### 14.3.3 WBC 参数调优

WBC 的核心参数在 `algorithm/wbc_priority.cpp` 中。

**任务优先级**：在 `computeDdq()` 中定义的任务顺序就是优先级顺序。当前实现中：

```
优先级从高到低：
  1. static_Contact（足端接触约束）
  2. HipRPY（髋关节姿态）
  3. Pz（基座高度）
  4. CoMTrack（质心跟踪）
  5. CoMXY_HipRPY（水平质心 + 髋姿态）
  6. HandTrackJoints（手臂跟踪）
  7. HeadRP（头部姿态）
  8. fixedWaist（腰部固定）
  9. RedundantJoints（冗余关节归零）
```

如果某一优先级任务与更高优先级任务冲突，冲突部分会被投影到高优先级任务的零空间中。

**调优建议**：

- **足端接触严格性**：`static_Contact` 的 `kp/kd` 决定支撑腿足端是否漂移。建议 `kp=1000, kd=100` 起步
- **基座高度**：`Pz` 任务的权重影响机器人是否"塌腰"。如果发现机器人越来越矮，增大 `kp`
- **手臂摆动**：`HandTrackJoints` 的 PD 增益影响手臂是否僵硬。行走时较低的增益允许手臂自然摆动，跳跃时需要高增益保持手臂姿态

### 14.4 常见问题排查

#### 14.4.1 仿真发散怎么办？

**现象**：仿真运行几秒后机器人剧烈抖动或"爆炸"。

**排查步骤**：

1. **检查时间步长**：`mj_model->opt.timestep` 是否合理？MuJoCo 默认 0.5ms~1ms，如果控制周期 > 5ms 可能导致离散化不稳定
2. **降低 PD 增益**：将 `pvtCtr.setJointPD` 中的 kp/kd 统一除以 2，看是否缓解
3. **检查前馈力 `Fr_ff`**：`walk_wbc.cpp` L184 中固定值 370N 是否匹配实际重量？如果超过实际重量 50% 以上，可能导致足端力过大
4. **检查 WBC 任务权重**：`RedundantJoints` 的零空间权重如果过大，会压制高优先级任务
5. **QP 求解失败**：检查控制台是否输出 `qp_status != 0` 的警告

#### 14.4.2 机器人摔倒的原因分析

| 现象 | 可能原因 | 检查方向 |
|------|---------|---------|
| 向前扑倒 | 前进速度过快 / CoM 超前于支撑区 | 降低 `xv_des`，增大 `footPlacement.kp_vx` |
| 向后摔倒 | 起步时速度变化太剧烈 | 增加 `startWalkingTime` 前摇时间 |
| 侧向倾倒 | yaw 控制不稳 / 步宽不足 | 检查 `width_hips`，降低 `wz_des` |
| 下蹲越来越低 | Pz 任务增益不足 / 前馈力不够 | 增大 WBC 中 Pz 任务的 kp |
| 膝盖打弯异常 | 关节限位被触发 | 检查 `joint_ctrl_config.json` 中的 `maxPos` / `minPos` |

#### 14.4.3 QP 求解失败的处理

MPC 和 WBC 都依赖 qpOASES 求解二次规划问题。当 QP 求解失败时：

1. **检查控制台输出**：`qpStatus_MPC` 或 `qp_status` 是否为 0（0 表示成功）
2. **常见原因**：
   - 摩擦锥约束过紧（降低 `miu` 值）
   - 足端力上下界不合理（检查 `max[6]` / `min[6]`）
   - 状态估计异常（足端位置跳变导致约束冲突）
3. **临时对策**：增大 `nWSR`（最大迭代次数）或 `cpu_time`（求解时间上限）
4. **根本对策**：检查状态估计是否正确，或者放松约束边界

---

# 第六部分：扩展与展望

---

## 第15章 自定义机器人适配

OpenLoong 运动控制框架不仅适用于 AzureLoong 机器人，也支持其他双足/人形机器人。本章介绍适配自定义机器人的完整流程。

### 15.1 模型文件准备

#### 15.1.1 URDF 生成工具推荐

框架使用 [Pinocchio](https://github.com/stack-of-tasks/pinocchio) 进行运动学和动力学解算，需要 URDF 格式的模型描述。推荐以下方式生成 URDF：

| 工具 | 适用场景 | 备注 |
|------|---------|------|
| SolidWorks → SW2URDF 插件 | 已有 SolidWorks 模型 | 最常用，可导出惯量参数 |
| Onshape → Onshape-to-robot | 使用 Onshape 设计 | 自动生成 URDF + meshes |
| Fusion 360 → Fusion2URDF | 使用 Fusion 360 | 类似 SW2URDF |
| 手动编写 | 简单模型 | 不推荐用于复杂机器人 |

生成 URDF 后放置于 `models/` 目录下。

#### 15.1.2 网格文件（STL）的获取

MuJoCo 仿真需要 STL 格式的碰撞网格。URDF 导出工具通常会自动导出 STL 文件。需要注意：

- STL 文件应放置于 `models/meshes/` 目录
- URDF 中的 `<mesh filename="...">` 路径应指向 `meshes/`（相对路径）
- 建议**保留原模型名称**，避免修改 `MJ_interface.h` 中的传感器名称

### 15.2 参数调整指南

#### 15.2.1 质量、惯量、关节限位

URDF 中的质量/惯量参数通常从 CAD 软件直接导出，但仍需检查：

- **总质量**：影响前馈力 `Fr_ff` 和 MPC 中的 `m`（机器人质量）。`walk_wbc.cpp` L184 的 `370N` 对应约 37.7kg 腿重。如果机器人总重不同，需按比例调整
- **关节限位**：`joint_ctrl_config.json` 中的 `maxPos` / `minPos` 需与 URDF 一致。限位设置太松可能导致关节反转，太紧会限制运动范围
- **惯量**：若机器人动态与实际差距大，检查 `balanceinertia` 设置。MuJoCo 的 XML 编译选项中 `balanceinertia="true"` 可以自动平衡惯性张量

#### 15.2.2 PD 参数重新整定

每个机器人的关节 PD 参数不同，需要重新整定。文件 `common/joint_ctrl_config.json` 存储了所有关节的 PD 参数和限位：

```json
{
   "J_knee_l_pitch": {
      "kp": 2000.0,
      "kd": 200.0,
      "maxPos": 0.08727,
      "minPos": -2.35619,
      "maxSpeed": 19.16,
      "maxTorque": 396.0,
      "gear": 18.2
   }
}
```

**PD 整定经验法则**：

1. **膝关节（负重最大）**：`kp` 最高，2000 起；`kd` 约 kp/10
2. **踝关节（平衡关键）**：`kp` 中等，600~1000；`kd` 约 kp/6~kp/10
3. **髋关节（大幅运动）**：`kp` 中等，800 左右
4. **手臂关节（轻载）**：`kp` 较低，100~800
5. **腰部关节（承上启下）**：`kp` 非常高，5000（需要极高的刚度保持躯干水平）

在仿真中整定的 PD 参数移植到实物时，通常需要**降低 50%~70%**（仿真中忽略了许多非线性因素，如摩擦力、柔性、延迟等）。

### 15.3 Tutorial.md 模型替换实战

文件：`Tutorial.md`

仓库自带的 `Tutorial.md` 提供了详尽的模型替换指导。这里提炼其中的关键步骤：

#### 步骤一：替换 URDF

```cpp
// 在 demo 文件中修改：
Pin_KinDyn kinDynSolver("../models/your_robot.urdf");
```

#### 步骤二：替换 MuJoCo XML

```cpp
// 修改加载的 XML 文件：
mjModel* mj_model = mj_loadXML("../models/your_scene.xml", 0, error, 1000);
```

#### 步骤三：更新关节名称映射

由于框架通过字符串名称访问关节，需要更新以下文件中的关节名称列表：

| 文件 | 需修改的内容 |
|------|-------------|
| `common/MJ_interface.h` | `JointName` 数组——关节名称到 MuJoCo ID 的映射 |
| `algorithm/pino_kin_dyn.h` | `motorName` 数组——pinocchio 中关节名的索引 |
| `common/PVT_ctrl.h` | `motorName` 数组——PVT 控制器的关节索引 |
| `common/joint_ctrl_config.json` | 关节 PD 参数配置 |

#### 步骤四：更新算法中的关节索引

`wbc_priority.cpp` 中包含大量基于关节索引的硬编码（如 L178-L285）：

```cpp
// 如果您的机器人关节顺序不同，需要更新所有硬编码索引
kin_tasks_walk.taskLib[id].errX(0) = 0 - q(21);  // 21: head yaw
kin_tasks_walk.taskLib[id].J(0, 20) = 1;          // 20: head yaw
```

**建议的方法**：先在 `Tutorial.md` 的关节编号表中定义自己的关节索引，然后对照表逐一修改 `wbc_priority.cpp` 中的索引。

#### 步骤五：验证

1. 运行 `float_control.cpp` 检查 IK 是否正确（机器人保持姿态不抖动）
2. 运行 `walk_wbc.cpp` 检查行走是否稳定
3. 如果发散，回到 14.4 的问题排查流程

---

## 第16章 展望与进阶方向

### 16.1 强化学习与 MPC 的融合

#### 16.1.1 RL 与 MPC 的互补性

| 特性 | 强化学习（RL） | 模型预测控制（MPC） |
|------|---------------|-------------------|
| 模型依赖 | 不需要（无模型RL） | 需要精确模型 |
| 全局最优性 | 策略可逼近全局最优 | 有限时域内最优 |
| 复杂地形适应 | 强（通过大量训练） | 弱（模型误差大） |
| 可解释性 | 弱（黑盒策略） | 强（显式目标函数） |
| 安全性保证 | 难（需额外约束） | 自然支持（约束优化） |
| 计算开销 | 低（推理仅需前向传播） | 高（需在线求解优化） |

#### 16.1.2 结合方式

目前学术界和工业界的主流结合策略有三种：

1. **RL 学习策略，MPC 提供安全约束**：RL 策略输出参考轨迹，MPC 在跟踪的同时确保摩擦锥、关节限位等硬约束不被违反
2. **MPC 作为 RL 的策略网络**：将 MPC 的可微优化层嵌入 RL 策略网络，使 RL 可以端到端地学习 MPC 的权重参数
3. **RL 训练动力学模型，MPC 使用该模型**：RL 从运行数据中学习更准确的动力学模型（如考虑摩擦、柔性），替代 MPC 中简化的 SRBM

对于 OpenLoong 框架的使用者，推荐从**方案 1** 入手：将训练好的 RL 策略输出的足端力/关节角度作为 MPC 或 WBC 的参考输入，利用现有的力控框架来确保安全性。

### 16.2 Sim-to-Real 迁移

#### 16.2.1 仿真与现实的差距

从 MuJoCo 仿真迁移到实物机器人时，以下差异需要关注：

| 因素 | 仿真 | 现实 | 影响 |
|------|------|------|------|
| 动力学精度 | 完美模型 | 存在模型误差 | 跟踪偏差 |
| 传感器延迟 | 零延迟 | 10~50ms 延迟 | 状态估计滞后 |
| 执行器带宽 | 无限 | 有限（力矩环带宽 ~50Hz） | 高频指令无法执行 |
| 摩擦力 | 理想或无 | Coulomb + 粘滞摩擦 | 关节响应变慢 |
| 噪声 | 可添加 | 真实噪声谱 | 微分信号被污染 |
| 关节柔性 | 刚性关节 | 谐波减速器柔性 | 力矩控制震荡 |

#### 16.2.2 域随机化与系统辨识

**域随机化（Domain Randomization）** 是 Sim-to-Real 迁移最有效的方法之一。在训练中加入参数的随机变化，使策略学会适应不同动力学参数。

在 MuJoCo 中可通过修改 XML 实现：

```xml
<!-- 在仿真场景中对关键参数施加随机扰动 -->
<option timestep="0.001" gravity="0 0 -9.81"/>
<!-- 随机化方法：在代码中循环调用 mj_model 参数修改函数 -->
```

OpenLoong 框架用户可以：

1. 在 `joint_ctrl_config.json` 中加入噪声系数，模拟参数不确定性
2. 使用 `mj_model->opt.timestep` 等 MuJoCo 原生参数进行域随机化
3. 结合 `StateEst` 模块（`algorithm/StateEst.h`）的扩展卡尔曼滤波，补偿传感器噪声

**系统辨识（System Identification）**：建议实物部署前，对每个关节进行阶跃响应测试，获取实际带宽和摩擦参数，更新 `joint_ctrl_config.json` 中的 `kp`/`kd` 和限位参数。

### 16.3 全身控制的前沿研究方向

#### 16.3.1 非线性 MPC（全动力学模型）

当前 OpenLoong 框架中的 MPC 使用**单刚体模型（SRBM）**，忽略了关节动力学。非线性 MPC（NMPC）使用完整的浮动基座动力学模型，理论上可以获得更好的性能，但计算开销显著增加。

**当前进展**：
- 利用 [CasADi](https://web.casadi.org/) 或 [ACADOS](https://acados.github.io/) 等工具实现实时 NMPC
- 在 GPU 加速下，人形机器人 NMPC 的实时求解已可行（~200Hz）
- 对硬件要求高（需要高性能嵌入式工控机）

#### 16.3.2 学习型 WBC

传统 WBC 的任务优先级和权重是人工设计的，这在复杂场景下可能不是最优的。**学习型 WBC** 尝试用数据驱动方法自动调整 WBC 参数：

- 学习每个任务的最优 PD 增益（场景自适应）
- 学习任务优先级的动态调整策略（如受到外力时自动提升平衡任务权重）
- 学习关节零空间势函数（优化能量消耗）

#### 16.3.3 触觉反馈与全身协调

下一代人形机器人控制的重要方向是引入全身触觉：

- **足底力触觉**：已集成（通过 `mj_interface` 的传感器读数），实物中可使用 6 轴力/力矩传感器
- **全身皮肤触觉**：臂、躯干的碰撞检测与响应
- **视觉-触觉融合**：视觉预测地形，触觉验证接触

OpenLoong 框架的 `RobotState` 中的 `FL_est`/`FR_est`（足端力估计）为进一步拓展触觉反馈预留了接口。

### 16.4 推荐学习资源

#### 基础理论

- **书籍**：《Model Predictive Control for Robotics》（T. J. T. 等）—— MPC 在机器人中的系统应用
- **论文**：WBC 经典论文——"Hierarchical Quadratic Programming for Whole-Body Control"
- **课程**：MIT 6.832 "Underactuated Robotics"——全身控制的基础控制理论

#### 开源框架与工具

| 工具 | 用途 | 与 OpenLoong 的关联 |
|------|------|-------------------|
| [Pinocchio](https://github.com/stack-of-tasks/pinocchio) | 运动学/动力学解算 | 已集成 |
| [qpOASES](https://github.com/coin-or/qpOASES) | QP 求解器 | 已集成（MPC + WBC） |
| [MuJoCo](https://mujoco.org/) | 物理仿真 | 已集成 |
| [CasADi](https://web.casadi.org/) | NMPC 符号优化 | 可替代当前 MPC 实现 |
| [OCS2](https://github.com/leggedrobotics/ocs2) | 足式机器人 MPC 框架 | 类似架构参考 |

#### 社区与资源

- **OpenLoong 仓库**：本教程为配套代码，持续更新中
- **ODYSSEY 人形机器人社区**：包括机器人设计和控制开源资源
- **RoboCup 人形机器人组**：每年比赛，大量开源代码可供参考
- **IEEE-RAS 人形机器人国际会议**：每年发表大量全身控制最新成果

---

> **结语**：从纯 WBC 的最小可行示例，到 MPC+WBC 行走、跳跃、摇杆交互、楼梯行走、浮动基座控制——OpenLoong 框架覆盖了全身运动控制的主要应用场景。通过本书教程的学习，读者应能理解控制器的设计哲学、掌握调试分析方法，并具备将框架适配到自定义机器人的能力。全身控制是一个快速发展的领域，MPC 与 RL 的融合、Sim-to-Real 迁移等前沿方向值得持续关注。


---

## 统计信息


| 章节 | 文件 | 中文字数 | 估算页数 |
|------|------|---------|---------|
| 第一部分：绪论与基础 | part1_ch1-2.md | 3414 | ~7 |
| 第二部分：数学基础 | part2_ch3-5.md | 7370 | ~15 |
| 第三部分：步态规划与模型预测控制 | part3_ch6-7.md | 8435 | ~17 |
| 第四部分：全身控制与状态估计实现 | part3_ch8-9.md | 7085 | ~14 |
| 第五部分：系统集成 | part4_ch10-12.md | 6179 | ~12 |
| 第六部分：应用实践与展望 | part5-6_ch13-16.md | 6159 | ~12 |
| **总计** | **6 个文件** | **38642** | **~77** |