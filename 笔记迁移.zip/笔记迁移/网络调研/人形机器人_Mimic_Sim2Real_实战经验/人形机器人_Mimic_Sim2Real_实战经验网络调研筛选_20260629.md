# 人形机器人 Mimic / Sim2Real 实战经验网络调研报告

> 搜索日期: 2026-06-29
> 搜索平台: GitHub, Zhihu, CSDN, Cnblogs, Medium/Reddit, 英文技术博客
> 要求: 仅收录人类写的真实实战经验，已排除 AI 生成垃圾

---

## 一、GitHub 开源项目 (含实战部署经验)

### 1. unitreerobotics/unitree_rl_gym — Unitree 官方 Sim2Real 框架 ⭐

- **URL**: https://github.com/unitreerobotics/unitree_rl_gym
- **机器人**: H1, H1-2, G1
- **核心经验**:
  - 完整工作流: Train → Play → Sim2Sim (MuJoCo) → Sim2Real
  - **域随机化参数**: 摩擦系数 [0.1, 1.25], 基座质量扰动 [-1, 3] kg, 随机推力每 5s
  - 部署方式: Python (deploy_real.py) + C++ LibTorch (cpp_g1)
  - **关键教训**: H1_2 轻型末端执行器导致仿真不稳定 → 简化 URDF, 固定手/腕/肘碰撞体
  - 脚部滚轮连杆、膝盖连杆和基座碰撞必须保留
  - H1_2 奖励函数尚未调优 → reward 设计是 Sim2Real 关键瓶颈
  - 真机部署程序标注为 "not a stable control program", 仅供演示

### 2. NVlabs/HOVER — NVIDIA 全身神经控制 ⭐

- **URL**: https://github.com/NVlabs/HOVER
- **机器人**: Unitree H1
- **核心经验**:
  - 控制循环 200 Hz, 策略推理 50 Hz
  - 部署脚本: s2r_player.py
  - 安全部署流程: 启动 → 开发模式 → 加载策略 → 匹配起始姿态 → 逐步放下吊架至脚底触地 → 开始执行
  - 域随机化: 物理材质、刚体质量缩放(髋/腰/躯干)、CoM偏置、关节PD增益缩放、控制延迟随机化
  - **限制**: 主要支持稳定运动 + 上半身动作, 尚未使用外部传感器做根轨迹跟踪

### 3. nvidia-isaac/WBC-AGILE — NVIDIA 全身运动控制 ⭐

- **URL**: https://github.com/nvidia-isaac/WBC-AGILE
- **机器人**: Unitree G1
- **核心经验**:
  - README 明确标注 "validated sim-to-real transfer capabilities"
  - Teacher-Student 蒸馏: Student 使用 LSTM/GRU 处理部分可观测性
  - **Sim2MuJoCo 交叉验证**: 通用框架将 Isaac Lab 策略迁移到 MuJoCo 验证 (scripts/sim2mujoco_eval.py)
  - 预训练策略 `unitree_g1_velocity_history.pt` 不依赖特权信息, 可直接部署
  - `unitree_g1_velocity_height_recurrent_student.pt`: "ready for direct deployment"
  - 存在 `LESSONS_LEARNED.md` 文件 (内容未公开)

### 4. leggedrobotics/legged_gym — 足式机器人 RL 框架 ⭐

- **URL**: https://github.com/leggedrobotics/legged_gym
- **机器人**: ANYmal, Cassie (双足人形)
- **核心经验**:
  - unitree_rl_gym 的底层框架基础
  - 域随机化: 摩擦 [0, 1.5], 基座质量 [-5, 5] kg, 随机推力
  - **课程学习**: 地形难度和指令范围自适应调整
  - 执行器网络 (Actuator Network) 是 Sim2Real 关键组件
  - 已知坑: GPU 仿真三角网格地形的 net_contact_force_tensor 不可靠

### 5. huggingface/lerobot — 开源机器人学习框架 ⭐

- **URL**: https://github.com/huggingface/lerobot
- **机器人**: Unitree G1, Reachy 2
- **核心经验**:
  - HIL-SERL: Human-in-the-Loop RL, 结合离线示范 + 人工干预
  - 部署文档: AGENT_GUIDE.md + unitree_g1.mdx (SDK 安装/仿真设置/物理机器人连接)
  - 支持 ACT, Diffusion, GR00T N1.5, SmolVLA 等策略

### 6. Improbable-AI/walk-these-ways ⭐

- **URL**: https://github.com/Improbable-AI/walk-these-ways
- **核心经验**:
  - Docker 部署流水线
  - 安全措施: 横滚/俯仰 > 1.6 rad 自动切断电源, PowerProtect level 9
  - Multiplicity of Behavior (MoB) 提高策略鲁棒性

---

## 二、知乎 (Zhihu) — 人类写作实战文章

### ⭐ 推荐 1: 人形机器人运动控制 Know-How
- **URL**: https://zhuanlan.zhihu.com/p/1993986785630499920
- **作者**: Jagger (专栏: 腿足机器人前沿)
- **核心内容**: 万字长文实战指南
  - 传统运动控制 (MPC/WBC) → RL 强化学习的技术演进
  - 两条完整学习路线: Model-based (优化控制) + Learning-based (强化学习)
  - 实操建议: Pinocchio 动力学库安装、URDF 导入、MuJoCo 仿真、手写 QP
  - Sim2Real 瓶颈: 硬件电气设计、电机稳定性、URDF 精度、模拟器对并联机构限制
  - BFM (Behavior Foundation Model) 最新范式
- **甄别判断**: 深度参与 RoboParty 开源项目, 含大量实操经验和代码级细节

### ⭐ 推荐 2: RL做足式机器人运控的经典必读文章
- **URL**: https://zhuanlan.zhihu.com/p/29806809248
- **作者**: 韬晦待时 (与 HugWBC 一作宇斐联合整理)
- **核心内容**:
  - 四足到人形的关键论文梳理
  - 关键技术判断: "Domain Randomization ≈ Dynamics Randomization, 可以混用"
  - Sim2Real gap 来源: 算法能 cover 的 gap 有限, 机器人本体性能参数决定迁移上限
  - "大部分成功迁移的都是串联杆机构, 并联杆和软体机器人难以被刚体模拟器建模"

### ⭐ 推荐 3: 人形机器人从实践到理论系列
- **URL**: https://zhuanlan.zhihu.com/p/1982471173326528684 (第16篇-AMP)
- **作者**: 星穷碧落人归尽
- **核心内容**:
  - DeepMimic → AMP → 关节重定向 → 真机部署 实操链路
  - PPO 算法在 gym 环境中实现起-走-跳的具体设计
  - 推荐宇树&深蓝学院《人形机器人系统:理论与实践》课程

### 推荐 4: Holosoma — 15 分钟实现 sim-to-real 人形机器人运动学习
- **URL**: https://zhuanlan.zhihu.com/p/1979564323178312746
- **作者**: AI椰青
- **核心内容**:
  - FastSAC/FastTD3 算法详解 (off-policy RL)
  - 层归一化、CDQ 禁用、动作边界设置、低折扣因子 gamma
  - 奖励设计极简原则 (<10 项), 具体列出每一项
  - **在真实宇树 G1 完成了部署**, 演示 >2 分钟舞蹈
  - 代码开源在 Holosoma 仓库

### 推荐 5: 机器人通用大模型基础(3)-Sim2Real
- **URL**: https://zhuanlan.zhihu.com/p/1889609310222386585
- **作者**: Jim Li
- **核心内容**:
  - Domain Randomization 原理和实现
  - 以 H1_2 为例指出哪些变量被随机化 (摩擦/质量/推力)
  - 坦诚判断: "zero-shot sim2real 拍视频很火, 离工业化落地差距很大, 视频里的动作大概率是从成千上万个失败 Policy 里挑的"

---

## 三、CSDN — 经过甄别的人类写作文章

### ✅ 推荐 1: 从仿真到实机：Python控制人形机器人落地的7个关键陷阱
- **URL**: https://blog.csdn.net/AlgoChat/article/details/153045515
- **作者**: AlgoChat
- **核心内容**: 有具体代码和参数
  - 真实 PID 控制器在实机上因电机响应延迟产生振荡
  - 带通信延迟补偿的控制循环 C++ 代码
  - 惯量参数误差、关节摩擦模型不准确、通信延迟数据 (2-8ms)
  - 仿真 vs 实机对比表: 控制频率 1000→500 Hz, 位置误差 <0.1°→<1.5°

### ✅ 推荐 2: 智元 D1 强化学习sim-to-real系列 | rl_sar框架深度解析
- **URL**: https://blog.csdn.net/lovely_yoshino/article/details/156202385
- **作者**: lovely_yoshino (具身智能专栏)
- **核心内容**:
  - rl_sar 框架: 四足/轮足/人形机器人 RL 部署框架深度解析
  - 分层架构: 仿真/实机层 → 核心库层(rl_sdk) → 策略配置层 → 输入接口层
  - RobotState/RobotCommand 数据结构设计
  - 支持 IsaacGym→Gazebo→真机 全链路

### ✅ 推荐 3: 人形机器人真机部署实录：为什么你的算法跑得通，落地却总"炸机"？
- **URL**: https://blog.csdn.net/old_tree/article/details/160819182
- **作者**: old_tree
- **核心内容**:
  - Sim2Real Gap 的本质: 不是代码逻辑问题, 是底层工程物理鸿沟
  - 硬件三坑: 背隙(Backlash)、线束疲劳、散热漂移
  - 三个工程建议: 强化输出端闭环、域随机化 10-20%、建立快速重置机制
  - (末尾有营销内容, 但前半部分技术分析扎实)

### ✅ 推荐 4: Holosoma 人形机器人强化学习的训练框架 | 代码分析 | 复现
- **URL**: https://blog.csdn.net/guo-pu.blog.csdn.net/article/details/162104599
- **作者**: guo-pu
- **核心内容**:
  - Holosoma 架构: 多模拟器支持 (IsaacGym/IsaacSim/MuJoCo)
  - 算法: PPO + FastSAC 针对人形机器人优化
  - 任务: 速度跟踪 + 全身跟踪 (whole-body tracking)
  - 支持 sim-to-sim 和 sim-to-real 部署

---

## 四、Cnblogs (博客园) — 经过甄别的人类写作文章

### ✅ 推荐 1: 从视频到舞步：详解基于AI的人形机器人运动模仿全栈技术 ⭐
- **URL**: https://www.cnblogs.com/jzssuanfa/p/19803401
- **作者**: jzssuanfa
- **核心内容**: 最完整的端到端 mimic 流水线实战文章
  - **五阶段全景**: GVHMR (运动提取) → GMR (重定向) → BeyondMimic (RL训练) → MuJoCo (Sim2Sim验证) → rl_sar (真机部署)
  - 每个阶段有具体命令和参数, 完整代码示例
  - Sim2Sim 验证核心挑战: 确保 BeyondMimic (Isaac Lab) 与 rl_sar (MuJoCo) 物理参数/观测空间/动作空间完全一致
  - 真机部署三坑: 通信延迟补偿、状态估计误差(IMU+编码器噪声)、模型不匹配
  - **这是目前能找到的最完整的中文端到端 mimic 部署实战文章**

### ✅ 推荐 2: 从0到1打造一台机器人走起来 - 指南
- **URL**: https://www.cnblogs.com/yfceshi/p/19055654
- **作者**: yfceshi
- **核心内容**:
  - 自研双足机器人, 傅利叶智能关节模组
  - HumanoidGym + PPO + 非对称 Actor-Critic + 特权信息
  - Real2Sim 验证: 从 MuJoCo 采样动作值在实物验证
  - 实机部署技巧: 伪并行技术提高数据获取效率, IMU 优化和仿真对齐

### ✅ 推荐 3: 【H2O系列】包括人形机器人WBC相关论文小结
- **URL**: https://www.cnblogs.com/myleaf/p/18727733
- **作者**: 泪水下的笑靥 (myleaf)
- **核心内容**:
  - SMPL/AMASS 数据集详细笔记
  - H2O (Human-to-Humanoid) 全身遥操作技术解析
  - ExBody (Expressive Whole-Body Control) 核心思想: 上半身模仿参考运动, 下半身仅保持平衡
  - 个人学习笔记风格, 包含大量细节理解和主观评价

### ✅ 推荐 4: Qmini 部署开发指南
- **URL**: https://www.cnblogs.com/Star-Vik/p/19642364
- **作者**: StarVik
- **核心内容**:
  - 仿真训练(RoboTamer4Qmini, Python) ↔ 实机部署(RoboTamerSdk4Qmini, C++) 双仓库工作流
  - 树莓派 + Unitree SDK + ONNX Runtime 部署实践
  - 电机串口配置细节 (SerialGroup 配置)
  - 错误的认知纠正: 混淆仿真和实机仓库的教训

### ✅ 推荐 5: SERL：让真机强化学习从"难用"走向"可复现"
- **URL**: https://www.cnblogs.com/rossiXYZ/p/20711693
- **作者**: rossiXYZ
- **核心内容**:
  - SERL 框架全景剖析: SAC + RLPD + High UTD + REDQ
  - Sim-to-Real Gap 的本质分析
  - 真机 RL 的瓶颈: 不只是算法, 还有系统集成
  - 代码结构和数据流分析

---

## 五、英文平台 — 实战经验

### ⭐ 推荐 1: Sim-to-Real for Humanoids: Deployment Best Practices
- **URL**: https://vnrobo.com/en/blog/rl-humanoid-10-sim2real
- **作者**: Nguyễn Anh Tuấn (2026-04-09)
- **核心内容**: **目前最详细的人形 Sim2Real 工程实践指南之一**
  - **完整的域随机化参数表** (Python 代码给出):
    - 基座质量 ±15%, 每 link ±10%, CoM ±2cm, 惯量 ±20%
    - 关节摩擦/阻尼/armature/stiffness 范围
    - 电机强度 ±15%, 动作延迟 0-30ms, 观测延迟 0-15ms
    - 推力 0-50N, 间隔 5-15s
  - **Sim vs Real Gap 量化对比表**:
    - 控制延迟: Sim 0ms → Real 5-20ms (Critical!)
    - 电机强度: Sim 100% → Real 85-95%
    - 连杆质量: CAD 精确 → 实际 +5-10% (含线缆)
    - 柔性问题: 仿真刚体 → 谐波减速器柔性 (High impact)
  - **电机系统辨识** 完整代码 (chrip 信号 + 优化)
  - **值函数缩放 (Value Function Scaling)**:
    - Humanoid 的问题: 奖励尺度随任务剧烈变化 (locomotion vs parkour)
    - 动态 scaling 解决多任务训练不稳定
  - **安全部署流程**: 挂架 → 零扭矩 → 逐步加载

### ⭐ 推荐 2: Sim-to-Real Transfer: A Practitioner's Guide for 2026
- **URL**: https://al.roboticscenter.ai/blog/sim-to-real-tips-practitioners
- **作者**: Jerry Huang, Robotics Center of Silicon Valley
- **核心内容**:
  - **什么容易迁移**: 平地行走、基础抓取、导航 → 依赖刚体动力学的任务
  - **什么难以迁移**: 柔体操作(叠布/布线)、亚毫米精度装配、流体/颗粒物操作
  - **系统域随机化**: 先找 5-10 个真机 trials 的失败模式, 再针对性随机化
  - 视觉随机化参数: 相机偏移 ±10cm、亮度 ±30%、hue ±20%、高斯模糊 0-2px
  - 物理随机化: 摩擦 ±50%、质量 ±30%、关节阻尼 ±20%、延迟 0-20ms
  - **Real2Sim 标定**: 花 2-4 小时做系统辨识, 将测量值作为域随机化中心 → 减少 30-50% Sim2Real error
  - **层次化策略**: coarse (依赖几何/轨迹) → fine (依赖真实接触数据在线微调)

---

## 六、关键经验总结

### 域随机化参数共识 (多项目交叉验证)

| 参数 | 典型范围 | 来源 |
|------|---------|------|
| 地面摩擦系数 | [0.1, 1.5] | unitree_rl_gym, legged_gym, vnrobo |
| 基座质量扰动 | [-5, +5] kg 或 ±15% | 多个项目一致 |
| 推力间隔 | 5-15 秒, 0-50 N | vnrobo, unitree_rl_gym |
| PD 刚度缩放 | 75%-150% 名义值 | Isaac Lab, HOVER |
| PD 阻尼缩放 | 30%-300% 名义值 | Isaac Lab |
| 动作延迟 | 0-30 ms | vnrobo, HOVER |
| 观测噪声 | 各传感器独立配置 | 通用 |

### 部署架构共识

1. **训练阶段**: Teacher 策略使用特权观测 (仿真内训练)
2. **蒸馏阶段**: Student 策略仅使用真实传感器 (IMU + 关节编码器)
3. **导出格式**: TorchScript (.pt) 或 ONNX (.onnx)
4. **部署运行时**: C++ (LibTorch/ONNX Runtime) 优先于 Python
5. **验证步骤**: Sim2Sim 交叉验证 (Isaac Lab ↔ MuJoCo) 必不可少

### 经验教训/踩坑汇总

- 简化 URDF 对仿真稳定性至关重要 (尤其轻型末端执行器)
- 奖励函数调优是 Sim2Real 迁移最大瓶颈之一
- 三角网格地形接触力传感器在 GPU 仿真中不可靠
- 控制延迟随机化 (1-3 步) 显著提高策略鲁棒性
- 部署前必须经过 Sim2Sim 验证
- 使用吊架逐步释放机器人是最安全的部署方式
- 电机系统辨识 (Real2Sim) 可减少 30-50% 迁移误差
- 并联杆机构和软体机器人难以被现有刚体模拟器建模
- 硬件性能 (电气设计/电机稳定性/驱动延迟) 决定 Sim2Real 上限

---

## 七、排除清单 (AI 生成/营销号/无实质内容)

以下内容已被甄别并排除:
- CSDN 上大量标题含"【人形机器人】高级Sim2Real: 世界模型重建..."等 AI 生成综述文章
- 知乎营销号 "具身智能之心" (598 篇文章卖课, 无实质)
- 知乎 "进化加速度" (二级市场研报风格)
- 所有 CSDN 上 "AIGC" 标签的专栏文章
- 博客园 wgwyanfs (2770 篇随笔, 内容泛泛的产业分析)
- 博客园 shangxuns (4588 篇, 供应商营销文)

---

*报告结束*
