# 系列总结：RL Humanoid 工程实践系列 (vnrobo.com)

> 作者：Nguyễn Anh Tuấn (Robotics & AI Engineer)
> 原文：https://vnrobo.com/en/blog/
> 共 10+ 篇，涵盖从双足行走基础到 Sim2Real 部署全流程

---

## 1. RL for Bipedal Walking: From Paper to Practice

**核心观点**：RL 已彻底改变双足行走控制范式，ZMP（零力矩点）传统方法过于保守且不具自适应性。

**关键内容**：
- MDP 设计决定 80% 的成败。观测空间 = 本体感知（IMU + 关节编码器）+ 速度指令，**不使用视觉**（本体感知 1kHz vs 相机 30-60Hz，平衡控制需要高频反馈）。
- 动作空间 = PD 目标位置（非直接力矩输出），更稳定。
- 奖励设计：velocity tracking（指数形式优于线性）+ energy penalty（不能太大也不能太小）+ feet air time（关键！否则机器人会"滑行"）。
- 地形课程学习（curriculum）：从平地向复杂地形渐进。

---

## 2. Reward Engineering for Bipedal Walking

**核心观点**：奖励函数是策略的"灵魂"，12+ 个奖励项对自然步态是必需的。

**12 个奖励项详解**：
- **主目标**：linear_vel_tracking (1.5)、angular_vel_tracking (0.8)
- **姿态**：upright (0.5)、base_height (0.3)
- **步态质量**：foot_clearance (0.3)、contact_pattern (0.4)、foot_slip (-0.1)
- **平滑性**：action_rate (-0.01)、torque (-0.00005)、joint_acceleration (-0.0001)
- **安全**：termination (-200)、joint_limit (-1.0)

**消融实验**：去掉哪个奖励项后果如何——linear_vel_tracking 和 upright 是 Critical 级别（机器人不走路/直接摔），foot_clearance 是 High 级别（机器人拖脚）。

**课程学习三阶段**：Standing（0-500 iter，静止站立）→ Weight Shifting（500-1500，慢速指令）→ Walking（1500+，全速跟踪）。

---

## 3. RL for Humanoid: From Humanoid-Gym to Sim2Real

**核心观点**：Humanoid-Gym 是目前最标准的人形 RL 框架，完整覆盖训练 → Sim2Sim 验证 → 零样本 Sim2Real。

**Humanoid-Gym 特性**：基于 Isaac Gym 并行训练 4096 个机器人、Sim2Sim（Isaac Gym → MuJoCo）验证、零样本 Sim2Real（已验证 RobotEra XBot-S/L）。

**RL vs MPC 对比**：RL 推理 0.1-1ms（vs MPC 5-50ms），对模型精度要求低，但对 DR 要求高。

**零样本 Sim2Real 四要素**：
1. 域随机化（摩擦 0.5-1.5、质量 ±3kg、电机强度 80-120%）
2. 观测设计（只用真机能获取的信号，不用 ground truth）
3. 位置目标动作空间（PD 跟踪更稳定）
4. 延迟补偿（仿真中加入观测延迟 0-3 步）

---

## 4. Domain Randomization: The Key to Sim-to-Real Transfer

**核心观点**：域随机化是 Sim2Real 迁移最广泛验证有效的技术。贝叶斯视角：DR 等效于在环境参数的后验分布上训练。

**三种 DR**：
1. **视觉 DR**：光照 (200-5000 lux)、色温 (3000-8000K)、相机 FOV (55-75°)、纹理、背景干扰
2. **动力学 DR**：质量 (0.5-2.0x)、摩擦 (0.3-1.5)、执行器强度 (0.85-1.15)、动作延迟 (0-3 frame)、重力噪声
3. **传感器 DR**：关节编码器噪声 (+0.005 rad)、IMU 噪声 (MPU-6050 参数)、力传感器 dropout (1%)

**样例研究**：OpenAI Rubik's Cube (ADR 自动扩展随机化范围，成功率 ~84%)、Agility Digit (~91%)、ANYmal Parkour (~93%)。

**反模式**：过度随机化（范围超出物理可能）、忽略参数相关性（重物通常摩擦大）、没有课程学习、只做视觉 DR 忽略动力学 DR。

---

## 5. Sim-to-Real for Humanoids: Deployment Best Practices

**核心观点**：人形 Sim2Real 比四足更难（双足天然不稳、支撑域窄、重心高）,一份代码完整的人形部署清单。

**Sim vs Real Gap 量化表**：控制延迟 0ms→5-20ms (Critical)、电机强度 100%→85-95%、连杆质量 +5-10%（含线缆）、柔性问题（谐波减速器，High impact）。

**电机系统辨识代码**：chirp 信号 (0.5→5.5 Hz) 激励电机，scipy.optimize 拟合 Kp/Kd/摩擦/阻尼。

**部署框架**：PolicyInference（JIT trace + 预分配 tensor 加速）→ SafetyLayer（跌落检测、关节限位、阻尼模式 fallback）→ HumanoidDeployment（主循环）。

**调试指南**：列出 6 种常见失败模式及修复方案（立即摔倒→观测不匹配；摆动/振荡→PD增益过高或延迟；侧向漂移→IMU偏置）。

**完整部署清单**：系统辨识已完成、DR 范围覆盖真实值、安全层已测试、急停硬件就位、推理速度已基准测试（<5ms 适用于 50Hz）。

---

## 6. LIFT Humanoid (ICLR 2026)

**核心观点**：LIFT 提出"预训练 SAC + 物理知识世界模型 + 确定性环境微调"的三阶段流水线，将真机数据需求压缩到 80-590 秒。

**三阶段**：
1. **MuJoCo Playground 预训练 SAC**：Large-batch + High UTD + 1024 并行环境 → ~1 小时 / 4090
2. **物理知识世界模型**：Lagrangian 动力学分支（显式物理方程 + 小残差）+ 接触残差预测器（小 MLP）
3. **微调**：真实环境确定性执行（取 μ(s)，不采样）+ 世界模型内随机探索

**关键创新**：世界模型不是黑箱（如 Dreamer 的 GRU/RSSM），而是将物理方程硬编码，网络只学残差。泛化性远超纯数据驱动的模型。

**工程陷阱**：忘记 `--save_buffer_data` 会丢失 replay buffer（重跑 1 小时）、DR 过于激进导致 SAC 不收敛、UTD 过高导致过拟合（建议从 4 开始渐增）、WM 残差爆炸需要 L2 正则。

---

## 整体评价

Nguyễn Anh Tuấn 的系列是目前互联网上**最系统的端到端人形 RL 实战教程**。从双足行走的 MDP 建模 → 12 个奖励项的精细设计 → Humanoid-Gym 训练 → Sim2Sim 验证 → 域随机化理论 → 真机部署清单 → 前沿 LIFT 方法复现，每篇都有**可执行的代码**和**可量化的参数**。中文社区目前缺乏同等级别的系统性实战教程。
