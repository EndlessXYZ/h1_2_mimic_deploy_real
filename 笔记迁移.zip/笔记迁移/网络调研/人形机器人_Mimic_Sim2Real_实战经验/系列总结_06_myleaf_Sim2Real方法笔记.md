# myleaf《机器人领域的Sim2Real相关方法》知识点笔记

**作者**: 泪水下的笑靥 (myleaf, 博客园)
**原文**: https://www.cnblogs.com/myleaf/p/19722445
**性质**: 个人学习笔记，非系统教程。作者明确"梦到哪里写到哪里"，内容以文献知识点摘录为主，附带个人理解和备注。

> 关联文章：同一作者的[BeyondMimic]G1复现细节、VR->G1复现过程记录也涉及 sim2real 实践。

---

## 核心内容覆盖四种方法

**1. CMA-ES（协方差矩阵自适应进化策略）**
- 观点：作为黑箱优化工具，目标函数不可导、含接触、带延迟噪声时很自然的选择。不要求梯度，只要求能比较候选解好坏。
- 作者从论文推断："CMA-ES 只要求能比较候选解的好坏，不依赖梯度"
- 亮点：协方差更新学的是"优胜样本相对旧均值的成功移动方向"，能把新搜索分布沿有希望的方向拉长，而普通方法更容易过早收缩。
- 关键理解：CMA-ES 在 Sim2Real 里适用于"让仿真更像真机"或"调一小撮关键参数"的场景。

**2. SPI（Sampling-based Parameter Identification with Active Exploration, CMU 2025）**
- 两阶段框架：Stage 1 先用 motion priors + 预训练 RL policies 采真机轨迹，切 clips 做多步预测辨识；Stage 2 再训练新 policy，形成闭环。
- 辨识变量：base/pelvis 惯量参数 + 电机参数，使用 CMA-ES 优化
- 作者拆解了 cost 三大块：Base Prediction Cost（浮动底座全状态）、Joint Prediction Cost（关节位置/速度/力矩）、Parameter Regularization（约束不离 URDF 名义值太远）
- 亮点：不是拟合某个末端轨迹，而是拟合整机的全状态演化

**3. UAN（Unsupervised Actuator Net, MIT 带臂四足）**
- 用残差网络加 PD 输出来模拟真实 PD 行为
- 流程：真机 rollout → 计算 q/dq 差值 → UAN 输出残差 torque → 作用到 torque 上作为最终仿真输入
- 部署时要去掉 UAN（仅在仿真对齐阶段使用）
- 作者给出简化理解："残差网络补偿的是仿真与真机之间的执行器行为差异"

**4. PACE（ETH 四足, 2025）**
- 核心目标：不用大规模 dynamics randomization、不用复杂残差网络、不用高维奖励工程
- 而是用一小组可解释的关节动力学参数对齐仿真到真机
- 三步流程：
  1. 固定基座下采 chirp 轨迹真机数据
  2. CMA-ES 搜索小维度动力学参数使仿真回放匹配真机
  3. 在拟合后的仿真里训练 blind locomotion，zero-shot 部署
- 作者的核心洞察："很多 sim2real 工作的问题根源不在刚体动力学完全错了，而在执行器/关节侧的真实动态没有被正确建模"
- 同样选 CMA-ES，因为"存在局部极小值、维度不高、GPU 并行下既稳定又样本效率不错"

---

## 整体评估

- **质量**: 中上。作者的笔记形式虽然松散，但对每篇论文的方法论提炼到位，尤其是对 CMA-ES 的适用场景分析和 SPI 的 cost 拆解
- **独特价值**: 提供了一个"文献综述型"视角，与 rossiXYZ 的 SERL 实战系列形成互补
- **局限性**: 作者自称"梦到哪里写到哪里"，未亲自动手复现上述方法，部分理解来自论文阅读
- **与其他来源的关联**: PACE 和 SPI 与 vnrobo 的系统辨识文章（chrip 信号 + 优化）核心思路一致，可相互印证
