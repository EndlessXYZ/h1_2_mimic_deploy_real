# 知乎 AI椰青《Holosoma — 15 分钟实现 Sim-to-Real 人形机器人运动学习》

**作者**: AI椰青（知乎）
**原文**: https://zhuanlan.zhihu.com/p/1979564323178312746
**性质**: Amazon FAR 开源框架 Holosoma 的技术解读 + FastSAC/FastTD3 算法详解。原文因知乎反爬机制无法直接读取，以下基于 Holosoma 官方论文和代码仓库信息综合。

---

## 背景：Holosoma 是什么

Holosoma 是 Amazon FAR（Frontier AI & Robotics）团队开源的人形机器人综合训练框架，核心作者包括 Younggyo Seo、Carmelo Sferrazza、Pieter Abbeel 等。
- 论文：《Learning Sim-to-Real Humanoid Locomotion & Whole-Body Tracking in 15 Minutes》
- GitHub: https://github.com/amazon-far/holosoma
- 支持仿真后端：IsaacGym, IsaacSim, MJWarp (MuJoCo+Warp)
- 支持硬件：Unitree G1, Booster T1

## 核心亮点

**1. 15 分钟 Sim-to-Real**
- 使用 FastSAC（off-policy SAC 的高效变体）在单张 RTX 4090 上 15 分钟训练出可迁移的人形运动策略
- 对比 PPO 需要小时级训练，速度提升一个数量级
- 归因于：off-policy 的数据效率 + 大规模并行环境（single GPU 数千环境）

**2. 极简奖励设计（<10 项）**
- 知乎文章列出每一项具体设计
- 与 vnrobo 的 12+ 奖励项和课程学习形成对比：不同的流派

**3. 域随机化设计**
- 随机化动力学参数、粗糙地形、推扰
- 动作边界设置、低折扣因子 gamma 的调优经验

**4. 真机部署验证**
- 在真机 Unitree G1 上演示 2+ 分钟舞蹈
- 支持 whole-body tracking（全身运动跟踪）

## 算法要点

- **FastSAC/FastTD3**: 在标准 SAC/TD3 基础上优化了大并行规模下的稳定性
- **Layer Normalization**: 用于稳定大规模 off-policy 训练
- **CDQ 禁用特定配置**: 避免 critic 过估计
- **动作边界设置技巧**: 与人形机器人关节限位对齐

---

## 整体评估

- **质量**: 高。Holosoma 是 2025-2026 年最值得关注的人形 RL 框架之一，FastSAC 代表了 off-policy RL 在人形领域的最新进展
- **独特价值**: 与 rossiXYZ 的 SERL 系列（同样强调 off-policy RL/SAC+RLPD）形成直接呼应，共同佐证"off-policy 正在超越 PPO"这一趋势
- **与已有系列的关系**: 补充了 vnrobo 系列中 LIFT 文章（ICLR 2026, 预训练 SAC + 微调）前后的技术脉络
- **代码开源**: 作为 Amazon FAR 的官方项目，维护活跃，文档完整
