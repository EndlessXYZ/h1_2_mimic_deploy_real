# 知乎 Jim Li《机器人通用大模型基础(3)-Sim2Real》

**作者**: Jim Li（知乎, AI全栈, 公众号: Jim聊聊AI）
**原文**: https://zhuanlan.zhihu.com/p/1889609310222386585
**性质**: "机器人通用大模型基础"系列第3篇，以 Domain Randomization 为核心，使用宇树 H1_2 的 unitree_rl_gym 源码作为案例，适合对 DR 有初步了解需求的读者。

---

## 文章结构

### 1. 前言：Zero-Shot Sim2Real 热潮

2025年3月人形机器人"突然"学会各种高级舞蹈的推文刷屏，Figure 和 Boston Dynamics 的演示视频中都标明"Zero Shot"（无需真机再训练）。作者提出问题："如果说从仿真环境部署到真实环境的 Gap 被解决了，那真的是一大进步了，即使只是解决了 Locomotion。" 文章聚焦回答：**Domain Randomization 如何解决 Sim2Real 问题？**

### 2. Domain Randomization 核心原理

**两个维度**：
- **物理属性随机化**：质量、关节摩擦力、地面摩擦系数——模拟硬件差异或环境变化
- **环境条件随机化**：地面倾斜度、障碍物分布、光照条件——确保多场景稳定性

**三个步骤**：
1. 模拟环境构建（MuJoCo/PyBullet）
2. 参数随机化范围设定（如关节摩擦 [0.1, 0.5]）
3. 策略训练（PPO/SAC），每个 episode 生成新的随机参数

### 3. 与 RL 的结合

- **奖励函数**：需对随机变化不敏感（步态稳定性、能量效率、速度一致性）
- **高频控制补偿**：真机部署时结合 kHz 级扭矩反馈控制，实时补偿模拟与现实的差异

### 4. Actor 网络输出猜想

作者基于对常见 RL 框架的理解做出的推测：
- **关节目标位置或扭矩**：位置控制输出关节角度（rad），通过 PD 转电机指令；扭矩控制直接输出 Nm
- **全身协调参数**：步态相位（gait phase）、重心偏移量（CoM adjustment）
- **与 Critic 配合**：Critic 评估动作价值（行走稳定性/能量效率），引导 Actor 学鲁棒策略
- **底层控制器衔接**：通过 PD 或阻抗控制器处理高频动态（如落地冲击）

结论：Actor 输出很可能是连续向量 = 所有关节目标动作 + 少量高层运动参数。

### 5. 宇树 H1_2 示例（有完整代码）

```python
class domain_rand(LeggedRobotCfg.domain_rand):
    randomize_friction = True
    friction_range = [0.1, 1.25]
    randomize_base_mass = True
    added_mass_range = [-1., 3.]
    push_robots = True
    push_interval_s = 5
    max_push_vel_xy = 1.5
```

**三个 DR 实现的代码**：

- **摩擦系数随机化**：用 `torch.randint` 分 64 个 bucket 采样摩擦系数，通过 `gym.set_asset_rigid_shape_properties` 设置到仿真环境
- **基础质量随机化**：`np.random.uniform` 在 [-1, 3] kg 范围内扰动 base link 质量，`gym.set_actor_rigid_body_properties` 设置
- **随机推力**：每 5 秒对 x/y 方向施加速度扰动（[-1.5, 1.5] m/s），通过 `set_actor_root_state_tensor_indexed` 实现

### 6. 最后：坦诚的判断

> "虽然最近 simulation + RL for zero-shot sim2real 的范式拍起视频来很火，但离工业化落地还是有挺大差距的，视频里看到的动作大概率是从成千上万个失败 Policy 里挑了几个能拍 Demo 的给大家展示。从当前的开源实现来看，这么多年最大的进步应该是 Isaac 物理仿真引擎。"

---

## 整体评估

- **质量**: 中上。文章结构清晰，从原理到代码循序渐进，H1_2 的 DR 参数配置和实现代码对实践者有价值
- **独特价值**: 是调研中唯一直接贴出 unitree_rl_gym DR 代码并逐行解读的文章（摩擦/质量/推力三种 DR 的具体 API 调用）
- **核心判断**: "zero-shot sim2real 拍视频很火，离工业化落地还差很远"——与 unitree_rl_gym 官方 README 的 "not a stable control program" 声明、Jagger 的工程瓶颈分析、韬晦待时的硬件判断形成**四方共识**
- **局限性**: Actor 网络设计部分属于"猜想"而非实践验证；整体属于入门-中级水平，不及 rossiXYZ 的 SERL 系列深入
