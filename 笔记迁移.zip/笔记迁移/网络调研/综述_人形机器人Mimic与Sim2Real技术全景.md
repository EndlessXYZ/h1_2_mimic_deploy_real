# 人形机器人 Mimic 与 Sim2Real 技术全景综述

> 综述日期: 2026-06-29 (v2, 补充myleaf/Holosoma/硬件三坑等内容)
> 基础素材: 博客园、知乎、CSDN、GitHub、英文技术博客 等平台的人类作者实战文章
> 声明: 本文基于网络调研中筛选出的人类写作实战经验汇编而成，已排除 AI 生成内容

---

## 摘要

人形机器人的 Sim2Real（Simulation to Reality）迁移和 Mimic（运动模仿）是当前具身智能领域最具工程挑战的方向之一。本文基于对中文互联网（博客园、知乎、CSDN）及英文技术社区（GitHub、vnrobo.com、roboticscenter.ai）共 20+ 篇人类作者实战文章的深度阅读，系统梳理了人形机器人从仿真训练到真机部署的全栈技术体系。核心发现：域随机化参数在多个项目间高度一致（摩擦 [0.1,1.5]、质量 ±15%、延迟 0-30ms）；奖励函数设计是 Sim2Real 最大瓶颈之一；硬件性能（电气设计、驱动延迟）决定迁移上限；Sim2Sim 交叉验证（Isaac Gym ↔ MuJoCo）是部署前不可或缺的质检环节。

---

## 1. 技术路线总览

### 1.1 Mimic（运动模仿）流水线

从人类视频到机器人真机执行 Mimic 动作，有一条被多个实践验证的**五阶段流水线** [jzssuanfa-2026]：

```
人类视频 → ① 运动提取 (GVHMR) → ② 运动重定向 (GMR)
  → ③ RL训练 (BeyondMimic/PPO) → ④ Sim2Sim验证 (MuJoCo)
  → ⑤ 真机部署 (rl_sar/C++)
```

**数据流格式转换链**：`.mp4` → `.pt`（SMPLX 参数）→ `.pkl`（重定向结果）→ `.csv`（关节角度）→ `.npz`（物理信息）→ `.onnx`（部署模型）。

这条流水线最关键的发现是：**Sim2Sim 验证环节往往比 Sim2Real 本身更容易出问题**——Isaac Lab 与 MuJoCo 在物理参数、观测空间、动作空间上的任何细微不一致都可能导致策略失效 [jzssuanfa-2026]。

### 1.2 部署工作流共识

多项目（unitree_rl_gym [unitree-2024], HOVER [NVLabs-2024], WBC-AGILE [NVIDIA-2025]）验证的工作流共识 [github-调研-2026]：

```
训练 (Isaac Gym/Lab, Teacher with privileged info)
→ 蒸馏 (Student with only proprioception)
→ 导出 (TorchScript / ONNX)
→ Sim2Sim验证 (MuJoCo交叉验证)
→ 真机部署 (C++ LibTorch / ONNX Runtime)
→ 安全执行 (吊架逐步释放 → 零扭矩 → 加载策略 → 行走)
```

---

## 2. 域随机化 (Domain Randomization): 共识与量化

域随机化是 Sim2Real 最广泛验证有效的技术。从贝叶斯角度看，DR 等效于在环境参数的后验分布上训练——当随机化范围足够宽时，真实世界只是分布中的一个样本 [Tobin-2017, vnrobo-DR-2026]。

### 2.1 参数范围共识

从多个项目交叉验证得出的域随机化参数共识 [rossiXYZ-SERL, vnrobo-Sim2Real, unitree_rl_gym, HOVER]：

| 参数类别 | 参数名 | 典型范围 | 来源项目 |
|---------|-------|---------|---------|
| **接触** | 地面摩擦系数 | [0.1, 1.5] 或 [0.4, 1.5] | 普遍一致 |
| **质量** | 基座质量扰动 | ±15% 或 [-5, +5] kg | 普遍一致 |
| **质量** | 连杆质量 | ±10% | HOVER, vnrobo |
| **质心** | CoM 偏置 | ±2cm | HOVER, vnrobo |
| **惯量** | 惯性张量 | ±20% | HOVER, vnrobo |
| **执行器** | PD 刚度缩放 | 75%-150% | Isaac Lab |
| **执行器** | PD 阻尼缩放 | 30%-300% | Isaac Lab |
| **执行器** | 电机强度 | ±15% | vnrobo, unitree |
| **延迟** | 动作延迟 | 0-30ms | HOVER, vnrobo |
| **延迟** | 观测延迟 | 0-15ms/0-3帧 | 普遍 |
| **噪声** | 关节位置噪声 | σ=0.005-0.01 rad | 普遍 |
| **噪声** | IMU 角速度噪声 | σ=0.01-0.05 rad/s | vnrobo |
| **扰动** | 随机推力 | 0-50N, 间隔5-15s | 普遍 |
| **地形** | 地面粗糙度 | 0-0.03m | vnrobo |

### 2.2 Sim vs Real Gap 量化

量化的差距评估是 DR 参数设计的依据 [vnrobo-Sim2Real-2026]：

| 参数 | 仿真理想值 | 真实值 | 影响等级 |
|------|-----------|--------|---------|
| 控制延迟 | 0 ms | 5-20 ms | **Critical** |
| 关节摩擦 | 0 Nm | 0.01-0.05 Nm | Medium |
| 地面摩擦 | 1.0 | 0.3-1.2 | **High** |
| 电机强度 | 100% | 85-95% | Medium |
| 传感器噪声 | 0 | IMU: ±2° | Medium |
| 连杆质量 | CAD 精确 | +5-10%（含线缆） | Medium |
| 柔性 | 刚体 | 谐波减速器柔性 | **High** |

**关键结论**：控制延迟和柔性是最难通过算法弥补的差距，硬件层面的选择直接决定 Sim2Real 的上限 [韬晦待时-2026, Jagger-2026]。

### 2.3 DR 的反模式

实战经验总结出四种常见的 DR 反模式 [vnrobo-DR-2026]：
1. **过度随机化**：随机化范围超出物理可能（如摩擦 [0.01, 10.0]），策略无法收敛
2. **参数独立随机化**：现实中重物通常摩擦大，独立随机化产生不存在的物理组合
3. **无课程学习**：一开始就全范围随机化，策略学不到任何有效行为
4. **只随机化视觉忽略动力学**：视觉 DR 容易实现，但动力学 DR 对控制策略影响更大

---

## 3. 奖励函数设计: 最关键的瓶颈

奖励函数设计被多个项目一致认为是 Sim2Real 迁移的最大瓶颈之一 [vnrobo-Reward-2026, rossiXYZ-SERL]。

### 3.1 12+ 奖励项标准框架

通过多篇实战文章的交叉验证，一个完整的人形行走奖励函数包含以下 12 个核心项 [vnrobo-Reward-2026]：

| 类别 | 奖励项 | 权重 | 说明 |
|------|-------|------|------|
| **速度跟踪** | linear_vel_tracking | 1.5 | 指数形式 `exp(-error²/σ²)` |
| **速度跟踪** | angular_vel_tracking | 0.8 | 跟踪偏航角速度 |
| **姿态** | upright | 0.5 | 躯干直立惩罚 |
| **姿态** | base_height | 0.3 | 保持目标高度（G1: 0.72m） |
| **步态** | foot_clearance | 0.3 | 摆腿相脚离地高度 |
| **步态** | contact_pattern | 0.4 | 双脚交替落地 |
| **步态** | foot_slip | -0.1 | 脚底滑移惩罚 |
| **平滑** | action_rate | -0.01 | 动作变化率惩罚 |
| **平滑** | torque | -5e-5 | 能耗惩罚 |
| **平滑** | joint_acceleration | -1e-4 | 关节加速度惩罚 |
| **安全** | termination | -200 | 摔倒数倍惩罚 |
| **安全** | joint_limit | -1.0 | 关节限位惩罚 |

### 3.2 奖励设计的最佳实践

**指数跟踪优于线性**：`exp(-error²/σ²)` 在目标附近产生平滑梯度，σ 控制跟踪严格度 [vnrobo-Reward-2026]。

**课程学习三阶段** [multiple sources]：
- Phase 1 (0-500 iter): 静止站立，只有 upright + alive + termination
- Phase 2 (500-1500): 慢速指令 (0.2 m/s)，逐渐增加 tracking 权重
- Phase 3 (1500+): 全速随机指令 [-1.0, 1.0] m/s

**消融实验的关键发现** [vnrobo-Reward-2026]：去掉 `linear_vel_tracking` 或 `upright` 会导致策略完全失败（Critical 级），去掉 `foot_clearance` 会导致机器人拖脚（High 级），而去掉 `feet_air_time` 仅影响步态自然度（Low 级）。

### 3.3 奖励函数调优的工程经验

- **从简开始**：最初只用 tracking + alive + termination，逐步添加其他项 [Humanoid-Gym]
- **归一化**：各奖励项的数值量级应接近，`termination = -200` 时不能让 `torque = -0.0001` 主导梯度
- **视频 > 曲线**：更关注行为视频而非奖励曲线，曲线平滑不等于行为正确 [vnrobo-Reward-2026]

---

## 4. 算法选型: On-Policy vs Off-Policy

### 4.1 PPO（主流通用方案）

PPO + Isaac Gym/Lab 是目前人形运动控制的主流方案 [legged_gym, Humanoid-Gym, unitree_rl_gym]。

**优势**：训练稳定、超参数少、并行化友好（4096 个环境同时训练）。
**劣势**：On-policy 样本效率低，需要数亿步仿真才能收敛，策略迁移到新环境往往需要重新训练。

典型配置 [legged_gym]: 策略网络 MLP [512, 256, 128]，Critic 同结构，学习率 3e-4，clip_param=0.2，训练 2-4 小时 / RTX 4090。

### 4.2 SAC + RLPD（样本高效部署方案）

SERL [rossiXYZ-SERL-2026] 的成功揭示了另一条路线：SAC（Off-policy）作为底座，结合 RLPD（Prior Data 混合采样）和 High UTD（每条数据 20 次更新），实现**真机 20 分钟收敛**。

**核心技术** [rossiXYZ-RLPD-2026]：
- **50/50 混合采样**：每个 Batch 强制 50% 来自演示数据 + 50% 来自在线采集数据
- **High UTD = 20**：每采集一条环境数据，做 20 次梯度更新
- **Layer Normalization**：控制 High UTD 带来的梯度爆炸
- **Pessimistic Backup**：`next_q = mean(Q) - ρ·std(Q)` 而非 `min(Q1, Q2)`

### 4.3 LIFT: 预训练 + 微调新范式

LIFT（ICLR 2026）[vnrobo-LIFT-2026] 提出了三阶段流水线，将真机数据需求压缩到 **80-590 秒**：

1. **MuJoCo Playground 预训练 SAC**：Large-batch + High UTD + 1024 并行 → ~1h/4090
2. **物理知识世界模型**：Lagrangian 动力学分支（硬编码物理方程 + 小残差网络），泛化性远超纯数据驱动模型
3. **微调**：真实环境确定性执行，世界模型内随机探索

这是目前数据效率最高的人形 RL 方案。

### 4.4 FastSAC/Holosoma: Off-Policy 训练的分钟级突破

Amazon FAR 的 Holosoma 框架 [Holosoma-2026] 将 Sim-to-Real 训练压缩到 **15 分钟**。其核心是 FastSAC——在标准 SAC 基础上针对大规模并行（single GPU 数千环境）做了稳定性优化。

**关键技术选择** [Holosoma-2026]：
- **Layer Normalization**：稳定大规模 off-policy 训练的关键，与 SERL 的 RLPD 一致
- **极简奖励设计（<10 项）**：与 Section 3 的 12+ 项主流框架形成对比——说明简洁也能有效
- **CDQ 禁用特定配置**：避免 critic 过估计
- **单 GPU 4090**：15 分钟，而 PPO 需要小时级

**趋势判断**：PPO → SAC/RLPD → FastSAC 代表了算法效率的持续进步。不同方案适用于不同场景：PPO（通用稳定）、SAC+RLPD（真机高效）、FastSAC（极速迭代）。

---

## 5. 部署工程: 从仿真到真机的关键细节

### 5.1 真机部署全流程清单

综合多个项目的部署经验 [HOVER, unitree_rl_gym, vnrobo-Sim2Real]，标准部署流程如下：

**预部署检查**：
- [ ] 系统辨识已完成（电机 Kp/Kd/摩擦/阻尼）
- [ ] DR 范围已覆盖辨识出的真实值
- [ ] 策略已通过 Sim2Sim 验证
- [ ] 安全层已在仿真中测试
- [ ] 急停硬件就位，软质地面铺设
- [ ] 推理速度已基准测试（<5ms for 50Hz）

**首次部署协议**：
1. 吊架悬挂，无地面接触 → 验证关节跟踪（正弦波指令）
2. 降至地面，零速度指令（仅站立）
3. 极慢速度指令（0.1 m/s 前进）
4. 20+ 分钟内逐步增加至目标速度
5. 测试推力恢复（轻柔推搡）
6. 平地上验证通过后才进入复杂地形

### 5.2 系统辨识

这是被多个项目强调但常被忽视的步骤。通过 chirp 信号（0.5→5.5 Hz）激励每个关节，采集力矩-位置-速度数据，拟合 PD 参数和摩擦模型 [vnrobo-Sim2Real-2026]。将辨识结果作为 DR 的**中心值**，而非使用 CAD 理想值，可减少 30-50% 的 Sim2Real 误差 [roboticscenter-2026]。

#### 系统辨识的主流方法

**基于 CMA-ES 的黑箱优化** [myleaf-2026]：当目标函数不可导、含接触、带延迟噪声时，CMA-ES 是自然选择。它不要求梯度，只要求能比较候选解优劣。协方差更新学的是"优胜样本相对旧均值的成功移动方向"，不会被局部极小值过早困住。PACE（ETH 2025）和 SPI（CMU 2025）均采用此策略。

**SPI 两阶段框架** [myleaf-2026]：Stage 1 用 motion priors + 预训练 RL policies 采真机轨迹，切成多段 clips 做多步预测辨识；Stage 2 将优化后的模型参数传给新 policy 训练。Cost 拆为三大块：Base Prediction Cost（整机全状态）、Joint Prediction Cost（关节位置/速度/力矩）、Parameter Regularization（约束不离 URDF 名义值太远）。

**UAN 残差补偿网络** [myleaf-2026]：MIT 的方法用残差网络补偿 PD 执行器行为差异——真机 rollout 后计算 q/dq 差值，UAN 输出残差扭矩作用到仿真扭矩上。部署时去掉 UAN，仅在仿真对齐阶段使用。

**CMA-ES 的共同选择理由**：PACE 和 SPI 独立选择了 CMA-ES 而非梯度方法，理由是"存在局部极小值但维度不高，GPU 并行仿真下既稳定又样本效率不错" [myleaf-2026]。这构成了一个值得关注的经验事实。

### 5.3 观测空间设计原则

**不使用视觉**：成功的 locomotion 策略只用本体感知（IMU + 关节编码器）[vnrobo-Bipedal-2026]。原因是本体感知频率可达 1kHz，而相机仅 30-60Hz，对平衡控制而言太慢。

**仅使用真机可获取的信号**：在训练时禁用 ground truth position、contact force 等只能在仿真中获取的信号 [Humanoid-Gym]。

**历史帧堆叠**：使用过去 5-10 帧的观测序列，让策略隐式估计速度和接触状态 [vnrobo-Sim2Real, rossiXYZ-SERL]。

### 5.4 安全层设计

真机部署必须有多层安全保护 [vnrobo-Sim2Real, unitree_sdk2]：

1. **跌落检测**：躯干高度 < 0.3m 或倾斜 > 60° → 激活阻尼模式
2. **关节限位夹持**：软限位（减速）+ 硬限位（截止）
3. **速度限幅**：每步关节位置变化不超过 `max_vel × dt`
4. **急停硬件**：物理急停按钮始终在操作员手边

---

## 6. 实用项目索引

### 6.1 可直接使用的开源框架

| 项目 | 描述 | 适合场景 |
|------|------|---------|
| [unitree_rl_gym](https://github.com/unitreerobotics/unitree_rl_gym) | Unitree 官方 Sim2Real 框架 | H1/G1 全流程部署 |
| [Humanoid-Gym](https://github.com/roboterax/humanoid-gym) | RobotEra 官方框架 | 标准人形训练 |
| [legged_gym](https://github.com/leggedrobotics/legged_gym) | ETH 足式 RL 框架 | 基础学习 |
| [IsaacLab](https://github.com/isaac-sim/IsaacLab) | NVIDIA 通用平台 | 高级研究与迁移 |
| [rl_sar](https://github.com/lovelyyoshino/rl_sar_comment) | 部署框架 | Sim2Sim → 真机 |
| [HOVER](https://github.com/NVlabs/HOVER) | NVIDIA 全身控制 | H1 动作跟踪 |
| [LIFT-humanoid](https://github.com/bigai-ai/LIFT-humanoid) | ICLR 2026 高数据效率 | 数据稀缺场景 |

### 6.2 必读实战文章索引

| 文章 | 类型 | 核心价值 |
|------|------|---------|
| 从视频到舞步 [jzssuanfa-2026] | 端到端流水线 | 最完整的中文 Mimic 部署实战 |
| SERL 五篇系列 [rossiXYZ-2026] | 源码级算法分析 | 最深入的真机 RL 框架剖析 |
| RL Humanoid 10篇系列 [vnrobo-2026] | 系统教程 | 最系统的端到端 RL 实战教程 |
| 人形机器人运动控制 Know-How [Jagger-2026] | 万字长文 | Sim2Real 瓶颈的工程洞见 |
| RL足式综述 [韬晦待时-2026] | 综述+点评 | 硬件决定上限的核心判断 |
| Sim2Real相关方法 [myleaf-2026] | 文献知识点笔记 | CMA-ES/SPI/UAN/PACE 四种系统辨识方法对比 |
| RL运控技术栈观察 [星穷碧落-2026] | 技术路线分析 | AMP/BFM/世界模型三条路线的分层判断 |
| Holosoma/FastSAC [Holosoma-2026] | 论文+开源框架 | 15 分钟 Sim2Real 训练，off-policy 最新进展 |
| 真机部署实录 [old_tree-2026] | 工程经验 | 硬件三坑（背隙/线束/散热）分类 |

---

## 7. 关键经验教训汇总

### 已形成共识的原则

1. **DR 参数范围高度一致**：摩擦 [0.1,1.5]、质量 ±15%、延迟 0-30ms，适用于绝大多数项目
2. **Sim2Sim 不可跳过**：在不同物理引擎间验证策略，是对硬件保险的基本尊重
3. **奖励从简开始**：12 项奖励中的大多数可以后续添加，先保证基础行走
4. **硬件决定上限**：电气设计、驱动延迟、机械柔性决定了最终迁移效果 [韬晦待时-2026, Jagger-2026]
5. **硬件三坑必须正视**：Backlash（背隙）、线束疲劳、散热漂移是 Sim2Real 部署中最常被忽视但影响最大的物理层问题 [old_tree-2026]
6. **系统辨识选 CMA-ES**：PACE 和 SPI 独立选择 CMA-ES 而非梯度方法，构成了值得关注的经验共识 [myleaf-2026]

### 仍在开放的挑战

1. **奖励函数设计仍是瓶颈**：reward 调参缺乏系统方法论，主要依赖经验和试错
2. **并联机构难以建模**：现有刚体模拟器对并联机构、软体机器人的建模精度不足
3. **zero-shot 迁移不稳定**：即使是成熟的框架（unitree_rl_gym），官方也将部署程序标注为 "not a stable control program"，仅供演示
4. **跨物理引擎迁移不确定性**：Sim2Sim 的 gap 有时比 Sim2Real 更大 [vnrobo-LIFT-2026]

---

## 参考文献

1. jzssuanfa. (2026). 从视频到舞步：详解基于AI的人形机器人运动模仿全栈技术. 博客园. https://www.cnblogs.com/jzssuanfa/p/19803401
2. rossiXYZ. (2026). SERL系列（全景篇/SAC/RLPD/工程篇）. 博客园. https://www.cnblogs.com/rossiXYZ/p/20711693
3. Nguyễn Anh Tuấn. (2026). RL Humanoid Series (10 parts). VnRobo. https://vnrobo.com/en/blog/
4. Nguyễn Anh Tuấn. (2026). Sim-to-Real for Humanoids: Deployment Best Practices. VnRobo. https://vnrobo.com/en/blog/rl-humanoid-10-sim2real
5. Nguyễn Anh Tuấn. (2026). Domain Randomization: The Key to Sim-to-Real Transfer. VnRobo. https://vnrobo.com/en/blog/sim-series-4-domain-randomization
6. Nguyễn Anh Tuấn. (2026). LIFT humanoid ICLR 2026. VnRobo. https://vnrobo.com/en/blog/lift-humanoid-iclr-2026-pretrain-finetune
7. Nguyễn Anh Tuấn. (2026). Reward Engineering for Bipedal Walking. VnRobo. https://vnrobo.com/en/blog/rl-humanoid-2-reward
8. 韬晦待时. (2026). RL做足式机器人运控的经典必读文章. 知乎. https://zhuanlan.zhihu.com/p/29806809248
9. Jagger. (2026). 人形机器人运动控制 Know-How. 知乎. https://zhuanlan.zhihu.com/p/1993986785630499920
10. Unitree Robotics. (2024). unitree_rl_gym. GitHub. https://github.com/unitreerobotics/unitree_rl_gym
11. NVIDIA Labs. (2024). HOVER. GitHub. https://github.com/NVlabs/HOVER
12. NVIDIA. (2025). WBC-AGILE. GitHub. https://github.com/nvidia-isaac/WBC-AGILE
13. ETH Zurich. (2022). legged_gym. GitHub. https://github.com/leggedrobotics/legged_gym
14. Jerry Huang. (2026). Sim-to-Real Transfer: A Practitioner's Guide. Robotics Center. https://al.roboticscenter.ai/blog/sim-to-real-tips-practitioners
15. Tobin et al. (2017). Domain Randomization for Transferring Deep Neural Networks from Simulation to the Real World. arXiv:1703.06907.
16. 星穷碧落人归尽. (2026). 人形机器人从实践到理论系列（第16篇-AMP）. 知乎. https://zhuanlan.zhihu.com/p/1982471173326528684
17. Jim Li. (2026). 机器人通用大模型基础(3)-Sim2Real. 知乎. https://zhuanlan.zhihu.com/p/1889609310222386585
18. myleaf. (2026). 机器人领域的Sim2Real相关方法. 博客园. https://www.cnblogs.com/myleaf/p/19722445
19. Amazon FAR. (2025). Holosoma: Learning Sim-to-Real Humanoid Locomotion in 15 Minutes. GitHub. https://github.com/amazon-far/holosoma
20. Younggyo Seo et al. (2025). Learning Sim-to-Real Humanoid Locomotion in 15 Minutes. arXiv.
21. old_tree. (2026). 人形机器人真机部署实录. CSDN. https://blog.csdn.net/old_tree/article/details/160819182

---

*综述完 | 基于网络调研的人类作者实战经验汇编*
